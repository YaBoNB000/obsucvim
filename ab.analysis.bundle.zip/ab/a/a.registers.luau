-- Static PC/register audit reference for a.txt; original VM/protection layer removed.
-- No original or recovered business code was executed during analysis.
-- Logical registers are zero-based. Original PCs, including local-only noise, are retained.
local P = {}

P[0] = function(ENV, UPVALUES, ...)
	local R = {}
	local pc = 1
	while true do
		if pc == 1 then
			-- R1 = ENV["print"]
			R[1] = ENV["print"]
			pc = 2
		elseif pc == 2 then
			-- R4 = R4
			R[4] = R[4]
			pc = 3
		elseif pc == 3 then
			-- NOOP (local-only noise)
			pc = 4
		elseif pc == 4 then
			-- R2 = "kkksu"
			R[2] = "kkksu"
			pc = 5
		elseif pc == 5 then
			-- NOOP (local-only noise)
			pc = 6
		elseif pc == 6 then
			-- CALL R1(R2); results -> R2 onward; requested 1
			do
				local results = table.pack(R[1](R[2]))
				for i = 1, math.max(1, results.n) do
					R[1 + i] = results[i]
				end
			end
			pc = 7
		elseif pc == 7 then
			-- R0 = R2
			R[0] = R[2]
			pc = 8
		elseif pc == 8 then
			-- return 
			return
		else
			error("Invalid recovered PC: " .. tostring(pc))
		end
	end
end

local ENV = (getfenv and getfenv()) or _G
return P[0](ENV, {})
