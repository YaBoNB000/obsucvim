-- b.txt 的可读业务恢复稿；变量名为重命名，不是原始源码逐字找回。
-- 不保留 VM、执行器绑定和反调试；分析时未执行业务。
local function fibonacci(n)
	if n < 2 then
		return n
	end
	return fibonacci(n - 1) + fibonacci(n - 2)
end

local values = {}
local total = 0
for i = 1, 10 do
	local value = fibonacci(i)
	values[#values + 1] = value
	total = total + value
end

print("kkksu-mid:" .. table.concat(values, ",") .. "|" .. total)
