-- Static PC/register audit reference for b.txt; original VM/protection layer removed.
-- No original or recovered business code was executed during analysis.
-- Logical registers are zero-based. Original PCs, including local-only noise, are retained.
local P = {}

P[0] = function(ENV, UPVALUES, ...)
	local R = {}
	local arguments = table.pack(...)
	R[0] = arguments[1]
	local pc = 1
	while true do
		if pc == 1 then
			-- R2 = R0; R3 = 2
			R[2] = R[0]
			R[3] = 2
			pc = 2
		elseif pc == 2 then
			-- NOOP (local-only noise)
			pc = 3
		elseif pc == 3 then
			-- R1 = R2 < R3
			R[1] = R[2] < R[3]
			pc = 4
		elseif pc == 4 then
			-- if not R1 then pc = 9
			pc = not R[1] and 9 or 5
		elseif pc == 5 then
			-- R4 = R0
			R[4] = R[0]
			pc = 6
		elseif pc == 6 then
			-- return R4
			return R[4]
		elseif pc == 7 then
			-- pc = 9
			pc = 9
		elseif pc == 8 then
			-- NOOP (local-only noise)
			pc = 9
		elseif pc == 9 then
			-- R8 = UPVALUE[0]
			R[8] = UPVALUES[1]()
			pc = 10
		elseif pc == 10 then
			-- R17 = 26; R10 = R0
			R[17] = 26
			R[10] = R[0]
			pc = 11
		elseif pc == 11 then
			-- R11 = 1
			R[11] = 1
			pc = 12
		elseif pc == 12 then
			-- R9 = R10 - R11
			R[9] = R[10] - R[11]
			pc = 13
		elseif pc == 13 then
			-- CALL R8(R9); results -> R9 onward; requested 1
			do
				local results = table.pack(R[8](R[9]))
				for i = 1, math.max(1, results.n) do
					R[8 + i] = results[i]
				end
			end
			pc = 14
		elseif pc == 14 then
			-- R6 = R9
			R[6] = R[9]
			pc = 15
		elseif pc == 15 then
			-- R12 = UPVALUE[0]; R14 = R0
			R[12] = UPVALUES[1]()
			R[14] = R[0]
			pc = 16
		elseif pc == 16 then
			-- R15 = 2
			R[15] = 2
			pc = 17
		elseif pc == 17 then
			-- R13 = R14 - R15
			R[13] = R[14] - R[15]
			pc = 18
		elseif pc == 18 then
			-- CALL R12(R13); results -> R13 onward; requested 1
			do
				local results = table.pack(R[12](R[13]))
				for i = 1, math.max(1, results.n) do
					R[12 + i] = results[i]
				end
			end
			pc = 19
		elseif pc == 19 then
			-- R7 = R13
			R[7] = R[13]
			pc = 20
		elseif pc == 20 then
			-- R5 = R6 + R7
			R[5] = R[6] + R[7]
			pc = 21
		elseif pc == 21 then
			-- return R5
			return R[5]
		else
			error("Invalid recovered PC: " .. tostring(pc))
		end
	end
end

P[1] = function(ENV, UPVALUES, ...)
	local R = {}
	local pc = 1
	while true do
		if pc == 1 then
			-- R0 = CLOSURE(proto0)
			do
				local cells = {}
				cells[1] = function() return R[0] end
				R[0] = function(...) return P[0](ENV, cells, ...) end
			end
			pc = 2
		elseif pc == 2 then
			-- R1 = {}
			R[1] = {}
			pc = 3
		elseif pc == 3 then
			-- R3 = 0
			R[3] = 0
			pc = 4
		elseif pc == 4 then
			-- R2 = 0
			R[2] = 0
			pc = 5
		elseif pc == 5 then
			-- R6 = 1
			R[6] = 1
			pc = 6
		elseif pc == 6 then
			-- R4 = 10
			R[4] = 10
			pc = 7
		elseif pc == 7 then
			-- NOOP (local-only noise)
			pc = 8
		elseif pc == 8 then
			-- R5 = 1
			R[5] = 1
			pc = 9
		elseif pc == 9 then
			-- NOOP (local-only noise)
			pc = 10
		elseif pc == 10 then
			-- R7 = 0
			R[7] = 0
			pc = 11
		elseif pc == 11 then
			-- R8 = R5 >= R7
			R[8] = R[5] >= R[7]
			pc = 12
		elseif pc == 12 then
			-- R9 = R6 > R4
			R[9] = R[6] > R[4]
			pc = 13
		elseif pc == 13 then
			-- R10 = R8; R44 = R44
			R[10] = R[8]
			R[44] = R[44]
			pc = 14
		elseif pc == 14 then
			-- if not R10 then pc = 16
			pc = not R[10] and 16 or 15
		elseif pc == 15 then
			-- R10 = R9
			R[10] = R[9]
			pc = 16
		elseif pc == 16 then
			-- R11 = R5 < R7
			R[11] = R[5] < R[7]
			pc = 17
		elseif pc == 17 then
			-- R12 = R6 < R4
			R[12] = R[6] < R[4]
			pc = 18
		elseif pc == 18 then
			-- R13 = R11
			R[13] = R[11]
			pc = 19
		elseif pc == 19 then
			-- if not R13 then pc = 21
			pc = not R[13] and 21 or 20
		elseif pc == 20 then
			-- R13 = R12
			R[13] = R[12]
			pc = 21
		elseif pc == 21 then
			-- R14 = R10
			R[14] = R[10]
			pc = 22
		elseif pc == 22 then
			-- if R14 then pc = 25
			pc = R[14] and 25 or 23
		elseif pc == 23 then
			-- NOOP (local-only noise)
			pc = 24
		elseif pc == 24 then
			-- R14 = R13
			R[14] = R[13]
			pc = 25
		elseif pc == 25 then
			-- if R14 then pc = 41
			pc = R[14] and 41 or 26
		elseif pc == 26 then
			-- R15 = R6; R17 = R0
			R[15] = R[6]
			R[17] = R[0]
			pc = 27
		elseif pc == 27 then
			-- R18 = R15
			R[18] = R[15]
			pc = 28
		elseif pc == 28 then
			-- CALL R17(R18); results -> R18 onward; requested 1
			do
				local results = table.pack(R[17](R[18]))
				for i = 1, math.max(1, results.n) do
					R[17 + i] = results[i]
				end
			end
			pc = 29
		elseif pc == 29 then
			-- R16 = R18; R19 = R1
			R[16] = R[18]
			R[19] = R[1]
			pc = 30
		elseif pc == 30 then
			-- R23 = R1
			R[23] = R[1]
			pc = 31
		elseif pc == 31 then
			-- R21 = #R23
			R[21] = #R[23]
			pc = 32
		elseif pc == 32 then
			-- R22 = 1
			R[22] = 1
			pc = 33
		elseif pc == 33 then
			-- R20 = R21 + R22
			R[20] = R[21] + R[22]
			pc = 34
		elseif pc == 34 then
			-- R24 = R16
			R[24] = R[16]
			pc = 35
		elseif pc == 35 then
			-- R19[R20] = R24
			R[19][R[20]] = R[24]
			pc = 36
		elseif pc == 36 then
			-- R26 = R2; R27 = R16
			R[26] = R[2]
			R[27] = R[16]
			pc = 37
		elseif pc == 37 then
			-- R25 = R26 + R27
			R[25] = R[26] + R[27]
			pc = 38
		elseif pc == 38 then
			-- R2 = R25
			R[2] = R[25]
			pc = 39
		elseif pc == 39 then
			-- R6 = R6 + R5
			R[6] = R[6] + R[5]
			pc = 40
		elseif pc == 40 then
			-- pc = 10
			pc = 10
		elseif pc == 41 then
			-- R29 = ENV["print"]
			R[29] = ENV["print"]
			pc = 42
		elseif pc == 42 then
			-- R31 = "kkksu-mid:"
			R[31] = "kkksu-mid:"
			pc = 43
		elseif pc == 43 then
			-- R38 = ENV["table"]
			R[38] = ENV["table"]
			pc = 44
		elseif pc == 44 then
			-- R39 = "concat"
			R[39] = "concat"
			pc = 45
		elseif pc == 45 then
			-- R35 = R38[R39]
			R[35] = R[38][R[39]]
			pc = 46
		elseif pc == 46 then
			-- R36 = R1
			R[36] = R[1]
			pc = 47
		elseif pc == 47 then
			-- R37 = ","
			R[37] = ","
			pc = 48
		elseif pc == 48 then
			-- CALL R35(R36, R37); results -> R36 onward; requested 1
			do
				local results = table.pack(R[35](R[36], R[37]))
				for i = 1, math.max(1, results.n) do
					R[35 + i] = results[i]
				end
			end
			pc = 49
		elseif pc == 49 then
			-- R33 = R36
			R[33] = R[36]
			pc = 50
		elseif pc == 50 then
			-- R40 = "|"
			R[40] = "|"
			pc = 51
		elseif pc == 51 then
			-- R41 = R2
			R[41] = R[2]
			pc = 52
		elseif pc == 52 then
			-- R34 = R40 .. R41
			R[34] = R[40] .. R[41]
			pc = 53
		elseif pc == 53 then
			-- R32 = R33 .. R34
			R[32] = R[33] .. R[34]
			pc = 54
		elseif pc == 54 then
			-- R30 = R31 .. R32
			R[30] = R[31] .. R[32]
			pc = 55
		elseif pc == 55 then
			-- CALL R29(R30); results -> R30 onward; requested 1
			do
				local results = table.pack(R[29](R[30]))
				for i = 1, math.max(1, results.n) do
					R[29 + i] = results[i]
				end
			end
			pc = 56
		elseif pc == 56 then
			-- R28 = R30
			R[28] = R[30]
			pc = 57
		elseif pc == 57 then
			-- return 
			return
		else
			error("Invalid recovered PC: " .. tostring(pc))
		end
	end
end

local ENV = (getfenv and getfenv()) or _G
return P[1](ENV, {})
