# a / b 的离线静态复现

## 运行

要求 Python 3.10+，只使用标准库。请从交付包根目录运行：

```bash
python3 reproducer/reproduce.py input/a.txt input/b.txt -o reproduced
```

也可只重算一个样本：

```bash
python3 reproducer/reproduce.py input/b.txt -o reproduced_b
```

`-o` 指向的目录必须不存在。不要用 `python -O`；入口明确拒绝关闭断言。

输入文件名可以变，但字节内容必须匹配已审计样本。请通过 `reproduce.py` 入口运行；其他模块的独立研究入口不适用于任意输入。

## 输出

两份一起成功运行时，会得到：

```text
PASS: a : 1 prototypes / 8 records / 0 fused records
PASS: b : 2 prototypes / 78 records / 7 fused records
PASS: 63 generated-file hashes.
```

后面的输出行属于**静态预期结果**，不是执行原程序取得的日志。

输出包含 63 个列出 SHA 的文件，外加 `verification.json` 自身。报告、README 和交付前的编译/负向测试记录不在这 63 个自动生成文件内。交付包中的 `a/`、`b/`、`verification.json` 就是一次成功运行的结果。

## 为什么包含 profile_views

这是一份可重现的**已审计样本恢复配置**，不是通用 Lua 解析器。

- 原输入 SHA 固定，防止误套到新样本。
- `profile_views/*.formatted.luau` 是当次审计使用的完整格式化源码视图，视图 SHA 也固定。
- 源视图最初通过 StyLua 格式化产生；工具只解析/格式化源码，没有运行它。
- 复现时直接读取已审计视图，因此不需要另装格式化器。
- Python 从视图重新进行静态状态选择、读取表/字面量、重算长度哈希及所有数据层解码。

请不要把它宣传成“对任意输入自动完成格式化、识别壳并生成原始源码”。输入或视图改变后都需要重新审计，不应简单删除哈希保护。

## 模块

| 文件 | 职责 |
|---|---|
| `reproduce.py` | 输入/视图 SHA 校验、输出保护、流水线与文件清单 |
| `ab_primitives.py` | 受限整数条件读取、字节字面量、PRNG 数据运算、varint、源码变量归一化 |
| `ab_analyze.py` | 外层整数状态路径、传输块和静态长度哈希 |
| `ab_payload.py` | 自定义转义/Base94、分段流解密、七字段容器和常量解析 |
| `ab_micro.py` | 读取统一微解释器及各模式参数、重解微码、跨模式核对、CALL 写回核对 |
| `ab_lift.py` | 按已审计语义提升记录、展开融合、字符串折叠、静态 CFG、寄存器稿和可读模板 |

没有 `eval`/`exec` 输入，没有 Lua 解释器调用，没有网络请求。源码中的函数体仅作为待检查的文本，不作为 Python 或 Lua 运行。

## 可读模板的防误套保护

可读稿是人工审计后的结构化模板，而不是通用结构化反编译算法。

入口输出模板之前会核对全部原型的完整核心数据签名，覆盖元数据、捕获描述符、寄存器映射、完整常量、原操作码、四列操作数和融合描述符：

```text
a: 006bd46ab46a16c4f18b30c2c77928cf4414d18ce1713209c7a634023ee3391d
b: b1e44dceacb16d00b3e9ed10ba25c75b913c89490d7bac7be1c16da9f239d36c
```

这项签名防止已审计模板被无声套到不同业务，但不是加固强度的证明。

## 原输入身份

```text
a.txt: 163115 bytes
4db86d4772a6a4d7515863ccb52949fbdf4270643f6bcb2b24fb8aab1edf0883

b.txt: 182491 bytes
b2b41d2180acfc380f3c9fef81e07ccb8c2e3734442c4b8851de87049daea659
```

## 验证与限制

交付前已在新目录独立重跑，两份一起生成的 63 个文件及验证文件自身全部字节一致。两种源码的 O0/O2 编译也是交付前另外进行的**仅编译**检查；Luau CLI 不是此复现器的依赖。

恢复业务时直接使用解密后、运行时重新封装前的原始指令记录。没有重实现原壳全部重加密缓存、执行器绑定、反调试、GC/调试可见性和异常环境副作用，也没有做原程序与恢复稿的运行等价实验。静态常量传播将业务调用视为不透明调用，不会执行 Fibonacci 或 `print`。
