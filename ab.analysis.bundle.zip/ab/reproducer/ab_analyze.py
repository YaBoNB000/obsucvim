"""Static transport and source simplification for the a/b Obsucvim samples.
Never runs Lua or its VM. Temporary research driver; audited stages are Python data operations.
"""
from pathlib import Path
import re,json,sys
import ab_primitives as u
ROOT=Path(__file__).resolve().parents[1]
CONFIG={
'a':dict(dispatch='dS',statevar='k',initial=3,final=236,vm='[29]',arrays=[68,79],base=[7,16],stride=[43,120],seed=32,salt=53,prng=[(35,14,27,39),(14,32,4,21),(5,2,12,7)],checksum=[(24,26)],hash_arg='h',blocks=[('iE',1,79,[(33,1,20)]),('nD',21,79,[(33,21,40)]),('aV',41,79,[(33,41,60)]),('gW',61,79,[(33,61,80)]),('Me',81,79,[(33,81,90),(71,1,10)])]),
'b':dict(dispatch='_r',statevar='za',initial=4,final=236,vm='[117]',arrays=[2,104],base=[31,121],stride=[23,48],seed=124,salt=57,prng=[(17,17,31,48),(18,20,20,13),(36,12,6,3)],checksum=[(12,32),(24,47)],hash_arg='c',blocks=[('X',1,93,[(118,1,24)]),('km',25,93,[(118,25,48)]),('Kf',49,93,[(118,49,72)]),('tm',73,92,[(118,73,90),(78,1,5)]),('oB',96,92,[(78,6,28)]),('dV',119,229,[(78,29,86)]),('BD',177,228,[(78,87,90),(12,1,53)]),('yK',234,228,[(12,54,90),(62,1,20)]),('mB',291,228,[(62,21,77)]),('Ed',348,228,[(62,78,90),(58,1,44)])])}

def trace_outer(F,cfg):
 S=F[cfg['dispatch']]
 def select(H):
  stack={};found=[]
  for line in S.splitlines():
   indent=len(line)-len(line.lstrip('\t'));t=line.strip();stack={k:v for k,v in stack.items() if k<=indent}
   parent=all(v[1] for k,v in stack.items() if k<indent)
   if t.startswith('if ') and t.endswith(' then'):
    expr=re.sub(r'\b'+cfg['statevar']+r'\b','H',t[3:-5]);truth=u.integer_condition(expr,H) if parent else False;stack[indent]=(parent,truth)
   elif t=='else':
    p,previous=stack[indent];stack[indent]=(p,not previous if p else False)
   elif t=='end':stack.pop(indent,None)
   elif parent:
    z=re.search(r'^'+cfg['statevar']+r',.*= \w+(?::(\w+)\(|\[(\d+)\]\()',t)
    if z:found.append(z[1] or '['+z[2]+']')
  assert len(found)==1,(H,found)
  return found[0]
 H=cfg['initial'];trace=[];seen=set()
 while H<cfg['final']:
  assert H not in seen and len(seen)<300;seen.add(H);name=select(H)
  ret=re.findall(r'^\t\treturn (\d+),',F[name],re.M);assert ret,(H,name)
  nextH=int(ret[-1]);trace.append({'state':H,'handler':name,'next_state':nextH});H=nextH
 assert H==cfg['final'],H
 return trace

def outer(P,F,cfg):
 num=lambda k:u.arithmetic(F['['+str(k)+']']);A,B=[list(map(int,re.findall(r'\d+',F['['+str(k)+']']))) for k in cfg['arrays']]
 get=lambda pair:A[pair[0]-1]+B[pair[1]-1]
 state=(num(cfg['seed'])+num(cfg['salt']))%u.MOD28
 base=sum(map(num,cfg['base']))%u.MOD32;stride=(num(cfg['stride'][0])-num(cfg['stride'][1]))%u.MOD32
 schedule=[(get(t[:2]),get(t[2:])) for t in cfg['prng']]
 blobs={}
 for _,_,_,ranges in cfg['blocks']:
  for k,_,_ in ranges:
   m=re.fullmatch(r'\[(=*)\[(.*?)\]\1\]',F['['+str(k)+']'],re.S);assert m,k;blobs[k]=m[2].encode('ascii')
 trace=trace_outer(F,cfg);assert [t['handler'] for t in trace if t['handler'] in [x[0] for x in cfg['blocks']]]==[x[0] for x in cfg['blocks']]
 parts=[];blocks=[]
 for name,word,size,ranges in cfg['blocks']:
  for mul,add in schedule:
   assert state*mul+add<2**53;state=(state*mul+add)%u.MOD28
  mask=u.fold_bytes(state);out=bytearray();start=word
  for key,first,last in ranges:
   for group in range(first,last+1):
    x=0
    for c in blobs[key][5*(group-1):5*group]:x=x*94+c-33
    x=(x-(base+word*stride)%u.MOD32)%u.MOD32;word+=1
    for b in x.to_bytes(4,'little'):out.append(b^((mask+len(out)+1)%256))
  part=bytes(out[:size]);parts.append(part);blocks.append({'handler':name,'word_start':start,'word_end':word-1,'size':size,'state':state,'mask':mask,'ranges':ranges,'sha256':u.sha256(part)})
 encoded=[b''.join(parts[i:i+5]) for i in range(0,len(parts),5)]
 check=0
 for data in encoded:check=(check*31+sum(data))%u.MOD32
 expected=0
 for pair in cfg['checksum']:expected=(expected*31+get(pair))%u.MOD32
 assert check==expected,(check,expected)
 for i,x in enumerate(encoded):(P/f'outer_{i}.base94').write_bytes(x)
 u.save_json(P/'outer_evidence.json',{'encoded_lengths':list(map(len,encoded)),'encoded_sums':list(map(sum,encoded)),'checksum':check,'base':base,'stride':stride,'schedule':schedule,'blocks':blocks,'state_trace':trace})
 print(P.name,'OUTER',list(map(len,encoded)),'checksum',check,'trace',len(trace))
 return encoded

HP=re.compile(r'\(function\((\w+)\)local(\w+)=\((\d+)\+(0|#\w+)\)%268435456for(\w+)=1,#\1do\2=\(\2\*(\d+)\+#\1\[\5\]\+\5\*(\d+)\+(\d+)\)%268435456endreturn\((\d+)\+\2\)%268435456end\)\((\w+)\)')
def fold(P,S,encoded,cfg):
 compact=re.sub(r'\s+','',S);records=[]
 # Statically known literal array lengths. The nearest prior literal definition is checked individually.
 for m in HP.finditer(compact):
  if m[10]!=cfg['hash_arg']:continue
  extra=0
  if m[4]!='0':
   name=m[4][1:];matches=list(re.finditer(r'local'+re.escape(name)+r'=\{([\d,+\-]+)\}',compact[:m.start()]))
   if not matches:print('UNFOLDED EXTRA',m[4]);continue
   text=matches[-1][1];extra=len([x for x in text.split(',') if x]);assert extra in [60,86,94],(name,extra)
  params=tuple(int(m[k]) for k in [3,6,7,8,9]);value=u.length_hash(list(map(len,encoded)),params,extra)
  records.append({'compact_expression':m[0],'value':value,'extra':extra,'parameters':params})
 for r in records:
  pattern=r'\s*'.join(re.escape(c) for c in r['compact_expression']);S,n=re.subn(pattern,str(r['value']),S);assert n>=1
 u.save_json(P/'length_hashes.json',records);(P/'constants_readable.luau').write_text(S)
 print('FOLDED',len(records),'extra',[r['extra'] for r in records if r['extra']])
 return S

if __name__=='__main__':
 for name in sys.argv[1:] or ['a','b']:
  P=ROOT/('work/ab_'+name);F=json.loads((P/'top_fields.json').read_text());cfg=CONFIG[name]
  encoded=outer(P,F,cfg);fold(P,(P/'formatted.luau').read_text(),encoded,cfg)
