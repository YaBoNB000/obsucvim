"""Audited static semantic lifting for the pinned a/b samples. Does not run their VM/business."""
from ab_analyze import ROOT,u
import re,json,sys,math,csv,collections
NAMES=['CALL_APPEND','POW','NOT','GE','ADD','IDIV','SUB','JF','LOADK','RETURN','CALL','NEG','SHORTSTR','GETTABLE','VARARGTABLE','NE','MOD','APPEND','LT','SETGLOBAL','CONCAT','VARARG_COUNT','NEWTABLE','SETUPVAL','LEN','JMP','EQ','APPEND_VARARGS','MUL','CLOSURE','LE','GT','GETUPVAL','STRING','SETTABLE','CALL_EXTRA','NOOP','GETGLOBAL','NIL','CALL_EXPANDED','DIV','MOVE','JT','NOOP']
GUARDS={'a':[[3,5]],'b':[[2,8],[7,9,23]]}
EXPECTED_SUMS={'a':[[110571,1367981]],'b':[[48291,1687825],[817714,105002164]]}
TOP=object()
def lit(v):
 if v is None:return 'nil'
 if v is True:return 'true'
 if v is False:return 'false'
 if isinstance(v,str):return json.dumps(v,ensure_ascii=False)
 return str(v)
def strdecode(value,seed,delta):
 out=[];steps=[]
 for i,c in enumerate(value.encode('latin1'),1):
  seed=(seed*257+delta+i)%65521;b=(c-seed%256)%256;out.append(b);steps.append({'i':i,'cipher_byte':c,'state':seed,'decoded_byte':b})
 return bytes(out).decode('latin1'),steps

def subops(p,row,proof):
 op=row['opcode'];args=row['operands']
 if op<=43:return [{'opcode':op,'name':NAMES[op],'operands':args}]
 assert op in range(172,176) or op in range(236,240),op
 slot=op-(172 if op<236 else 236);bias=(p['constant_seed']*48901+52612)%65536
 packed=(p['capsule_blob'][slot]-bias)%65536;low,high=packed%256,packed//256
 for leaf in [low,high]:
  assert leaf in [176,177,178,179,240,241,242,243],leaf
  rec=proof['handlers'][str(leaf)];assert len(rec['micro_programs'][0]['instructions'])==1
 A,B,C,D=args
 basic={176:8,177:41,178:38,179:32,240:8,241:41,242:38,243:32}
 record={'prototype':p['id'],'pc':row['pc'],'opcode':op,'descriptor_index':slot+1,'masked_word':p['capsule_blob'][slot],'mask':bias,'packed_word':packed,'leaf_handlers':[low,high],'operand_routing':[args,[C,D,C,D]]}
 proof.setdefault('fusion_expansions',[]).append(record)
 return [{'opcode':basic[low],'name':NAMES[basic[low]],'operands':args,'leaf':low},{'opcode':basic[high],'name':NAMES[basic[high]],'operands':[C,D,C,D],'leaf':high}]

def lift_data(P,name):
 protos=json.loads((P/'prototypes.normalized.json').read_text());proof=json.loads((P/'micro.audit.json').read_text());strings=[];guards=[];fusion={'handlers':proof['handlers']}
 for p in protos:
  assert [p['operand_sum'],p['operand_weighted_sum']]==EXPECTED_SUMS[name][p['id']]
  tail=bytes.fromhex(p['trailing_bytes_hex'])
  if tail:
   r=u.Reader(tail);assert r.byte()==106;r.raw(r.var());assert r.p==len(tail)
  inv={v-1:i for i,v in enumerate(p['register_map'])}
  assert len(inv)==p['maxstack']
  p['fused_descriptor_mask']=(p['constant_seed']*48901+52612)%65536
  p['fused_descriptors']=[{'word':(v-p['fused_descriptor_mask'])%65536,'leaf_handlers':[(v-p['fused_descriptor_mask'])%256,((v-p['fused_descriptor_mask'])%65536)//256]} for v in p['capsule_blob']]
  for row in p['instructions']:
   if row['pc'] in GUARDS[name][p['id']]:
    pc=row['pc'];test=(p['columns_raw'][0][pc-1]+p['columns_raw'][2][pc-1]+pc)%2==0
    guards.append({'prototype':p['id'],'pc':pc,'condition_even':test,'old_opcode':row['opcode'],'new_opcode':43 if test else row['opcode'],'business_effect':'both 36/43 are local-only noise'})
    if test:assert row['opcode']==36;row['opcode']=43
   steps=subops(p,row,fusion);row['steps']=steps
   for q in steps:
    A,B,C,D=q['operands'];op=q['opcode'];q['registers']=[inv.get(v) for v in [A,B,C,D]]
    if op in [8,37,33]:assert 0<=B<len(p['constants'])
    if op==33:
     cipher=p['constants'][B]['value'];value,detail=strdecode(cipher,C,D);q['decoded_string']=value;strings.append({'prototype':p['id'],'pc':row['pc'],'constant_index_zero_based':B,'seed':C,'delta':D,'cipher_hex':cipher.encode('latin1').hex(),'plaintext':value,'steps':detail})
    q['text']=describe(q,p)
 u.save_json(P/'prototypes.lifted.json',protos);u.save_json(P/'strings.proof.json',strings);u.save_json(P/'opcode_tamper.proof.json',guards)
 u.save_json(P/'fusion.proof.json',{'method':'read masked 16-bit per-prototype descriptors and leaf microprograms; no handler execution','expansions':fusion.get('fusion_expansions',[]),'descriptors':[{'prototype':p['id'],'mask':p['fused_descriptor_mask'],'descriptors':p['fused_descriptors']} for p in protos]})
 with (P/'instructions.csv').open('w',encoding='utf-8',newline='') as f:
  w=csv.writer(f,lineterminator='\n');w.writerow(['prototype','pc','raw_opcode','effective_opcode','step','name','A','B','C','D','lifted'])
  for p in protos:
   for row in p['instructions']:
    for j,q in enumerate(row['steps'],1):w.writerow([p['id'],row['pc'],row['raw_opcode'],row['opcode'],j,q['name'],*q['operands'],q['text']])
 for p in protos:
  print(name,'PROTO',p['id'])
  for row in p['instructions']:print(f"{row['pc']:03d}",'; '.join(q['text'] for q in row['steps']))
 return protos

def describe(q,p):
 A,B,C,D=q['operands'];op=q['opcode'];x=q['registers'];r=lambda j:'R'+str(x[j]);K=p['constants']
 if op in [36,43]:return 'NOOP (local-only noise)'
 if op==8:return r(0)+' = '+lit(K[B]['value'])
 if op==33:return r(0)+' = '+lit(q['decoded_string'])
 if op==37:return r(0)+' = ENV['+lit(K[B]['value'])+']'
 if op==41:return r(0)+' = '+r(1)
 if op==22:return r(0)+' = {}'
 if op in [4,6,18,3,31,20]:
  sym={4:'+',6:'-',18:'<',3:'>=',31:'>',20:'..'}[op];return r(0)+' = '+r(1)+' '+sym+' '+r(2)
 if op==13:return r(0)+' = '+r(1)+'['+r(2)+']'
 if op==24:return r(0)+' = #'+r(1)
 if op==34:return r(0)+'['+r(1)+'] = '+r(2)
 if op in [7,42]:return ('if not ' if op==7 else 'if ')+r(0)+' then pc = '+str(B)
 if op==25:return 'pc = '+str(B)
 if op==32:return r(0)+' = UPVALUE['+str(B)+']'
 if op==29:return r(0)+' = CLOSURE(proto'+str(B)+')'
 if op==38:return 'R'+str(A)+'..R'+str(A+B-1)+' = nil'
 if op==10:return 'CALL R'+str(A)+'('+', '.join('R'+str(A+i) for i in range(1,B+1))+'); results -> R'+str(A+1)+' onward; requested '+str(C)
 if op==9:return 'return '+', '.join('R'+str(A+i) for i in range(B))
 raise ValueError(('Unsupported used opcode',op))

def equal(a,b):
 if a is TOP or b is TOP:return a is b
 return type(a) is type(b) and a==b

def cfg_proof(P,protos):
 proofs=[]
 for p in protos:
  n=p['maxstack'];start=[None]*n
  for i in range(p['numparams']):start[i]=TOP
  states={1:tuple(start)};todo=collections.deque([1]);edges=set()
  while todo:
   pc=todo.popleft();r=list(states[pc]);row=p['instructions'][pc-1];destinations=None
   for q in row['steps']:
    A,B,C,D=q['operands'];a,b,c,d=q['registers'];op=q['opcode']
    if op in [36,43]:pass
    elif op==8:r[a]=p['constants'][B]['value']
    elif op==33:r[a]=q['decoded_string']
    elif op==37:r[a]=('global',p['constants'][B]['value'])
    elif op==41:r[a]=r[b]
    elif op==22:r[a]=('table',p['id'],pc)
    elif op==29:r[a]=('closure',B)
    elif op in [4,6,18,3,31,20]:
     v,w=r[b],r[c]
     if v is TOP or w is TOP:r[a]=TOP
     else:
      try:
       r[a]={4:lambda:v+w,6:lambda:v-w,18:lambda:v<w,3:lambda:v>=w,31:lambda:v>w,20:lambda:str(v)+str(w)}[op]()
      except (TypeError,ValueError):r[a]=TOP
    elif op in [13,24,32]:r[a]=TOP
    elif op==34:pass # abstract table contents are opaque
    elif op==38:
     for k in range(A,A+B):r[k]=None
    elif op==10:
     # No VM/business execution: the call and its possible returned values stay opaque.
     for k in range(A+1,n):r[k]=TOP
    elif op==25:destinations=[B]
    elif op in [7,42]:
     if r[a] is TOP:destinations=[pc+1,B]
     else:
      truth=r[a] is not None and r[a] is not False;take=not truth if op==7 else truth;destinations=[B if take else pc+1]
    elif op==9:destinations=[]
    else:raise ValueError(op)
   if destinations is None:destinations=[pc+1]
   for nxt in destinations:
    assert 1<=nxt<=p['instruction_count'],(p['id'],pc,nxt)
    edges.add((pc,nxt));new=tuple(r)
    if nxt in states:new=tuple(a if equal(a,b) else TOP for a,b in zip(states[nxt],new))
    if nxt not in states or any(not equal(a,b) for a,b in zip(states[nxt],new)):
     states[nxt]=new;todo.append(nxt)
  result={'prototype':p['id'],'method':'finite-lattice constant propagation; calls and table contents remain opaque','reachable_pcs':sorted(states),'unreachable_pcs':sorted(set(range(1,p['instruction_count']+1))-states.keys()),'edges':[list(e) for e in sorted(edges)]};proofs.append(result)
 u.save_json(P/'cfg.proof.json',proofs);return proofs

def register_source(name,protos):
 lines=['-- Static PC/register audit reference for '+name+'.txt; original VM/protection layer removed.','-- No original or recovered business code was executed during analysis.','-- Logical registers are zero-based. Original PCs, including local-only noise, are retained.','local P = {}','']
 for p in protos:
  lines+=['P['+str(p['id'])+'] = function(ENV, UPVALUES, ...)', '\tlocal R = {}']
  if p['numparams']:
   lines+=['\tlocal arguments = table.pack(...)']+['\tR['+str(k)+'] = arguments['+str(k+1)+']' for k in range(p['numparams'])]
  lines+=['\tlocal pc = 1','\twhile true do']
  for row in p['instructions']:
   pc=row['pc'];lines+=['\t\t'+('if' if pc==1 else 'elseif')+' pc == '+str(pc)+' then','\t\t\t-- '+('; '.join(q['text'] for q in row['steps']))]
   terminal=False
   for q in row['steps']:
    A,B,C,D=q['operands'];a,b,c,d=q['registers'];op=q['opcode'];rr=lambda k:'R['+str(k)+']';code=[]
    if op in [36,43]:pass
    elif op==8:code=[rr(a)+' = '+lit(p['constants'][B]['value'])]
    elif op==33:code=[rr(a)+' = '+lit(q['decoded_string'])]
    elif op==37:code=[rr(a)+' = ENV['+lit(p['constants'][B]['value'])+']']
    elif op==41:code=[rr(a)+' = '+rr(b)]
    elif op==22:code=[rr(a)+' = {}']
    elif op in [4,6,18,3,31,20]:code=[rr(a)+' = '+rr(b)+' '+{4:'+',6:'-',18:'<',3:'>=',31:'>',20:'..'}[op]+' '+rr(c)]
    elif op==13:code=[rr(a)+' = '+rr(b)+'['+rr(c)+']']
    elif op==24:code=[rr(a)+' = #'+rr(b)]
    elif op==34:code=[rr(a)+'['+rr(b)+'] = '+rr(c)]
    elif op==32:code=[rr(a)+' = UPVALUES['+str(B+1)+']()']
    elif op==29:
     target=protos[B];assert all(0<d<32768 for d in target['upvalue_descriptors']);code=['do','\tlocal cells = {}']
     for j,desc in enumerate(target['upvalue_descriptors'],1):code+=['\tcells['+str(j)+'] = function() return '+rr(desc-1)+' end']
     code+=['\t'+rr(a)+' = function(...) return P['+str(B)+'](ENV, cells, ...) end','end']
    elif op==38:code=[rr(k)+' = nil' for k in range(A,A+B)]
    elif op==10:
     assert D==0;code=['do','\tlocal results = table.pack('+rr(A)+'('+', '.join(rr(A+i) for i in range(1,B+1))+'))','\tfor i = 1, math.max('+str(C)+', results.n) do','\t\tR['+str(A)+' + i] = results[i]','\tend','end']
    elif op==25:code=['pc = '+str(B)];terminal=True
    elif op in [7,42]:code=['pc = '+('not ' if op==7 else '')+rr(a)+' and '+str(B)+' or '+str(pc+1)];terminal=True
    elif op==9:code=['return'+(' '+', '.join(rr(A+i) for i in range(B)) if B else '')];terminal=True
    else:raise ValueError(op)
    lines+=['\t\t\t'+l for l in code]
   if not terminal:lines+=['\t\t\tpc = '+str(pc+1)]
  lines+=['\t\telse','\t\t\terror("Invalid recovered PC: " .. tostring(pc))','\t\tend','\tend','end','']
 lines+=['local ENV = (getfenv and getfenv()) or _G','return P['+str(protos[-1]['id'])+'](ENV, {})',''];return '\n'.join(lines)

SOURCES={
'a':'-- a.txt 的可读业务恢复稿；不保留原 VM、执行器绑定和反调试保护。\n-- 仅静态推导与编译检查，未执行原脚本或本恢复稿。\nprint("kkksu")\n',
'b':'-- b.txt 的可读业务恢复稿；变量名为重命名，不是原始源码逐字找回。\n-- 不保留 VM、执行器绑定和反调试；分析时未执行业务。\nlocal function fibonacci(n)\n\tif n < 2 then\n\t\treturn n\n\tend\n\treturn fibonacci(n - 1) + fibonacci(n - 2)\nend\n\nlocal values = {}\nlocal total = 0\nfor i = 1, 10 do\n\tlocal value = fibonacci(i)\n\tvalues[#values + 1] = value\n\ttotal = total + value\nend\n\nprint("kkksu-mid:" .. table.concat(values, ",") .. "|" .. total)\n'}

def finish(P,name):
 protos=lift_data(P,name);cfg=cfg_proof(P,protos);(P/(name+'.registers.luau')).write_text(register_source(name,protos),encoding='utf-8',newline='\n')
 core=[{k:p[k] for k in ['id','maxstack','numparams','is_vararg','upvalue_descriptors','register_map','constants','opcodes_raw','columns_raw','capsule_blob']} for p in protos]
 signature=u.sha256(json.dumps(core,sort_keys=True,ensure_ascii=True,separators=(',',':')).encode())
 expected_core={'a':'006bd46ab46a16c4f18b30c2c77928cf4414d18ce1713209c7a634023ee3391d','b':'b1e44dceacb16d00b3e9ed10ba25c75b913c89490d7bac7be1c16da9f239d36c'}
 assert signature==expected_core[name],('Manual readable template core mismatch',signature)
 # Readable source is manually audited and guarded by the entire parsed-core signature.
 (P/(name+'.recovered.luau')).write_text(SOURCES[name],encoding='utf-8',newline='\n')
 strings=json.loads((P/'strings.proof.json').read_text())
 if name=='a':
  assert len(strings)==1 and strings[0]['plaintext']=='kkksu';expected='kkksu'
 else:
  assert [s['plaintext'] for s in strings]==['kkksu-mid:',',','|']
  assert protos[1]['constants'][0]['value']==protos[1]['constants'][16]['value']==10
  f0,f1=0,1;values=[]
  for _ in range(10):values.append(f1);f0,f1=f1,f0+f1
  expected='kkksu-mid:'+','.join(map(str,values))+'|'+str(sum(values))
 (P/'expected_output.txt').write_text(expected+'\n',encoding='utf-8',newline='\n')
 facts={'input':name+'.txt','method':'static decoding/source lifting; mathematical expected output, not runtime observation','core_signature':signature,'prototype_count':len(protos),'record_count':sum(p['instruction_count'] for p in protos),'plaintext_bytes':sum(p['size'] for p in protos),'fused_record_count':sum(len(row['steps'])>1 for p in protos for row in p['instructions']),'expanded_operation_count':sum(len(row['steps']) for p in protos for row in p['instructions']),'expected_output':expected,'unreachable_pcs':{str(p['prototype']):p['unreachable_pcs'] for p in cfg}}
 u.save_json(P/'recovery_facts.json',facts);print('FACTS',facts);return facts

if __name__=='__main__':
 for n in sys.argv[1:] or ['a','b']:finish(ROOT/('work/ab_'+n),n)
