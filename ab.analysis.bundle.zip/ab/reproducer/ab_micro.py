"""Static microprogram extraction and source-level instruction expansion; no VM execution."""
from ab_analyze import ROOT,u
import re,json,sys
from ab_primitives import normalize

def split_args(s):
 out=[];start=0;depth=0
 for i,c in enumerate(s):
  if c in '({[':depth+=1
  elif c in ')}]':depth-=1
  elif c==',' and depth==0:out.append(s[start:i].strip());start=i+1
 out.append(s[start:].strip());return out

STRLIT=r'''("(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*')'''
def analyze(name,P=None):
 P=P or ROOT/('work/ab_'+name);S=(P/'constants_readable.luau').read_text();table='CS' if name=='a' else 'My'
 mark=next(z for z in re.finditer(r'local function (\w+)\(([^\n()]*)\)',S) if len(z[2].split(','))==15)
 core_name=mark[1];head=mark.start();end=S.index('\n\t\t\t\tend',mark.end());body=S[head:end]
 (P/'micro_core.luau.txt').write_text(body)
 params=[x.strip() for x in mark[2].split(',')];state,*_=params;iv=params[11]
 # Source data blocks after environment-provider consumption and before the unified micro interpreter.
 off=S.rfind(table+'[',0,head);start=S.rfind('for ',0,off)
 region=S[off:head];cipherrecords=[]
 for z in re.finditer(r'local (\w+)\s*=\s*'+STRLIT,region,re.S):
  raw=u.quoted_bytes(z[2])
  if len(raw)<100:continue
  tail=region[z.end():];before_for=tail.split('for ',1)[0]
  nums=re.findall(r'local (\w+) = (\d+)\s*\n',before_for);assert len(nums)==3,(name,z[1],nums)
  seed,mul,add=[int(x[1]) for x in nums];data=u.stream_decode(raw,seed,mul,add)
  dest=re.search(r'\n\t{5}(\w+) = \w+\s*\n',tail);assert dest
  rec={'cipher_name':z[1],'source_name':dest[1],'seed':seed,'mul':mul,'add':add,'size':len(data),'data_hex':data.hex(),'sha256':u.sha256(data)};cipherrecords.append(rec)
  (P/f'micro_{len(cipherrecords)-1}.bin').write_bytes(data)
 assert len(cipherrecords)==(3 if name=='a' else 4),(name,len(cipherrecords),off)
 # Wrapper calls specify byte layout, permutation of primitive IDs, and which encrypted stream is used.
 wrappers=[]
 for z in re.finditer(r'^\t{4}local (\w+) = function\(([^\n]*)\)',S[end:],re.M):
  a=end+z.start();b=S.index('\n\t\t\t\tend',end+z.end());src=S[a:b]
  call=re.search(r'return '+re.escape(core_name)+r'\((.*)\)',src,re.S)
  if not call:continue
  args=split_args(call[1]);assert len(args)==15,(z[1],len(args))
  ids=list(map(int,re.findall(r'\d+',args[11])));layout=list(map(int,args[12:]));stream=next(x for x in cipherrecords if x['source_name']==args[8])
  wrappers.append({'name':z[1],'micro_id':cipherrecords.index(stream),'ids':ids,'layout':layout,'source':src})
 assert len(wrappers)==len(cipherrecords)
 # Primitive names are table-indexed; read and normalize the single shared implementation.
 opmatch=re.search(r'local (\w+), (\w+), (\w+) = \w+\[\w+\], \w+\[\w+\], \w+\[\w+\]',body)
 opvar=opmatch[1]
 pat=re.compile(r'^\t{6}(?:if|elseif)\s+(?:'+iv+r'\[(\d+)\]\s*==\s*'+opvar+'|'+opvar+r'\s*==\s*'+iv+r'\[(\d+)\])\s+then',re.M)
 marks=list(pat.finditer(body));stop=body.index('\n\t\t\t\t\t\tend',marks[-1].end())
 branches={int(z[1] or z[2]):body[z.end():marks[i+1].start() if i+1<len(marks) else stop] for i,z in enumerate(marks)}
 roles=[]
 for index in [1,2,3,4,5,6,7,8,9,10,11,13,15,16,17,18,19,20]:
  # Multi-assignment at beginning maps roles directly to state numeric fields.
  pass
 rolemark=re.search(r'local ([\w, ]+) =\s*\n\s*'+state+r'\[1\]',body);assert rolemark
 roles=[x.strip() for x in rolemark[1].split(',')];assert len(roles)==18,(name,roles)
 operands=re.search(r'local (\w+) = \{ '+', '.join(params[1:5])+r' \}',body)[1]
 scratch=re.search(r'local (\w+) = \{\}',body[rolemark.end():])[1]
 cfg={'roles':roles,'args':params[1:5],'state':state,'operands':operands,'scratch':scratch,'returns':params[6],'nreturns':params[7],'arg1':opmatch[2],'arg2':opmatch[3]}
 primitiveproof={str(i):{'source':src,'normalized':normalize(src,cfg,'MICRO_A','MICRO_B')} for i,src in branches.items()}
 # Outer instruction handlers. Composite pair handlers are retained rather than mistaken for aliases.
 handlers={}
 for z in re.finditer(re.escape(table)+r'\[\((\d+) \+ \w+\) % 256\] = function\([^\n]+\)',S):
  a=z.start();b=S.index('\n\t\t\t\tend',z.end());src=S[a:b];programs=[]
  for mode,w in enumerate(wrappers):
   q=re.search(r'\b'+w['name']+r'\(\s*(?:\w+\s*,\s*){5}(\d+)',src)
   if not q:continue
   offset=int(q[1]);data=bytes.fromhex(cipherrecords[w['micro_id']]['data_hex']);size=data[offset-1];assert size%3==0,(name,z[1],w['name'],offset,size)
   instructions=[]
   for p in range(offset,offset+size,3):
    triple=data[p:p+3];op,a1,a2=[triple[i-1] for i in w['layout']];assert op in w['ids'],(name,z[1],w['name'],offset,op)
    prim=w['ids'].index(op)+1;instructions.append({'primitive':prim,'args':[a1,a2]})
   programs.append({'mode':mode,'offset':offset,'size':size,'instructions':instructions})
  if programs:
   assert len(programs)==len(wrappers),(name,z[1],len(programs))
   assert all(x['instructions']==programs[0]['instructions'] for x in programs),(name,z[1],programs)
  handlers[z[1]]={'source':src,'micro_programs':programs}
 # Operand permutation from audited rank formula: rank=(18+(prototype_index+1)*5)%24.
 aliases={i:i for i in range(44)}
 for z in re.finditer(r'\{\s*(\d+)\s*,\s*(\d+)\s*\}',S):
  a,b=map(int,z.groups())
  if 64<=a<256 and b<44:aliases[a]=b
 protos=json.loads((P/'prototypes.raw.json').read_text());rows=[]
 for p in protos:
  perm=u.permutation((18+(p['id']+1)*5)%24,4);inv={v-1:i for i,v in enumerate(p['register_map'])};p['operand_permutation']=perm;p['instructions']=[]
  for i,op in enumerate(p['opcodes_raw']):
   args=[None]*4
   for j in range(4):args[perm[j]]=p['columns_raw'][j][i]
   base=aliases.get(op,op);h=handlers[str(base)];programs=h['micro_programs'];prims=programs[0]['instructions'] if programs else None
   row={'pc':i+1,'raw_opcode':op,'opcode':base,'operands':args,'register_candidates':[inv.get(x) for x in args],'micro':prims};p['instructions'].append(row);rows.append({'prototype':p['id'],**row})
  print(name,'proto',p['id'],'register_map',p['register_map'],'permutation',perm)
  for row in p['instructions']:print(row)
 callback_name='ZZ' if name=='a' else 'NF'
 cb=re.search(r'^\t{4}'+callback_name+r' = function\(\w+\)',S,re.M);assert cb
 callback=S[cb.start():S.index('\n\t\t\t\tend',cb.end())];return_programs=[]
 for mode,w in enumerate(wrappers):
  z=re.search(r'\b'+w['name']+r'\(\s*(?:[^,]+,\s*){5}(\d+)\s*,',callback);assert z,(name,w['name'])
  offset=int(z[1]);data=bytes.fromhex(cipherrecords[w['micro_id']]['data_hex']);assert data[offset-1]==3
  op,a1,a2=[data[offset+i-1] for i in w['layout']];prim=w['ids'].index(op)+1
  return_programs.append({'mode':mode,'offset':offset,'primitive':prim,'micro_args':[a1,a2],'normalized':normalize(branches[prim],cfg,a1,a2)})
 assert len({x['normalized'] for x in return_programs})==1
 assert 'REGMAP[v0+v2]' in return_programs[0]['normalized']
 u.save_json(P/'call_convention.proof.json',{'callback_name':callback_name,'source':callback,'modes':return_programs,'all_modes_match':True,'first_result_zero_based':'logical R[A+1]'})
 out={'core_name':core_name,'config':cfg,'streams':cipherrecords,'wrappers':wrappers,'primitive_branches':primitiveproof,'handlers':handlers,'aliases':aliases}
 u.save_json(P/'micro.audit.json',out);u.save_json(P/'prototypes.normalized.json',protos)
 with (P/'primitive_summary.txt').open('w') as f:
  for k,v in primitiveproof.items():f.write('PRIMITIVE '+k+'\n'+v['normalized']+'\n\n')
 print(name,'MODES',len(wrappers),'PRIMITIVES',len(branches),'HANDLERS',len(handlers))
 print('PRIMITIVE USAGE',{k:(v['micro_programs'][0]['instructions'] if v['micro_programs'] else 'COMPOSITE') for k,v in handlers.items()})

if __name__=='__main__':
 for n in sys.argv[1:] or ['a','b']:analyze(n)
