"""Static decoding of a/b transport containers and their seven tagged fields."""
from ab_analyze import ROOT,u
import re,json,sys,math
CFG={
 'a':dict(alphabet=('D',126619168,2063753,185258773),escape=('o',201189770,32925631,173077141)),
 'b':dict(alphabet=('jU',107324785,31946625,160692935),escape=('nP',193866465,9195109,126539809))}

def array(S,name):
 z=re.search(r'local '+re.escape(name)+r'\s*=\s*\{([\d,\s]+)\}',S);assert z,name
 return bytes(int(x) for x in re.findall(r'\d+',z[1]))

def decode(name,P=None):
 P=P or ROOT/('work/ab_'+name);S=(P/'constants_readable.luau').read_text();cfg=CFG[name]
 alpha=u.stream_decode(array(S,cfg['alphabet'][0]),*cfg['alphabet'][1:]);esc=u.stream_decode(array(S,cfg['escape'][0]),*cfg['escape'][1:]);assert len(set(alpha))==94 and len(esc)==60
 escapes={esc[5*i:5*i+5]:esc[50+i:51+i] for i in range(10)};assert len(escapes)==10
 marker=esc[0];assert all(k[0]==marker for k in escapes)
 digits={c:i for i,c in enumerate(alpha)}
 u.save_json(P/'transport_keys.json',{'alphabet':alpha.hex(),'escapes':{k.decode():v.hex() for k,v in escapes.items()},'escape_marker':marker,'alphabet_parameters':cfg['alphabet'],'escape_parameters':cfg['escape'],'prototype_parameters':{'seed':168094115,'stride':137552023,'mul':17192171,'add':35201417},'constant_parameters':{'mul':16496879,'add':190194809}})
 protos=[]
 for idx,encfile in enumerate(sorted(P.glob('outer_*.base94'))):
  enc=encfile.read_bytes();expanded=bytearray();pos=0
  while pos<len(enc):
   if enc[pos]==marker:
    assert enc[pos:pos+5] in escapes,(pos,enc[pos:pos+5]);expanded+=escapes[enc[pos:pos+5]];pos+=5
   else:expanded.append(enc[pos]);pos+=1
  assert len(expanded)%5==0
  raw=bytearray()
  for pos in range(0,len(expanded),5):
   x=0
   for c in expanded[pos:pos+5]:x=x*94+digits[c]
   raw+=(x%u.MOD32).to_bytes(4,'little')
  size=int.from_bytes(raw[:4],'little');assert size<=len(raw)-4 and len(raw)-4-size<4,(size,len(raw))
  cipher=bytes(raw[4:4+size]);seed=(168094115+idx*137552023)%u.MOD28;n=min(64,len(cipher));h=0
  for c in cipher[:n]:h=(h*31+c)%u.MOD28
  data=u.stream_decode(cipher[:n],seed,17192171,35201417)+u.stream_decode(cipher[n:],(seed+h)%u.MOD28,17192171,35201417)
  (P/f'prototype_{idx}.cipher.bin').write_bytes(cipher);(P/f'prototype_{idx}.plain.bin').write_bytes(data)
  R=u.Reader(data);p={'id':idx,'size':size,'fields':[],'padding_fields':[],'cipher_sha256':u.sha256(cipher),'plain_sha256':u.sha256(data)}
  while len(p['fields'])<7:
   pos=R.p;tag=R.byte()
   if tag==63:p['maxstack'],p['numparams'],p['is_vararg']=R.var(),R.var(),R.var();kind='metadata'
   elif tag==227:p['constant_seed']=R.var();kind='constant_seed'
   elif tag in [22,121,137]:
    count=R.var();assert 0<=count<=10000,(pos,tag,count)
    kind={22:'upvalue_descriptors',121:'register_map',137:'capsule_blob'}[tag];p[kind]=[R.var() for _ in range(count)]
   elif tag==104:
    p['constant_count'],p['constant_bytes']=R.var(),R.var();p['constant_cipher_hex']=R.raw(p['constant_bytes']).hex();kind='constants'
   elif tag==106:
    pad=R.raw(R.var());p['padding_fields'].append({'tag':tag,'offset':pos,'end':R.p,'hex':pad.hex()});continue
   else:
    count=R.var();assert 0<=count<=10000,(name,idx,pos,tag,count,data[:20].hex());ops=list(R.raw(count));cols=[[R.var() for _ in range(count)] for _ in range(4)];kind='instructions'
    p['instruction_count']=count;p['opcodes_raw']=ops;p['columns_raw']=cols
    p['operand_sum']=sum(map(sum,cols))%u.MOD32;p['operand_weighted_sum']=sum((k*count+j+1)*v for k,c in enumerate(cols) for j,v in enumerate(c))%u.MOD32
   p['fields'].append({'name':kind,'tag':tag,'offset':pos,'end':R.p})
  p['parsed_end']=R.p;p['trailing_bytes_hex']=data[R.p:].hex()
  if R.p<len(data):
   pos=R.p;assert R.byte()==106;pad=R.raw(R.var());p['padding_fields'].append({'tag':106,'offset':pos,'end':R.p,'hex':pad.hex()})
  assert R.p==len(data);p['container_end']=R.p
  plain=u.stream_decode(bytes.fromhex(p['constant_cipher_hex']),p['constant_seed'],16496879,190194809);(P/f'prototype_{idx}.constants.bin').write_bytes(plain)
  C=u.Reader(plain);constants=[]
  for j in range(p['constant_count']):
   tag=C.byte()
   if tag==0:v=None
   elif tag==1:v=C.byte()==1
   elif tag==3:v=C.raw(C.byte()+C.byte()*256).decode('latin1')
   else:
    mantissa,signexp=C.uvar(),C.uvar();exp=signexp//2-2048;assert abs(exp)<2048
    v=math.ldexp(mantissa,exp)*(-1 if signexp%2 else 1)
    if math.isfinite(v) and v==int(v):v=int(v)
   constants.append({'index':j+1,'tag':tag,'value':v})
  assert C.p==len(plain),(name,idx,C.p,len(plain));p['constants']=constants;protos.append(p)
  print(name,'PROTO',idx,'bytes',size,'parsed',R.p,'metadata',[p[k] for k in ['maxstack','numparams','is_vararg']],'rows',p['instruction_count'],'caps',len(p['capsule_blob']),'up',p['upvalue_descriptors'],'checks',[p['operand_sum'],p['operand_weighted_sum']])
  print('CONSTANTS',constants);print('OPS',p['opcodes_raw']);print('COLS',p['columns_raw']);print('CAPS',p['capsule_blob'][:100])
 u.save_json(P/'prototypes.raw.json',protos)

if __name__=='__main__':
 for n in sys.argv[1:] or ['a','b']:decode(n)
