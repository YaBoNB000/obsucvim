"""Small Python data/source primitives; never eval/exec or execute input Lua."""

from __future__ import annotations

import ast,hashlib,json,math,operator,re
from pathlib import Path
MOD28=1<<28
MOD32=1<<32

def sha256(data:bytes)->str:return hashlib.sha256(data).hexdigest()

def save_json(path:Path,value):
 path.parent.mkdir(parents=True,exist_ok=True)
 path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')

def canonical(text:str)->str:
 # Used only for hash-pinned snippet-presence checks, never as a general Lua lexer.
 return re.sub(r'\s+','',text).replace(';','')

def arithmetic(text:str)->int:
 """A deliberately small literal grammar. Never eval/exec."""
 assert re.fullmatch(r'\s*\d+(?:\s*[+-]\s*\d+)*\s*',text),text
 terms=re.findall(r'[+-]?\s*\d+',text)
 return sum(int(re.sub(r'\s+','',x)) for x in terms)

def numeric_field(source:str,index:int)->int:
 z=re.search(r'\['+str(index)+r'\]\s*=\s*(\d+(?:\s*[+-]\s*\d+)*)\s*[,}]',source)
 assert z,('numeric field',index)
 return arithmetic(z[1])

def numeric_array(source:str,name:str)->list[int]:
 z=re.search(name+r'\s*=\s*\{([\d,\s]+)\}',source);assert z,('numeric array',name)
 return [int(x) for x in re.findall(r'\d+',z[1])]

def quoted_bytes(literal:str)->bytes:
 assert literal[0] in '\"\'' and literal[-1]==literal[0]
 out=bytearray();p=1;esc={'a':7,'b':8,'f':12,'n':10,'r':13,'t':9,'v':11,'\\':92,'"':34,"'":39}
 while p<len(literal)-1:
  c=literal[p];p+=1
  if c!='\\':out.extend(c.encode('utf-8'));continue
  c=literal[p];p+=1
  if c.isascii() and c.isdigit():
   ds=c
   while len(ds)<3 and p<len(literal)-1 and literal[p].isascii() and literal[p].isdigit():ds+=literal[p];p+=1
   value=int(ds);assert value<=255;out.append(value)
  elif c=='x':out.append(int(literal[p:p+2],16));p+=2
  elif c=='z':
   while p<len(literal)-1 and literal[p].isspace():p+=1
  elif c=='\n':out.append(10)
  else:assert c in esc,c;out.append(esc[c])
 return bytes(out)

def local_quoted(source:str,name:str)->bytes:
 z=re.search(r'local\s+'+re.escape(name)+r'''\s*=\s*("(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*')''',source,re.S)
 assert z,('quoted local',name)
 return quoted_bytes(z[1])

def fold_bytes(value:int)->int:return (value+(value>>8)+(value>>16)+(value>>24))&255

def stream_decode(data:bytes,seed:int,mul:int,add:int)->bytes:
 out=bytearray()
 for value in data:
  assert seed*mul+add<2**53,'would require explicit floating-point emulation'
  seed=(seed*mul+add)%MOD28;out.append((value-fold_bytes(seed))&255)
 return bytes(out)

def length_hash(lengths,params,extra=0):
 initial,mul,index_term,add,final=params;state=(initial+extra)%MOD28
 for index,size in enumerate(lengths,1):
  assert state*mul+size+index*index_term+add<2**53
  state=(state*mul+size+index*index_term+add)%MOD28
 return (state+final)%MOD28

def integer_condition(expr,H):
 ops={ast.Add:operator.add,ast.Sub:operator.sub,ast.Mult:operator.mul,ast.Mod:operator.mod}
 comparisons={ast.Eq:operator.eq,ast.NotEq:operator.ne,ast.Lt:operator.lt,ast.LtE:operator.le,ast.Gt:operator.gt,ast.GtE:operator.ge}
 def walk(x):
  if isinstance(x,ast.Constant) and isinstance(x.value,(int,bool)):return x.value
  if isinstance(x,ast.Name) and x.id=='H':return H
  if isinstance(x,ast.BinOp) and type(x.op) in ops:return ops[type(x.op)](walk(x.left),walk(x.right))
  if isinstance(x,ast.UnaryOp) and isinstance(x.op,ast.Not):return not walk(x.operand)
  if isinstance(x,ast.Compare) and len(x.ops)==1 and type(x.ops[0]) in comparisons:return comparisons[type(x.ops[0])](walk(x.left),walk(x.comparators[0]))
  raise ValueError('Not an allowlisted outer integer condition: '+ast.dump(x))
 return bool(walk(ast.parse(expr.replace('~=','!='),mode='eval').body))

class Reader:
 def __init__(self,data):self.data=data;self.p=0
 def byte(self):
  assert self.p<len(self.data),(self.p,len(self.data))
  x=self.data[self.p];self.p+=1;return x
 def var(self):
  x=0
  for k in range(4):
   c=self.byte();x+=(c if k==3 else c%128)*128**k
   if c<128 or k==3:return x-MOD32 if x>=2**31 else x
  raise AssertionError
 def raw(self,n):
  assert n>=0 and self.p+n<=len(self.data),(self.p,n,len(self.data))
  x=self.data[self.p:self.p+n];self.p+=n;return x
 def uvar(self):
  x=0
  for k in range(10):
   c=self.byte();x+=(c%128)*128**k
   if c<128:return x
  raise ValueError('numeric constant varint too long')

def permutation(rank,n):
 pool=list(range(n));out=[]
 for k in range(n-1,-1,-1):q,rank=divmod(rank,math.factorial(k));out.append(pool.pop(q))
 assert rank==0
 return out

role_names=['REG','CONST','REGMAP','SPILL','ENV','VARARGS','VARARG_COUNT','UPVAL','CLOSURE','META','CALLABLE','LENMETA','FLOOR','ERROR','TYPE','API18','RAWGET','RAWSET']

def normalize(source,cfg,arg1,arg2):
 fixed=dict(zip(cfg['roles'],role_names));fixed.update(zip(cfg['args'],['ARG_A','ARG_B','ARG_C','ARG_D']))
 fixed.update({cfg['state']:'STATE',cfg['operands']:'ARGS',cfg['scratch']:'TMP',cfg['returns']:'RETURNS',cfg['nreturns']:'NRET',cfg['arg1']:str(arg1),cfg['arg2']:str(arg2)})
 # Local declaration scopes are indentation-bounded in the formatted, audited branches.
 scopes={};count=0;out=[];do_indents=[]
 def subst(text,indent):
  env=fixed.copy()
  for level,scope in sorted(scopes.items()):
   if level<=indent:env.update(scope)
  def replace(z):
   # Table member names are not lexical variable references.
   if z.start()>0 and text[z.start()-1]=='.':return z[0]
   return env.get(z[0],z[0])
  return re.sub(r'\b[A-Za-z_][A-Za-z_0-9]*\b',replace,text)
 for line in source.splitlines():
  if not line.strip():continue
  indent=len(line)-len(line.lstrip('\t'));t=line.strip()
  scopes={k:v for k,v in scopes.items() if k<=indent}
  if t=='do':do_indents.append(indent);continue
  if t=='end' and indent in do_indents:
   do_indents.remove(indent);continue
  loop=re.fullmatch(r'for (\w+) = (.*) do',t)
  if loop:
   rhs=subst(loop[2],indent);new='v'+str(count);count+=1
   scopes.setdefault(indent+1,{})[loop[1]]=new
   out.append('for '+new+' = '+rhs+' do');continue
  z=re.fullmatch(r'local (\w+) = (-?\d+)',t)
  if z:
   scopes.setdefault(indent,{})[z[1]]=z[2];continue
  z=re.match(r'local ([A-Za-z_][\w]*(?:,\s*[A-Za-z_][\w]*)*)(\s*=.*)?$',t)
  if z:
   names=re.split(r',\s*',z[1]);rhs=subst(z[2] or '',indent);renamed=[]
   for name in names:
    new='v'+str(count);count+=1;renamed.append(new);scopes.setdefault(indent,{})[name]=new
   out.append('local '+','.join(renamed)+rhs)
  else:out.append(subst(t,indent))
 return re.sub(r'\s+','', '\n'.join(out))
