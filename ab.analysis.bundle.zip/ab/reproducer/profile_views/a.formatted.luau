-- This file was obfuscated by Obsucvim.

local GC = {
	[41] = buffer.len,
	WN = function(p, L, t, G, R, O, k)
		local n = L[8] ~= nil and 29 or 150
		return 59, L, G, R, O, k, t
	end,
	mp = function(n, k, O, R, G, t, L)
		local p = k[8] ~= nil and 24 or 235
		return 21, k, R, G, t, L, O
	end,
	[896] = function(p)
		local L = 7
		L = (213 * L + 225) % 268435456
		L = (L * 213 + 225) % 268435456
		return L
	end,
	YJ = function(L, p, t, G, R, O, k)
		local n = p[8]
		local e = if p[8] >= 0 then 46 else 150
		p[8] = L:ql(L:LB(n, 31) + (L[68][24] + L[79][26]))
		return 4, p, G, R, O, k, t
	end,
	iA = function(e, n, k, O, R, G, t)
		local p = n[8] ~= nil and 114 or 206
		return 68, n, O, R, G, t, k
	end,
	BI = function(p, t, G, R, O, k, n)
		local e = t[8] ~= nil and 79 or 196
		return 77, t, R, O, k, n, G
	end,
	dS = function(e, n, k, O, R, G, t, p)
		while true do
			if k <= 235 then
				if k <= 125 then
					if k <= 56 then
						if k <= 23 then
							if k <= 10 then
								if k <= 5 then
									if k <= 3 then
										if k % 5 * (k % 5) * (k % 5 * (k % 5)) >= 0 then
											k, O, R, G, t, p = e:YJ(n, O, R, G, t, p)
											continue
										else
											local L = k
										end
									else
										if k <= 4 then
											if (k * k + k) % 2 == 0 then
												k, O, R, G, t, p = e:iE(n, O, R, G, t, p)
												continue
											else
												local L = k
											end
										else
											if not ((k * k + k) % 2 == 0) then
												local L = k
											else
												k, O, R, G, t, p = e:nD(n, O, R, G, t, p)
												continue
											end
										end
									end
								else
									if k <= 8 then
										if not (k % 5 * (k % 5) * (k % 5 * (k % 5)) >= 0) then
											local L = k
										else
											k, O, R, G, t, p = e:aV(n, O, R, G, t, p)
											continue
										end
									else
										if k <= 9 then
											if not ((k * k + k) % 2 == 0) then
												local L = k
											else
												k, O, R, G, t, p = e:gW(n, O, R, G, t, p)
												continue
											end
										else
											if (k + 1) * (k + 1) >= k * k then
												k, O, R, G, t, p = e:Me(n, O, R, G, t, p)
												continue
											else
												local L = k
											end
										end
									end
								end
							else
								if k <= 14 then
									if k <= 11 then
										if k % 5 * (k % 5) * (k % 5 * (k % 5)) >= 0 then
											k, O, R, G, t, p = e:C(n, O, R, G, t, p)
											continue
										else
											local L = k
										end
									else
										if k <= 12 then
											if not (k % 5 * (k % 5) * (k % 5 * (k % 5)) >= 0) then
												local L = k
											else
												k, O, R, G, t, p = e:rw(n, O, R, G, t, p)
												continue
											end
										else
											if k % 3 * (k % 3) >= 0 then
												k, O, R, G, t, p = e:Dc(n, O, R, G, t, p)
												continue
											else
												local L = k
											end
										end
									end
								else
									if k <= 19 then
										if k <= 17 then
											if not ((k + 1) * (k + 1) >= k * k) then
												local L = k
											else
												k, O, R, G, t, p = e:Lq(n, O, R, G, t, p)
												continue
											end
										else
											if (k + 1) * (k + 1) >= k * k then
												k, O, R, G, t, p = e:mp(n, O, R, G, t, p)
												continue
											else
												local L = k
											end
										end
									else
										if k <= 21 then
											if (k + 1) * (k + 1) >= k * k then
												k, O, R, G, t, p = e:FS(n, O, R, G, t, p)
												continue
											else
												local L = k
											end
										else
											if not ((k + 1) * (k + 1) >= k * k) then
												local L = k
											else
												k, O, R, G, t, p = e:yY(n, O, R, G, t, p)
												continue
											end
										end
									end
								end
							end
						else
							if k <= 36 then
								if k <= 29 then
									if k <= 24 then
										if not (k % 5 * (k % 5) * (k % 5 * (k % 5)) >= 0) then
											local L = k
										else
											k, O, R, G, t, p = e:jj(n, O, R, G, t, p)
											continue
										end
									else
										if k <= 27 then
											if (k * k + k) % 2 == 0 then
												k, O, R, G, t, p = e:Yn(n, O, R, G, t, p)
												continue
											else
												local L = k
											end
										else
											if not (k % 5 * (k % 5) * (k % 5 * (k % 5)) >= 0) then
												local L = k
											else
												k, O, R, G, t, p = e:kU(n, O, R, G, t, p)
												continue
											end
										end
									end
								else
									if k <= 31 then
										if not ((k * k + k) % 2 == 0) then
											local L = k
										else
											k, O, R, G, t, p = e:LM(n, O, R, G, t, p)
											continue
										end
									else
										if k <= 33 then
											if not (k % 5 * (k % 5) * (k % 5 * (k % 5)) >= 0) then
												local L = k
											else
												k, O, R, G, t, p = e:yX(n, O, R, G, t, p)
												continue
											end
										else
											if (k * k + k) % 2 == 0 then
												k, O, R, G, t, p = e:HM(n, O, R, G, t, p)
												continue
											else
												local L = k
											end
										end
									end
								end
							else
								if k <= 42 then
									if k <= 37 then
										if not (k % 3 * (k % 3) >= 0) then
											local L = k
										else
											k, O, R, G, t, p = e:pr(n, O, R, G, t, p)
											continue
										end
									else
										if k <= 39 then
											if not ((k * k + k) % 2 == 0) then
												local L = k
											else
												k, O, R, G, t, p = e:Xm(n, O, R, G, t, p)
												continue
											end
										else
											if (k + 1) * (k + 1) >= k * k then
												k, O, R, G, t, p = e:yS(n, O, R, G, t, p)
												continue
											else
												local L = k
											end
										end
									end
								else
									if k <= 47 then
										if k <= 46 then
											if k % 5 * (k % 5) * (k % 5 * (k % 5)) >= 0 then
												k, O, R, G, t, p = e:ST(n, O, R, G, t, p)
												continue
											else
												local L = k
											end
										else
											if (k + 1) * (k + 1) >= k * k then
												k, O, R, G, t, p = e:LD(n, O, R, G, t, p)
												continue
											else
												local L = k
											end
										end
									else
										if k <= 55 then
											if k % 5 * (k % 5) * (k % 5 * (k % 5)) >= 0 then
												k, O, R, G, t, p = e:FQ(n, O, R, G, t, p)
												continue
											else
												local L = k
											end
										else
											if not (k % 3 * (k % 3) >= 0) then
												local L = k
											else
												k, O, R, G, t, p = e:WN(n, O, R, G, t, p)
												continue
											end
										end
									end
								end
							end
						end
					else
						if k <= 84 then
							if k <= 68 then
								if k <= 62 then
									if k <= 59 then
										if not (k % 3 * (k % 3) >= 0) then
											local L = k
										else
											k, O, R, G, t, p = e:NS(n, O, R, G, t, p)
											continue
										end
									else
										if k <= 60 then
											if (k * k + k) % 2 == 0 then
												k, O, R, G, t, p = e:tY(n, O, R, G, t, p)
												continue
											else
												local L = k
											end
										else
											if (k + 1) * (k + 1) >= k * k then
												k, O, R, G, t, p = e:Ic(n, O, R, G, t, p)
												continue
											else
												local L = k
											end
										end
									end
								else
									if k <= 66 then
										if k % 3 * (k % 3) >= 0 then
											k, O, R, G, t, p = e:aa(n, O, R, G, t, p)
											continue
										else
											local L = k
										end
									else
										if k <= 67 then
											if not (k % 5 * (k % 5) * (k % 5 * (k % 5)) >= 0) then
												local L = k
											else
												k, O, R, G, t, p = e:iA(n, O, R, G, t, p)
												continue
											end
										else
											if not (k % 3 * (k % 3) >= 0) then
												local L = k
											else
												k, O, R, G, t, p = e:JN(n, O, R, G, t, p)
												continue
											end
										end
									end
								end
							else
								if k <= 76 then
									if k <= 72 then
										if (k * k + k) % 2 == 0 then
											k, O, R, G, t, p = e:Bv(n, O, R, G, t, p)
											continue
										else
											local L = k
										end
									else
										if k <= 74 then
											if (k * k + k) % 2 == 0 then
												k, O, R, G, t, p = e:Gn(n, O, R, G, t, p)
												continue
											else
												local L = k
											end
										else
											if not ((k + 1) * (k + 1) >= k * k) then
												local L = k
											else
												k, O, R, G, t, p = e:BI(n, O, R, G, t, p)
												continue
											end
										end
									end
								else
									if k <= 79 then
										if k <= 77 then
											if not ((k * k + k) % 2 == 0) then
												local L = k
											else
												k, O, R, G, t, p = e:MQ(n, O, R, G, t, p)
												continue
											end
										else
											if not ((k * k + k) % 2 == 0) then
												local L = k
											else
												k, O, R, G, t, p = e:Gt(n, O, R, G, t, p)
												continue
											end
										end
									else
										if k <= 83 then
											if (k + 1) * (k + 1) >= k * k then
												k, O, R, G, t, p = e:Id(n, O, R, G, t, p)
												continue
											else
												local L = k
											end
										else
											if not ((k * k + k) % 2 == 0) then
												local L = k
											else
												k, O, R, G, t, p = e:mN(n, O, R, G, t, p)
												continue
											end
										end
									end
								end
							end
						else
							if k <= 102 then
								if k <= 95 then
									if k <= 85 then
										if k % 5 * (k % 5) * (k % 5 * (k % 5)) >= 0 then
											k, O, R, G, t, p = e:WK(n, O, R, G, t, p)
											continue
										else
											local L = k
										end
									else
										if k <= 93 then
											if k % 3 * (k % 3) >= 0 then
												k, O, R, G, t, p = e:fy(n, O, R, G, t, p)
												continue
											else
												local L = k
											end
										else
											if (k * k + k) % 2 == 0 then
												k, O, R, G, t, p = e:JD(n, O, R, G, t, p)
												continue
											else
												local L = k
											end
										end
									end
								else
									if k <= 96 then
										if not (k % 5 * (k % 5) * (k % 5 * (k % 5)) >= 0) then
											local L = k
										else
											k, O, R, G, t, p = e:jg(n, O, R, G, t, p)
											continue
										end
									else
										if k <= 98 then
											if k % 5 * (k % 5) * (k % 5 * (k % 5)) >= 0 then
												k, O, R, G, t, p = e:aB(n, O, R, G, t, p)
												continue
											else
												local L = k
											end
										else
											if (k * k + k) % 2 == 0 then
												k, O, R, G, t, p = e:wP(n, O, R, G, t, p)
												continue
											else
												local L = k
											end
										end
									end
								end
							else
								if k <= 113 then
									if k <= 103 then
										if k % 5 * (k % 5) * (k % 5 * (k % 5)) >= 0 then
											k, O, R, G, t, p = e:GE(n, O, R, G, t, p)
											continue
										else
											local L = k
										end
									else
										if k <= 107 then
											if k % 3 * (k % 3) >= 0 then
												k, O, R, G, t, p = e:IB(n, O, R, G, t, p)
												continue
											else
												local L = k
											end
										else
											if not ((k * k + k) % 2 == 0) then
												local L = k
											else
												k, O, R, G, t, p = e:RI(n, O, R, G, t, p)
												continue
											end
										end
									end
								else
									if k <= 121 then
										if k <= 114 then
											if not ((k * k + k) % 2 == 0) then
												local L = k
											else
												k, O, R, G, t, p = e:OZ(n, O, R, G, t, p)
												continue
											end
										else
											if not ((k * k + k) % 2 == 0) then
												local L = k
											else
												k, O, R, G, t, p = e:Pj(n, O, R, G, t, p)
												continue
											end
										end
									else
										if k <= 123 then
											if not (k % 5 * (k % 5) * (k % 5 * (k % 5)) >= 0) then
												local L = k
											else
												k, O, R, G, t, p = e:nI(n, O, R, G, t, p)
												continue
											end
										else
											if not (k % 3 * (k % 3) >= 0) then
												local L = k
											else
												k, O, R, G, t, p = e:Lv(n, O, R, G, t, p)
												continue
											end
										end
									end
								end
							end
						end
					end
				else
					if k <= 178 then
						if k <= 150 then
							if k <= 138 then
								if k <= 133 then
									if k <= 129 then
										if not ((k * k + k) % 2 == 0) then
											local L = k
										else
											k, O, R, G, t, p = e:IZ(n, O, R, G, t, p)
											continue
										end
									else
										if k <= 132 then
											if (k * k + k) % 2 == 0 then
												k, O, R, G, t, p = e:zQ(n, O, R, G, t, p)
												continue
											else
												local L = k
											end
										else
											if not (k % 3 * (k % 3) >= 0) then
												local L = k
											else
												k, O, R, G, t, p = e:SV(n, O, R, G, t, p)
												continue
											end
										end
									end
								else
									if k <= 136 then
										if (k + 1) * (k + 1) >= k * k then
											k, O, R, G, t, p = e:Al(n, O, R, G, t, p)
											continue
										else
											local L = k
										end
									else
										if k <= 137 then
											if not ((k * k + k) % 2 == 0) then
												local L = k
											else
												k, O, R, G, t, p = e:xN(n, O, R, G, t, p)
												continue
											end
										else
											if (k + 1) * (k + 1) >= k * k then
												k, O, R, G, t, p = e:FH(n, O, R, G, t, p)
												continue
											else
												local L = k
											end
										end
									end
								end
							else
								if k <= 144 then
									if k <= 141 then
										if not (k % 3 * (k % 3) >= 0) then
											local L = k
										else
											k, O, R, G, t, p = e:pe(n, O, R, G, t, p)
											continue
										end
									else
										if k <= 142 then
											if k % 5 * (k % 5) * (k % 5 * (k % 5)) >= 0 then
												k, O, R, G, t, p = e:qq(n, O, R, G, t, p)
												continue
											else
												local L = k
											end
										else
											if (k * k + k) % 2 == 0 then
												k, O, R, G, t, p = e:_W(n, O, R, G, t, p)
												continue
											else
												local L = k
											end
										end
									end
								else
									if k <= 147 then
										if k <= 145 then
											if not ((k * k + k) % 2 == 0) then
												local L = k
											else
												k, O, R, G, t, p = e:UP(n, O, R, G, t, p)
												continue
											end
										else
											if not ((k + 1) * (k + 1) >= k * k) then
												local L = k
											else
												k, O, R, G, t, p = e:HF(n, O, R, G, t, p)
												continue
											end
										end
									else
										if k <= 148 then
											if not (k % 3 * (k % 3) >= 0) then
												local L = k
											else
												k, O, R, G, t, p = e:oD(n, O, R, G, t, p)
												continue
											end
										else
											if not (k % 3 * (k % 3) >= 0) then
												local L = k
											else
												k, O, R, G, t, p = e:Y_(n, O, R, G, t, p)
												continue
											end
										end
									end
								end
							end
						else
							if k <= 164 then
								if k <= 155 then
									if k <= 152 then
										if not ((k + 1) * (k + 1) >= k * k) then
											local L = k
										else
											k, O, R, G, t, p = e:nQ(n, O, R, G, t, p)
											continue
										end
									else
										if k <= 154 then
											if not (k % 3 * (k % 3) >= 0) then
												local L = k
											else
												k, O, R, G, t, p = e:If(n, O, R, G, t, p)
												continue
											end
										else
											if not (k % 5 * (k % 5) * (k % 5 * (k % 5)) >= 0) then
												local L = k
											else
												k, O, R, G, t, p = e:c(n, O, R, G, t, p)
												continue
											end
										end
									end
								else
									if k <= 158 then
										if not ((k + 1) * (k + 1) >= k * k) then
											local L = k
										else
											k, O, R, G, t, p = e:TQ(n, O, R, G, t, p)
											continue
										end
									else
										if k <= 159 then
											if not (k % 5 * (k % 5) * (k % 5 * (k % 5)) >= 0) then
												local L = k
											else
												k, O, R, G, t, p = e:qZ(n, O, R, G, t, p)
												continue
											end
										else
											if not (k % 5 * (k % 5) * (k % 5 * (k % 5)) >= 0) then
												local L = k
											else
												k, O, R, G, t, p = e:NP(n, O, R, G, t, p)
												continue
											end
										end
									end
								end
							else
								if k <= 170 then
									if k <= 165 then
										if k % 3 * (k % 3) >= 0 then
											k, O, R, G, t, p = e:Do(n, O, R, G, t, p)
											continue
										else
											local L = k
										end
									else
										if k <= 169 then
											if (k + 1) * (k + 1) >= k * k then
												k, O, R, G, t, p = e:wB(n, O, R, G, t, p)
												continue
											else
												local L = k
											end
										else
											if k % 5 * (k % 5) * (k % 5 * (k % 5)) >= 0 then
												k, O, R, G, t, p = e:X(n, O, R, G, t, p)
												continue
											else
												local L = k
											end
										end
									end
								else
									if k <= 174 then
										if k <= 173 then
											if not (k % 3 * (k % 3) >= 0) then
												local L = k
											else
												k, O, R, G, t, p = e:dQ(n, O, R, G, t, p)
												continue
											end
										else
											if not (k % 3 * (k % 3) >= 0) then
												local L = k
											else
												k, O, R, G, t, p = e:Rr(n, O, R, G, t, p)
												continue
											end
										end
									else
										if k <= 175 then
											if not ((k + 1) * (k + 1) >= k * k) then
												local L = k
											else
												k, O, R, G, t, p = e:o_(n, O, R, G, t, p)
												continue
											end
										else
											if k % 5 * (k % 5) * (k % 5 * (k % 5)) >= 0 then
												k, O, R, G, t, p = e:Au(n, O, R, G, t, p)
												continue
											else
												local L = k
											end
										end
									end
								end
							end
						end
					else
						if k <= 206 then
							if k <= 190 then
								if k <= 185 then
									if k <= 179 then
										if (k + 1) * (k + 1) >= k * k then
											k, O, R, G, t, p = e:SL(n, O, R, G, t, p)
											continue
										else
											local L = k
										end
									else
										if k <= 180 then
											if k % 3 * (k % 3) >= 0 then
												k, O, R, G, t, p = e:TV(n, O, R, G, t, p)
												continue
											else
												local L = k
											end
										else
											if k % 3 * (k % 3) >= 0 then
												k, O, R, G, t, p = e:wj(n, O, R, G, t, p)
												continue
											else
												local L = k
											end
										end
									end
								else
									if k <= 187 then
										if k % 3 * (k % 3) >= 0 then
											k, O, R, G, t, p = e:Ct(n, O, R, G, t, p)
											continue
										else
											local L = k
										end
									else
										if k <= 188 then
											if not (k % 3 * (k % 3) >= 0) then
												local L = k
											else
												k, O, R, G, t, p = e:tq(n, O, R, G, t, p)
												continue
											end
										else
											if not ((k + 1) * (k + 1) >= k * k) then
												local L = k
											else
												k, O, R, G, t, p = e:ey(n, O, R, G, t, p)
												continue
											end
										end
									end
								end
							else
								if k <= 196 then
									if k <= 191 then
										if k % 3 * (k % 3) >= 0 then
											k, O, R, G, t, p = e:Tr(n, O, R, G, t, p)
											continue
										else
											local L = k
										end
									else
										if k <= 195 then
											if k % 3 * (k % 3) >= 0 then
												k, O, R, G, t, p = e:DC(n, O, R, G, t, p)
												continue
											else
												local L = k
											end
										else
											if k % 3 * (k % 3) >= 0 then
												k, O, R, G, t, p = e:zD(n, O, R, G, t, p)
												continue
											else
												local L = k
											end
										end
									end
								else
									if k <= 203 then
										if k <= 197 then
											if (k + 1) * (k + 1) >= k * k then
												k, O, R, G, t, p = e:rg(n, O, R, G, t, p)
												continue
											else
												local L = k
											end
										else
											if k % 5 * (k % 5) * (k % 5 * (k % 5)) >= 0 then
												k, O, R, G, t, p = e:Aq(n, O, R, G, t, p)
												continue
											else
												local L = k
											end
										end
									else
										if k <= 205 then
											if k % 3 * (k % 3) >= 0 then
												k, O, R, G, t, p = e:oa(n, O, R, G, t, p)
												continue
											else
												local L = k
											end
										else
											if not (k % 5 * (k % 5) * (k % 5 * (k % 5)) >= 0) then
												local L = k
											else
												k, O, R, G, t, p = e:JK(n, O, R, G, t, p)
												continue
											end
										end
									end
								end
							end
						else
							if k <= 220 then
								if k <= 215 then
									if k <= 211 then
										if not (k % 3 * (k % 3) >= 0) then
											local L = k
										else
											k, O, R, G, t, p = e:_X(n, O, R, G, t, p)
											continue
										end
									else
										if k <= 214 then
											if not ((k * k + k) % 2 == 0) then
												local L = k
											else
												k, O, R, G, t, p = e:uk(n, O, R, G, t, p)
												continue
											end
										else
											if not (k % 3 * (k % 3) >= 0) then
												local L = k
											else
												k, O, R, G, t, p = e:_H(n, O, R, G, t, p)
												continue
											end
										end
									end
								else
									if k <= 217 then
										if not (k % 3 * (k % 3) >= 0) then
											local L = k
										else
											k, O, R, G, t, p = e:Qm(n, O, R, G, t, p)
											continue
										end
									else
										if k <= 218 then
											if k % 5 * (k % 5) * (k % 5 * (k % 5)) >= 0 then
												k, O, R, G, t, p = e:DQ(n, O, R, G, t, p)
												continue
											else
												local L = k
											end
										else
											if (k + 1) * (k + 1) >= k * k then
												k, O, R, G, t, p = e:_y(n, O, R, G, t, p)
												continue
											else
												local L = k
											end
										end
									end
								end
							else
								if k <= 229 then
									if k <= 222 then
										if (k * k + k) % 2 == 0 then
											k, O, R, G, t, p = e:iU(n, O, R, G, t, p)
											continue
										else
											local L = k
										end
									else
										if k <= 224 then
											if not ((k + 1) * (k + 1) >= k * k) then
												local L = k
											else
												k, O, R, G, t, p = e:Pv(n, O, R, G, t, p)
												continue
											end
										else
											if (k + 1) * (k + 1) >= k * k then
												k, O, R, G, t, p = e:yt(n, O, R, G, t, p)
												continue
											else
												local L = k
											end
										end
									end
								else
									if k <= 232 then
										if k <= 231 then
											if not (k % 3 * (k % 3) >= 0) then
												local L = k
											else
												k, O, R, G, t, p = e[29](e, n, k, O, R, G, t, p)
												continue
											end
										else
											if (k + 1) * (k + 1) >= k * k then
												k, O, R, G, t, p = e:VZ(n, O, R, G, t, p)
												continue
											else
												local L = k
											end
										end
									else
										if k <= 233 then
											if not ((k * k + k) % 2 == 0) then
												local L = k
											else
												k, O, R, G, t, p = e:wF(n, O, R, G, t, p)
												continue
											end
										else
											if not ((k + 1) * (k + 1) >= k * k) then
												local L = k
											else
												k, O, R, G, t, p = e:jH(n, O, R, G, t, p)
												continue
											end
										end
									end
								end
							end
						end
					end
				end
			else
				local L, A = e:Uy(n, k)
				if L == 2 then
					return 2, A
				end
				k = L
			end
		end
	end,
	[107] = ("")["sub"],
	[101] = string.format,
	RI = function(p, t, G, R, O, k, n)
		local e = t[8] ~= nil and 19 or 195
		return 114, t, R, O, k, n, G
	end,
	[29] = function(e, n, k, O, R, G, t)
		local p = 1122 + 7883
		local A = p * 842 - 6060
		if A * A >= 0 then
			local L = A - p
		end
		local L = A + 1 - 1
		local s = 168 + 4372
		local w = s * 825 - 9444
		if w * w >= 0 then
			local c = w - s
		end
		local c = w + 1 - 1
		local mL = function(W)
			local Q = 8935 + 8975
			local U = Q * 104 - 1316
			if U * U >= 0 then
				local H = U - Q
			end
			local H = U + 1 - 1
			local J = 6699 + 9315
			local i = J * 821 - 9804
			if i * i >= 0 then
				local r = i - J
			end
			local r = i + 1 - 1
			local h = { W }
			local I = {}
			do
				local g = {
					19,
					108,
					23,
					211,
					17,
					221,
					21,
					34,
					3,
					63,
					37,
					108,
					40,
					133,
					1,
					118,
					9,
					63,
					26,
					205,
					6,
					28,
					18,
					51,
					32,
					213,
					8,
					222,
					14,
					194,
					7,
					115,
					34,
					119,
					38,
					220,
					20,
					216,
					39,
					52,
					24,
					31,
					31,
					122,
					28,
					131,
					4,
					118,
					15,
					45,
					33,
					52,
					11,
					194,
					30,
					30,
					25,
					137,
					36,
					37,
					22,
					109,
					29,
					197,
					0,
					51,
					2,
					238,
					5,
					236,
					10,
					124,
					12,
					42,
					35,
					217,
					16,
					124,
					13,
					118,
					41,
					195,
					42,
					45,
					27,
					17,
				}
				local u = 1
				while u <= #g do
					local m = g[u]
					I[m] = (
						g[u + 1]
						- (
								(function(d)
									local l = (153553698 + #g) % 268435456
									for f = 1, #d do
										l = (l * 36922 + #d[f] + f * 30669 + 51754939) % 268435456
									end
									return (60709335 + l) % 268435456
								end)(h)
								+ m
									* (function(l)
										local d = (202338265 + #g) % 268435456
										for f = 1, #l do
											d = (d * 11530 + #l[f] + f * 16536 + 137442116) % 268435456
										end
										return (142396696 + d) % 268435456
									end)(h)
							)
							% 65536
					) % 256
					u += 2
				end
			end
			local g = (function(u)
				local g = (86131722 + 0) % 268435456
				for m = 1, #u do
					g = (g * 33338 + #u[m] + m * 33094 + 216577710) % 268435456
				end
				return (46549352 + g) % 268435456
			end)(h) % 256
			local u = {}
			local m = {}
			m[42] = math.floor
			m[39] = type
			m[55] = ("")["sub"]
			m[12] = getmetatable
			m[53] = select
			m[57] = rawset
			m[45] = unpack
			m[37] = ("")["char"]
			m[24] = tonumber
			m[73] = getfenv
			m[31] = error
			m[71] = ("")["byte"]
			m[23] = setmetatable
			m[58] = rawget
			m[44] = pcall
			local d, l, f, S, a, B, v, M, K, X, F, P, y, x, Y =
				m[42], m[39], m[55], m[12], m[53], m[57], m[45], m[37], m[24], m[73], m[31], m[71], m[23], m[58], m[44]
			local q = {}
			q[1] = M(110, 117, 109, 98, 101, 114)
			q[2] = M(95, 95, 112, 111, 119)
			q[3] = M(
				97,
				116,
				116,
				101,
				109,
				112,
				116,
				32,
				116,
				111,
				32,
				112,
				101,
				114,
				102,
				111,
				114,
				109,
				32,
				97,
				114,
				105,
				116,
				104,
				109,
				101,
				116,
				105,
				99,
				32,
				111,
				110,
				32,
				97,
				32
			)
			q[4] = M(32, 118, 97, 108, 117, 101)
			q[5] = M(115, 116, 114, 105, 110, 103)
			q[6] = M(95, 95, 108, 101)
			q[7] = M(97, 116, 116, 101, 109, 112, 116, 32, 116, 111, 32, 99, 111, 109, 112, 97, 114, 101, 32)
			q[8] = M(32, 119, 105, 116, 104, 32)
			q[9] = M(95, 95, 115, 117, 98)
			q[10] = M(95, 95, 97, 100, 100)
			q[11] = M(95, 95, 117, 110, 109)
			q[12] = M(95, 95, 99, 111, 110, 99, 97, 116)
			q[13] = M(
				97,
				116,
				116,
				101,
				109,
				112,
				116,
				32,
				116,
				111,
				32,
				112,
				101,
				114,
				102,
				111,
				114,
				109,
				32,
				99,
				111,
				110,
				99,
				97,
				116,
				101,
				110,
				97,
				116,
				105,
				111,
				110,
				32,
				111,
				110,
				32,
				97,
				32
			)
			q[14] = M(95, 95, 108, 116)
			q[15] = M(95, 95, 109, 111, 100)
			q[16] = M(116, 97, 98, 108, 101)
			q[17] = M(95, 95, 110, 101, 119, 105, 110, 100, 101, 120)
			q[18] = M(102, 117, 110, 99, 116, 105, 111, 110)
			q[19] = M(97, 116, 116, 101, 109, 112, 116, 32, 116, 111, 32, 105, 110, 100, 101, 120, 32, 97, 32)
			q[20] = M(95, 95, 105, 110, 100, 101, 120)
			q[21] = M(98, 111, 111, 108, 101, 97, 110)
			q[22] = M(110, 105, 108)
			q[23] = M(95, 95, 101, 113)
			q[24] = M(95, 95, 108, 101, 110)
			q[25] = M(95, 95, 109, 117, 108)
			q[26] = M(95, 95, 100, 105, 118)
			q[27] = M(99, 104, 97, 114)
			q[28] = M(98, 121, 116, 101)
			q[29] = M()
			q[30] = M(112, 97, 99, 107)
			q[31] = M(95, 95, 99, 97, 108, 108)
			q[32] = M(97, 116, 116, 101, 109, 112, 116, 32, 116, 111, 32, 99, 97, 108, 108, 32, 97, 32)
			local D = {
				76,
				19,
				225,
				117,
				120,
				125,
				84,
				242,
				66,
				207,
				65,
				177,
				20,
				138,
				143,
				85,
				190,
				27,
				98,
				156,
				212,
				224,
				128,
				120,
				194,
				189,
				191,
				8,
				170,
				130,
				92,
				188,
				82,
				77,
				19,
				135,
				21,
				23,
				79,
				121,
				166,
				139,
				62,
				180,
				53,
				67,
				202,
				15,
				209,
				213,
				50,
				53,
				191,
				219,
				106,
				192,
				164,
				61,
				129,
				232,
				131,
				90,
				231,
				161,
				7,
				88,
				127,
				146,
				102,
				229,
				142,
				206,
				61,
				123,
				69,
				145,
				121,
				121,
				145,
				5,
				129,
				156,
				213,
				71,
				177,
				245,
				248,
				85,
				34,
				166,
				222,
				79,
				184,
				139,
			}
			local T = {}
			do
				local o = (function(z)
					local o = (24972781 + #D) % 268435456
					for N = 1, #z do
						o = (o * 45477 + #z[N] + N * 23136 + 252084009) % 268435456
					end
					return (201925045 + o) % 268435456
				end)(h)
				for z = 1, 94 do
					o = (
						(function(N)
								local Z = (168019828 + #D) % 268435456
								for j = 1, #N do
									Z = (Z * 59767 + #N[j] + j * 11547 + 243655060) % 268435456
								end
								return (150562993 + Z) % 268435456
							end)(h)
							* o
						+ (function(Z)
							local N = (242361688 + #D) % 268435456
							for j = 1, #Z do
								N = (N * 21417 + #Z[j] + j * 29071 + 71436706) % 268435456
							end
							return (187920179 + N) % 268435456
						end)(h)
					) % 268435456
					T[(D[z] - (o % 256 + d(o / 256) % 256 + d(o / 65536) % 256 + d(o / 16777216)) % 256) % 256] = z - 1
				end
			end
			local o = {
				10,
				64,
				94,
				98,
				33,
				29,
				161,
				24,
				73,
				225,
				232,
				245,
				203,
				66,
				189,
				237,
				17,
				159,
				164,
				140,
				228,
				145,
				15,
				137,
				44,
				203,
				136,
				161,
				239,
				99,
				168,
				235,
				93,
				219,
				157,
				233,
				66,
				73,
				98,
				64,
				21,
				163,
				77,
				99,
				230,
				129,
				146,
				183,
				218,
				42,
				172,
				220,
				174,
				145,
				158,
				93,
				235,
				34,
				251,
				210,
			}
			local z = {}
			do
				local Z = (function(N)
					local Z = (60482582 + #o) % 268435456
					for j = 1, #N do
						Z = (Z * 12590 + #N[j] + j * 57603 + 241659740) % 268435456
					end
					return (34397924 + Z) % 268435456
				end)(h)
				local N = {}
				for j = 1, 60 do
					Z = (
						(function(Wd)
								local kr = (26169205 + #o) % 268435456
								for hG = 1, #Wd do
									kr = (kr * 54947 + #Wd[hG] + hG * 92 + 174682384) % 268435456
								end
								return (212812053 + kr) % 268435456
							end)(h)
							* Z
						+ (function(kr)
							local Wd = (267253574 + #o) % 268435456
							for hG = 1, #kr do
								Wd = (Wd * 30934 + #kr[hG] + hG * 50571 + 227200639) % 268435456
							end
							return (265520724 + Wd) % 268435456
						end)(h)
					) % 268435456
					N[j] = (o[j] - (Z % 256 + d(Z / 256) % 256 + d(Z / 65536) % 256 + d(Z / 16777216)) % 256) % 256
				end
				for j = 0, 9 do
					z[M(N[j * 5 + 1], N[j * 5 + 2], N[j * 5 + 3], N[j * 5 + 4], N[j * 5 + 5])] = M(N[50 + j + 1])
				end
			end
			local function N(Z, j)
				local Wd = 4820 + 687
				local kr = Wd * 307 - 4400
				if kr * kr >= 0 then
					local hG = kr - Wd
				end
				local hG = kr + 1 - 1
				local NC = 5861 + 8019
				local BA = NC * 262 - 4873
				if BA * BA >= 0 then
					local Gg = BA - NC
				end
				local Gg = BA + 1 - 1
				local TG = P(Z, j)
				if TG < 128 then
					return TG, j + 1
				end
				local eG = P(Z, j + 1)
				if eG < 128 then
					return TG - 128 + eG * 128, j + 2
				end
				local qm = P(Z, j + 2)
				if qm < 128 then
					local WA = TG - 128 + (eG - 128) * 128 + qm * 16384
					if WA >= 2147483648 then
						WA -= 4294967296
					end
					return WA, j + 3
				end
				local WA = P(Z, j + 3)
				local op = TG - 128 + (eG - 128) * 128 + (qm - 128) * 16384 + WA * 2097152
				if op >= 2147483648 then
					op -= 4294967296
				end
				return op, j + 4
			end
			local function op(WA, qm)
				local eG = 8668 + 1854
				local TG = eG * 926 - 9853
				if TG * TG >= 0 then
					local Gg = TG - eG
				end
				local Gg = TG + 1 - 1
				local BA = 2869 + 9576
				local NC = BA * 853 - 2930
				if NC * NC >= 0 then
					local hG = NC - BA
				end
				local hG = NC + 1 - 1
				return P(WA, qm) + P(WA, qm + 1) * 256
			end
			local function hG(NC)
				local BA = 164 + 2950
				local Gg = BA * 277 - 6671
				if Gg * Gg >= 0 then
					local TG = Gg - BA
				end
				local TG = Gg + 1 - 1
				local eG = 6216 + 7896
				local qm = eG * 483 - 2347
				if qm * qm >= 0 then
					local WA = qm - eG
				end
				local WA = qm + 1 - 1
				local kr = ""
				local Wd = 1
				local j = #NC
				local Z = 107
				while Wd <= j do
					if P(NC, Wd) == Z then
						kr = kr .. (z[f(NC, Wd, Wd + 4)] or "")
						Wd += 5
					else
						kr = kr .. f(NC, Wd, Wd)
						Wd += 1
					end
				end
				local kx = ""
				j = #kr
				for mg = 1, j, 5 do
					local YI = 0
					YI = YI * 94 + T[P(kr, mg)]
					YI = YI * 94 + T[P(kr, mg + 1)]
					YI = YI * 94 + T[P(kr, mg + 2)]
					YI = YI * 94 + T[P(kr, mg + 3)]
					YI = YI * 94 + T[P(kr, mg + 4)]
					local OC = YI % 256
					YI = d(YI / 256)
					local IZ = YI % 256
					YI = d(YI / 256)
					local nT = YI % 256
					YI = d(YI / 256)
					local JZ = YI % 256
					kx = kx .. M(OC, IZ, nT, JZ)
				end
				local JZ = P(kx, 1) + P(kx, 2) * 256 + P(kx, 3) * 65536 + P(kx, 4) * 16777216
				local nT = 9287 + 7827
				local IZ = nT * 333 - 3880
				if IZ * IZ >= 0 then
					local OC = IZ - nT
				end
				local OC = IZ + 1 - 1
				return f(kx, 5, 4 + JZ)
			end
			local IZ = (function(OC)
				local IZ = (96167417 + 0) % 268435456
				for nT = 1, #OC do
					IZ = (IZ * 10734 + #OC[nT] + nT * 30979 + 183848201) % 268435456
				end
				return (242762458 + IZ) % 268435456
			end)(h)
			local nT = (function(OC)
				local nT = (60369412 + 0) % 268435456
				for JZ = 1, #OC do
					nT = (nT * 54986 + #OC[JZ] + JZ * 15790 + 190834236) % 268435456
				end
				return (268140508 + nT) % 268435456
			end)(h)
			local JZ = (function(OC)
				local JZ = (128344386 + 0) % 268435456
				for kx = 1, #OC do
					JZ = (JZ * 22143 + #OC[kx] + kx * 14965 + 53278431) % 268435456
				end
				return (228767310 + JZ) % 268435456
			end)(h)
			local kx = (function(OC)
				local kx = (191475518 + 0) % 268435456
				for Z = 1, #OC do
					kx = (kx * 52194 + #OC[Z] + Z * 20486 + 63304452) % 268435456
				end
				return (219151928 + kx) % 268435456
			end)(h)
			local Z = (function(OC)
				local Z = (168450504 + 0) % 268435456
				for j = 1, #OC do
					Z = (Z * 23574 + #OC[j] + j * 20749 + 155546773) % 268435456
				end
				return (194480966 + Z) % 268435456
			end)(h)
			local j = (function(OC)
				local j = (258596760 + 0) % 268435456
				for Wd = 1, #OC do
					j = (j * 50622 + #OC[Wd] + Wd * 22426 + 8217449) % 268435456
				end
				return (236009785 + j) % 268435456
			end)(h)
			local Wd = (function(OC)
				local Wd = (185318385 + 0) % 268435456
				for kr = 1, #OC do
					Wd = (Wd * 39325 + #OC[kr] + kr * 34279 + 125933990) % 268435456
				end
				return (172277543 + Wd) % 268435456
			end)(h)
			local OC = { 137, 75, 35, 181, 103, 227, 138, 237, 11, 233, 110, 10, 125, 100, 226, 255 }
			local kr = 425938197190 + 694788791619 - 1120685052886
			for WA = 1, 16 do
				kr = (
					(846089843081 + 243401671281 - 1089479642287) * kr + (960331635135 + 758132574561 - 1718268237036)
				) % 268435456
				OC[WA] = (OC[WA] - (kr % 256 + d(kr / 256) % 256 + d(kr / 65536) % 256 + d(kr / 16777216)) % 256) % 256
			end
			local WA = M(OC[1], OC[2], OC[3], OC[1], OC[4], OC[5], OC[6], OC[7])
			local qm = M(OC[8], OC[2], OC[9], OC[10], OC[3], OC[1], OC[4], OC[5], OC[6], OC[7])
			local eG = M(OC[10], OC[11], OC[12], OC[13], OC[7])
			local TG = M(OC[5], OC[6], OC[14], OC[2])
			local Gg = M(OC[3])
			local BA = M(OC[2], OC[3])
			local NC = M(OC[15], OC[8], OC[2], OC[15], OC[16])
			local YI = {}
			local mg
			local MQ
			local nh = 7484 + 5109
			local du = nh * 509 - 9116
			if du * du >= 0 then
				local pJ = du - nh
			end
			local pJ = du + 1 - 1
			local Qx = 0
			local ez = 2123 + 6298
			local gn = ez * 251 - 3569
			if gn * gn >= 0 then
				local Tb = gn - ez
			end
			local Tb = gn + 1 - 1
			local CS = {}
			local wL, Rp, gN, pu
			local ZZ, sk, Kr, DT
			local UE
			local Wj
			local UW
			local Jc, ge, SB, UA, tY, YG, jO, dn, lt, ji, lK
			local ky
			local Lu
			local Qj
			local hj = 0
			local Qb, EX
			local dL
			local kl = function()
				local nW = 7910 + 8088
				local sp = nW * 928 - 4800
				if sp * sp >= 0 then
					local LJ = sp - nW
				end
				local LJ = sp + 1 - 1
				local Tq = 8565 + 7056
				local VD = Tq * 25 - 5436
				if VD * VD >= 0 then
					local Tc = VD - Tq
				end
				local Tc = VD + 1 - 1
				local Ki, kl = 0, 1
				while Ki < 4294967296 do
					Ki = (Ki * 1103515245 + 12345) % 268435456
					kl = (kl * 80659 + 95050511) % 268435456
					if Ki == kl and Ki == 123456789 then
						break
					end
				end
			end
			local Ki
			local Tc
			local VD = 8392 + 4181
			local Tq = VD * 213 - 1569
			if Tq * Tq >= 0 then
				local LJ = Tq - VD
			end
			local LJ = Tq + 1 - 1
			local sp
			local nW, mN
			local GQ
			mg = function(
				bY,
				nN,
				sj,
				hu,
				Os,
				QQ,
				sF,
				cd,
				SN,
				hl,
				QM,
				lX,
				dI,
				fL,
				IK,
				fH,
				ue,
				uF,
				Ww,
				Jn,
				wj,
				yD,
				xi,
				Em,
				Ph
			)
				local NO, xg, eS, Tx, Ls, hX, jq, xC, ps, mD, HO, Ys, oU, Ym, UC, NA, MH, Dv, uT, gx, sR, sd, Ll, wH, WQ =
					Em, dI, lX, nN, SN, fH, bY, Jn, Ww, wj, ue, QQ, QM, hu, hl, xi, IK, yD, uF, fL, cd, Ph, Os, sF, sj
				local kZ = (function()
					local EB = mD and mD[eS(116, 121, 112, 101)] or type
					local Ra = mD and mD[eS(112, 99, 97, 108, 108)] or pcall
					local HL = mD and mD[eS(120, 112, 99, 97, 108, 108)] or xpcall
					local rY = mD and mD[eS(101, 114, 114, 111, 114)] or error
					local uU = mD and mD[eS(114, 97, 119, 103, 101, 116)] or rawget
					local XQ = mD and mD[eS(114, 97, 119, 115, 101, 116)] or rawset
					local oG = mD and mD[eS(103, 101, 116, 109, 101, 116, 97, 116, 97, 98, 108, 101)] or getmetatable
					local mI = mD and mD[eS(115, 101, 116, 109, 101, 116, 97, 116, 97, 98, 108, 101)] or setmetatable
					local zQ = mD and mD[eS(116, 111, 115, 116, 114, 105, 110, 103)] or tostring
					local id = mD and mD[eS(116, 111, 110, 117, 109, 98, 101, 114)] or tonumber
					local SK = mD
							and mD[eS(115, 116, 114, 105, 110, 103)]
							and mD[eS(115, 116, 114, 105, 110, 103)][eS(103, 109, 97, 116, 99, 104)]
						or _G[eS(115, 116, 114, 105, 110, 103)]
							and _G[eS(115, 116, 114, 105, 110, 103)][eS(103, 109, 97, 116, 99, 104)]
					local Xp = mD and mD[eS(117, 110, 112, 97, 99, 107)]
						or _G[eS(117, 110, 112, 97, 99, 107)]
						or _G[eS(116, 97, 98, 108, 101)] and _G[eS(116, 97, 98, 108, 101)][eS(117, 110, 112, 97, 99, 107)]
					local OD = mD and mD[eS(112, 114, 105, 110, 116)] or print
					local FI = mD and mD[eS(119, 97, 114, 110)] or _G and _G[eS(119, 97, 114, 110)]
					local ap = mD[eS(110, 101, 119, 112, 114, 111, 120, 121)]
					local Hr = mD and mD[eS(100, 101, 98, 117, 103)] and mD[eS(100, 101, 98, 117, 103)][eS(
						105,
						110,
						102,
						111
					)] or _G[eS(100, 101, 98, 117, 103)] and _G[eS(100, 101, 98, 117, 103)][eS(105, 110, 102, 111)]
					local Qa = false
					local function tV()
						local cN = 0
						local Kl
						repeat
							cN += 1
						until cN == Kl
						return (nil)[1]
					end
					local function Kl()
						Qa = true
						tV()
					end
					local cN = {}
					local Oi
					local function qv()
						if EB(Xp) == eS(102, 117, 110, 99, 116, 105, 111, 110) then
							local lO = Ra(Xp, {}, 0, 64)
							if not lO then
								Qa = true
							end
						end
						if EB(Oi) == eS(116, 97, 98, 108, 101) then
							if EB(OD) == eS(102, 117, 110, 99, 116, 105, 111, 110) and Oi.print ~= OD then
								Qa = true
							end
							if EB(FI) == eS(102, 117, 110, 99, 116, 105, 111, 110) and Oi.warn ~= FI then
								Qa = true
							end
						end
					end
					local function lO()
						local function Pm()
							return (nil)[1]
						end
						if
							EB(Hr) == eS(102, 117, 110, 99, 116, 105, 111, 110)
							and EB(SK) == eS(102, 117, 110, 99, 116, 105, 111, 110)
							and EB(zQ) == eS(102, 117, 110, 99, 116, 105, 111, 110)
							and EB(id) == eS(102, 117, 110, 99, 116, 105, 111, 110)
						then
							local Ke, vg = Ra(Hr, Pm, eS(108))
							local IV, ec = Ra(Hr, Pm, eS(115))
							local DU
							local dt = HL(Pm, function(dt)
								for kZ in SK(zQ(dt), eS(58, 40, 37, 100, 43, 41, 58)) do
									DU = id(kZ)
								end
								return dt
							end)
							if
								dt
								or not Ke
								or EB(vg) ~= eS(110, 117, 109, 98, 101, 114)
								or not IV
								or EB(ec) ~= eS(115, 116, 114, 105, 110, 103)
								or ec == eS(91, 67, 93)
								or EB(DU) ~= eS(110, 117, 109, 98, 101, 114)
								or vg ~= DU
							then
								Qa = true
							end
							local kZ, Mp = Ra(Hr, rY, eS(115))
							if kZ and EB(Mp) == eS(115, 116, 114, 105, 110, 103) and Mp ~= eS(91, 67, 93) then
								Qa = true
							end
						end
						if EB(Hr) == eS(102, 117, 110, 99, 116, 105, 111, 110) then
							local function Mp(kZ)
								if EB(kZ) ~= eS(102, 117, 110, 99, 116, 105, 111, 110) then
									return false
								end
								local dt, DU = Ra(Hr, kZ, eS(115))
								return dt and EB(DU) == eS(115, 116, 114, 105, 110, 103) and DU == eS(91, 67, 93)
							end
							local DU = mD and mD[eS(95, 71)] or _G
							if EB(DU) == eS(116, 97, 98, 108, 101) then
								local dt = uU(DU, eS(108, 111, 97, 100, 115, 116, 114, 105, 110, 103))
								local kZ = uU(DU, eS(108, 111, 97, 100))
								if EB(dt) == eS(102, 117, 110, 99, 116, 105, 111, 110) and not Mp(dt) then
									Qa = true
								end
								if EB(kZ) == eS(102, 117, 110, 99, 116, 105, 111, 110) and not Mp(kZ) then
									Qa = true
								end
							end
						end
					end
					local function Pm()
						if
							EB(EB) ~= eS(102, 117, 110, 99, 116, 105, 111, 110)
							or EB(Ra) ~= eS(102, 117, 110, 99, 116, 105, 111, 110)
							or EB(HL) ~= eS(102, 117, 110, 99, 116, 105, 111, 110)
							or EB(rY) ~= eS(102, 117, 110, 99, 116, 105, 111, 110)
							or EB(uU) ~= eS(102, 117, 110, 99, 116, 105, 111, 110)
							or EB(XQ) ~= eS(102, 117, 110, 99, 116, 105, 111, 110)
							or EB(oG) ~= eS(102, 117, 110, 99, 116, 105, 111, 110)
							or EB(mI) ~= eS(102, 117, 110, 99, 116, 105, 111, 110)
						then
							tV()
						end
					end
					local function DU()
						if EB(ap) == eS(102, 117, 110, 99, 116, 105, 111, 110) then
							local Mp, kZ = Ra(ap, true)
							if not Mp or kZ == nil then
								Qa = true
							else
								local dt, ec = Ra(oG, kZ)
								if not dt or EB(ec) ~= eS(116, 97, 98, 108, 101) then
									Qa = true
								else
									ec[eS(95, 95, 116, 111, 115, 116, 114, 105, 110, 103)] = Kl
									ec[eS(95, 95, 99, 111, 110, 99, 97, 116)] = Kl
									ec[eS(95, 95, 99, 97, 108, 108)] = Kl
									cN[#cN + 1] = kZ
								end
							end
						end
						local function kZ(Mp)
							local ec = {}
							local dt = {
								[eS(95, 95, 109, 101, 116, 97, 116, 97, 98, 108, 101)] = Mp,
								[eS(95, 95, 116, 111, 115, 116, 114, 105, 110, 103)] = Kl,
								[eS(95, 95, 99, 111, 110, 99, 97, 116)] = Kl,
								[eS(95, 95, 105, 116, 101, 114)] = Kl,
							}
							local IV, vg = Ra(mI, ec, dt)
							if not IV or vg ~= ec then
								Qa = true
								return
							end
							local Ke, Mj = Ra(oG, ec)
							if not Ke or Mj ~= Mp then
								Qa = true
							end
							cN[#cN + 1] = ec
						end
						kZ(eS(116, 100, 100, 120, 104, 112, 102, 99, 112, 105))
						kZ(eS(108, 115, 112, 104, 104, 102, 115, 116, 100, 109))
						kZ(eS(118, 121, 109, 103, 103, 108, 107, 104, 113, 114))
					end
					local function kZ()
						local Mj = mD and mD[eS(103, 101, 116, 102, 101, 110, 118)] or getfenv
						if EB(Mj) == eS(102, 117, 110, 99, 116, 105, 111, 110) then
							local Ke, vg = Ra(Mj)
							if Ke then
								Oi = vg
							end
						end
						if Oi == nil then
							Oi = mD and mD[eS(95, 71)] or _G
						end
						if
							EB(Oi) ~= eS(116, 97, 98, 108, 101)
							or EB(OD) ~= eS(102, 117, 110, 99, 116, 105, 111, 110)
							or FI ~= nil and EB(FI) ~= eS(102, 117, 110, 99, 116, 105, 111, 110)
						then
							Qa = true
						end
						local vg = {}
						local Ke = function() end
						local IV = Ra(XQ, vg, -271823, Ke)
						if not IV or uU(vg, -271823) ~= Ke then
							Qa = true
						end
						XQ(vg, -271823, nil)
						if uU(vg, -271823) ~= nil or Ra(rY) then
							Qa = true
						end
					end
					qv()
					lO()
					Pm()
					DU()
					kZ()
					if Qa then
						tV()
					end
					return cN
				end)()
				local DU, Pm, lO, qv, Oi, cN, Kl, tV = wH(WQ)
				local Qa = tV
				local Hr = tV * 257
				local ap = { 125, 77, 96 }
				local FI = 0
				FI = (FI * 257 + 240) % 268435456
				FI = (FI * 257 + 11) % 268435456
				for OD = 1, #ap do
					FI = (FI * 257 + ap[OD]) % 268435456
				end
				local Xp = (
					FI
					- (function(OD)
						local Xp = (188035349 + 0) % 268435456
						for SK = 1, #OD do
							Xp = (Xp * 11517 + #OD[SK] + SK * 39544 + 83974006) % 268435456
						end
						return (71309547 + Xp) % 268435456
					end)(HO)
				) % 268435456
				Qa = (Qa + Xp) % 268435456
				Hr = (Hr + Xp * (240 + 1)) % 268435456
				local OD, SK, id, zQ
				local mI = 0
				local oG = 1
				while oG <= #ap do
					local XQ = (ap[oG] - (240 + oG * 11) % 256) % 256
					if 71 == XQ then
						SK, id, zQ = OD(HO, Ys, DU, Pm, lO, qv, (Oi + Qa) % 268435456, cN)
					elseif 79 == XQ then
						mI = 1
					elseif 130 == XQ then
						OD = Kl(xg, eS, Tx, Ls, NO, oU, Ym, UC, NA, MH, Dv, uT, gx, sR, sd, Ll)
					else
						Qa = (
							Qa
							+ (function(uU)
								local rY = (133896116 + 0) % 268435456
								for HL = 1, #uU do
									rY = (rY * 43782 + #uU[HL] + HL * 59273 + 52608295) % 268435456
								end
								return (214484304 + rY) % 268435456
							end)(HO)
						) % 268435456
						Hr = (
							Hr
							+ (function(rY)
									local uU = (133896116 + 0) % 268435456
									for HL = 1, #rY do
										uU = (uU * 43782 + #rY[HL] + HL * 59273 + 52608295) % 268435456
									end
									return (214484304 + uU) % 268435456
								end)(HO)
								* (240 + 1)
						) % 268435456
					end
					oG += 1
				end
				if mI ~= 1 then
					Qa = (
						Qa
						+ (function(XQ)
							local uU = (133896116 + 0) % 268435456
							for rY = 1, #XQ do
								uU = (uU * 43782 + #XQ[rY] + rY * 59273 + 52608295) % 268435456
							end
							return (214484304 + uU) % 268435456
						end)(HO)
					) % 268435456
					Hr = (
						Hr
						+ (function(uU)
								local XQ = (133896116 + 0) % 268435456
								for rY = 1, #uU do
									XQ = (XQ * 43782 + #uU[rY] + rY * 59273 + 52608295) % 268435456
								end
								return (214484304 + XQ) % 268435456
							end)(HO)
							* (11 + 1)
					) % 268435456
				end
				ap = nil
				local XQ = {}
				local rY = (
					(function(uU)
						local rY = (102452934 + 0) % 268435456
						for HL = 1, #uU do
							rY = (rY * 29242 + #uU[HL] + HL * 29802 + 18942273) % 268435456
						end
						return (105343007 + rY) % 268435456
					end)(HO) + Qa
				) % 67108859
				local HL = (
					(function(uU)
						local HL = (71309340 + 0) % 268435456
						for Ra = 1, #uU do
							HL = (HL * 6415 + #uU[Ra] + Ra * 62663 + 146333524) % 268435456
						end
						return (87595431 + HL) % 268435456
					end)(HO) + Hr
				) % 67108819
				local uU, Ra, EB, IV, Ke, vg, Mj = XQ, SK, id, rY, HL, zQ, kZ
				XQ, SK, id, rY, HL, zQ, kZ = nil, nil, nil, nil, nil, nil, nil
				return function()
					return uU, Ra, EB, IV, Ke, vg, Mj
				end
			end
			Wj = function()
				local Mj = {
					156,
					190,
					241,
					65,
					123,
					180,
					4,
					50,
					134,
					180,
					246,
					65,
					123,
					2,
					95,
					90,
					232,
					243,
					35,
					57,
					234,
					114,
					85,
					11,
					223,
					8,
					130,
					239,
					82,
					190,
					63,
					207,
					163,
					245,
					76,
					62,
					64,
					235,
					167,
					70,
					242,
					168,
					93,
					37,
					103,
					254,
					180,
					75,
					26,
					113,
					231,
					45,
					46,
					234,
					134,
					30,
					162,
					70,
					210,
					107,
					65,
					130,
					85,
					29,
					140,
					176,
					57,
					194,
					56,
					201,
					79,
					235,
					157,
					147,
					121,
					95,
					67,
					53,
					162,
					88,
					226,
					53,
					12,
					69,
					241,
					187,
					136,
					178,
					234,
					168,
					207,
					22,
					187,
					135,
					45,
					225,
					166,
					236,
					236,
					247,
					19,
					21,
					39,
					44,
					66,
					29,
					134,
					229,
					237,
					35,
					181,
					88,
					219,
					123,
					14,
					167,
					60,
					189,
					94,
					248,
					139,
					208,
					104,
					118,
					15,
					55,
					134,
					173,
					242,
					47,
					84,
					152,
					141,
					195,
					148,
					212,
					17,
					75,
					136,
					151,
					33,
					247,
					36,
					42,
					23,
					172,
					50,
					181,
					70,
					225,
					27,
					57,
					125,
					179,
					231,
					16,
					208,
					225,
					12,
					244,
					228,
					229,
					202,
					186,
					181,
					175,
					232,
					23,
					239,
					236,
					218,
					192,
					165,
					142,
					126,
					120,
					100,
					83,
					103,
					79,
					151,
					189,
					224,
					100,
					217,
					30,
					150,
					9,
					115,
					204,
					44,
					148,
					5,
					7,
					138,
					238,
					214,
					34,
					130,
					235,
					67,
					97,
					230,
					54,
					143,
					229,
					56,
					132,
					222,
					44,
					58,
					228,
					59,
					158,
					7,
					223,
					144,
					100,
					12,
					213,
					146,
					194,
					36,
					40,
					122,
					45,
					210,
					117,
					45,
					210,
					136,
					14,
					165,
					80,
					232,
					144,
					189,
					39,
					155,
					250,
					159,
					198,
					57,
					189,
					51,
					163,
					30,
					126,
					254,
					124,
					225,
					100,
					187,
					213,
					38,
					3,
					200,
					78,
					170,
					242,
					103,
					215,
					62,
					148,
					241,
					86,
					12,
					5,
					58,
					196,
					223,
					233,
					241,
					11,
					31,
					52,
					71,
					85,
					89,
					251,
					182,
					15,
					30,
					196,
					158,
					184,
					182,
					170,
					61,
					245,
					180,
					86,
					206,
					155,
					125,
					81,
					42,
					22,
					113,
					54,
					111,
					12,
					78,
					205,
					104,
					245,
					126,
					6,
					68,
					217,
					65,
					8,
					247,
					141,
					117,
					84,
					57,
					38,
					16,
					233,
					202,
					193,
					145,
					136,
					89,
					59,
					49,
					20,
					243,
					218,
					236,
					195,
					195,
					39,
					26,
					52,
					52,
					42,
					61,
					65,
					0,
					135,
					229,
					32,
					79,
					150,
					120,
					171,
					155,
					175,
					64,
					234,
					168,
					130,
					69,
					35,
					162,
					251,
					213,
					160,
					116,
					53,
					255,
					219,
					156,
					72,
					42,
					141,
					28,
					31,
					243,
					37,
					114,
					183,
					166,
					231,
					221,
					233,
					212,
					93,
					247,
					126,
					11,
					147,
					35,
					169,
					56,
					5,
					228,
					254,
					159,
					88,
					44,
					248,
					197,
					156,
					99,
					48,
					10,
					217,
					161,
					125,
					157,
					94,
					127,
					189,
					237,
					23,
					76,
					102,
					160,
					216,
					247,
					141,
					18,
					178,
					218,
					72,
					83,
					121,
					121,
					141,
					170,
					193,
					217,
					239,
					0,
					7,
					124,
					1,
					3,
					171,
					87,
					11,
					176,
					82,
					2,
					188,
					64,
					141,
					52,
					145,
					235,
					62,
					159,
					244,
					134,
					189,
					73,
					94,
					126,
					171,
					205,
					157,
					195,
					2,
					61,
					142,
					190,
					23,
					224,
					141,
					86,
					17,
					200,
					126,
					234,
					132,
					143,
					59,
					52,
					75,
					176,
					132,
					137,
					194,
					159,
					165,
					182,
					190,
					221,
					3,
					31,
					231,
					240,
					246,
					255,
					202,
					117,
					155,
					177,
					114,
					191,
					32,
					138,
					227,
					69,
					116,
					117,
					236,
					87,
					231,
					88,
					32,
					46,
					250,
					47,
					211,
					116,
					14,
					182,
					82,
					5,
					169,
					126,
					31,
					221,
					137,
					16,
					207,
					135,
					43,
					36,
					157,
					153,
					87,
					5,
					133,
					196,
					185,
					239,
					5,
					9,
					35,
					62,
					97,
					18,
					58,
					86,
					141,
					169,
					208,
					13,
					36,
					12,
					115,
					129,
					115,
					241,
					148,
					29,
					182,
					88,
					244,
					145,
					44,
					194,
					78,
					19,
					181,
					227,
					135,
					52,
					208,
					125,
					48,
					42,
					35,
					157,
					171,
					134,
					40,
					88,
					119,
					167,
					227,
					17,
					60,
					96,
					146,
					184,
					47,
					63,
					107,
					10,
					75,
					158,
					224,
					53,
					116,
					187,
					192,
					104,
					159,
					60,
					127,
					211,
					20,
					91,
					157,
					231,
					39,
					51,
					35,
					161,
					223,
					198,
					88,
					221,
					115,
					65,
					70,
					104,
					210,
					16,
					104,
					170,
					232,
					66,
					128,
					207,
					23,
					134,
					206,
					176,
					26,
					161,
					75,
					7,
					175,
					8,
					178,
					227,
					218,
					225,
					136,
					110,
					134,
					115,
					30,
					191,
					22,
					108,
					162,
					233,
					26,
					74,
					145,
					182,
					1,
					38,
					95,
					161,
					210,
					114,
					67,
					164,
					240,
					115,
					152,
				}
				local vg = {
					[1913177497] = { 238, 3, 66, 114 },
					[1183952898] = { 449, 5, 183, 34 },
					[131645916] = { 242, 11, 234, 117 },
					[1632638400] = { 74, 5, 74, 229 },
					[623449726] = { 461, 7, 180, 186 },
					[497260597] = { 473, 15, 56, 10 },
					[1232758709] = { 418, 11, 198, 20 },
					[1054105864] = { 197, 5, 3, 95 },
					[223583735] = { 293, 6, 128, 219 },
					[1858685975] = { 441, 6, 101, 92 },
					[1396599950] = { 160, 7, 155, 242 },
					[1098212889] = { 537, 8, 115, 42 },
					[2008001177] = { 352, 4, 181, 199 },
					[448704036] = { 66, 6, 195, 132 },
					[3317017] = { 17, 4, 86, 30 },
					[414394002] = { 627, 4, 138, 176 },
					[1021571137] = { 334, 6, 177, 4 },
					[830317702] = { 586, 7, 177, 68 },
					[2031039315] = { 572, 10, 143, 45 },
					[1867617413] = { 315, 16, 40, 228 },
					[1008296497] = { 53, 8, 78, 151 },
					[1451387043] = { 203, 8, 29, 85 },
					[500771008] = { 455, 5, 33, 62 },
					[856142473] = { 636, 3, 47, 254 },
					[1448400496] = { 215, 7, 251, 188 },
					[1575817833] = { 257, 10, 19, 99 },
					[1185969156] = { 2, 12, 10, 65 },
					[83035268] = { 361, 5, 63, 201 },
					[1274966827] = { 499, 5, 136, 122 },
					[141473096] = { 607, 4, 208, 141 },
					[939957106] = { 37, 7, 44, 173 },
					[1036520604] = { 514, 9, 186, 172 },
					[911237811] = { 492, 5, 158, 96 },
					[1192941572] = { 561, 6, 195, 171 },
					[904817065] = { 270, 10, 74, 17 },
					[1794015821] = { 404, 10, 188, 47 },
					[794291109] = { 379, 9, 226, 139 },
					[1169477498] = { 45, 4, 87, 163 },
					[726447197] = { 431, 8, 226, 173 },
					[415221754] = { 392, 11, 38, 207 },
					[245688763] = { 615, 8, 97, 73 },
					[1544063418] = { 343, 4, 76, 54 },
					[1756801047] = { 285, 4, 57, 3 },
					[1841058095] = { 110, 12, 40, 148 },
					[1100719850] = { 643, 12, 205, 56 },
					[783940119] = { 26, 6, 55, 110 },
					[846709719] = { 528, 8, 39, 21 },
					[682051499] = { 135, 5, 244, 58 },
					[1267126172] = { 371, 3, 74, 59 },
					[360536777] = { 549, 10, 239, 153 },
					[1945346128] = { 225, 6, 88, 174 },
					[268095887] = { 84, 4, 12, 194 },
					[146666980] = { 595, 8, 144, 69 },
					[586680284] = { 183, 10, 51, 102 },
					[929766536] = { 145, 6, 27, 142 },
					[2073515671] = { 234, 3, 88, 151 },
					[982052410] = { 125, 8, 100, 57 },
					[431029307] = { 99, 7, 120, 13 },
					[2146936116] = { 168, 11, 177, 237 },
					[1479013277] = { 507, 6, 25, 163 },
					[1359350563] = { 303, 8, 80, 140 },
					[1917656334] = { 92, 6, 238, 182 },
					[1530816220] = { 152, 4, 134, 63 },
				}
				local Ke = {}
				local IV
				local EB = ""
				do
					local function Ra(uU)
						local HL = coroutine.wrap(function()
							return uU(65)
						end)
						local rY, XQ = pcall(HL)
						if not rY or XQ ~= "A" then
							return "65:" .. tostring(XQ)
						end
						local oG = coroutine.wrap(function()
							return uU(90)
						end)
						local mI, zQ = pcall(oG)
						if not mI or zQ ~= "Z" then
							return "90:" .. tostring(zQ)
						end
						local id = coroutine.wrap(function()
							return uU(48)
						end)
						local SK, OD = pcall(id)
						if not SK or OD ~= "0" then
							return "48:" .. tostring(OD)
						end
						local Xp = coroutine.wrap(function()
							return uU(95)
						end)
						local FI, ap = pcall(Xp)
						if not FI or ap ~= "_" then
							return "95:" .. tostring(ap)
						end
						return nil
					end
					local function ap(FI)
						for Xp, OD in pairs(FI) do
							if type(OD) == "function" then
								local SK = Ra(OD)
								if SK == nil then
									return OD
								end
							end
						end
						return nil
					end
					local FI, OD = pcall(getmetatable, "")
					EB = "M=" .. tostring(FI) .. "/" .. type(OD)
					if FI and type(OD) == "table" then
						local Xp, id = pcall(function()
							local Xp = ap(OD)
							if not Xp then
								for SK, id in pairs(OD) do
									if type(id) == "table" then
										Xp = ap(id)
										if Xp then
											break
										end
									end
								end
							end
							return Xp
						end)
						if Xp then
							IV = id
						end
					end
					if not IV then
						local id, Xp = pcall(getfenv, 0)
						if id and type(Xp) == "table" then
							local zQ, SK = pcall(function()
								for SK, zQ in pairs(Xp) do
									if type(zQ) == "table" then
										local mI = ap(zQ)
										if mI then
											return mI
										end
									end
								end
								return nil
							end)
							if zQ then
								IV = SK
							end
						end
					end
					if not IV then
						local Xp, id = pcall(function()
							return ("\0")["char"]
						end)
						if Xp and type(id) == "function" then
							local SK = Ra(id)
							if SK == nil then
								IV = id
							else
								EB = EB .. ";L=" .. SK
							end
						else
							EB = EB .. ";L=" .. tostring(Xp) .. "/" .. type(id)
						end
					end
				end
				if not IV then
					return {
						0,
						function()
							return 0
						end,
					}
				end
				local OD, FI, ap = pcall, type, rawget
				local function Ra(id, Xp)
					local SK = FI(id)
					local zQ = nil
					if SK == "table" then
						local mI, oG = OD(ap, id, Xp)
						if mI then
							zQ = oG
						end
					end
					if zQ ~= nil then
						return zQ
					end
					local oG, mI = OD(function()
						return id[Xp]
					end)
					if oG then
						return mI
					end
					return nil
				end
				local function mI(oG)
					local zQ = Ke[oG]
					if zQ then
						return zQ
					end
					local SK = vg[oG]
					if not SK then
						return nil
					end
					local Xp = ""
					for id = 1, SK[2] do
						Xp = Xp .. IV((Mj[SK[1] + id - 1] - SK[3] - id * SK[4]) % 256)
					end
					Ke[oG] = Xp
					return Xp
				end
				local Xp, SK = pcall(getfenv, 0)
				if not Xp or type(SK) ~= "table" then
					SK = nil
				end
				local function zQ(oG, id)
					if type(oG) ~= "table" then
						return nil
					end
					local XQ = rawget(oG, id)
					if XQ ~= nil then
						return XQ
					end
					local rY, HL = pcall(function()
						return oG[id]
					end)
					if rY then
						return HL
					end
					return nil
				end
				local HL = zQ(SK, mI(1396599950))
				local rY, XQ = false, nil
				if type(HL) == "function" then
					rY, XQ = pcall(HL)
				end
				if not rY or type(XQ) ~= "table" then
					XQ = nil
				end
				local function id(oG)
					local uU = zQ(XQ, oG)
					if uU == nil then
						uU = zQ(SK, oG)
					end
					return uU
				end
				local uU = zQ(SK, mI(1858685975))
				local oG = zQ(SK, mI(1054105864))
				local Hr = zQ(SK, mI(1169477498))
				local Qa = id(mI(500771008))
				local tV = id(mI(1183952898))
				local Kl = id(mI(1530816220))
				local cN = id(mI(1917656334))
				local Oi = id(mI(1021571137))
				local qv = id(mI(982052410))
				local lO = id(mI(2008001177))
				local Pm = id(mI(223583735))
				local DU = id(mI(726447197))
				local kZ = id(mI(1451387043))
				local WQ = id(mI(1185969156))
				local wH = id(mI(1100719850))
				local Ll = id(mI(1192941572))
				local sd = Hr and zQ(Hr, mI(682051499))
				local sR = Hr and zQ(Hr, mI(2073515671))
				local gx = Hr and zQ(Hr, mI(83035268))
				local uT = uU and zQ(uU, mI(1756801047))
				local Dv = uU and zQ(uU, mI(1544063418))
				local MH = uU and zQ(uU, mI(1913177497))
				local NA = oG and zQ(oG, mI(783940119))
				local UC = oG and zQ(oG, mI(448704036))
				local Ym = oG and zQ(oG, mI(1192941572))
				local oU = id(mI(1867617413))
				local Ys = id(mI(415221754))
				local HO = id(mI(360536777))
				local mD = id(mI(904817065))
				local ps = id(mI(1232758709))
				local xC = id(mI(2031039315))
				local jq = id(mI(1945346128))
				local hX = id(mI(414394002))
				local Ls = id(mI(1008296497))
				local Tx = id(mI(830317702))
				local eS = id(mI(3317017))
				local xg = Qa and zQ(Qa, mI(431029307))
				local NO = Qa and zQ(Qa, mI(141473096))
				local Ph = Qa and zQ(Qa, mI(1841058095))
				local Em = Qa and zQ(Qa, mI(131645916))
				local xi = Qa and zQ(Qa, mI(146666980))
				local yD = Qa and zQ(Qa, mI(794291109))
				local wj = Qa and zQ(Qa, mI(1794015821))
				local Jn = Kl and Kl(NO) == "function" and NO or xg
				local Ww = mI(623449726)
				OD, FI, ap = tV, Kl, cN
				do
					local uF = ""
					local function ue(fH, IK)
						if Kl(IK) ~= "function" then
							uF = uF .. fH .. ","
						end
					end
					ue("identifyexecutor", oU)
					ue("checkcaller", Ys)
					ue("iscclosure", HO)
					ue("islclosure", mD)
					ue("newcclosure", ps)
					ue("loadstring", xC)
					ue("typeof", jq)
					if Kl(xg) ~= "function" and Kl(NO) ~= "function" then
						uF = uF .. "debug.info,"
					end
					ue("debug.getconstants", Ph)
					ue("debug.getupvalues", Em)
					if Kl(xi) ~= "function" and Kl(yD) ~= "function" then
						uF = uF .. "debug.getproto,"
					end
					ue("debug.setupvalue", wj)
					if Kl(hX) ~= "table" and Kl(hX) ~= "userdata" then
						uF = uF .. "game,"
					end
					if Kl(Ls) ~= "table" then
						uF = uF .. "Instance,"
					end
					if Kl(Tx) ~= "table" then
						uF = uF .. "Vector3,"
					end
					if Kl(eS) ~= "table" then
						uF = uF .. "task,"
					end
					if uF ~= "" then
						error(
							"[Obsucvim] this executor lacks APIs the hardened build requires: "
								.. uF
								.. " - use the compatible build (--no-bind-executor) here, or a Synapse-class executor",
							0
						)
					end
				end
				local ue = 0
				local uF = 1
				local IK = 0
				local fH = 501215084 % 2147483647
				local fL = 0
				local dI = (fH * 65599 + 1941807579 + fL) % 2147483647
				local lX = (fH * 4099 + 602552662 + fL % 104729) % 2147483647
				local QM = (fH * 8191 + 301032434 + fL % 65521 * 131) % 2147483647
				local hl = false
				local SN = false
				local cd = 235696870
				local sF = 0
				local QQ = 0
				local Os = false
				local hu = 968102153
				local sj = -1
				local nN = -1
				local bY = -1
				local dt = 235696870
				local function ec()
					hl = true
					fL = 0
					cd = dt
				end
				local function Mp(GZ, SP)
					GZ %= 2147483648
					SP %= 2147483648
					local BC = 0
					local aJ = 1
					for Fk = 0, 30 do
						local GC = GZ % 2
						local Lz = SP % 2
						if GC ~= Lz then
							BC += aJ
						end
						GZ = (GZ - GC) / 2
						SP = (SP - Lz) / 2
						aJ *= 2
					end
					return BC
				end
				local function aJ()
					local BC = sF % 65536
					local SP = (sF - BC) / 65536
					return (BC * 65599 + SP * 257 + fH * 4099 + dI + lX + QM + fL + 2342953557) % 2147483647
				end
				local function SP()
					dI = (fH * 65599 + 1941807579 + fL) % 2147483647
					lX = (fH * 4099 + 602552662 + fL % 104729) % 2147483647
					QM = (fH * 8191 + 301032434 + fL % 65521 * 131) % 2147483647
				end
				local function BC()
					if Kl == nil then
						return false
					end
					if
						zQ(SK, mI(1858685975)) ~= uU
						or zQ(SK, mI(1054105864)) ~= oG
						or zQ(SK, mI(1169477498)) ~= Hr
						or zQ(SK, mI(500771008)) ~= Qa and zQ(XQ, mI(500771008)) ~= Qa
						or zQ(SK, mI(1183952898)) ~= tV
						or zQ(SK, mI(1530816220)) ~= Kl
						or zQ(SK, mI(1917656334)) ~= cN
						or zQ(SK, mI(1021571137)) ~= Oi
						or zQ(SK, mI(2008001177)) ~= lO
						or zQ(SK, mI(1100719850)) ~= wH
						or zQ(SK, mI(1185969156)) ~= WQ
						or zQ(SK, mI(982052410)) ~= qv
						or zQ(SK, mI(1451387043)) ~= kZ
						or zQ(SK, mI(223583735)) ~= Pm
						or zQ(SK, mI(726447197)) ~= DU
						or zQ(uU, mI(1756801047)) ~= uT
						or zQ(uU, mI(1544063418)) ~= Dv
						or zQ(uU, mI(1913177497)) ~= MH
						or zQ(oG, mI(783940119)) ~= NA
						or zQ(oG, mI(448704036)) ~= UC
						or zQ(Hr, mI(83035268)) ~= gx
					then
						return false
					end
					if not SK or Kl(HL) ~= "function" or zQ(SK, mI(1396599950)) ~= HL then
						return false
					end
					local GZ, Lz = tV(HL)
					if not GZ or Lz ~= XQ then
						return false
					end
					if
						id(mI(1867617413)) ~= oU
						or id(mI(415221754)) ~= Ys
						or id(mI(360536777)) ~= HO
						or id(mI(904817065)) ~= mD
						or id(mI(1232758709)) ~= ps
						or id(mI(2031039315)) ~= xC
						or id(mI(1945346128)) ~= jq
						or id(mI(414394002)) ~= hX
						or id(mI(1008296497)) ~= Ls
						or id(mI(830317702)) ~= Tx
						or id(mI(3317017)) ~= eS
					then
						return false
					end
					if
						not Qa
						or zQ(Qa, mI(431029307)) ~= xg
						or zQ(Qa, mI(141473096)) ~= NO
						or zQ(Qa, mI(1841058095)) ~= Ph
						or zQ(Qa, mI(131645916)) ~= Em
						or zQ(Qa, mI(146666980)) ~= xi
						or zQ(Qa, mI(794291109)) ~= yD
						or zQ(Qa, mI(1794015821)) ~= wj
					then
						return false
					end
					return true
				end
				local function Lz(GZ, GC)
					if Kl(GZ) ~= "table" then
						return false
					end
					for Fk, br in lO, GZ do
						if br == GC then
							return true
						end
					end
					return false
				end
				local function GC(GZ)
					return Kl(GZ) == "table" and lO(GZ) == nil
				end
				local function GZ(br, Fk)
					if Kl(br) ~= "function" then
						return false
					end
					local PA, HH = tV(HO, br)
					local nz, Ji = tV(mD, br)
					return PA and nz and HH == Fk and Ji == not Fk
				end
				local function Ji()
					if
						Kl(oU) ~= "function"
						or Kl(Ys) ~= "function"
						or Kl(HO) ~= "function"
						or Kl(mD) ~= "function"
						or Kl(ps) ~= "function"
						or Kl(xC) ~= "function"
						or Kl(jq) ~= "function"
						or Kl(Jn) ~= "function"
						or Kl(Ph) ~= "function"
						or Kl(Em) ~= "function"
						or Kl(xi) ~= "function" and Kl(yD) ~= "function"
						or Kl(wj) ~= "function"
					then
						return false, 0
					end
					if XQ == SK then
						return false, 0
					end
					local nz = zQ(SK, mI(497260597))
					local HH = zQ(XQ, mI(497260597))
					local PA, Fk = {}, {}
					local br, Cv = false, false
					local JF = tV(function()
						Oi(SK, mI(497260597), PA)
						br = zQ(XQ, mI(497260597)) ~= PA
						Oi(XQ, mI(497260597), Fk)
						local OT, JF = tV(HL)
						Cv = OT and JF == XQ and zQ(JF, mI(497260597)) == Fk
					end)
					local OT = tV(Oi, SK, mI(497260597), nz)
					local dT = tV(Oi, XQ, mI(497260597), HH)
					if not JF or not OT or not dT or not br or not Cv then
						return false, 0
					end
					local nA, Go, Yt = tV(oU)
					local pB, Js, SW = tV(oU)
					if
						not nA
						or not pB
						or Kl(Go) ~= "string"
						or Kl(Yt) ~= "string"
						or Kl(SW) ~= "string"
						or #Go < 1
						or #Go > 128
						or #Yt > 128
						or Go ~= Js
						or Yt ~= SW
					then
						return false, 0
					end
					local Sv, wD = tV(Ys)
					if not Sv or wD ~= true then
						return false, 0
					end
					if
						Kl(hX) ~= "table" and Kl(hX) ~= "userdata"
						or Kl(Ls) ~= "table"
						or Kl(Tx) ~= "table"
						or Kl(eS) ~= "table"
					then
						return false, 0
					end
					local eg, Vd, CV = tV(function()
						local NZ = ""
						NZ = NZ .. "g:" .. Kl(hX)
						local OI = zQ(hX, mI(586680284))
						local vs, CF = tV(function()
							return hX[mI(586680284)]
						end)
						NZ = NZ .. ",rp:" .. tostring(vs) .. "/" .. Kl(CF) .. ",er:" .. Kl(OI)
						if OI == nil and vs then
							OI = CF
						end
						NZ = NZ .. ",gs:" .. Kl(OI)
						local si, tZ = tV(OI, hX, mI(1448400496))
						NZ = NZ .. ",pl:" .. tostring(si) .. "/" .. Kl(tZ)
						local MK = nil
						if tZ ~= nil then
							local WD, gZ = tV(function()
								return zQ(tZ, mI(1036520604))
							end)
							if WD then
								MK = gZ
							end
							if MK == nil then
								local FA, EL = tV(function()
									return tZ[mI(1036520604)]
								end)
								if FA then
									MK = EL
								end
							end
						end
						NZ = NZ .. ",cn:" .. tostring(MK)
						local gZ = zQ(Tx, mI(1267126172))
						if gZ == nil then
							local WD, EL = tV(function()
								return Tx[mI(1267126172)]
							end)
							if WD then
								gZ = EL
							end
						end
						NZ = NZ .. ",vn:" .. Kl(gZ)
						local EL, WD = tV(gZ)
						NZ = NZ .. ",v3:" .. tostring(EL) .. "/" .. jq(WD)
						local FA = jq(WQ({}, {}))
						NZ = NZ .. ",smt:" .. tostring(FA)
						local ws = zQ(Ls, mI(1267126172))
						if ws == nil then
							local CV, Kn = tV(function()
								return Ls[mI(1267126172)]
							end)
							if CV then
								ws = Kn
							end
						end
						NZ = NZ .. ",in:" .. Kl(ws)
						local Kn = zQ(eS, mI(268095887))
						local CV = zQ(eS, mI(1274966827))
						local Vd = zQ(eS, mI(1632638400))
						NZ = NZ .. ",tw:" .. Kl(Kn) .. ",tsp:" .. Kl(CV) .. ",tdf:" .. Kl(Vd)
						local eg = si == true
							and tZ ~= nil
							and MK == mI(1448400496)
							and EL == true
							and jq(WD) == mI(830317702)
							and FA == "table"
							and Kl(ws) == "function"
							and Kl(Kn) == "function"
							and Kl(CV) == "function"
							and Kl(Vd) == "function"
						return eg == true, NZ
					end)
					if not eg or Vd ~= true then
						return false, 0
					end
					local Kn = { uT, Dv, MH, NA, UC, gx, Pm, tV, Kl, kZ, DU, cN, Oi, qv, lO, WQ, wH, Ym or Ll, Jn }
					for ws = 1, #Kn do
						if not GZ(Kn[ws], true) then
							return false, 0
						end
					end
					local function ws(FA)
						return FA
					end
					if not GZ(ws, false) then
						return false, 0
					end
					local FA = tV(Ph, uT)
					local WD, EL = tV(Em, uT)
					local gZ = tV(wj, uT, 1, 0)
					if FA or gZ or WD and not GC(EL) then
						return false, 0
					end
					if Kl(xi) == "function" then
						local MK = tV(xi, uT, 1)
						if MK then
							return false, 0
						end
					end
					if Kl(yD) == "function" then
						local MK = tV(yD, uT)
						if MK then
							return false, 0
						end
					end
					local MK = 137873413
					local function tZ(si)
						MK = (MK * 31 + si) % 4294967296
					end
					local function si()
						return 919907151
					end
					local CF, vs = tV(Ph, si)
					if not CF or Kl(vs) ~= "table" then
						return false, 0
					end
					tZ(919907151)
					local function OI(NZ)
						hu = (hu + NZ) % 2147483647
						return hu
					end
					local NZ, iD = tV(Em, OI)
					if not NZ or Kl(iD) ~= "table" then
						return false, 0
					end
					tZ(968102153)
					local tH = tV(wj, OI, 1, 718038252)
					local GX = tV(wj, OI, 1, 968102153)
					if not tH or not GX or OI(0) ~= 968102153 then
						return false, 0
					end
					tZ(718038252)
					local function gP()
						local function IS(gb)
							return (gb + 800490738) % 2147483647
						end
						return IS
					end
					local IS = gP()
					local gb, lr = tV(IS, 84980)
					if not gb or lr ~= 800575718 or not GZ(IS, false) then
						return false, 0
					end
					local mL = false
					if Kl(xi) == "function" then
						local xT = tV(xi, gP, 1)
						if not xT then
							return false, 0
						end
						mL = true
						local qK, wm = tV(xi, gP, 1, true)
						if not qK or Kl(wm) ~= "table" then
							return false, 0
						end
					end
					if Kl(yD) == "function" then
						local wm, qK = tV(yD, gP)
						if not wm or Kl(qK) ~= "table" then
							return false, 0
						end
						mL = true
					end
					if not mL then
						return false, 0
					end
					tZ(800575718)
					local qK, wm, xT = tV(xC, mI(1359350563), mI(2146936116))
					if not qK or wm ~= nil or Kl(xT) ~= "string" or #xT < 1 then
						return false, 0
					end
					local gs = Ww .. kZ(899212014)
					local hs, jh = tV(xC, gs)
					if not hs or Kl(jh) ~= "function" then
						return false, 0
					end
					local Ec, mO = tV(jh)
					if not Ec or mO ~= 899212014 or not GZ(jh, false) then
						return false, 0
					end
					local fz, rV = tV(Ph, jh)
					if not fz or not Lz(rV, 899212014) then
						return false, 0
					end
					tZ(899212014)
					local function UR(xw)
						return sR(xw)
					end
					local xw, Qy = tV(ps, UR)
					if not xw or Kl(Qy) ~= "function" then
						return false, 0
					end
					local bp, xY = tV(Qy, -99323)
					if not bp or xY ~= 99323 or not GZ(Qy, true) then
						return false, 0
					end
					local RU, tv = tV(Em, Qy)
					if RU and not GC(tv) then
						return false, 0
					end
					tZ(99323)
					local NX = 0
					local EK = 0
					local by = 0
					local WR = tV(function()
						local function Xj(cw)
							local cV = 7
							for Xg = 1, #cw do
								cV = (cV * 31 + uT(cw, Xg)) % 2147483647
							end
							return cV
						end
						local cV = zQ(Tx, mI(1267126172))
						if cV == nil then
							cV = Tx[mI(1267126172)]
						end
						local cw = cV(1, 2, 3)
						NX = Xj(kZ(cw))
						EK = Xj(jq(cw))
						local Xg = zQ(hX, mI(586680284))
						if Xg == nil then
							Xg = hX[mI(586680284)]
						end
						local qk = Xg(hX, mI(1575817833))
						local mC = zQ(qk, mI(846709719))
						if mC == nil then
							mC = qk[mI(846709719)]
						end
						local Il = mC(qk) == true and 1 or 0
						local Ce, Fp = tV(Ys)
						local WR = Ce and Fp == true and 1 or 0
						by = Il + WR * 2 + #Go * 4
					end)
					if not WR then
						NX, EK, by = 0, 0, 0
					end
					sj, nN, bY = NX, EK, by
					tZ(NX)
					tZ(EK)
					tZ(by)
					return true, MK
				end
				local xY = function(WR, by)
					ue += 1
					if hl then
						return dt
					end
					if Os and QQ ~= aJ() then
						ec()
						return dt
					end
					local EK = WR % 65536
					local NX = (WR - EK) / 65536
					sF = (sF * 4093 + EK * 257 + NX * 17 + ue * 31 + fH + fL + 1526193414) % 2147483647
					sF = Mp(sF, WR % 2147483648) % 2147483647
					Os = true
					fH = (fH + sF % 65521 + ue * 17 + IK) % 2147483647
					SP()
					QQ = aJ()
					if not by and ue < uF then
						return cd
					end
					if lX ~= (fH * 4099 + 602552662 + fL % 104729) % 2147483647 then
						ec()
						return dt
					end
					IK += 1
					local tv = by or not SN or IK % 5 == 0
					local RU = BC()
					local xY = 615241666
					if RU and tv then
						RU, xY = Ji()
					end
					if RU and xY ~= 615241666 then
						RU = false
					end
					if not RU then
						ec()
						return dt
					end
					if QM ~= (fH * 8191 + 301032434 + fL % 65521 * 131) % 2147483647 then
						ec()
						return dt
					end
					if not SN then
						fL = (xY + 4258023473) % 4294967296
						SN = true
					end
					if fL ~= 578297843 then
						ec()
						return dt
					end
					cd = fL
					fH = (fH * 48271 + ue + IK * 17 + fL % 65521) % 2147483647
					SP()
					if Os then
						QQ = aJ()
					end
					uF = ue + 63 + fH % 21
					return cd
				end
				xY(0, true)
				return { cd, xY }
			end
			UW = function()
				local xY = bit32
				local Ji = buffer
				local GZ = string
				local GC = table
				local Lz = math
				local BC = coroutine
				local SP = loadstring
				local aJ = select
				local Mp = pcall
				local ec = setmetatable
				local dt = rawequal
				local bY = rawget
				local nN = tostring
				local sj = bit32.bxor
				local hu = buffer.create
				local Os = string.byte
				local QQ = coroutine.resume
				local sF = 0
				local cd = game
				local SN = Enum
				local hl = Instance
				local QM = Random
				local lX = task
				local dI = game.GetService
				local fL = Enum.HumanoidRigType
				local fH = Instance.new
				local IK = Random.new
				local uF = task.spawn
				local ue = type(table.freeze) == "function"
				local Ww = table.freeze({})
				local Jn = pcall(function()
					Ww[1] = 1
				end)
				ue = ue and not Jn
				sF = (sF * 45595 + (ue and 0 or 1)) % 268435456
				local wj = true
				local yD = loadstring("return 84, nil, 537")
				wj = type(yD) == "function" and select("#", yD()) == 3 and select(3, yD()) == 537
				local xi, Em = loadstring("local =")
				wj = wj and xi == nil and type(Em) == "string"
				sF = (sF * 32835 + (wj and 0 or 1)) % 268435456
				local Ph = Random.new(51018400)
				local NO = Ph["NextNumber"](Ph)
				local xg = type(NO) == "number" and NO >= 0 and NO < 1
				sF = (sF * 46839 + (xg and 0 or 1)) % 268435456
				local eS = Ph["NextInteger"](Ph, 189, 1164)
				local Tx = type(eS) == "number" and math.floor(eS) == eS and eS >= 189 and eS <= 1164
				sF = (sF * 61963 + (Tx and 0 or 1)) % 268435456
				local Ls = Ph["NextNumber"](Ph)
				local hX = type(Ls) == "number" and Ls >= 0 and Ls < 1 and Ls ~= NO
				sF = (sF * 59285 + (hX and 0 or 1)) % 268435456
				local jq = Random.new(120034213)
				local xC = Random.new(120034213)
				local ps = jq["NextNumber"](jq) == xC["NextNumber"](xC)
				sF = (sF * 31153 + (ps and 0 or 1)) % 268435456
				local mD = Random.new(260616117)
				mD["NextNumber"](mD)
				local HO = mD["Clone"](mD)
				local Ys = HO["NextNumber"](HO)
				local oU = HO["Clone"](HO)
				local Ym = oU["NextNumber"](oU)
				local UC = HO["NextNumber"](HO)
				local NA = Ym == UC
				sF = (sF * 50323 + (NA and 0 or 1)) % 268435456
				local MH = Random.new(241379581)
				local Dv = Random.new(241379581 + 1)
				local uT = MH["NextNumber"](MH) ~= Dv["NextNumber"](Dv)
				sF = (sF * 42163 + (uT and 0 or 1)) % 268435456
				local gx = true
				local sd = coroutine.create(function(sR)
					local sd = coroutine.yield(sR + 1)
					return sd + 2
				end)
				local sR, Ll = coroutine.resume(sd, 9)
				local wH, WQ = coroutine.resume(sd, 11)
				gx = sR and Ll == 10 and wH and WQ == 13 and coroutine.status(sd) == "dead"
				local kZ = 0
				local DU = coroutine.create(function()
					for DU = 1, 7 do
						coroutine.yield(DU)
					end
				end)
				for Pm = 1, 7 do
					local lO, qv = coroutine.resume(DU)
					if lO and qv == Pm then
						kZ += 1
					end
				end
				gx = gx and kZ == 7 and coroutine.close(DU)
				sF = (sF * 433 + (gx and 0 or 1)) % 268435456
				local qv = false
				local lO = task.spawn(function()
					qv = true
				end)
				local Pm = qv and type(lO) == "thread"
				sF = (sF * 43425 + (Pm and 0 or 1)) % 268435456
				local Oi = false
				local cN = task.delay(86400, function()
					Oi = true
				end)
				local Kl, tV = pcall(task.cancel, cN)
				local Qa = type(cN) == "thread" and not Oi and Kl
				sF = (sF * 63885 + (Qa and 0 or 1)) % 268435456
				local Hr = not pcall(task.wait, {})
				sF = (sF * 3863 + (Hr and 0 or 1)) % 268435456
				local oG = game:GetService("RunService")
				local uU, id = pcall(function()
					return oG["IsStudio"](nil)
				end)
				local XQ = not uU and type(id) == "string" and #id > 0
				sF = (sF * 1223 + (XQ and 0 or 1)) % 268435456
				local rY, HL = pcall(function()
					return oG["IsStudio"](oG)
				end)
				local zQ = rY and type(HL) == "boolean"
				sF = (sF * 8099 + (zQ and 0 or 1)) % 268435456
				local SK, Xp = pcall(function()
					return game.GetChildren(nil)
				end)
				local mI = not SK and type(Xp) == "string" and #Xp > 0
				sF = (sF * 6129 + (mI and 0 or 1)) % 268435456
				local Ra = true
				local ap = buffer.fromstring("\189\166\1997")
				Ra = Ra and buffer.len(ap) == 4 and buffer.readu8(ap, 0) == 189 and buffer.readu8(ap, 3) == 55
				Ra = Ra and buffer.readu16(ap, 1) == 51110 and buffer.readu32(ap, 0) == 935831229
				Ra = Ra and buffer.tostring(ap) == "\189\166\1997"
				local FI = buffer.create(8)
				buffer.writeu16(FI, 0, 42712)
				buffer.writeu32(FI, 2, 86670166)
				Ra = Ra and buffer.readu8(FI, 0) == 216 and buffer.readu8(FI, 1) == 166
				Ra = Ra and buffer.readu8(FI, 2) == 86 and buffer.readu8(FI, 5) == 5
				buffer.writef64(FI, 0, 0.5)
				Ra = Ra and buffer.readf64(FI, 0) == 0.5
				buffer.writestring(FI, 0, "Az")
				Ra = Ra and buffer.readstring(FI, 0, 2) == "Az"
				buffer.fill(FI, 0, 7, 4)
				Ra = Ra and buffer.readu8(FI, 0) == 7 and buffer.readu8(FI, 3) == 7
				local OD = buffer.create(4)
				buffer.writebits(OD, 3, 5, 8)
				Ra = Ra and buffer.readbits(OD, 3, 5) == 8
				local EB = buffer.fromstring("Az")
				buffer.copy(EB, 0, ap, 0, 2)
				Ra = Ra and buffer.tostring(EB) == "\189\166"
				Ra = Ra
					and not pcall(buffer.readu8, ap, 99)
					and not pcall(buffer.writeu8, FI, -1, 0)
					and not pcall(buffer.readstring, ap, 3, 2)
				sF = (sF * 4189 + (Ra and 0 or 1)) % 268435456
				local IV = string.char(65, 0, 90)
				local Ke = IV == "A\0Z"
				sF = (sF * 2249 + (Ke and 0 or 1)) % 268435456
				local vg = string.sub("abcdef", 2, -2)
				sF = (sF * 21511 + (vg == "bcde" and 0 or 1)) % 268435456
				local Mj = string.rep("xy", 3)
				sF = (sF * 31243 + (Mj == "xyxyxy" and 0 or 1)) % 268435456
				local RU = #IV
				sF = (sF * 7649 + (RU - 3)) % 268435456
				local tv = string.byte(IV, 2)
				sF = (sF * 24759 + tv) % 268435456
				local NX = Instance.new("Folder")
				local EK = Instance.new("Folder")
				EK["Parent"] = NX
				local by = typeof(NX) == "Instance"
					and NX["ClassName"] == "Folder"
					and type(NX["Name"]) == "string"
					and #NX["GetChildren"](NX) == 1
				sF = (sF * 40721 + (by and 0 or 1)) % 268435456
				local WR = NX["ChildRemoved"]
				local bp = WR["Connect"](WR, function() end)
				local Qy = bp["Connected"] == true
				bp["Disconnect"](bp)
				Qy = Qy and bp["Connected"] == false
				sF = (sF * 36165 + (Qy and 0 or 1)) % 268435456
				NX["Destroy"](NX)
				local xw, UR = pcall(function()
					EK["Parent"] = NX
				end)
				local rV = not xw and type(UR) == "string" and #UR > 0
				sF = (sF * 33977 + (rV and 0 or 1)) % 268435456
				local fz = Enum.HumanoidRigType
				local mO = fz["FromName"](fz, "R6")
				local Ec = fz["FromName"](fz, "R6")
				local jh = fz["FromValue"](fz, 0)
				local hs = fz["R6"]
				local gs = mO == Ec
					and mO == jh
					and mO == hs
					and mO["Name"] == "R6"
					and mO["Value"] == 0
					and mO["EnumType"] == fz
				sF = (sF * 52327 + (gs and 0 or 1)) % 268435456
				local xT = typeof(Enum) == "Enums"
					and typeof(fz) == "Enum"
					and typeof(mO) == "EnumItem"
					and getmetatable(Enum) == "The metatable is locked"
					and getmetatable(fz) == "The metatable is locked"
					and getmetatable(mO) == "The metatable is locked"
				sF = (sF * 2067 + (xT and 0 or 1)) % 268435456
				local wm = select("#", "h", nil, "t")
				sF = (sF * 189 + (wm - 3)) % 268435456
				local qK = -17 % 5
				sF = (sF * 10329 + (qK - 3)) % 268435456
				local mL = math.floor(-1.25)
				sF = (sF * 46253 + (mL + 2)) % 268435456
				local lr = bit32.bxor(1017694120, 3571925043)
				sF = (sF * 6483 + (lr - 3897526171)) % 268435456
				local gb = bit32.band(3226652047, 1026962850)
				sF = (sF * 12083 + (gb - 1181058)) % 268435456
				local gP = {
					__index = function()
						return "AA"
					end,
					__add = function(IS, gP)
						return IS.ORQ + gP.ORQ
					end,
					__tostring = function()
						return "o"
					end,
				}
				local IS = setmetatable({ ORQ = 13 }, gP)
				local GX = setmetatable({ ORQ = 7 }, gP)
				local tH = IS.iq == "AA"
					and IS + GX == 20
					and tostring(IS) == "o"
					and rawequal(IS, IS)
					and not rawequal(IS, GX)
					and IS.ORQ == 13
					and rawget(IS, "zz") == nil
				sF = (sF * 62039 + (tH and 0 or 1)) % 268435456
				local iD = {}
				for NZ = 1, 3 do
					local OI = NZ * 10
					iD[NZ] = function(vs)
						OI += vs
						return OI
					end
				end
				local OI = iD[1](4) == 14 and iD[1](2) == 16 and iD[2](1) == 21 and iD[3](0) == 30
				sF = (sF * 2183 + (OI and 0 or 1)) % 268435456
				local NZ = true
				if type(_G["clonefunction"]) == "function" then
					local vs = _G["clonefunction"](pcall)
					local CF, si = vs(function()
						return 37
					end)
					NZ = type(vs) == "function" and CF and si == 37
				end
				sF = (sF * 37733 + (NZ and 0 or 1)) % 268435456
				local si = bit32 == xY
					and buffer == Ji
					and string == GZ
					and table == GC
					and math == Lz
					and coroutine == BC
					and loadstring == SP
					and select == aJ
					and pcall == Mp
					and setmetatable == ec
					and rawequal == dt
					and rawget == bY
					and tostring == nN
					and bit32.bxor == sj
					and buffer.create == hu
					and string.byte == Os
					and coroutine.resume == QQ
				sF = (sF * 18163 + (si and 0 or 1)) % 268435456
				local CF = game == cd
					and Enum == SN
					and Instance == hl
					and Random == QM
					and task == lX
					and game.GetService == dI
					and Enum.HumanoidRigType == fL
					and Instance.new == fH
					and Random.new == IK
					and task.spawn == uF
				sF = (sF * 44217 + (CF and 0 or 1)) % 268435456
				return sF
			end
			do
				local CF = X(0)[qm]
				local si = X(0)[WA]
				local NZ = X(0)[eG]
				local OI = NZ and NZ[TG]
				local iD = X(0)[BA]
				Tc = iD and iD[NC]
				local tH = 0
				local GX = 0
				do
					local IS, gP = Y(function()
						return OI(CF, Gg)
					end)
					if IS and l(gP) == q[5] then
						for gb = 1, #gP do
							tH = (tH * 31 + P(gP, gb)) % 268435456
						end
					end
					tH = (
						tH
						+ (
							IS and 0
							or (function(gb)
								local lr = (116902706 + 0) % 268435456
								for mL = 1, #gb do
									lr = (lr * 55902 + #gb[mL] + mL * 31231 + 101497289) % 268435456
								end
								return (3262223 + lr) % 268435456
							end)(h)
						)
					) % 268435456
				end
				local gP = {}
				do
					local IS = X(1)
					if l(IS) == "table" then
						local lr, gb = next(IS)
						while lr ~= nil do
							gP[lr] = gb
							lr, gb = next(IS, lr)
						end
					end
				end
				do
					local IS = function() end
					local gb = si(IS)
					for lr = 1, #gb do
						Qx = (Qx * (464376813272 + 189597995096 - 653974808346) + P(gb, lr)) % 268435456
					end
					local lr = {}
					local mL = si(lr)
					for qK = 1, #mL do
						Qx = (Qx * (919606365100 + 835413180293 - 1755019545353) + P(mL, qK)) % 268435456
					end
					local qK = Tc and Tc() or 0
					local wm = d(qK * (407993143997 + 884288830875 - 1292277002217))
					for xT = 1, 5 do
						Qx = (Qx * (714220229964 + 937631703988 - 1651851933928) + wm % 256) % 268435456
						wm = d(wm / 256)
					end
				end
				ky = (
					(
							(function(wm)
								local qK = (244790661 + 0) % 268435456
								for mL = 1, #wm do
									qK = (qK * 7471 + #wm[mL] + mL * 30033 + 267840219) % 268435456
								end
								return (87006344 + qK) % 268435456
							end)(h)
							+ tH % 65536 * (function(qK)
								local wm = (130214018 + 0) % 268435456
								for mL = 1, #qK do
									wm = (wm * 35444 + #qK[mL] + mL * 21758 + 212589107) % 268435456
								end
								return (149753959 + wm) % 268435456
							end)(h)
							+ d(tH / 65536)
								* (function(wm)
									local qK = (160144212 + 0) % 268435456
									for mL = 1, #wm do
										qK = (qK * 45353 + #wm[mL] + mL * 38348 + 135020803) % 268435456
									end
									return (171782962 + qK) % 268435456
								end)(h)
						)
						% 268435456
					- (function(qK)
						local wm = (84506074 + 0) % 268435456
						for mL = 1, #qK do
							wm = (wm * 11815 + #qK[mL] + mL * 50650 + 248149746) % 268435456
						end
						return (177078020 + wm) % 268435456
					end)(h)
				) % 268435456
				local qK = (function(wm)
					local qK = (108855473 + 0) % 268435456
					for mL = 1, #wm do
						qK = (qK * 50577 + #wm[mL] + mL * 50784 + 89356432) % 268435456
					end
					return (200757531 + qK) % 268435456
				end)(h)
				local mL = (function(wm)
					local mL = (169164171 + 0) % 268435456
					for lr = 1, #wm do
						mL = (mL * 45392 + #wm[lr] + lr * 42589 + 71351497) % 268435456
					end
					return (58469422 + mL) % 268435456
				end)(h)
				MQ = function(wm, lr, gb, IS, xT, gs, hs, jh, Ec, mO, fz, rV, UR, xw, Qy, bp)
					local WR = { 387074319028 + 463363014871 - 850437223328 }
					local by = { 730558655828 + 160437823050 - 890995110897 }
					local function EK(NX, tv)
						NX = hs(NX)
						local RU = #NX
						local Mj = RU
						if Mj > 64 then
							Mj = 64
						end
						local vg = {}
						local Ke = (UR + (tv - 1) * xw) % 268435456
						for IV = 1, Mj do
							Ke = (fz * Ke + rV) % 268435456
							vg[IV] = lr(
								(
									wm(NX, IV) - (Ke % 256 + gb(Ke / 256) % 256 + gb(Ke / 65536) % 256 + gb(
										Ke / 16777216
									)) % 256
								) % 256
							)
						end
						local IV = 0
						for EB = 1, Mj do
							IV = (IV * 31 + wm(NX, EB)) % 268435456
						end
						Ke = (UR + (tv - 1) * xw + IV) % 268435456
						for EB = Mj + 1, RU do
							Ke = (fz * Ke + rV) % 268435456
							vg[EB] = lr(
								(
									wm(NX, EB) - (Ke % 256 + gb(Ke / 256) % 256 + gb(Ke / 65536) % 256 + gb(
										Ke / 16777216
									)) % 256
								) % 256
							)
						end
						NX = table.concat(vg)
						local EB = 63
						local OD = 227
						local FI = 22
						local ap = 104
						local Ra = 121
						local mI = 106
						local Xp = 7
						local SK = 137
						local zQ = 1
						local HL = 0
						local rY = 0
						local XQ = 1
						local id, uU, oG, Hr, Qa, tV, Kl, cN, Oi, Pm, lO, qv, DU, kZ, WQ, wH, Ll, sR, sd
						while XQ <= 2 do
							if XQ == 1 then
								local gx = wm(NX, zQ)
								zQ += 1
								if gx == EB then
									local uT
									uT, zQ = jh(NX, zQ)
									id = uT
									uT, zQ = jh(NX, zQ)
									uU = uT
									uT, zQ = jh(NX, zQ)
									oG = uT
									HL += 1
								elseif gx == OD then
									local uT
									uT, zQ = jh(NX, zQ)
									Hr = uT
									sd = (
										uT * (978023374279 + 435538024138 - 1413561349516)
										+ (94128499755 + 494765743334 - 588894190477)
									) % 65536
									HL += 1
								elseif gx == FI then
									local uT
									uT, zQ = jh(NX, zQ)
									tV = {}
									for Dv = 1, uT do
										local MH
										MH, zQ = jh(NX, zQ)
										tV[Dv] = MH
									end
									HL += 1
								elseif gx == ap then
									local uT
									uT, zQ = jh(NX, zQ)
									Kl = uT
									uT, zQ = jh(NX, zQ)
									Qa = uT
									rY = zQ
									zQ += Qa
									HL += 1
								elseif gx == Ra then
									local uT
									uT, zQ = jh(NX, zQ)
									Oi = {}
									for MH = 1, uT do
										local Dv
										Dv, zQ = jh(NX, zQ)
										Oi[MH] = Dv
									end
									HL += 1
								elseif gx == mI then
									local uT
									uT, zQ = jh(NX, zQ)
									zQ += uT
								elseif gx == SK then
									local uT
									uT, zQ = jh(NX, zQ)
									sR = {}
									for Dv = 1, uT do
										local MH
										MH, zQ = jh(NX, zQ)
										sR[Dv] = MH
									end
									HL += 1
								else
									local uT
									uT, zQ = jh(NX, zQ)
									Pm = uT
									lO = {}
									for MH = 1, Pm do
										lO[MH] = wm(NX, zQ)
										zQ += 1
									end
									local MH = zQ
									qv = {}
									for Dv = 1, Pm do
										local NA = wm(NX, zQ)
										if NA < 128 then
											qv[Dv] = NA
											zQ += 1
										else
											local UC = wm(NX, zQ + 1)
											if UC < 128 then
												qv[Dv] = NA - 128 + UC * 128
												zQ += 2
											else
												local Ym = wm(NX, zQ + 2)
												if Ym < 128 then
													local oU = NA - 128 + (UC - 128) * 128 + Ym * 16384
													if oU >= 2147483648 then
														oU -= 4294967296
													end
													qv[Dv] = oU
													zQ += 3
												else
													local oU = wm(NX, zQ + 3)
													local Ys = NA
														- 128
														+ (UC - 128) * 128
														+ (Ym - 128) * 16384
														+ oU * 2097152
													if Ys >= 2147483648 then
														Ys -= 4294967296
													end
													qv[Dv] = Ys
													zQ += 4
												end
											end
										end
									end
									DU = {}
									for NA = 1, Pm do
										local Dv = wm(NX, zQ)
										if Dv < 128 then
											DU[NA] = Dv
											zQ += 1
										else
											local UC = wm(NX, zQ + 1)
											if UC < 128 then
												DU[NA] = Dv - 128 + UC * 128
												zQ += 2
											else
												local Ym = wm(NX, zQ + 2)
												if Ym < 128 then
													local Ys = Dv - 128 + (UC - 128) * 128 + Ym * 16384
													if Ys >= 2147483648 then
														Ys -= 4294967296
													end
													DU[NA] = Ys
													zQ += 3
												else
													local Ys = wm(NX, zQ + 3)
													local oU = Dv
														- 128
														+ (UC - 128) * 128
														+ (Ym - 128) * 16384
														+ Ys * 2097152
													if oU >= 2147483648 then
														oU -= 4294967296
													end
													DU[NA] = oU
													zQ += 4
												end
											end
										end
									end
									kZ = {}
									for Dv = 1, Pm do
										local NA = wm(NX, zQ)
										if NA < 128 then
											kZ[Dv] = NA
											zQ += 1
										else
											local UC = wm(NX, zQ + 1)
											if UC < 128 then
												kZ[Dv] = NA - 128 + UC * 128
												zQ += 2
											else
												local Ym = wm(NX, zQ + 2)
												if Ym < 128 then
													local oU = NA - 128 + (UC - 128) * 128 + Ym * 16384
													if oU >= 2147483648 then
														oU -= 4294967296
													end
													kZ[Dv] = oU
													zQ += 3
												else
													local oU = wm(NX, zQ + 3)
													local Ys = NA
														- 128
														+ (UC - 128) * 128
														+ (Ym - 128) * 16384
														+ oU * 2097152
													if Ys >= 2147483648 then
														Ys -= 4294967296
													end
													kZ[Dv] = Ys
													zQ += 4
												end
											end
										end
									end
									WQ = {}
									for NA = 1, Pm do
										local Dv = wm(NX, zQ)
										if Dv < 128 then
											WQ[NA] = Dv
											zQ += 1
										else
											local UC = wm(NX, zQ + 1)
											if UC < 128 then
												WQ[NA] = Dv - 128 + UC * 128
												zQ += 2
											else
												local Ym = wm(NX, zQ + 2)
												if Ym < 128 then
													local Ys = Dv - 128 + (UC - 128) * 128 + Ym * 16384
													if Ys >= 2147483648 then
														Ys -= 4294967296
													end
													WQ[NA] = Ys
													zQ += 3
												else
													local Ys = wm(NX, zQ + 3)
													local oU = Dv
														- 128
														+ (UC - 128) * 128
														+ (Ym - 128) * 16384
														+ Ys * 2097152
													if oU >= 2147483648 then
														oU -= 4294967296
													end
													WQ[NA] = oU
													zQ += 4
												end
											end
										end
									end
									local Dv = zQ
									zQ = MH
									local NA = 0
									for UC = 1, Pm do
										local Ym = wm(NX, zQ)
										if Ym < 128 then
											NA = (NA + Ym) % 4294967296
											zQ += 1
										else
											local oU = wm(NX, zQ + 1)
											if oU < 128 then
												NA = (NA + (Ym - 128) + oU * 128) % 4294967296
												zQ += 2
											else
												local Ys = wm(NX, zQ + 2)
												if Ys < 128 then
													local HO = Ym - 128 + (oU - 128) * 128 + Ys * 16384
													if HO >= 2147483648 then
														HO -= 4294967296
													end
													NA = (NA + HO) % 4294967296
													zQ += 3
												else
													local HO = wm(NX, zQ + 3)
													local mD = Ym
														- 128
														+ (oU - 128) * 128
														+ (Ys - 128) * 16384
														+ HO * 2097152
													if mD >= 2147483648 then
														mD -= 4294967296
													end
													NA = (NA + mD) % 4294967296
													zQ += 4
												end
											end
										end
									end
									for Ym = 1, Pm do
										local UC = wm(NX, zQ)
										if UC < 128 then
											NA = (NA + UC) % 4294967296
											zQ += 1
										else
											local oU = wm(NX, zQ + 1)
											if oU < 128 then
												NA = (NA + (UC - 128) + oU * 128) % 4294967296
												zQ += 2
											else
												local Ys = wm(NX, zQ + 2)
												if Ys < 128 then
													local mD = UC - 128 + (oU - 128) * 128 + Ys * 16384
													if mD >= 2147483648 then
														mD -= 4294967296
													end
													NA = (NA + mD) % 4294967296
													zQ += 3
												else
													local mD = wm(NX, zQ + 3)
													local HO = UC
														- 128
														+ (oU - 128) * 128
														+ (Ys - 128) * 16384
														+ mD * 2097152
													if HO >= 2147483648 then
														HO -= 4294967296
													end
													NA = (NA + HO) % 4294967296
													zQ += 4
												end
											end
										end
									end
									for UC = 1, Pm do
										local Ym = wm(NX, zQ)
										if Ym < 128 then
											NA = (NA + Ym) % 4294967296
											zQ += 1
										else
											local oU = wm(NX, zQ + 1)
											if oU < 128 then
												NA = (NA + (Ym - 128) + oU * 128) % 4294967296
												zQ += 2
											else
												local Ys = wm(NX, zQ + 2)
												if Ys < 128 then
													local HO = Ym - 128 + (oU - 128) * 128 + Ys * 16384
													if HO >= 2147483648 then
														HO -= 4294967296
													end
													NA = (NA + HO) % 4294967296
													zQ += 3
												else
													local HO = wm(NX, zQ + 3)
													local mD = Ym
														- 128
														+ (oU - 128) * 128
														+ (Ys - 128) * 16384
														+ HO * 2097152
													if mD >= 2147483648 then
														mD -= 4294967296
													end
													NA = (NA + mD) % 4294967296
													zQ += 4
												end
											end
										end
									end
									for Ym = 1, Pm do
										local UC = wm(NX, zQ)
										if UC < 128 then
											NA = (NA + UC) % 4294967296
											zQ += 1
										else
											local oU = wm(NX, zQ + 1)
											if oU < 128 then
												NA = (NA + (UC - 128) + oU * 128) % 4294967296
												zQ += 2
											else
												local Ys = wm(NX, zQ + 2)
												if Ys < 128 then
													local mD = UC - 128 + (oU - 128) * 128 + Ys * 16384
													if mD >= 2147483648 then
														mD -= 4294967296
													end
													NA = (NA + mD) % 4294967296
													zQ += 3
												else
													local mD = wm(NX, zQ + 3)
													local HO = UC
														- 128
														+ (oU - 128) * 128
														+ (Ys - 128) * 16384
														+ mD * 2097152
													if HO >= 2147483648 then
														HO -= 4294967296
													end
													NA = (NA + HO) % 4294967296
													zQ += 4
												end
											end
										end
									end
									zQ = MH
									local UC = 0
									for Ym = 1, Pm do
										local oU = wm(NX, zQ)
										if oU < 128 then
											UC = (UC + (0 * Pm + Ym) * oU % 4294967296) % 4294967296
											zQ += 1
										else
											local Ys = wm(NX, zQ + 1)
											if Ys < 128 then
												UC = (UC + (0 * Pm + Ym) * (oU - 128 + Ys * 128) % 4294967296)
													% 4294967296
												zQ += 2
											else
												local HO = wm(NX, zQ + 2)
												if HO < 128 then
													local mD = oU - 128 + (Ys - 128) * 128 + HO * 16384
													if mD >= 2147483648 then
														mD -= 4294967296
													end
													UC = (UC + (0 * Pm + Ym) * mD % 4294967296) % 4294967296
													zQ += 3
												else
													local mD = wm(NX, zQ + 3)
													local ps = oU
														- 128
														+ (Ys - 128) * 128
														+ (HO - 128) * 16384
														+ mD * 2097152
													if ps >= 2147483648 then
														ps -= 4294967296
													end
													UC = (UC + (0 * Pm + Ym) * ps % 4294967296) % 4294967296
													zQ += 4
												end
											end
										end
									end
									for oU = 1, Pm do
										local Ym = wm(NX, zQ)
										if Ym < 128 then
											UC = (UC + (1 * Pm + oU) * Ym % 4294967296) % 4294967296
											zQ += 1
										else
											local Ys = wm(NX, zQ + 1)
											if Ys < 128 then
												UC = (UC + (1 * Pm + oU) * (Ym - 128 + Ys * 128) % 4294967296)
													% 4294967296
												zQ += 2
											else
												local HO = wm(NX, zQ + 2)
												if HO < 128 then
													local ps = Ym - 128 + (Ys - 128) * 128 + HO * 16384
													if ps >= 2147483648 then
														ps -= 4294967296
													end
													UC = (UC + (1 * Pm + oU) * ps % 4294967296) % 4294967296
													zQ += 3
												else
													local ps = wm(NX, zQ + 3)
													local mD = Ym
														- 128
														+ (Ys - 128) * 128
														+ (HO - 128) * 16384
														+ ps * 2097152
													if mD >= 2147483648 then
														mD -= 4294967296
													end
													UC = (UC + (1 * Pm + oU) * mD % 4294967296) % 4294967296
													zQ += 4
												end
											end
										end
									end
									for Ym = 1, Pm do
										local oU = wm(NX, zQ)
										if oU < 128 then
											UC = (UC + (2 * Pm + Ym) * oU % 4294967296) % 4294967296
											zQ += 1
										else
											local Ys = wm(NX, zQ + 1)
											if Ys < 128 then
												UC = (UC + (2 * Pm + Ym) * (oU - 128 + Ys * 128) % 4294967296)
													% 4294967296
												zQ += 2
											else
												local HO = wm(NX, zQ + 2)
												if HO < 128 then
													local mD = oU - 128 + (Ys - 128) * 128 + HO * 16384
													if mD >= 2147483648 then
														mD -= 4294967296
													end
													UC = (UC + (2 * Pm + Ym) * mD % 4294967296) % 4294967296
													zQ += 3
												else
													local mD = wm(NX, zQ + 3)
													local ps = oU
														- 128
														+ (Ys - 128) * 128
														+ (HO - 128) * 16384
														+ mD * 2097152
													if ps >= 2147483648 then
														ps -= 4294967296
													end
													UC = (UC + (2 * Pm + Ym) * ps % 4294967296) % 4294967296
													zQ += 4
												end
											end
										end
									end
									for oU = 1, Pm do
										local Ym = wm(NX, zQ)
										if Ym < 128 then
											UC = (UC + (3 * Pm + oU) * Ym % 4294967296) % 4294967296
											zQ += 1
										else
											local Ys = wm(NX, zQ + 1)
											if Ys < 128 then
												UC = (UC + (3 * Pm + oU) * (Ym - 128 + Ys * 128) % 4294967296)
													% 4294967296
												zQ += 2
											else
												local HO = wm(NX, zQ + 2)
												if HO < 128 then
													local ps = Ym - 128 + (Ys - 128) * 128 + HO * 16384
													if ps >= 2147483648 then
														ps -= 4294967296
													end
													UC = (UC + (3 * Pm + oU) * ps % 4294967296) % 4294967296
													zQ += 3
												else
													local ps = wm(NX, zQ + 3)
													local mD = Ym
														- 128
														+ (Ys - 128) * 128
														+ (HO - 128) * 16384
														+ ps * 2097152
													if mD >= 2147483648 then
														mD -= 4294967296
													end
													UC = (UC + (3 * Pm + oU) * mD % 4294967296) % 4294967296
													zQ += 4
												end
											end
										end
									end
									wH = NA
									Ll = UC
									zQ = Dv
									HL += 1
								end
								if HL >= Xp then
									XQ = 2
								end
							else
								zQ = rY
								cN = {}
								local gx = ("")["char"]
								local function UC()
									Hr = (Ec * Hr + mO) % 268435456
									local NA = (
										wm(NX, zQ) - (Hr % 256 + gb(Hr / 256) % 256 + gb(Hr / 65536) % 256 + gb(
											Hr / 16777216
										)) % 256
									) % 256
									zQ += 1
									return NA
								end
								for NA = 1, Kl do
									local Dv = UC()
									if Dv == 0 then
										cN[NA] = nil
									elseif Dv == 1 then
										cN[NA] = UC() == 1
									elseif Dv == 3 then
										local MH = UC()
										local uT = UC()
										local Ym = MH + uT * 256
										local oU = ""
										for Ys = 1, Ym do
											oU = oU .. gx(UC())
										end
										cN[NA] = oU
									else
										local oU = 0
										local Ym = 1
										while true do
											local uT = UC()
											if uT < 128 then
												oU += uT * Ym
												break
											end
											oU += (uT - 128) * Ym
											Ym *= 128
										end
										local uT = 0
										local MH = 1
										while true do
											local Ys = UC()
											if Ys < 128 then
												uT += Ys * MH
												break
											end
											uT += (Ys - 128) * MH
											MH *= 128
										end
										local Ys = gb(uT / 2) - 2048
										local HO = 1
										if Ys >= 0 then
											for mD = 1, Ys do
												HO *= 2
											end
										else
											for mD = 1, 0 - Ys do
												HO /= 2
											end
										end
										local mD = oU * HO
										if uT % 2 == 1 then
											mD = 0 - mD
										end
										cN[NA] = mD
									end
								end
								if zQ ~= rY + Qa then
									wH = (wH or 0) + zQ + 1
									Ll = (Ll or 0) + rY + Qa + 1
								end
								XQ = 3
							end
						end
						return {
							eE = id,
							Sg = uU,
							Xl = oG,
							cJ = tV,
							lnr = cN,
							pc = Oi,
							uk = wH,
							bo = Ll,
							_U = lO,
							QoJ = qv,
							Xq = DU,
							BS = kZ,
							cst = WQ,
							BIy = sR,
							uF = sd,
						}
					end
					return function(sd, sR, Ll, wH, WQ, kZ, DU, qv)
						local lO = {}
						local Pm = { 167, 195, 177 }
						local Oi = 0
						Oi = (Oi * 257 + 55) % 268435456
						Oi = (Oi * 257 + 253) % 268435456
						for cN = 1, #Pm do
							Oi = (Oi * 257 + Pm[cN]) % 268435456
						end
						local cN = (Oi - mL) % 268435456
						local Kl = 1
						while Kl <= #Pm do
							local tV = (Pm[Kl] - (55 + Kl * 253) % 256) % 256
							if tV == 115 then
								local Qa = 1
								while Qa <= #sd do
									local Hr = EK(sd[Qa], Qa)
									lO[Qa] = Hr
									local oG = (Hr.uk - WR[Qa]) % 4294967296
									local uU = (Hr.bo - by[Qa]) % 4294967296
									Hr.MD = (
										oG % 65536 * (1 + (Ll + Qa * WQ) % 65521)
										+ gb(oG / 65536) * (1 + (wH + Qa * kZ) % 65521)
									) % 268435456
									Hr.Jf = (
										uU % 65536 * (1 + (wH + Qa * WQ) % 65521)
										+ gb(uU / 65536) * (1 + (Ll + Qa * kZ) % 65521)
									) % 268435456
									Qa += 1
								end
							elseif tV == 146 then
								do
									local Qa = lO[1]
									local uU = 3
									if (Qa.QoJ[uU] + Qa.BS[uU] + uU) % 2 == 0 then
										Qa._U[uU] = sR
									end
								end
								do
									local uU = lO[1]
									local Qa = 5
									if (uU.QoJ[Qa] + uU.BS[Qa] + Qa) % 2 == 0 then
										uU._U[Qa] = sR
									end
								end
							elseif 131 == tV then
								local Qa = lO
								local uU = {}
								local oG = 0
								local Hr = 0
								do
									local id = {}
									local XQ = bp(id)
									for rY = 1, #XQ do
										Hr = (Hr * 31 + wm(XQ, rY)) % 268435456
									end
								end
								local XQ = { { 1 } }
								local id = { 2 }
								local rY = { { 3, 5 } }
								local HL, zQ, SK, Xp, mI, Ra, ap, FI, OD, EB, IV, Ke, vg, Mj, RU, tv, NX, UC, gx, Dv, NA, mD, HO, Ys, MH, uT, Ym, oU, ps, xC, jq, hX, Ls, Tx, eS =
									406976442045 + 185580505174 - 592556945567,
									435333783242 + 130820854332 - 566154606608,
									358181186726 + 1043229339109 - 1401410511775,
									90876027946 + 724861798225 - 815737800187,
									45331429397 + 165289153612 - 210620528036,
									616362908959 + 768842369894 - 1385205275695,
									974064830917 + 667714637622 - 1641779434423,
									169416070734 + 815174673787 - 984590707656,
									163426964044 + 886563707804 - 1049990659693,
									125163149882 + 1033524966369 - 1158688056426,
									43052902932 + 129700936252 - 172753794029,
									174685282897 + 78617323556 - 253302558903,
									522197946099 + 712989388108 - 1235187271738,
									897292345249 + 137244574783 - 1034536901063,
									375312043694 + 34570325008 - 409882364403,
									785019129709 + 89670537769 - 874689667460,
									808761757560 + 478943393503 - 1287705151058,
									745062166362 + 969999580611 - 1715061746323,
									147086865988 + 483527580897 - 630614446802,
									1026534685662 + 165282610252 - 1191817289220,
									300508378251 + 1082532978168 - 1383041334806,
									659279097651 + 896279990689 - 1555559044707,
									747900836188 + 556477246723 - 1304378053948,
									791962501488 + 1001634849234 - 1793597319364,
									1090999200764 + 313984493714 - 1404983648201,
									677218814267 + 449178091217 - 1126396902707,
									1005853028820 + 197583228508 - 1203436203701,
									376163980975 + 476504559325 - 852668484278,
									667841773878 + 808852148088 - 1476693916545,
									444138061518 + 710649198410 - 1154787232487,
									84181510183 + 830213420930 - 914394918342,
									232232561260 + 576919411980 - 809151958074,
									46427407381 + 292684310664 - 339111687960,
									539454782203 + 287911111814 - 827238573705,
									1029814916063 + 175609922641 - 1205233812683
								for xg = 1, #Qa do
									local NO = Qa[xg]
									local Ph = (
										cN
										+ NO.MD % 65521 * (1 + (xg + EB) % 65521)
										+ NO.Jf % 65521 * (1 + (xg + Ke) % 65521)
									) % 268435456
									NO.MD = nil
									NO.Jf = nil
									local Em = xg * ap % 65521
									local xi = rY[xg]
									for yD = 1, #xi do
										local wj = xi[yD]
										Em = (
											Em * HL
											+ NO.QoJ[wj] * zQ
											+ NO.Xq[wj] * SK
											+ NO.BS[wj] * Xp
											+ NO.cst[wj] * mI
											+ wj * Ra
										) % 65521
									end
									Em += 1
									oG = (oG * 257 + Em) % 268435456
									local wj = 2 * ((WQ + Em * EB + xg * IV) % 16000000) + 1
									local yD = (kZ + Em * Ke + xg * vg) % 268435456
									local Jn = (DU + Em * Mj + xg * RU) % 268435456
									local Ww = 3 + (Em * Dv + xg * NA) % 7
									local ue = (tv + xg * NX) % 24
									local uF = { 0, 1, 2, 3 }
									local IK = {}
									local fH = { 6, 2, 1, 1 }
									for fL = 1, 4 do
										local dI = fL == 4 and 0 or gb(ue / fH[fL])
										if fL < 4 then
											ue %= fH[fL]
										end
										IK[fL] = uF[dI + 1]
										for lX = dI + 1, #uF - 1 do
											uF[lX] = uF[lX + 1]
										end
										uF[#uF] = nil
									end
									local dI = 1
									for fL = 1, 4 do
										if IK[fL] == 1 then
											dI = fL
											break
										end
									end
									local fL = (UC + xg * gx + Ph % 720 * (1 + Ys % 719)) % 720
									local lX = { 0, 1, 2, 3, 4, 5 }
									local QM = {}
									local hl = { 120, 24, 6, 2, 1, 1 }
									for SN = 1, 6 do
										local cd = SN == 6 and 0 or gb(fL / hl[SN])
										if SN < 6 then
											fL %= hl[SN]
										end
										QM[SN] = lX[cd + 1]
										for sF = cd + 1, #lX - 1 do
											lX[sF] = lX[sF + 1]
										end
										lX[#lX] = nil
									end
									local cd = XQ[xg]
									local SN = #cd
									local sF, QQ, Os = {}, {}, {}
									for hu = 1, SN do
										local sj = cd[hu]
										local nN = hu < SN and cd[hu + 1] - 1 or #NO._U
										sF[hu] = nN - sj + 1
										Os[sj] = hu
										QQ[hu] = hu > 1 and QQ[hu - 1] + sF[hu - 1] * 5 or 1
									end
									local nN = { NO.QoJ, NO.Xq, NO.BS, NO.cst }
									local sj, hu = NO._U, nN[dI]
									local bY = {}
									for dt = 1, #sj do
										if sj[dt] == 29 or sj[dt] == 84 or sj[dt] == 148 or sj[dt] == 196 then
											local ec = hu[dt] + 1
											local Mp = (ec * jq + Em * hX + xg * Ls + Ph % 65521 * Ls) % 65521
											hu[dt] = Mp
											bY[#bY + 1] = Mp
											bY[#bY + 1] = ec
										end
									end
									local dt = {}
									local Mp = 1
									for ec = 1, SN do
										local aJ = cd[ec]
										local SP = (
											Ll
											+ xg * wH
											+ aJ * Jn
											+ Hr
											+ Em * FI
											+ Ph % 65521 * ((xg * IV + Em * EB + aJ * HO) % 65521) % 268435456
											+ (29398560781 + 727927661906 - 757296669783)
										) % 268435456
										for BC = aJ, aJ + sF[ec] - 1 do
											SP = (wj * SP + yD) % 268435456
											dt[Mp] = (
												NO.QoJ[BC]
												+ (54115316249 + 860314697104 - 914429987393)
												+ SP % 65536
											) % 65536
											Mp += 1
											SP = (wj * SP + yD) % 268435456
											dt[Mp] = (
												NO.BS[BC]
												+ (418405165762 + 1006177548244 - 1424582668067)
												+ SP % 65536
												+ Em
											) % 65536
											Mp += 1
											SP = (wj * SP + yD) % 268435456
											dt[Mp] = (
												NO.Xq[BC]
												+ (478627566814 + 892954891679 - 1371582411044)
												+ SP % 65536
											) % 65536
											Mp += 1
											SP = (wj * SP + yD) % 268435456
											dt[Mp] = (
												NO._U[BC]
												+ (616110219038 + 665875141430 - 1281985322693)
												+ SP % 65536
											) % 65536
											Mp += 1
											SP = (wj * SP + yD) % 268435456
											dt[Mp] = (
												NO.cst[BC]
												+ (224588903016 + 1045799269862 - 1270388144906)
												+ SP % 65536
											) % 65536
											Mp += 1
											if (BC - aJ + 1) % Ww == 0 then
												SP = (SP + Em * mD + BC * HO) % 268435456
											end
										end
									end
									local SP = (Ll + xg * wH + Hr) % 268435456
									local aJ = NO.lnr
									local ec = 0
									for BC in pairs(aJ) do
										if BC > ec then
											ec = BC
										end
									end
									local BC, Lz, GC, GZ, Ji = {}, {}, {}, {}, {}
									local xY = 1
									for vs = 1, ec do
										Ji[vs] = xY
										local tZ = (
											Ll
											+ xg * wH
											+ Hr
											+ Em * OD
											+ Ph % 65521 * ((xg * vg + vs * ps + Em) % 65521) % 268435456
											+ (1079180093942 + 440413928653 - 1519411222218)
										) % 268435456
										local MK = aJ[vs]
										local gZ = Qy(MK)
										local EL = (tZ + vs * qv) % 268435456
										EL = (WQ * EL + kZ) % 268435456
										EL = (WQ * EL + kZ) % 268435456
										local WD = gZ == "string" and eS or Tx
										local FA = (tZ + vs * WD) % 268435456
										FA = (WQ * FA + kZ) % 268435456
										FA = (WQ * FA + kZ) % 268435456
										if gZ == "number" then
											if MK % 1 == 0 and MK > -1125899906842624.0 and MK < 1125899906842624.0 then
												BC[vs] = (QM[2] + EL) % 65536
												Lz[vs] = MK + FA
											else
												local ws = bp(MK)
												BC[vs] = (QM[6] + EL) % 65536
												GZ[vs] = #ws
												for Kn = 1, #ws do
													FA = (WQ * FA + kZ) % 268435456
													GC[xY] = (wm(ws, Kn) + FA % 256) % 256
													xY += 1
												end
											end
										elseif gZ == "string" then
											BC[vs] = (QM[3] + EL) % 65536
											GZ[vs] = #MK
											for ws = 1, #MK do
												FA = (WQ * FA + kZ) % 268435456
												GC[xY] = (wm(MK, ws) + FA % 256) % 256
												xY += 1
											end
										elseif gZ == "boolean" then
											if MK then
												BC[vs] = (QM[4] + EL) % 65536
											else
												BC[vs] = (QM[5] + EL) % 65536
											end
										else
											BC[vs] = (QM[1] + EL) % 65536
										end
									end
									local FA = (Em * Ys + xg * MH + Ym + Ph % 65536 * ((xg + Ys) % 65536)) % 65536
									local WD = {}
									for EL = 1, #NO.cJ do
										FA = (FA * uT + Ym + EL) % 65536
										WD[EL] = (NO.cJ[EL] + FA) % 65536
									end
									local EL = (
										NO.Sg + (Em * oU + xg * ps + Ym + Ph % 65536 * ((xg + ps) % 65536)) % 65536
									) % 65536
									FA = nil
									uU[xg] = {
										jp = cd,
										lXC = sF,
										mF = QQ,
										Rug = Os,
										fQ = dt,
										al = (xg + xC) % 65521,
										pc = NO.pc,
										JH = id[xg],
										MpX = WD,
										Wze = EL,
										CV = bY,
										vjC = ec,
										okB = BC,
										zC = Lz,
										Cd = GC,
										XC = GZ,
										eP = Ji,
										BIy = NO.BIy,
										uF = NO.uF,
									}
								end
								for EL = 1, #uU do
									local WD = uU[EL].CV
									for FA = 1, #WD, 2 do
										uU[EL][WD[FA]] = uU[WD[FA + 1]]
										WD[FA] = nil
										WD[FA + 1] = nil
									end
									uU[EL].CV = nil
								end
								return uU[#uU], Hr, oG
							else
								cN = (cN + qK) % 268435456
							end
							Kl += 1
						end
					end
				end
				local by = (function(EK)
					local by = (224362904 + 0) % 268435456
					for WR = 1, #EK do
						by = (by * 47264 + #EK[WR] + WR * 14266 + 231556892) % 268435456
					end
					return (66501233 + by) % 268435456
				end)(h)
				local WR = (function(EK)
					local WR = (96457290 + 0) % 268435456
					for bp = 1, #EK do
						WR = (WR * 18953 + #EK[bp] + bp * 6990 + 255260513) % 268435456
					end
					return (153586536 + WR) % 268435456
				end)(h)
				local bp = (function(EK)
					local bp = (85607889 + 0) % 268435456
					for Qy = 1, #EK do
						bp = (bp * 20449 + #EK[Qy] + Qy * 10916 + 186229121) % 268435456
					end
					return (222579329 + bp) % 268435456
				end)(h)
				UE = function(
					EK,
					Qy,
					xw,
					UR,
					rV,
					fz,
					mO,
					Ec,
					jh,
					hs,
					gs,
					xT,
					IS,
					gb,
					lr,
					wm,
					Kl,
					cN,
					Oi,
					Pm,
					lO,
					qv,
					DU,
					kZ,
					WQ,
					wH,
					Ll,
					sR,
					sd,
					tV,
					eS,
					Tx,
					Ls,
					hX,
					jq,
					xC,
					ps,
					oU,
					Ym,
					uT,
					MH
				)
					local Ys = mO[53]
					local HO = (sR * tV + sd * eS + Tx) % 268435456
					local mD = (sR * Ls + sd * hX + jq) % 268435456
					local NA = fz
					local Dv = 169416070734 + 815174673787 - 984590707656
					local gx = 163426964044 + 886563707804 - 1049990659693
					local UC = 644110004523 + 943729753015 - 1587839757536
					local NX, tv =
						912657421736 + 754014565215 - 1666671980873, 1003174857683 + 661956340020 - 1665131193023
					local RU = 986714266059 + 1039644956132 - 2026359222177
					local Mj, vg =
						539454782203 + 287911111814 - 827238573705, 1029814916063 + 175609922641 - 1205233812683
					local Ke, IV, EB, OD, FI, ap, Ra, mI, Xp, SK, zQ, HL, rY, id, XQ, Hr, oG, uU, Qa =
						125163149882 + 1033524966369 - 1158688056426,
						43052902932 + 129700936252 - 172753794029,
						174685282897 + 78617323556 - 253302558903,
						522197946099 + 712989388108 - 1235187271738,
						897292345249 + 137244574783 - 1034536901063,
						375312043694 + 34570325008 - 409882364403,
						785019129709 + 89670537769 - 874689667460,
						808761757560 + 478943393503 - 1287705151058,
						1026534685662 + 165282610252 - 1191817289220,
						300508378251 + 1082532978168 - 1383041334806,
						659279097651 + 896279990689 - 1555559044707,
						747900836188 + 556477246723 - 1304378053948,
						791962501488 + 1001634849234 - 1793597319364,
						1090999200764 + 313984493714 - 1404983648201,
						677218814267 + 449178091217 - 1126396902707,
						1005853028820 + 197583228508 - 1203436203701,
						376163980975 + 476504559325 - 852668484278,
						667841773878 + 808852148088 - 1476693916545,
						444138061518 + 710649198410 - 1154787232487
					local WD = { 858942415759 + 525379344628 - 1384321697953 }
					local EL = 0
					for FA = 1, #WD do
						EL = (EL * 257 + WD[FA]) % 268435456
					end
					local FA = (EL - bp) % 268435456
					local xY = (
						Ym * (926467543983 + 1078379090422 - 2004846521941) + (
							258079968888
							+ 311435499153
							- 569290073329
						)
					) % 268435456
					fz = (fz + xY) % 268435456
					fz = (fz + MH * (1058260380652 + 1076119645685 - 2134379979558)) % 268435456
					local Ji, GZ, GC, Lz, BC
					local ec = { 86, 143, 152, 1, 150 }
					local aJ = 0
					aJ = (aJ * 257 + 103) % 268435456
					aJ = (aJ * 257 + 193) % 268435456
					for SP = 1, #ec do
						aJ = (aJ * 257 + ec[SP]) % 268435456
					end
					local SP = (aJ - WR) % 268435456
					local Mp = 1
					while Mp <= #ec do
						local dt = (ec[Mp] - (103 + Mp * 193) % 256) % 256
						if dt == 46 then
							Ji = function(bY, hu, sj, nN)
								local Os = (bY.al - Qa - 1) % 65521 + 1
								local QQ, sF, SN, cd, hl = bY.okB, bY.zC, bY.Cd, bY.XC, bY.eP
								local QM = (
									745062166362
									+ 969999580611
									- 1715061746323
									+ Os * (147086865988 + 483527580897 - 630614446802)
									+ mD % 720 * (1 + oG % 719)
									+ FA % 720 * (1 + uU % 719)
									+ SP % 720 * (1 + id % 719)
									+ oU % 720 * (1 + XQ % 719)
								) % 720
								local lX = { 0, 1, 2, 3, 4, 5 }
								local fL = {}
								local dI = { 120, 24, 6, 2, 1, 1 }
								for fH = 1, 6 do
									local IK = fH == 6 and 0 or hs(QM / dI[fH])
									if fH < 6 then
										QM %= dI[fH]
									end
									fL[fH] = lX[IK + 1]
									for uF = IK + 1, #lX - 1 do
										lX[uF] = lX[uF + 1]
									end
									lX[#lX] = nil
								end
								local IK = uT(Os)
								local fH = (
									mD % 65521 * ((Os + EB) % 65521)
									+ FA % 65521 * ((WD[Os] + OD) % 65521)
									+ SP % 65521 * ((Os + oG) % 65521)
									+ oU % 65521 * ((WD[Os] + uU) % 65521)
								) % 268435456
								local uF = (
									EK
									+ Os * Qy
									+ NA
									+ WD[Os] * gx
									+ fH
									+ (
											IK * (891649470367 + 428914803911 - 1320563634463)
											+ (342548600991 + 707659965769 - 1050012263252)
										)
										% 268435456
								) % 268435456
								local ue = ("")["char"]
								local Ww = {}
								local Jn = {}
								local yD = {}
								yD.__index = function(wj, xi)
									if Jn[xi] then
										return rawget(wj, xi)
									end
									if QQ[xi] == nil then
										Jn[xi] = true
										return nil
									end
									local Em = (uF + xi * xC) % 268435456
									Em = (xw * Em + UR) % 268435456
									Em = (xw * Em + UR) % 268435456
									local Ph = (QQ[xi] - Em) % 65536
									local NO = Ph == fL[3] and vg or Mj
									local xg = (uF + xi * NO) % 268435456
									xg = (xw * xg + UR) % 268435456
									xg = (xw * xg + UR) % 268435456
									local gZ
									if Ph == fL[2] then
										gZ = sF[xi] - xg
									elseif Ph == fL[3] or Ph == fL[6] then
										local MK = cd[xi]
										local tZ = hl[xi]
										local vs = ""
										for ws = 1, MK do
											xg = (xw * xg + UR) % 268435456
											vs = vs .. ue((SN[tZ] - xg % 256) % 256)
											tZ += 1
										end
										if Ph == fL[3] then
											return vs
										else
											gZ = nN(vs)
										end
									elseif Ph == fL[4] then
										gZ = true
									elseif Ph == fL[5] then
										gZ = false
									end
									Jn[xi] = true
									rawset(wj, xi, gZ)
									return gZ
								end
								return setmetatable(Ww, yD)
							end
						elseif dt == 150 then
							GC = function(yD, Jn, Ww, ue, uF)
								local fH = (yD.al - Qa - 1) % 65521 + 1
								local IK = (WD[fH] * oG + fH * uU + XQ) % 65521
								local dI = (
									HO % 65521 * ((fH + Ke) % 65521)
									+ mD % 65521 * ((WD[fH] + EB) % 65521)
									+ FA % 65521 * ((fH + uU) % 65521)
									+ SP % 65521 * ((WD[fH] + SK) % 65521)
									+ oU % 65521 * ((fH + XQ) % 65521)
								) % 268435456
								local fL, lX, QM, hl, cd, SN, sF, QQ, Os, nN, sj, hu, bY, gZ, xg =
									mO[12],
									mO[31],
									mO[55],
									mO[73],
									mO[44],
									mO[45],
									mO[23],
									mO[58],
									mO[39],
									mO[24],
									mO[57],
									mO[71],
									mO[42],
									mO[37],
									mO[53]
								local NO = Ji(yD, gZ, SN, nN)
								local Ph = yD.pc
								local Em = {}
								local xi = {
									Jn,
									NO,
									Ph,
									Em,
									Ec,
									ue,
									(uF + IK) % 65536,
									Ww,
									Lz,
									lr,
									wm,
									Kl,
									cN,
									gZ,
									hs,
									lX,
									Os,
									fL,
									QQ,
									sj,
									jh,
									gs,
									xT,
									IS,
									Hr = 1,
									Wh = 0,
									nP = nil,
									UlK = nil,
									zc = IK,
									Yu = RU,
									kRN = 25 + IK % 4096 * 2048,
									RQ = 1305 + IK % 4096 * 2048,
									KU = gb,
									gZwy = 0,
									fT = 2 + (WD[fH] * Xp + fH * SK + IK) % 15,
									MT = dI,
									Cl = 3,
									GT = (fH * 1 + 0) % 3,
								}
								xi.BoGm = yD
								xi.Rug = yD.Rug
								xi.Yz = {}
								xi.zoLA = {}
								xi.Z_A = 0
								xi.rK = 0
								xi.kR = GZ
								GZ(xi, 1)
								return xi
							end
						elseif 106 == dt then
							BC = function(xi, Em, Ph, NO, xg)
								local gZ = GC(xi, Em, Ph, NO, xg)
								local bY = 0
								local hu = Ll and Ll() or 0
								local sj = 0
								local nN = nil
								local Os = 0
								while true do
									gZ.Wh = 225042644584 + 958125953470 - 1183168598038
									if gZ.nP ~= nil then
										local QQ = (gZ.nP - gZ.zc) % 17
										local sF = QQ == 1 and DU or QQ == 2 and kZ or QQ == 3 and WQ or wH
										gZ.nP = nil
										sF(gZ)
									else
										local sF = bY % 4
										local QQ = sF == 0 and Oi or sF == 1 and Pm or sF == 2 and lO or qv
										QQ(gZ)
										bY += 1
									end
									gZ.gZwy += 1
									if gZ.gZwy == gZ.fT then
										gZ.GT = (
											gZ.GT + hs((gZ.MT + 268435455) / 268435456) * (1 + gZ.MT % (gZ.Cl - 1))
										) % gZ.Cl
									end
									if Ll and bY % 128 == 0 then
										local QQ = Ll()
										local sF = QQ - hu
										hu = QQ
										sj += 1
										if sj <= 4 then
											if not nN or sF < nN then
												nN = sF
											end
										else
											if nN and nN > 0 and sF > nN * 100 then
												Os += 1
											else
												Os = 0
											end
											if Os >= 2 then
												gZ.MT = (gZ.MT + (gZ.zc % 65521 * NX + tv + gZ.gZwy * Xp) % 268435456)
													% 268435456
												gZ.fT = gZ.gZwy + 2 + gZ.zc % 7
												Os = 0
											end
										end
									end
									if gZ.UlK ~= nil then
										local sF = gZ[gZ.RQ + 2 * gZ.Yu]
										local QQ = gZ[gZ.RQ + 3 * gZ.Yu]
										local SN = { gZ.GKJ, gZ.QS, gZ.Pdd, gZ.Rj, gZ.Byp }
										for cd = 1, 5 do
											local hl = SN[cd]
											if hl then
												for QM = 1, #hl do
													hl[QM] = nil
												end
											end
										end
										if gZ.zoLA then
											for hl = 1, #gZ.zoLA do
												local cd = gZ.Yz[gZ.zoLA[hl]]
												if cd then
													for QM = 1, 5 do
														local lX = cd[QM]
														if lX then
															for fL = 1, #lX do
																lX[fL] = nil
															end
															cd[QM] = nil
														end
													end
												end
											end
										end
										gZ.Yz = {}
										gZ.zoLA = {}
										gZ.GKJ, gZ.QS, gZ.Pdd, gZ.Rj, gZ.Byp = nil, nil, nil, nil, nil
										gZ.rK = nil
										gZ.Z_A = nil
										for cd = 0, 3 do
											gZ[gZ.RQ + cd * gZ.Yu] = nil
										end
										return jh(sF, 1, QQ)
									end
								end
							end
						elseif 238 == dt then
							Lz = function(Os, nN, sj, hu)
								local bY = (Os.al - Qa - 1) % 65521 + 1
								local gZ = WD[bY]
								local xg = (gZ * rY + bY * id + Hr) % 65536
								local NO = Os.MpX
								local Ph = {}
								for Em = 1, #NO do
									xg = (xg * XQ + Hr + Em) % 65536
									local xi = (NO[Em] - xg) % 65536
									if xi >= 49152 then
										Ph[Em] = sj[xi - 49152]
									elseif xi >= 32768 then
										Ph[Em] = { ORQ = nN[hu[xi - 32768]], psO = 1 }
									else
										Ph[Em] = { ORQ = nN, psO = hu[xi] }
									end
									xi = nil
								end
								local xi = (Os.Wze - (gZ * oG + bY * uU + Hr) % 65536) % 65536
								local Em = (gZ * oG + bY * uU + XQ) % 65521
								NO = nil
								xg = nil
								return function(...)
									local SN = Ys("#", ...)
									local QQ = { ... }
									local sF = SN - xi
									if sF < 0 then
										sF = 0
									end
									local cd = {}
									for hl = 1, sF do
										cd[1 + (hl + Em - 1) % sF] = QQ[xi + hl]
									end
									local hl = {}
									for lX = 1, xi do
										hl[Os.pc[lX]] = QQ[lX]
									end
									local lX = GC(Os, hl, Ph, cd, sF)
									local QM = 0
									local fL = Ll and Ll() or 0
									local dI = 0
									local IK = nil
									local fH = 0
									while true do
										lX.Wh = 225042644584 + 958125953470 - 1183168598038
										if lX.nP ~= nil then
											local uF = (lX.nP - lX.zc) % 17
											local ue = uF == 1 and DU or uF == 2 and kZ or uF == 3 and WQ or wH
											lX.nP = nil
											ue(lX)
										else
											local ue = QM % 4
											local uF = ue == 0 and Oi or ue == 1 and Pm or ue == 2 and lO or qv
											uF(lX)
											QM += 1
										end
										lX.gZwy += 1
										if lX.gZwy == lX.fT then
											lX.GT = (
												lX.GT + hs((lX.MT + 268435455) / 268435456) * (1 + lX.MT % (lX.Cl - 1))
											) % lX.Cl
										end
										if Ll and QM % 128 == 0 then
											local uF = Ll()
											local ue = uF - fL
											fL = uF
											dI += 1
											if dI <= 4 then
												if not IK or ue < IK then
													IK = ue
												end
											else
												if IK and IK > 0 and ue > IK * 100 then
													fH += 1
												else
													fH = 0
												end
												if fH >= 2 then
													lX.MT = (
														lX.MT + (lX.zc % 65521 * NX + tv + lX.gZwy * Xp) % 268435456
													) % 268435456
													lX.fT = lX.gZwy + 2 + lX.zc % 7
													fH = 0
												end
											end
										end
										if lX.UlK ~= nil then
											local ue = lX[lX.RQ + 2 * lX.Yu]
											local uF = lX[lX.RQ + 3 * lX.Yu]
											local Ww = { lX.GKJ, lX.QS, lX.Pdd, lX.Rj, lX.Byp }
											for Jn = 1, 5 do
												local yD = Ww[Jn]
												if yD then
													for wj = 1, #yD do
														yD[wj] = nil
													end
												end
											end
											if lX.zoLA then
												for yD = 1, #lX.zoLA do
													local Jn = lX.Yz[lX.zoLA[yD]]
													if Jn then
														for wj = 1, 5 do
															local vs = Jn[wj]
															if vs then
																for tZ = 1, #vs do
																	vs[tZ] = nil
																end
																Jn[wj] = nil
															end
														end
													end
												end
											end
											lX.Yz = {}
											lX.zoLA = {}
											lX.GKJ, lX.QS, lX.Pdd, lX.Rj, lX.Byp = nil, nil, nil, nil, nil
											lX.rK = nil
											lX.Z_A = nil
											for Jn = 0, 3 do
												lX[lX.RQ + Jn * lX.Yu] = nil
											end
											return jh(ue, 1, uF)
										end
									end
								end
							end
						elseif dt == 166 then
							GZ = function(Em, xi)
								local Ph = Em.BoGm
								local NO = (Ph.al - Qa - 1) % 65521 + 1
								Em.Z_A += 1
								local xg = (Em.Z_A * NX + xi * tv + NO) % 65536
								local gZ = Em.Yz[xi]
								if gZ then
									local bY = gZ[8]
									for hu = 1, #gZ[1] do
										gZ[1][hu] = (gZ[1][hu] - bY + xg) % 65536
										gZ[2][hu] = (gZ[2][hu] - bY + xg) % 65536
										gZ[3][hu] = (gZ[3][hu] - bY + xg) % 65536
										gZ[4][hu] = (gZ[4][hu] - bY + xg) % 256
										gZ[5][hu] = (gZ[5][hu] - bY + xg) % 65536
									end
									gZ[8] = xg
									Em.GKJ, Em.QS, Em.Pdd, Em.Rj, Em.Byp = gZ[4], gZ[1], gZ[3], gZ[2], gZ[5]
									Em.sRW, Em.zR = gZ[6], gZ[7]
									Em.rK = xg
									return
								end
								if UC == 0 and Em.GKJ then
									local bY = { Em.GKJ, Em.QS, Em.Pdd, Em.Rj, Em.Byp }
									for hu = 1, 5 do
										local sj = bY[hu]
										if sj then
											for nN = 1, #sj do
												sj[nN] = nil
											end
										end
									end
									Em.GKJ, Em.QS, Em.Pdd, Em.Rj, Em.Byp = nil, nil, nil, nil, nil
								end
								local bY = WD[NO]
								local sj = 2 * ((xw + bY * Ke + NO * IV) % 16000000) + 1
								local hu = (UR + bY * EB + NO * OD) % 268435456
								local nN = (rV + bY * FI + NO * ap) % 268435456
								local Os = 3 + (bY * Xp + NO * SK) % 7
								local fH = Ph.jp[xi]
								local IK = Ph.lXC[xi]
								local dI = (
									HO % 65521 * ((NO + Ke) % 65521)
									+ FA % 65521 * ((bY + OD) % 65521)
									+ SP % 65521 * ((xi + SK) % 65521)
									+ oU % 65521 * ((fH + Xp) % 65521)
									+ Em.MT % 65521 * ((fH + NO + HL) % 65521)
								) % 268435456
								local fL = (EK + NO * Qy + fH * nN + fz + WD[NO] * Dv + dI) % 268435456
								local QM, lX, hl, cd, sF = {}, {}, {}, {}, {}
								local QQ = Ph.fQ
								local SN = Ph.mF[xi]
								for Ww = 1, IK do
									fL = (sj * fL + hu) % 268435456
									lX[Ww] = (QQ[SN] - fL % 65536 - (54115316249 + 860314697104 - 914429987393)) % 65536
									SN += 1
									fL = (sj * fL + hu) % 268435456
									cd[Ww] = (
										QQ[SN]
										- fL % 65536
										- (418405165762 + 1006177548244 - 1424582668067)
										- WD[NO]
									) % 65536
									SN += 1
									fL = (sj * fL + hu) % 268435456
									hl[Ww] = (QQ[SN] - fL % 65536 - (478627566814 + 892954891679 - 1371582411044))
										% 65536
									SN += 1
									fL = (sj * fL + hu) % 268435456
									QM[Ww] = (QQ[SN] - fL % 65536 - (616110219038 + 665875141430 - 1281985322693))
										% 65536
									SN += 1
									fL = (sj * fL + hu) % 268435456
									sF[Ww] = (QQ[SN] - fL % 65536 - (224588903016 + 1045799269862 - 1270388144906))
										% 65536
									SN += 1
									if Ww % Os == 0 then
										fL = (fL + bY * zQ + (fH + Ww - 1) * HL) % 268435456
									end
								end
								local Ww = (Ra + NO * mI) % 24
								local uF = { 0, 1, 2, 3 }
								local ue = {}
								local Jn = { 6, 2, 1, 1 }
								for yD = 1, 4 do
									local vs = yD == 4 and 0 or hs(Ww / Jn[yD])
									if yD < 4 then
										Ww %= Jn[yD]
									end
									ue[yD] = uF[vs + 1]
									for wj = vs + 1, #uF - 1 do
										uF[wj] = uF[wj + 1]
									end
									uF[#uF] = nil
								end
								local vs = { lX, hl, cd, sF }
								local yD = {}
								for wj = 1, 4 do
									yD[ue[wj] + 1] = vs[wj]
								end
								local wj, tZ, MK, ws, Kn = QM, yD[1], yD[2], yD[3], yD[4]
								for CV = 1, #wj do
									wj[CV] = (wj[CV] + xg) % 256
									tZ[CV] = (tZ[CV] + xg) % 65536
									MK[CV] = (MK[CV] + xg) % 65536
									ws[CV] = (ws[CV] + xg) % 65536
									Kn[CV] = (Kn[CV] + xg) % 65536
								end
								local CV = { tZ, ws, MK, wj, Kn, fH, fH + IK - 1, xg }
								if UC > 0 then
									Em.Yz[xi] = CV
									Em.zoLA[#Em.zoLA + 1] = xi
									if #Em.zoLA > UC then
										local Vd = Em.zoLA[1]
										for eg = 1, #Em.zoLA - 1 do
											Em.zoLA[eg] = Em.zoLA[eg + 1]
										end
										Em.zoLA[#Em.zoLA] = nil
										local eg = Em.Yz[Vd]
										Em.Yz[Vd] = nil
										if eg then
											for wD = 1, 5 do
												local Sv = eg[wD]
												if Sv then
													for SW = 1, #Sv do
														Sv[SW] = nil
													end
													eg[wD] = nil
												end
											end
										end
									end
								end
								Em.GKJ, Em.QS, Em.Pdd, Em.Rj, Em.Byp = wj, tZ, MK, ws, Kn
								Em.sRW, Em.zR = fH, fH + IK - 1
								Em.rK = xg
							end
						else
							fz = (fz + by) % 268435456
							NA = (NA + by) % 268435456
						end
						Mp += 1
					end
					ec = nil
					return BC
				end
				Jc = (
					(function(Mp)
						local SP = (166168250 + 0) % 268435456
						for aJ = 1, #Mp do
							SP = (SP * 62557 + #Mp[aJ] + aJ * 20262 + 180118395) % 268435456
						end
						return (98269434 + SP) % 268435456
					end)(h) + Qx
				) % 268435456
				ge = (
					(function(SP)
						local Mp = (139094879 + 0) % 268435456
						for aJ = 1, #SP do
							Mp = (Mp * 34614 + #SP[aJ] + aJ * 52264 + 264056709) % 268435456
						end
						return (77334149 + Mp) % 268435456
					end)(h) + Qx
				) % 268435456
				SB = (
					(function(Mp)
						local SP = (160685029 + 0) % 268435456
						for aJ = 1, #Mp do
							SP = (SP * 61783 + #Mp[aJ] + aJ * 57518 + 162135474) % 268435456
						end
						return (64238525 + SP) % 268435456
					end)(h) + Qx
				) % 268435456
				UA = (
					(function(SP)
						local Mp = (205791655 + 0) % 268435456
						for aJ = 1, #SP do
							Mp = (Mp * 11570 + #SP[aJ] + aJ * 55290 + 134238161) % 268435456
						end
						return (179873095 + Mp) % 268435456
					end)(h) + Qx
				) % 268435456
				tY = (
					(function(Mp)
						local SP = (234026181 + 0) % 268435456
						for aJ = 1, #Mp do
							SP = (SP * 26649 + #Mp[aJ] + aJ * 12007 + 231606192) % 268435456
						end
						return (81740678 + SP) % 268435456
					end)(h) + Qx
				) % 268435456
				YG = (function(SP)
					local Mp = (260339103 + 0) % 268435456
					for aJ = 1, #SP do
						Mp = (Mp * 5843 + #SP[aJ] + aJ * 18827 + 225592263) % 268435456
					end
					return (126358787 + Mp) % 268435456
				end)(h)
				jO = (function(Mp)
					local SP = (211460451 + 0) % 268435456
					for aJ = 1, #Mp do
						SP = (SP * 36544 + #Mp[aJ] + aJ * 23864 + 11695559) % 268435456
					end
					return (121740757 + SP) % 268435456
				end)(h)
				dn = (function(SP)
					local Mp = (36570817 + 0) % 268435456
					for aJ = 1, #SP do
						Mp = (Mp * 19319 + #SP[aJ] + aJ * 39564 + 69902671) % 268435456
					end
					return (95605719 + Mp) % 268435456
				end)(h)
				lt = (function(Mp)
					local SP = (38151492 + 0) % 268435456
					for aJ = 1, #Mp do
						SP = (SP * 35142 + #Mp[aJ] + aJ * 39057 + 24233868) % 268435456
					end
					return (108188137 + SP) % 268435456
				end)(h)
				ji = (function(SP)
					local Mp = (219797183 + 0) % 268435456
					for aJ = 1, #SP do
						Mp = (Mp * 45709 + #SP[aJ] + aJ * 57531 + 85175184) % 268435456
					end
					return (218664638 + Mp) % 268435456
				end)(h)
				lK = (function(Mp)
					local SP = (133882784 + 0) % 268435456
					for aJ = 1, #Mp do
						SP = (SP * 17832 + #Mp[aJ] + aJ * 16934 + 87441617) % 268435456
					end
					return (232584782 + SP) % 268435456
				end)(h)
				local SP = 217764525
				local aJ = {
					[SP] = {
						Jc,
						ge,
						SB,
						UA,
						tY,
						(function(Mp)
							local aJ = (1063907 + 0) % 268435456
							for ec = 1, #Mp do
								aJ = (aJ * 20856 + #Mp[ec] + ec * 18553 + 100806620) % 268435456
							end
							return (180014276 + aJ) % 268435456
						end)(h),
						MQ,
						ky,
					},
				}
				local ec = function(Mp)
					local ec = aJ[Mp]
					aJ[Mp] = nil
					return ec[1], ec[2], ec[3], ec[4], ec[5], ec[6], ec[7], ec[8]
				end
				local Mp, BC = Y(function()
					return mg(h, d, SP, hG, si, g, ec, j, f, N, z, M, P, Z, nT, h, h, kx, h, h, gP, JZ, IZ, T, l)
				end)
				mg = nil
				MQ = nil
				if not Mp then
					kl()
				end
				YI, Ki, Qj, Qb, EX, Lu, dL = BC()
				BC = nil
				local Lz = Wj()
				Wj = nil
				nW, mN = Lz[1], Lz[2]
				local GC, GZ = Y(UW)
				UW = nil
				GQ = (GC and GZ or 12345679) % 268435456
				CS[449] = dL
				for Ji, xY in pairs(YI) do
					if Ji < 256 then
						CS[(Ji + Qx) % 256] = xY
					end
				end
				local xY = 0
				local Ji
				local FA = (Qj % 256 + Lu % 256 * (645793354540 + 836857957765 - 1482651312162) + 0 * 17) % 256
				local EL = 1012786445271 + 628993901860 - 1641780347010
				do
					local WD =
						"\23\184\231\15\253|\169@!\225\207\196:\207^a\213\225\224\18z\247\193\211\250'R\223^z\196\213\201d\183\150\187\\\166\158-\133\8L?\243\192\199\8\8\194\182\15\132\170.\128\205\190\28\231\247*OCa\229d\184\21\233\163VLX+*~\172dc\164l\13`9\221w\237\130\241_[yq\254g?\229W\178\159\18\162\247H\172\10i\162>\231\149\193q\150\195\169e\206\247\156\236\18\224m\238.\184x\153r\17\229\26\142}6^\171bP\19)\149\152\193\214u\253\162J7\216\190HI\190=)\134=\177\8\254\142\238vK\209)\136Jy\235A\154x\7t_\178\249\251\189\169C\28--V\"R\241\134L\244V\205<\148`E\165\2454Q\150~\155\133\219\131\138\206\146\149\197\222\244\179 F\222\204p\172\245\147V\186%\18\144\253/k(\211\13\219\225p\159cL\2\19\184K\23PQr\1\134,\206\20\10\188t]\192\209\5\19G\173\140\211\230\200T\247"
					local Qa = ""
					local uU = ("")["char"]
					local Hr = (function(oG)
						local Hr = (156878687 + 0) % 268435456
						for XQ = 1, #oG do
							Hr = (Hr * 31115 + #oG[XQ] + XQ * 57490 + 207006257) % 268435456
						end
						return (104626909 + Hr) % 268435456
					end)(h)
					local XQ = (function(oG)
						local XQ = (212669983 + 0) % 268435456
						for id = 1, #oG do
							XQ = (XQ * 4061 + #oG[id] + id * 40668 + 109254111) % 268435456
						end
						return (76239574 + XQ) % 268435456
					end)(h)
					local id = (function(oG)
						local id = (122238028 + 0) % 268435456
						for rY = 1, #oG do
							id = (id * 17794 + #oG[rY] + rY * 35036 + 69449127) % 268435456
						end
						return (126481492 + id) % 268435456
					end)(h)
					for oG = 1, #WD do
						Hr = (XQ * Hr + id) % 268435456
						local rY = (
							P(WD, oG) - (Hr % 256 + d(Hr / 256) % 256 + d(Hr / 65536) % 256 + d(Hr / 16777216)) % 256
						) % 256
						xY = (xY * 257 + rY) % 268435456
						Qa = Qa .. uU((rY + (FA + oG * EL) % 256) % 256)
					end
					Ji = Qa
					WD = nil
					Qa = nil
					Hr = nil
					XQ = nil
					id = nil
				end
				local id
				local XQ = (Qj % 256 + Lu % 256 * (924152731054 + 390718596277 - 1314871327246) + 1 * 17) % 256
				local Hr = 454409690835 + 652723821871 - 1107133512487
				do
					local uU =
						"W,\224\29cR\172O\21\201\23\203\133V\243\163V\170\12\132>\254g6\195\187\190#]\156f\204\185\1540G>\219\153H\129\229C\163\157\197D\6>\227Y\204\14\24OH\134\249'C\22#\180R\21\1590u~\192cX\166\136[|\149mH\220\166v\199\30^\22\232\198FB\154\22\211-B\11q\10\191<\20s\141\0[\15)\145\192\168?FX\181\230\140O\21\189x\4\133\21\170F\211\127\204mH\145-=tl\20\132\144\240jAv\219|u\196\25C\232\160\157\179\192\222\28\199\234\215\171\199G\230\213\134L\225\138\16<\166\156\165\187&\235R\149\137o0\244\200\165{\208\179)x\175\22\148a\218\129sh\229\222\223[\13(\223`CL\248D|\204\185\12_$\248n\186\176j^\218b\13!\136\1Y\143P5\237\210`\185\219\190\222xY\142\23\240\155.E\173no0\131\168\245\178\149\167#\227\228\127U\27Z\16E\159s<1n"
					local Qa = ""
					local WD = ("")["char"]
					local oG = (function(rY)
						local oG = (64946038 + 0) % 268435456
						for HL = 1, #rY do
							oG = (oG * 53990 + #rY[HL] + HL * 36472 + 121724034) % 268435456
						end
						return (30037847 + oG) % 268435456
					end)(h)
					local HL = (function(rY)
						local HL = (52705072 + 0) % 268435456
						for zQ = 1, #rY do
							HL = (HL * 40074 + #rY[zQ] + zQ * 5941 + 185004246) % 268435456
						end
						return (38866749 + HL) % 268435456
					end)(h)
					local zQ = (function(rY)
						local zQ = (29248819 + 0) % 268435456
						for SK = 1, #rY do
							zQ = (zQ * 41042 + #rY[SK] + SK * 14627 + 180650716) % 268435456
						end
						return (257858581 + zQ) % 268435456
					end)(h)
					for rY = 1, #uU do
						oG = (HL * oG + zQ) % 268435456
						local SK = (
							P(uU, rY) - (oG % 256 + d(oG / 256) % 256 + d(oG / 65536) % 256 + d(oG / 16777216)) % 256
						) % 256
						xY = (xY * 257 + SK) % 268435456
						Qa = Qa .. WD((SK + (XQ + rY * Hr) % 256) % 256)
					end
					id = Qa
					uU = nil
					Qa = nil
					oG = nil
					HL = nil
					zQ = nil
				end
				local zQ
				local HL = (Qj % 256 + Lu % 256 * (1016342628313 + 765691572580 - 1782034200639) + 2 * 17) % 256
				local oG = 614532345630 + 366650144938 - 981182490375
				do
					local WD =
						'y]\234\174\179L\251\215\163\170\2\202\246\237\20l\6J\151>R\130\212\246\02659\153\25\230\157/iT\160\18oc<5\188\187\23d\146\136\164\132\138\226@\224\186\159\206\127\254_6\244(\230\21U\148U`\155\246`\177:\145N\250\209u"$\134\252G#`\208\161\173\208?\254\180\207\231\181n\11\191\208Z\177\220\192\0092\183F&\211\2505\241\182=\131\239\135\183\226\188u\24f\130Xy\241Up\12\156\161\247\199\24U#Q\219F/\149^\168\151\245%44\5d\10U\150?\4\136\221q\160\1738_\167\14\226o\206\212"\203^\145\129 \233\\t\176\228\162[\25<%\189w\239\174\221\235\246\154|\221\28I?\210\12\176+ZX\203(\242\129\133=\196E\166\232UPn\136A\1399\7\12z\188M>\10\27\148/\208\200\0\19\237\143D\162M\196\155\27\243\217\135\200\239\164M\140\148\241\225\204\16\251\25\29*P\185\16\152\182`\242\229\147_\23u\246\28?\243\1642\5\241\165\163\11\211h}\160\196\233'
					local Qa = ""
					local uU = ("")["char"]
					local rY = (function(SK)
						local rY = (188767059 + 0) % 268435456
						for Xp = 1, #SK do
							rY = (rY * 49286 + #SK[Xp] + Xp * 6239 + 61059456) % 268435456
						end
						return (51676613 + rY) % 268435456
					end)(h)
					local Xp = (function(SK)
						local Xp = (240533764 + 0) % 268435456
						for mI = 1, #SK do
							Xp = (Xp * 40766 + #SK[mI] + mI * 56501 + 51647625) % 268435456
						end
						return (29460232 + Xp) % 268435456
					end)(h)
					local mI = (function(SK)
						local mI = (122463867 + 0) % 268435456
						for Ra = 1, #SK do
							mI = (mI * 57686 + #SK[Ra] + Ra * 27903 + 113526344) % 268435456
						end
						return (126523973 + mI) % 268435456
					end)(h)
					for SK = 1, #WD do
						rY = (Xp * rY + mI) % 268435456
						local Ra = (
							P(WD, SK) - (rY % 256 + d(rY / 256) % 256 + d(rY / 65536) % 256 + d(rY / 16777216)) % 256
						) % 256
						xY = (xY * 257 + Ra) % 268435456
						Qa = Qa .. uU((Ra + (HL + SK * oG) % 256) % 256)
					end
					zQ = Qa
					WD = nil
					Qa = nil
					rY = nil
					Xp = nil
					mI = nil
				end
				local function mI(Xp, rY, uU, Qa, WD, Ra, SK, ap, FI, OD, EB, IV, Ke, vg, Mj)
					local RU, tv, NX, UC, gx, Dv, NA, mD, HO, Ys, MH, uT, Ym, oU, ps, xC, jq, hX =
						Xp[1],
						Xp[2],
						Xp[3],
						Xp[4],
						Xp[5],
						Xp[6],
						Xp[7],
						Xp[8],
						Xp[9],
						Xp[10],
						Xp[11],
						Xp[13],
						Xp[15],
						Xp[16],
						Xp[17],
						Xp[18],
						Xp[19],
						Xp[20]
					local Ls = Xp.zc
					NA = (NA - Ls) % 65536
					local Tx = { rY, uU, Qa, WD }
					local eS = {}
					local tV = (P(FI, Ra) - (OD + Ra * EB) % 256) % 256
					local sd = Ra + 1
					local sR = sd + tV - 1
					while sd <= sR do
						local Ll = (P(FI, sd) - (OD + sd * EB) % 256) % 256
						local wH = (P(FI, sd + 1) - (OD + (sd + 1) * EB) % 256) % 256
						local WQ = (P(FI, sd + 2) - (OD + (sd + 2) * EB) % 256) % 256
						sd += 3
						local kZ = { Ll, wH, WQ }
						local DU, qv, lO = kZ[Ke], kZ[vg], kZ[Mj]
						if IV[1] == DU then
							do
								local Pm = 1
								local Oi = 2
								eS[Pm] = RU[Tx[Oi] + 1]
							end
							do
								local Oi = 2
								local Pm = 3
								eS[Oi] = RU[Tx[Pm] + 1]
							end
							do
								local Pm = 3
								local Oi = 0
								local cN, Kl = eS[1], eS[2]
								local wm, lr = ps(cN), ps(Kl)
								if wm == q[1] and lr == q[1] or wm == q[5] and lr == q[5] then
									eS[Pm] = cN < Kl
								else
									local gb, IS = Ys(cN, q[14])
									if not gb then
										local xT, gs = Ys(Kl, q[14])
										gb = xT
										IS = IS or gs
									end
									if gb then
										eS[Pm] = gb(cN, Kl)
									elseif IS then
										eS[Pm] = cN < Kl
									else
										oU(q[7] .. wm .. q[8] .. lr, 0)
									end
								end
							end
							do
								local lr = 1
								local wm = 3
								RU[Tx[lr] + 1] = eS[wm]
							end
						elseif IV[2] == DU then
							do
								local wm = 1
								local lr = 2
								eS[wm] = RU[Tx[lr] + 1]
							end
							do
								local lr = 2
								local wm = 3
								eS[lr] = RU[Tx[wm] + 1]
							end
							do
								local wm = 3
								local lr = 0
								local Kl, cN = eS[1], eS[2]
								local Oi, Pm = ps(Kl), ps(cN)
								local IS
								if Oi == Pm and (Oi == q[1] or Oi == q[5] or Oi == q[21] or Oi == q[22]) then
									IS = Kl == cN
								else
									local gb = Ys(Kl, q[23]) or Ys(cN, q[23])
									if gb then
										IS = gb(Kl, cN)
									else
										IS = Kl == cN
									end
								end
								eS[wm] = not IS
							end
							do
								local IS = 1
								local Pm = 3
								RU[Tx[IS] + 1] = eS[Pm]
							end
						elseif IV[3] == DU then
							if WD % 4 == 3 then
								local Pm = { rY, Qa }
								Pm[uU % 2 + 1] = WD
							elseif WD % 4 == 2 then
								local Pm = rY
								if uU % 2 == 0 then
									Pm += Qa % 3
								else
									Pm -= WD % 3
								end
							elseif WD % 4 == 0 then
								local Pm = (rY + uU) * (Qa % 17 + 1) - WD
							else
								local Pm
								if rY < uU then
									Pm = Qa
								else
									Pm = WD
								end
							end
						elseif IV[4] == DU then
							do
								local Pm = 1
								local IS = 1
								eS[Pm] = RU[Tx[IS] + 1]
							end
							do
								local IS = 2
								local Pm = 2
								eS[IS] = RU[Tx[Pm] + 1]
							end
							do
								local Pm = 0
								local IS = 0
								for Oi = 1, NA do
									eS[1][eS[2] + Oi] = Dv[1 + (Oi + Xp.zc - 1) % NA]
								end
								eS[2] = eS[2] + NA
							end
							do
								local IS = 2
								local Pm = 2
								RU[Tx[IS] + 1] = eS[Pm]
							end
						elseif IV[5] == DU then
							do
								local Pm = 1
								local IS = 2
								eS[Pm] = RU[Tx[IS] + 1]
							end
							do
								local IS = 2
								local Pm = 3
								eS[IS] = RU[Tx[Pm] + 1]
							end
							do
								local Pm = 3
								local IS = 0
								local Oi, cN = eS[1], eS[2]
								if ps(Oi) == q[1] and ps(cN) == q[1] then
									eS[Pm] = Oi ^ cN
								else
									local Kl, lr = Ys(Oi, q[2])
									if not Kl then
										local wm, gb = Ys(cN, q[2])
										Kl = wm
										lr = lr or gb
									end
									if Kl then
										eS[Pm] = Kl(Oi, cN)
									elseif lr then
										eS[Pm] = Oi ^ cN
									else
										oU(q[3] .. ps(Oi) .. q[4], 0)
									end
								end
							end
							do
								local cN = 1
								local Oi = 3
								RU[Tx[cN] + 1] = eS[Oi]
							end
						elseif IV[6] == DU then
							do
								local Oi = 1
								local cN = 1
								eS[Oi] = RU[Tx[cN] + 1]
							end
							do
								local cN = 2
								local Oi = 2
								eS[cN] = RU[Tx[Oi] + 1]
							end
							do
								local Oi = 3
								local cN = 3
								eS[Oi] = RU[Tx[cN] + 1]
							end
							do
								local cN = 0
								local Oi = 0
								local IS, Pm, lr = eS[1], eS[2], eS[3]
								if ps(IS) ~= q[16] then
									local Kl, gb = Ys(IS, q[17])
									if ps(Kl) == q[18] then
										Kl(IS, Pm, lr)
									elseif Kl ~= nil then
										hX(Kl, Pm, lr)
									elseif gb then
										IS[Pm] = lr
									else
										oU(q[19] .. ps(IS) .. q[4], 0)
									end
								else
									if jq(IS, Pm) == nil then
										local gb, Kl = Ys(IS, q[17])
										if ps(gb) == q[18] then
											gb(IS, Pm, lr)
										elseif gb ~= nil then
											hX(gb, Pm, lr)
										elseif Kl then
											IS[Pm] = lr
										else
											hX(IS, Pm, lr)
										end
									else
										hX(IS, Pm, lr)
									end
								end
							end
						elseif IV[7] == DU then
							do
								local lr = 1
								local Pm = 2
								eS[lr] = RU[Tx[Pm] + 1]
							end
							do
								local Pm = 2
								local lr = 3
								eS[Pm] = RU[Tx[lr] + 1]
							end
							do
								local lr = 3
								local Pm = 0
								local IS, Oi = eS[1], eS[2]
								if ps(IS) == q[1] and ps(Oi) == q[1] then
									eS[lr] = IS / Oi
								else
									local cN, Kl = Ys(IS, q[26])
									if not cN then
										local gb, wm = Ys(Oi, q[26])
										cN = gb
										Kl = Kl or wm
									end
									if cN then
										eS[lr] = cN(IS, Oi)
									elseif Kl then
										eS[lr] = IS / Oi
									else
										oU(q[3] .. ps(IS) .. q[4], 0)
									end
								end
							end
							do
								local Oi = 1
								local IS = 3
								RU[Tx[Oi] + 1] = eS[IS]
							end
						elseif IV[8] == DU then
							local IS = Tx[1] + 1
							local Oi = RU[NX[IS]]
							local Pm, lr = MH(Oi)
							local Kl = lr and 1 or 0
							local cN = Tx[2]
							local wm = Tx[4] % 2 == 1
							local gb = Tx[4] >= 2
							local gs = cN + Kl
							if gb then
								gs += RU[NX[IS + cN + 1]]
							end
							local xT = {}
							if Kl == 1 then
								xT[1] = Oi
							end
							local hs = gb and cN + RU[NX[IS + cN + 1]] or cN
							for jh = 1, hs do
								if gb and jh > cN then
									local Ec = IS + jh + 1
									local mO = NX[Ec]
									if mO then
										xT[Kl + jh] = RU[mO]
									else
										xT[Kl + jh] = UC[Ec]
									end
								else
									xT[Kl + jh] = RU[NX[IS + jh]]
								end
							end
							if wm then
								for jh = 1, NA do
									xT[gs + jh] = Dv[1 + (jh + Xp.zc - 1) % NA]
								end
								gs += NA
							end
							Xp[Xp.kRN + 512 + 0 * Xp.Yu] = Pm
							Xp[Xp.kRN + 512 + 1 * Xp.Yu] = xT
							Xp[Xp.kRN + 512 + 2 * Xp.Yu] = gs
							Xp[Xp.kRN + 512 + 3 * Xp.Yu] = Tx[1]
							Xp[Xp.kRN + 512 + 4 * Xp.Yu] = Tx[2]
							Xp[Xp.kRN + 512 + 5 * Xp.Yu] = Tx[3]
							Xp[Xp.kRN + 512 + 6 * Xp.Yu] = Tx[4]
							Xp.nP = (Xp.zc + 2) % 17
						elseif IV[9] == DU then
							if RU[Tx[1] + 1] then
								Xp.Hr = Tx[2]
							end
						elseif IV[10] == DU then
							local hs = Xp[Xp.kRN + 1024 + 7 * Xp.Yu]
							local xT = Xp[Xp.kRN + 1024 + 8 * Xp.Yu]
							for gs = 1, ap do
								hs[xT + gs] = SK[gs]
							end
							RU[Tx[3] + 1] = xT + ap
						elseif IV[11] == DU then
							local xT = Tx[1] + 1
							local hs = RU[NX[xT]]
							local gs, gb = MH(hs)
							local wm = gb and 1 or 0
							local cN = Tx[2]
							local Kl = RU[NX[xT + cN + 1]]
							local lr = cN + Kl + wm
							local Pm = {}
							if wm == 1 then
								Pm[1] = hs
							end
							for Oi = 1, cN + Kl do
								if Oi <= cN then
									Pm[wm + Oi] = RU[NX[xT + Oi]]
								else
									local IS = xT + Oi + 1
									local jh = NX[IS]
									if jh then
										Pm[wm + Oi] = RU[jh]
									else
										Pm[wm + Oi] = UC[IS]
									end
								end
							end
							if Tx[4] == 1 then
								for Oi = 1, NA do
									Pm[lr + Oi] = Dv[1 + (Oi + Xp.zc - 1) % NA]
								end
								lr += NA
							end
							Xp[Xp.kRN + 768 + 0 * Xp.Yu] = gs
							Xp[Xp.kRN + 768 + 1 * Xp.Yu] = Pm
							Xp[Xp.kRN + 768 + 2 * Xp.Yu] = lr
							Xp[Xp.kRN + 768 + 3 * Xp.Yu] = Tx[1]
							Xp[Xp.kRN + 768 + 4 * Xp.Yu] = Tx[2]
							Xp[Xp.kRN + 768 + 5 * Xp.Yu] = Tx[3]
							Xp[Xp.kRN + 768 + 6 * Xp.Yu] = Tx[4]
							Xp.nP = (Xp.zc + 3) % 17
						elseif IV[12] == DU then
							do
								local Pm = 1
								local lr = 2
								eS[Pm] = RU[Tx[lr] + 1]
							end
							do
								local lr = 2
								local Pm = 3
								eS[lr] = RU[Tx[Pm] + 1]
							end
							do
								local Pm = 3
								local lr = 0
								local Kl, cN = eS[1], eS[2]
								if ps(Kl) == q[1] and ps(cN) == q[1] then
									eS[Pm] = Kl % cN
								else
									local wm, gb = Ys(Kl, q[15])
									if not wm then
										local gs, hs = Ys(cN, q[15])
										wm = gs
										gb = gb or hs
									end
									if wm then
										eS[Pm] = wm(Kl, cN)
									elseif gb then
										eS[Pm] = Kl % cN
									else
										oU(q[3] .. ps(Kl) .. q[4], 0)
									end
								end
							end
							do
								local cN = 1
								local Kl = 3
								RU[Tx[cN] + 1] = eS[Kl]
							end
						elseif IV[13] == DU then
							do
								local Kl = 1
								local cN = 2
								eS[Kl] = RU[Tx[cN] + 1]
							end
							do
								local cN = 2
								local Kl = 3
								eS[cN] = RU[Tx[Kl] + 1]
							end
							do
								local Kl = 3
								local cN = 0
								local lr, Pm = eS[1], eS[2]
								local gb, wm = ps(lr), ps(Pm)
								local hs
								if gb == wm and (gb == q[1] or gb == q[5] or gb == q[21] or gb == q[22]) then
									hs = lr == Pm
								else
									local gs = Ys(lr, q[23]) or Ys(Pm, q[23])
									if gs then
										hs = gs(lr, Pm)
									else
										hs = lr == Pm
									end
								end
								eS[Kl] = hs
							end
							do
								local hs = 1
								local wm = 3
								RU[Tx[hs] + 1] = eS[wm]
							end
						elseif IV[14] == DU then
							RU[Tx[1] + 1] = NA
						elseif IV[15] == DU then
							do
								local wm = 1
								local hs = 2
								eS[wm] = tv[Tx[hs] + 1]
							end
							do
								local hs = 2
								local wm = 1
								eS[hs] = RU[Tx[wm] + 1]
							end
							do
								local wm = 1
								local hs = 2
								gx[eS[wm]] = eS[hs]
							end
						elseif IV[16] == DU then
							local hs = Tx[1] + 1
							local wm = RU[NX[hs]]
							local gb, Pm = MH(wm)
							local lr = Pm and 1 or 0
							local cN = Tx[2] + lr
							local Kl = {}
							if lr == 1 then
								Kl[1] = wm
							end
							for gs = 1, Tx[2] do
								Kl[lr + gs] = RU[NX[hs + gs]]
							end
							if Tx[4] == 1 then
								for gs = 1, NA do
									Kl[cN + gs] = Dv[1 + (gs + Xp.zc - 1) % NA]
								end
								cN += NA
							end
							Xp[Xp.kRN + 256 + 0 * Xp.Yu] = gb
							Xp[Xp.kRN + 256 + 1 * Xp.Yu] = Kl
							Xp[Xp.kRN + 256 + 2 * Xp.Yu] = cN
							Xp[Xp.kRN + 256 + 3 * Xp.Yu] = Tx[1]
							Xp[Xp.kRN + 256 + 4 * Xp.Yu] = Tx[2]
							Xp[Xp.kRN + 256 + 5 * Xp.Yu] = Tx[3]
							Xp[Xp.kRN + 256 + 6 * Xp.Yu] = Tx[4]
							Xp.nP = (Xp.zc + 1) % 17
						elseif IV[17] == DU then
							Xp.Hr = Tx[qv]
						elseif IV[18] == DU then
							do
								local Kl = 1
								local cN = 2
								eS[Kl] = RU[Tx[cN] + 1]
							end
							do
								local cN = 2
								local Kl = 3
								eS[cN] = RU[Tx[Kl] + 1]
							end
							do
								local Kl = 3
								local cN = 0
								eS[Kl] = Ym(eS[1] / eS[2])
							end
							do
								local cN = 1
								local Kl = 3
								RU[Tx[cN] + 1] = eS[Kl]
							end
						elseif IV[19] == DU then
							do
								local Kl = 1
								local cN = 2
								eS[Kl] = RU[Tx[cN] + 1]
							end
							do
								local cN = 2
								local Kl = 3
								eS[cN] = RU[Tx[Kl] + 1]
							end
							do
								local Kl = 3
								local cN = 0
								local lr, Pm = eS[1], eS[2]
								local gb, wm = ps(lr), ps(Pm)
								if gb == q[1] and wm == q[1] or gb == q[5] and wm == q[5] then
									eS[Kl] = lr <= Pm
								else
									local hs, gs = Ys(lr, q[6])
									if not hs then
										local xT, Oi = Ys(Pm, q[6])
										hs = xT
										gs = gs or Oi
									end
									if hs then
										eS[Kl] = hs(lr, Pm)
									elseif gs then
										eS[Kl] = lr <= Pm
									else
										oU(q[7] .. gb .. q[8] .. wm, 0)
									end
								end
							end
							do
								local wm = 1
								local gb = 3
								RU[Tx[wm] + 1] = eS[gb]
							end
						elseif IV[20] == DU then
							do
								local gb = 1
								local wm = 2
								eS[gb] = tv[Tx[wm] + 1]
							end
							do
								local wm = 2
								local gb = 1
								eS[wm] = gx[eS[gb]]
							end
							do
								local gb = 1
								local wm = 2
								RU[Tx[gb] + 1] = eS[wm]
							end
						elseif IV[21] == DU then
							do
								local wm = 1
								local gb = 2
								eS[wm] = RU[Tx[gb] + 1]
							end
							do
								local gb = 2
								local wm = 3
								eS[gb] = RU[Tx[wm] + 1]
							end
							do
								local wm = 3
								local gb = 0
								local Pm, lr = eS[1], eS[2]
								local cN, Kl = ps(Pm), ps(lr)
								if cN == q[1] and Kl == q[1] or cN == q[5] and Kl == q[5] then
									eS[wm] = Pm > lr
								else
									local gs, hs = Ys(Pm, q[14])
									if not gs then
										local Oi, xT = Ys(lr, q[14])
										gs = Oi
										hs = hs or xT
									end
									if gs then
										eS[wm] = gs(lr, Pm)
									elseif hs then
										eS[wm] = Pm > lr
									else
										oU(q[7] .. cN .. q[8] .. Kl, 0)
									end
								end
							end
							do
								local Kl = 1
								local cN = 3
								RU[Tx[Kl] + 1] = eS[cN]
							end
						elseif IV[22] == DU then
							do
								local cN = 1
								local Kl = 2
								eS[cN] = tv[Tx[Kl] + 1]
							end
							do
								local Kl = 1
								local cN = 1
								local lr = eS[cN]
								local Pm = Tx[3]
								local gb = Tx[4]
								local wm = q[29][q[28]]
								local hs = q[29][q[27]]
								local gs = q[29]
								for xT = 1, #lr do
									Pm = (Pm * 257 + gb + xT) % 65521
									gs = gs .. hs((wm(lr, xT) - Pm % 256) % 256)
								end
								eS[Kl] = gs
							end
							do
								local gs = 1
								local hs = 1
								RU[Tx[gs] + 1] = eS[hs]
							end
						elseif IV[23] == DU then
							local hs = {}
							RU[Tx[1] + 1] = hs
						elseif IV[24] == DU then
							do
								local hs = 1
								local gs = 2
								eS[hs] = RU[Tx[gs] + 1]
							end
							do
								local gs = 2
								local hs = 3
								eS[gs] = RU[Tx[hs] + 1]
							end
							do
								local hs = 3
								local gs = 0
								local wm, gb = eS[1], eS[2]
								if ps(wm) == q[1] and ps(gb) == q[1] then
									eS[hs] = wm + gb
								else
									local Pm, lr = Ys(wm, q[10])
									if not Pm then
										local cN, Kl = Ys(gb, q[10])
										Pm = cN
										lr = lr or Kl
									end
									if Pm then
										eS[hs] = Pm(wm, gb)
									elseif lr then
										eS[hs] = wm + gb
									else
										oU(q[3] .. ps(wm) .. q[4], 0)
									end
								end
							end
							do
								local gb = 1
								local wm = 3
								RU[Tx[gb] + 1] = eS[wm]
							end
						elseif IV[25] == DU then
							local wm = Tx[1] + 1
							Xp[Xp.RQ + 0 * Xp.Yu] = wm
							Xp[Xp.RQ + 1 * Xp.Yu] = ap
							local gb = ap
							if Tx[3] ~= 255 and Tx[3] > gb then
								gb = Tx[3]
							end
							for gs = 1, gb do
								local hs = NX[wm + gs]
								if hs then
									RU[hs] = SK[gs]
								else
									UC[wm + gs] = SK[gs]
								end
							end
						elseif IV[26] == DU then
							local gb = not RU[Tx[2] + 1]
							RU[Tx[1] + 1] = gb
						elseif IV[27] == DU then
							do
								local gb = 1
								local wm = 2
								eS[gb] = RU[Tx[wm] + 1]
							end
							do
								local wm = 2
								local gb = 3
								eS[wm] = RU[Tx[gb] + 1]
							end
							do
								local gb = 3
								local wm = 0
								local hs, gs = eS[1], eS[2]
								local lr, Pm = ps(hs), ps(gs)
								if lr == q[1] and Pm == q[1] or lr == q[5] and Pm == q[5] then
									eS[gb] = hs >= gs
								else
									local Kl, cN = Ys(hs, q[6])
									if not Kl then
										local xT, Oi = Ys(gs, q[6])
										Kl = xT
										cN = cN or Oi
									end
									if Kl then
										eS[gb] = Kl(gs, hs)
									elseif cN then
										eS[gb] = hs >= gs
									else
										oU(q[7] .. lr .. q[8] .. Pm, 0)
									end
								end
							end
							do
								local Pm = 1
								local lr = 3
								RU[Tx[Pm] + 1] = eS[lr]
							end
						elseif IV[28] == DU then
							do
								local lr = 1
								local Pm = 2
								eS[lr] = RU[Tx[Pm] + 1]
							end
							do
								local Pm = 2
								local lr = 3
								eS[Pm] = RU[Tx[lr] + 1]
							end
							do
								local lr = 3
								local Pm = 0
								local gs, hs = eS[1], eS[2]
								local wm
								if ps(gs) == q[5] then
									wm = gs[hs]
								elseif ps(gs) == q[16] then
									wm = jq(gs, hs)
									if wm == nil then
										local gb, cN = Ys(gs, q[20])
										if ps(gb) == q[18] then
											wm = gb(gs, hs)
										elseif gb ~= nil then
											wm = gb[hs]
										elseif cN then
											wm = gs[hs]
										end
									end
								else
									local cN, gb = Ys(gs, q[20])
									if ps(cN) == q[18] then
										wm = cN(gs, hs)
									elseif cN ~= nil then
										wm = cN[hs]
									elseif gb then
										wm = gs[hs]
									else
										oU(q[19] .. ps(gs) .. q[4], 0)
									end
								end
								eS[lr] = wm
							end
							do
								local wm = 1
								local hs = 3
								RU[Tx[wm] + 1] = eS[hs]
							end
						elseif IV[29] == DU then
							local hs = (1280 * Tx[1] + 34922) % 65536
							local wm = (Tx[2] - hs) % 65536
							local gs = (Tx[3] - hs) % 65536
							local Pm = (Tx[4] - hs) % 65536
							local lr = Ym(Pm / 256)
							local gb = { wm % 256, Ym(wm / 256), gs % 256, Ym(gs / 256), Pm % 256 }
							local cN = q[29][q[27]]
							local Kl = q[29]
							for Oi = 1, lr do
								Kl = Kl .. cN(gb[Oi])
							end
							RU[Tx[1] + 1] = Kl
						elseif IV[30] == DU then
							for Kl = 1, Tx[lO] do
								RU[NX[Tx[qv] + Kl]] = nil
							end
						elseif IV[31] == DU then
							RU[Tx[qv] + 1] = HO(Xp.BoGm[Tx[lO]], RU, mD, NX)
						elseif IV[32] == DU then
							do
								local Kl = 1
								local cN = 2
								eS[Kl] = RU[Tx[cN] + 1]
							end
							do
								local cN = 2
								local Kl = 3
								eS[cN] = RU[Tx[Kl] + 1]
							end
							do
								local Kl = 3
								local cN = 0
								local gb, lr = eS[1], eS[2]
								if ps(gb) == q[1] and ps(lr) == q[1] then
									eS[Kl] = gb - lr
								else
									local Pm, gs = Ys(gb, q[9])
									if not Pm then
										local wm, hs = Ys(lr, q[9])
										Pm = wm
										gs = gs or hs
									end
									if Pm then
										eS[Kl] = Pm(gb, lr)
									elseif gs then
										eS[Kl] = gb - lr
									else
										oU(q[3] .. ps(gb) .. q[4], 0)
									end
								end
							end
							do
								local lr = 1
								local gb = 3
								RU[Tx[lr] + 1] = eS[gb]
							end
						elseif IV[33] == DU then
							do
								local gb = 1
								local lr = 2
								eS[gb] = RU[Tx[lr] + 1]
							end
							do
								local lr = 2
								local gb = 3
								eS[lr] = RU[Tx[gb] + 1]
							end
							do
								local gb = 3
								local lr = 0
								local cN, Kl = eS[1], eS[2]
								local gs, Pm = ps(cN), ps(Kl)
								if (gs == q[1] or gs == q[5]) and (Pm == q[1] or Pm == q[5]) then
									eS[gb] = cN .. Kl
								else
									local hs, wm = Ys(cN, q[12])
									if not hs then
										local Oi, xT = Ys(Kl, q[12])
										hs = Oi
										wm = wm or xT
									end
									if hs then
										eS[gb] = hs(cN, Kl)
									elseif wm then
										eS[gb] = cN .. Kl
									else
										oU(q[13] .. gs .. q[4], 0)
									end
								end
							end
							do
								local Pm = 1
								local gs = 3
								RU[Tx[Pm] + 1] = eS[gs]
							end
						elseif IV[34] == DU then
							local gs = Tx[1] + 1
							for Pm = 1, ap do
								local Kl = NX[gs + Pm]
								if Kl then
									RU[Kl] = SK[Pm]
								else
									UC[gs + Pm] = SK[Pm]
								end
							end
							RU[NX[gs]] = ap
						elseif IV[35] == DU then
							do
								local gs = 1
								local Kl = 2
								eS[gs] = RU[Tx[Kl] + 1]
							end
							do
								local Kl = 2
								local gs = 1
								local Pm = eS[gs]
								local cN = uT and Ys(Pm, q[24])
								if cN then
									eS[Kl] = cN(Pm)
								else
									eS[Kl] = #Pm
								end
							end
							do
								local cN = 1
								local Pm = 2
								RU[Tx[cN] + 1] = eS[Pm]
							end
						elseif IV[36] == DU then
							local Pm = Tx[1] + 1
							Xp[Xp.RQ + 0 * Xp.Yu] = Pm
							Xp[Xp.RQ + 1 * Xp.Yu] = ap
							local cN = ap
							if Tx[3] ~= 255 and Tx[3] > cN then
								cN = Tx[3]
							end
							for gs = 1, cN do
								local Kl = NX[Pm + gs]
								if Kl then
									RU[Kl] = SK[gs]
								else
									UC[Pm + gs] = SK[gs]
								end
							end
						elseif IV[37] == DU then
							do
								local cN = 1
								local Pm = 2
								eS[cN] = RU[Tx[Pm] + 1]
							end
							do
								local Pm = 2
								local cN = 3
								eS[Pm] = RU[Tx[cN] + 1]
							end
							do
								local cN = 3
								local Pm = 0
								local Kl, gs = eS[1], eS[2]
								if ps(Kl) == q[1] and ps(gs) == q[1] then
									eS[cN] = Kl * gs
								else
									local lr, gb = Ys(Kl, q[25])
									if not lr then
										local wm, hs = Ys(gs, q[25])
										lr = wm
										gb = gb or hs
									end
									if lr then
										eS[cN] = lr(Kl, gs)
									elseif gb then
										eS[cN] = Kl * gs
									else
										oU(q[3] .. ps(Kl) .. q[4], 0)
									end
								end
							end
							do
								local gs = 1
								local Kl = 3
								RU[Tx[gs] + 1] = eS[Kl]
							end
						elseif IV[38] == DU then
							local Kl = mD[Tx[2] + 1]
							local gs = Kl.ORQ[Kl.psO]
							RU[Tx[1] + 1] = gs
						elseif IV[39] == DU then
							if not RU[Tx[1] + 1] then
								Xp.Hr = Tx[2]
							end
						elseif IV[40] == DU then
							local gs = {}
							local Kl = Tx[2]
							local Pm
							if Kl == 255 then
								local cN = Tx[4]
								for gb = 1, cN do
									gs[gb] = RU[NX[Tx[1] + gb]]
								end
								if Tx[3] == 1 then
									for gb = 1, NA do
										gs[cN + gb] = Dv[1 + (gb + Xp.zc - 1) % NA]
									end
									Pm = cN + NA
								else
									for gb = 1, Xp[Xp.RQ + 1 * Xp.Yu] do
										local lr = NX[Xp[Xp.RQ + 0 * Xp.Yu] + gb]
										if lr then
											gs[cN + gb] = RU[lr]
										else
											gs[cN + gb] = UC[Xp[Xp.RQ + 0 * Xp.Yu] + gb]
										end
									end
									Pm = cN + Xp[Xp.RQ + 1 * Xp.Yu]
								end
							else
								for cN = 1, Kl do
									gs[cN] = RU[NX[Tx[1] + cN]]
								end
								Pm = Kl
							end
							Xp[Xp.RQ + 2 * Xp.Yu] = gs
							Xp[Xp.RQ + 3 * Xp.Yu] = Pm
							Xp.UlK = (Xp.zc + Xp.Yu) % 65521
						elseif IV[41] == DU then
							local Pm = RU[Tx[2] + 1]
							RU[Tx[1] + 1] = Pm
						elseif IV[42] == DU then
							do
								local Pm = 1
								local Kl = 2
								eS[Pm] = RU[Tx[Kl] + 1]
							end
							do
								local Kl = 2
								local Pm = 1
								local gs = eS[Pm]
								if ps(gs) == q[1] then
									eS[Kl] = -gs
								else
									local cN, lr = Ys(gs, q[11])
									if cN then
										eS[Kl] = cN(gs)
									elseif lr then
										eS[Kl] = -gs
									else
										oU(q[3] .. ps(gs) .. q[4], 0)
									end
								end
							end
							do
								local gs = 1
								local Pm = 2
								RU[Tx[gs] + 1] = eS[Pm]
							end
						elseif IV[43] == DU then
							do
								local Pm = 1
								local gs = 1
								eS[Pm] = RU[Tx[gs] + 1]
							end
							do
								local gs = 2
								local Pm = 2
								eS[gs] = RU[Tx[Pm] + 1]
							end
							do
								local Pm = 3
								local gs = 3
								eS[Pm] = RU[Tx[gs] + 1]
							end
							do
								local gs = 0
								local Pm = 0
								eS[2] = eS[2] + 1
								eS[1][eS[2]] = eS[3]
							end
							do
								local Pm = 2
								local gs = 2
								RU[Tx[Pm] + 1] = eS[gs]
							end
						elseif IV[44] == DU then
							local gs = {}
							for Pm = 1, NA do
								gs[Pm] = Dv[1 + (Pm + Xp.zc - 1) % NA]
							end
							RU[Tx[1] + 1] = gs
						elseif IV[45] == DU then
							local gs = tv[Tx[2] + 1]
							RU[Tx[1] + 1] = gs
						elseif IV[46] == DU then
							local gs = mD[Tx[1] + 1]
							local Pm = RU[Tx[2] + 1]
							gs.ORQ[gs.psO] = Pm
						elseif IV[47] == DU then
							local Pm = RU[NX[Tx[1] + 1]]
							local gs, Kl = MH(Pm)
							local lr = Kl and 1 or 0
							local cN = Ym(Tx[4] / 2)
							local gb = Tx[4] % 2 == 1
							local hs = gb and RU[NX[Tx[1] + cN + 2]] or 0
							local wm = cN + lr + hs
							local xT = {}
							if lr == 1 then
								xT[1] = Pm
							end
							for Oi = 1, cN + hs do
								if gb and Oi > cN then
									local jh = Tx[1] + Oi + 2
									local IS = NX[jh]
									if IS then
										xT[lr + Oi] = RU[IS]
									else
										xT[lr + Oi] = UC[jh]
									end
								else
									xT[lr + Oi] = RU[NX[Tx[1] + Oi + 1]]
								end
							end
							Xp[Xp.kRN + 1024 + 0 * Xp.Yu] = gs
							Xp[Xp.kRN + 1024 + 1 * Xp.Yu] = xT
							Xp[Xp.kRN + 1024 + 2 * Xp.Yu] = wm
							Xp[Xp.kRN + 1024 + 3 * Xp.Yu] = Tx[1]
							Xp[Xp.kRN + 1024 + 4 * Xp.Yu] = Tx[2]
							Xp[Xp.kRN + 1024 + 5 * Xp.Yu] = Tx[3]
							Xp[Xp.kRN + 1024 + 6 * Xp.Yu] = Tx[4]
							Xp[Xp.kRN + 1024 + 7 * Xp.Yu] = RU[Tx[2] + 1]
							Xp[Xp.kRN + 1024 + 8 * Xp.Yu] = RU[Tx[3] + 1]
							Xp.nP = (Xp.zc + 4) % 17
						end
					end
					for lO = 1, 3 do
						eS[lO] = nil
					end
					DK = nil
					for lO = 1, 4 do
						Tx[lO] = nil
					end
				end
				local jq = function(sR, sd, tV, eS, Tx, Ls, hX, jq)
					return mI(
						sR,
						sd,
						tV,
						eS,
						Tx,
						Ls,
						hX,
						jq,
						Ji,
						FA,
						EL,
						{
							242,
							83,
							101,
							64,
							162,
							37,
							93,
							221,
							245,
							61,
							140,
							25,
							40,
							182,
							198,
							125,
							73,
							32,
							179,
							246,
							45,
							112,
							225,
							149,
							41,
							169,
							235,
							165,
							109,
							129,
							110,
							67,
							81,
							22,
							46,
							104,
							76,
							21,
							220,
							119,
							74,
							99,
							51,
							63,
							132,
							152,
							231,
						},
						1,
						3,
						2
					)
				end
				local xC = function(hX, Ls, Tx, eS, tV, sd, sR, xC)
					return mI(
						hX,
						Ls,
						Tx,
						eS,
						tV,
						sd,
						sR,
						xC,
						id,
						XQ,
						Hr,
						{
							210,
							239,
							217,
							128,
							93,
							107,
							63,
							244,
							106,
							75,
							175,
							74,
							59,
							104,
							214,
							231,
							64,
							40,
							182,
							113,
							200,
							187,
							26,
							161,
							65,
							168,
							204,
							208,
							73,
							172,
							24,
							96,
							174,
							150,
							235,
							125,
							196,
							27,
							87,
							189,
							185,
							144,
							76,
							160,
							157,
							92,
							218,
						},
						2,
						1,
						3
					)
				end
				local ps = function(sR, sd, tV, eS, Tx, Ls, hX, ps)
					return mI(
						sR,
						sd,
						tV,
						eS,
						Tx,
						Ls,
						hX,
						ps,
						zQ,
						HL,
						oG,
						{
							200,
							219,
							54,
							158,
							221,
							99,
							246,
							232,
							203,
							96,
							11,
							45,
							26,
							223,
							163,
							167,
							208,
							237,
							225,
							53,
							220,
							111,
							182,
							243,
							186,
							126,
							89,
							183,
							69,
							94,
							143,
							173,
							244,
							28,
							115,
							194,
							178,
							155,
							124,
							85,
							206,
							47,
							226,
							119,
							117,
							100,
							139,
						},
						3,
						1,
						2
					)
				end
				CS[(2 + Qx) % 256] = function(hX, Ls, Tx, eS, tV)
					if hX.GT == 2 then
						ps(hX, Ls, Tx, eS, tV, 1)
					elseif hX.GT == 0 then
						jq(hX, Ls, Tx, eS, tV, 1)
					elseif hX.GT == 1 then
						xC(hX, Ls, Tx, eS, tV, 1)
					end
					hX.Wh -= 1
					if hX.Wh <= 0 then
						return
					end
					local sd = hX.Hr
					if sd < hX.sRW or sd > hX.zR then
						hX.kR(hX, hX.Rug[sd])
					end
					local sR = sd - hX.sRW + 1
					local oU = CS[((hX.GKJ[sR] - hX.rK) % 256 + Qx) % 256]
					hX.Hr = sd + 1
					return oU(
						hX,
						(hX.QS[sR] - hX.rK) % 65536,
						(hX.Pdd[sR] - hX.rK) % 65536,
						(hX.Rj[sR] - hX.rK) % 65536,
						(hX.Byp[sR] - hX.rK) % 65536
					)
				end
				CS[(8 + Qx) % 256] = function(oU, sR, sd, tV, eS)
					if 2 == oU.GT then
						ps(oU, sR, sd, tV, eS, 5)
					elseif 1 == oU.GT then
						xC(oU, sR, sd, tV, eS, 7)
					elseif 0 == oU.GT then
						jq(oU, sR, sd, tV, eS, 7)
					end
					oU.Wh -= 1
					if oU.Wh == 0 then
						return
					end
					local Tx = oU.Hr
					if Tx < oU.sRW or Tx > oU.zR then
						oU.kR(oU, oU.Rug[Tx])
					end
					local Ls = Tx - oU.sRW + 1
					oU.Hr = Tx + 1
					return CS[((oU.GKJ[Ls] - oU.rK) % 256 + Qx) % 256](
						oU,
						(oU.QS[Ls] - oU.rK) % 65536,
						(oU.Pdd[Ls] - oU.rK) % 65536,
						(oU.Rj[Ls] - oU.rK) % 65536,
						(oU.Byp[Ls] - oU.rK) % 65536
					)
				end
				CS[(14 + Qx) % 256] = function(Ls, Tx, eS, tV, sd)
					if Ls.GT == 2 then
						ps(Ls, Tx, eS, tV, sd, 11)
					elseif 1 == Ls.GT then
						xC(Ls, Tx, eS, tV, sd, 14)
					elseif Ls.GT == 0 then
						jq(Ls, Tx, eS, tV, sd, 13)
					end
					Ls.Wh -= 1
					if Ls.Wh <= 0 then
						return
					end
					local sR = Ls.Hr
					if sR < Ls.sRW or sR > Ls.zR then
						Ls.kR(Ls, Ls.Rug[sR])
					end
					local oU = sR - Ls.sRW + 1
					local hX = (Ls.GKJ[oU] - Ls.rK) % 256
					Ls.Hr = sR + 1
					return CS[(hX + Qx) % 256](
						Ls,
						(Ls.QS[oU] - Ls.rK) % 65536,
						(Ls.Pdd[oU] - Ls.rK) % 65536,
						(Ls.Rj[oU] - Ls.rK) % 65536,
						(Ls.Byp[oU] - Ls.rK) % 65536
					)
				end
				CS[(31 + Qx) % 256] = function(hX, oU, sR, sd, tV)
					if 0 == hX.GT then
						jq(hX, oU, sR, sd, tV, 18)
					elseif hX.GT == 1 then
						xC(hX, oU, sR, sd, tV, 18)
					elseif hX.GT == 2 then
						ps(hX, oU, sR, sd, tV, 17)
					end
					hX.Wh -= 1
					if hX.Wh == 0 then
						return
					end
					local eS = hX.Hr
					if eS < hX.sRW or eS > hX.zR then
						hX.kR(hX, hX.Rug[eS])
					end
					local Tx = eS - hX.sRW + 1
					local Ls = (hX.GKJ[Tx] - hX.rK) % 256
					local Ym, uT, MH, Ys =
						(hX.QS[Tx] - hX.rK) % 65536,
						(hX.Pdd[Tx] - hX.rK) % 65536,
						(hX.Rj[Tx] - hX.rK) % 65536,
						(hX.Byp[Tx] - hX.rK) % 65536
					hX.Hr = eS + 1
					return CS[(Ls + Qx) % 256](hX, Ym, uT, MH, Ys)
				end
				CS[(6 + Qx) % 256] = function(Ys, MH, uT, Ym, Ls)
					if Ys.GT == 1 then
						xC(Ys, MH, uT, Ym, Ls, 24)
					elseif Ys.GT == 2 then
						ps(Ys, MH, uT, Ym, Ls, 23)
					elseif 0 == Ys.GT then
						jq(Ys, MH, uT, Ym, Ls, 25)
					end
					Ys.Wh -= 1
					if Ys.Wh <= 0 then
						return
					end
					local Tx = Ys.Hr
					if Tx < Ys.sRW or Tx > Ys.zR then
						Ys.kR(Ys, Ys.Rug[Tx])
					end
					local eS = Tx - Ys.sRW + 1
					local tV = (Ys.GKJ[eS] - Ys.rK) % 256
					Ys.Hr = Tx + 1
					return CS[(tV + Qx) % 256](
						Ys,
						(Ys.QS[eS] - Ys.rK) % 65536,
						(Ys.Pdd[eS] - Ys.rK) % 65536,
						(Ys.Rj[eS] - Ys.rK) % 65536,
						(Ys.Byp[eS] - Ys.rK) % 65536
					)
				end
				CS[(7 + Qx) % 256] = function(tV, eS, Tx, Ls, Ym)
					if tV.GT == 1 then
						xC(tV, eS, Tx, Ls, Ym, 30)
					elseif 2 == tV.GT then
						ps(tV, eS, Tx, Ls, Ym, 30)
					elseif tV.GT == 0 then
						jq(tV, eS, Tx, Ls, Ym, 30)
					end
					tV.Wh -= 1
					if tV.Wh == 0 then
						return
					end
					local uT = tV.Hr
					if uT < tV.sRW or uT > tV.zR then
						tV.kR(tV, tV.Rug[uT])
					end
					local MH = uT - tV.sRW + 1
					local Ys = CS[((tV.GKJ[MH] - tV.rK) % 256 + Qx) % 256]
					tV.Hr = uT + 1
					return Ys(
						tV,
						(tV.QS[MH] - tV.rK) % 65536,
						(tV.Pdd[MH] - tV.rK) % 65536,
						(tV.Rj[MH] - tV.rK) % 65536,
						(tV.Byp[MH] - tV.rK) % 65536
					)
				end
				CS[(29 + Qx) % 256] = function(Ys, MH, uT, Ym, Ls)
					if Ys.GT == 1 then
						xC(Ys, MH, uT, Ym, Ls, 37)
					elseif 0 == Ys.GT then
						jq(Ys, MH, uT, Ym, Ls, 36)
					elseif Ys.GT == 2 then
						ps(Ys, MH, uT, Ym, Ls, 37)
					end
					Ys.Wh -= 1
					if Ys.Wh <= 0 then
						return
					end
					local Tx = Ys.Hr
					if Tx < Ys.sRW or Tx > Ys.zR then
						Ys.kR(Ys, Ys.Rug[Tx])
					end
					local eS = Tx - Ys.sRW + 1
					local tV = (Ys.GKJ[eS] - Ys.rK) % 256
					local sd, sR, oU, hX =
						(Ys.QS[eS] - Ys.rK) % 65536,
						(Ys.Pdd[eS] - Ys.rK) % 65536,
						(Ys.Rj[eS] - Ys.rK) % 65536,
						(Ys.Byp[eS] - Ys.rK) % 65536
					Ys.Hr = Tx + 1
					return CS[(tV + Qx) % 256](Ys, sd, sR, oU, hX)
				end
				CS[(33 + Qx) % 256] = function(hX, oU, sR, sd, tV)
					if 0 == hX.GT then
						jq(hX, oU, sR, sd, tV, 40)
					elseif hX.GT == 1 then
						xC(hX, oU, sR, sd, tV, 42)
					elseif hX.GT == 2 then
						ps(hX, oU, sR, sd, tV, 44)
					end
					hX.Wh -= 1
					if hX.Wh == 0 then
						return
					end
					local eS = hX.Hr
					if eS < hX.sRW or eS > hX.zR then
						hX.kR(hX, hX.Rug[eS])
					end
					local Tx = eS - hX.sRW + 1
					local Ls = CS[((hX.GKJ[Tx] - hX.rK) % 256 + Qx) % 256]
					hX.Hr = eS + 1
					return Ls(
						hX,
						(hX.QS[Tx] - hX.rK) % 65536,
						(hX.Pdd[Tx] - hX.rK) % 65536,
						(hX.Rj[Tx] - hX.rK) % 65536,
						(hX.Byp[Tx] - hX.rK) % 65536
					)
				end
				CS[(12 + Qx) % 256] = function(Ls, Tx, eS, tV, sd)
					if 1 == Ls.GT then
						xC(Ls, Tx, eS, tV, sd, 47)
					elseif 0 == Ls.GT then
						jq(Ls, Tx, eS, tV, sd, 46)
					elseif 2 == Ls.GT then
						ps(Ls, Tx, eS, tV, sd, 51)
					end
					Ls.Wh -= 1
					if Ls.Wh <= 0 then
						return
					end
					local sR = Ls.Hr
					if sR < Ls.sRW or sR > Ls.zR then
						Ls.kR(Ls, Ls.Rug[sR])
					end
					local oU = sR - Ls.sRW + 1
					local hX = (Ls.GKJ[oU] - Ls.rK) % 256
					Ls.Hr = sR + 1
					return CS[(hX + Qx) % 256](
						Ls,
						(Ls.QS[oU] - Ls.rK) % 65536,
						(Ls.Pdd[oU] - Ls.rK) % 65536,
						(Ls.Rj[oU] - Ls.rK) % 65536,
						(Ls.Byp[oU] - Ls.rK) % 65536
					)
				end
				CS[(23 + Qx) % 256] = function(hX, oU, sR, sd, tV)
					if hX.GT == 1 then
						xC(hX, oU, sR, sd, tV, 52)
					elseif 2 == hX.GT then
						ps(hX, oU, sR, sd, tV, 58)
					elseif 0 == hX.GT then
						jq(hX, oU, sR, sd, tV, 50)
					end
					hX.Wh -= 1
					if hX.Wh == 0 then
						return
					end
					local eS = hX.Hr
					if eS < hX.sRW or eS > hX.zR then
						hX.kR(hX, hX.Rug[eS])
					end
					local Tx = eS - hX.sRW + 1
					hX.Hr = eS + 1
					return CS[((hX.GKJ[Tx] - hX.rK) % 256 + Qx) % 256](
						hX,
						(hX.QS[Tx] - hX.rK) % 65536,
						(hX.Pdd[Tx] - hX.rK) % 65536,
						(hX.Rj[Tx] - hX.rK) % 65536,
						(hX.Byp[Tx] - hX.rK) % 65536
					)
				end
				CS[(17 + Qx) % 256] = function(Tx, eS, tV, sd, sR)
					if 0 == Tx.GT then
						jq(Tx, eS, tV, sd, sR, 57)
					elseif Tx.GT == 1 then
						xC(Tx, eS, tV, sd, sR, 58)
					elseif Tx.GT == 2 then
						ps(Tx, eS, tV, sd, sR, 62)
					end
					Tx.Wh -= 1
					if Tx.Wh == 0 then
						return
					end
					local oU = Tx.Hr
					if oU < Tx.sRW or oU > Tx.zR then
						Tx.kR(Tx, Tx.Rug[oU])
					end
					local hX = oU - Tx.sRW + 1
					Tx.Hr = oU + 1
					return CS[((Tx.GKJ[hX] - Tx.rK) % 256 + Qx) % 256](
						Tx,
						(Tx.QS[hX] - Tx.rK) % 65536,
						(Tx.Pdd[hX] - Tx.rK) % 65536,
						(Tx.Rj[hX] - Tx.rK) % 65536,
						(Tx.Byp[hX] - Tx.rK) % 65536
					)
				end
				CS[(36 + Qx) % 256] = function(hX, oU, sR, sd, tV)
					if hX.GT == 1 then
						xC(hX, oU, sR, sd, tV, 65)
					elseif 2 == hX.GT then
						ps(hX, oU, sR, sd, tV, 69)
					elseif 0 == hX.GT then
						jq(hX, oU, sR, sd, tV, 62)
					end
					hX.Wh -= 1
					if hX.Wh == 0 then
						return
					end
					local eS = hX.Hr
					hX.Hr = eS + 1
					if eS < hX.sRW or eS > hX.zR then
						hX.kR(hX, hX.Rug[eS])
					end
					local Tx = eS - hX.sRW + 1
					local Ls = (hX.GKJ[Tx] - hX.rK) % 256
					local Ym = CS[(Ls + Qx) % 256]
					return Ym(
						hX,
						(hX.QS[Tx] - hX.rK) % 65536,
						(hX.Pdd[Tx] - hX.rK) % 65536,
						(hX.Rj[Tx] - hX.rK) % 65536,
						(hX.Byp[Tx] - hX.rK) % 65536
					)
				end
				CS[(5 + Qx) % 256] = function(Ym, Ls, Tx, eS, tV)
					if Ym.GT == 1 then
						xC(Ym, Ls, Tx, eS, tV, 71)
					elseif 2 == Ym.GT then
						ps(Ym, Ls, Tx, eS, tV, 76)
					elseif 0 == Ym.GT then
						jq(Ym, Ls, Tx, eS, tV, 66)
					end
					Ym.Wh -= 1
					if Ym.Wh <= 0 then
						return
					end
					local sd = Ym.Hr
					if sd < Ym.sRW or sd > Ym.zR then
						Ym.kR(Ym, Ym.Rug[sd])
					end
					local sR = sd - Ym.sRW + 1
					local oU = CS[((Ym.GKJ[sR] - Ym.rK) % 256 + Qx) % 256]
					Ym.Hr = sd + 1
					return oU(
						Ym,
						(Ym.QS[sR] - Ym.rK) % 65536,
						(Ym.Pdd[sR] - Ym.rK) % 65536,
						(Ym.Rj[sR] - Ym.rK) % 65536,
						(Ym.Byp[sR] - Ym.rK) % 65536
					)
				end
				CS[(26 + Qx) % 256] = function(oU, sR, sd, tV, eS)
					if oU.GT == 1 then
						xC(oU, sR, sd, tV, eS, 77)
					elseif oU.GT == 2 then
						ps(oU, sR, sd, tV, eS, 82)
					elseif 0 == oU.GT then
						jq(oU, sR, sd, tV, eS, 72)
					end
					oU.Wh -= 1
					if oU.Wh == 0 then
						return
					end
					local Tx = oU.Hr
					oU.Hr = Tx + 1
					if Tx < oU.sRW or Tx > oU.zR then
						oU.kR(oU, oU.Rug[Tx])
					end
					local Ls = Tx - oU.sRW + 1
					local Ym = (oU.GKJ[Ls] - oU.rK) % 256
					local hX = CS[(Ym + Qx) % 256]
					return hX(
						oU,
						(oU.QS[Ls] - oU.rK) % 65536,
						(oU.Pdd[Ls] - oU.rK) % 65536,
						(oU.Rj[Ls] - oU.rK) % 65536,
						(oU.Byp[Ls] - oU.rK) % 65536
					)
				end
				CS[(4 + Qx) % 256] = function(hX, Ym, Ls, Tx, eS)
					if hX.GT == 0 then
						jq(hX, Ym, Ls, Tx, eS, 78)
					elseif hX.GT == 1 then
						xC(hX, Ym, Ls, Tx, eS, 82)
					elseif hX.GT == 2 then
						ps(hX, Ym, Ls, Tx, eS, 88)
					end
					hX.Wh -= 1
					if hX.Wh <= 0 then
						return
					end
					local tV = hX.Hr
					hX.Hr = tV + 1
					if tV < hX.sRW or tV > hX.zR then
						hX.kR(hX, hX.Rug[tV])
					end
					local sd = tV - hX.sRW + 1
					local sR = (hX.GKJ[sd] - hX.rK) % 256
					local oU = CS[(sR + Qx) % 256]
					return oU(
						hX,
						(hX.QS[sd] - hX.rK) % 65536,
						(hX.Pdd[sd] - hX.rK) % 65536,
						(hX.Rj[sd] - hX.rK) % 65536,
						(hX.Byp[sd] - hX.rK) % 65536
					)
				end
				CS[(9 + Qx) % 256] = function(oU, sR, sd, tV, eS)
					if oU.GT == 2 then
						ps(oU, sR, sd, tV, eS, 94)
					elseif 1 == oU.GT then
						xC(oU, sR, sd, tV, eS, 89)
					elseif oU.GT == 0 then
						jq(oU, sR, sd, tV, eS, 83)
					end
					return
				end
				sk = function(eS)
					local tV = eS.KU(
						eS[eS.kRN + 512 + 0 * eS.Yu](
							eS[21](eS[eS.kRN + 512 + 1 * eS.Yu], 1, eS[eS.kRN + 512 + 2 * eS.Yu])
						)
					)
					if eS.GT == 0 then
						jq(
							eS,
							eS[eS.kRN + 512 + 3 * eS.Yu],
							eS[eS.kRN + 512 + 4 * eS.Yu],
							eS[eS.kRN + 512 + 5 * eS.Yu],
							eS[eS.kRN + 512 + 6 * eS.Yu],
							88,
							tV,
							tV.n
						)
					elseif 1 == eS.GT then
						xC(
							eS,
							eS[eS.kRN + 512 + 3 * eS.Yu],
							eS[eS.kRN + 512 + 4 * eS.Yu],
							eS[eS.kRN + 512 + 5 * eS.Yu],
							eS[eS.kRN + 512 + 6 * eS.Yu],
							95,
							tV,
							tV.n
						)
					elseif 2 == eS.GT then
						ps(
							eS,
							eS[eS.kRN + 512 + 3 * eS.Yu],
							eS[eS.kRN + 512 + 4 * eS.Yu],
							eS[eS.kRN + 512 + 5 * eS.Yu],
							eS[eS.kRN + 512 + 6 * eS.Yu],
							101,
							tV,
							tV.n
						)
					end
					for sd = 0, 8 do
						eS[eS.kRN + 512 + sd * eS.Yu] = nil
					end
					eS.Wh -= 1
					if eS.Wh == 0 then
						return
					end
					local sd = eS.Hr
					if sd < eS.sRW or sd > eS.zR then
						eS.kR(eS, eS.Rug[sd])
					end
					local sR = sd - eS.sRW + 1
					eS.Hr = sd + 1
					return CS[((eS.GKJ[sR] - eS.rK) % 256 + Qx) % 256](
						eS,
						(eS.QS[sR] - eS.rK) % 65536,
						(eS.Pdd[sR] - eS.rK) % 65536,
						(eS.Rj[sR] - eS.rK) % 65536,
						(eS.Byp[sR] - eS.rK) % 65536
					)
				end
				CS[(39 + Qx) % 256] = function(sR, sd, tV, eS, oU)
					if 0 == sR.GT then
						jq(sR, sd, tV, eS, oU, 93)
					elseif sR.GT == 1 then
						xC(sR, sd, tV, eS, oU, 99)
					elseif 2 == sR.GT then
						ps(sR, sd, tV, eS, oU, 106)
					end
					return
				end
				CS[(30 + Qx) % 256] = function(oU, eS, tV, sd, sR)
					if oU.GT == 2 then
						ps(oU, eS, tV, sd, sR, 113)
					elseif 1 == oU.GT then
						xC(oU, eS, tV, sd, sR, 106)
					elseif 0 == oU.GT then
						jq(oU, eS, tV, sd, sR, 100)
					end
					oU.Wh -= 1
					if oU.Wh <= 0 then
						return
					end
					local Tx = oU.Hr
					if Tx < oU.sRW or Tx > oU.zR then
						oU.kR(oU, oU.Rug[Tx])
					end
					local Ls = Tx - oU.sRW + 1
					local Ym = (oU.GKJ[Ls] - oU.rK) % 256
					local hX, uT, MH, Ys =
						(oU.QS[Ls] - oU.rK) % 65536,
						(oU.Pdd[Ls] - oU.rK) % 65536,
						(oU.Rj[Ls] - oU.rK) % 65536,
						(oU.Byp[Ls] - oU.rK) % 65536
					oU.Hr = Tx + 1
					return CS[(Ym + Qx) % 256](oU, hX, uT, MH, Ys)
				end
				DT = function(Ys)
					local MH = Ys.KU(
						Ys[Ys.kRN + 1024 + 0 * Ys.Yu](
							Ys[21](Ys[Ys.kRN + 1024 + 1 * Ys.Yu], 1, Ys[Ys.kRN + 1024 + 2 * Ys.Yu])
						)
					)
					if 0 == Ys.GT then
						jq(
							Ys,
							Ys[Ys.kRN + 1024 + 3 * Ys.Yu],
							Ys[Ys.kRN + 1024 + 4 * Ys.Yu],
							Ys[Ys.kRN + 1024 + 5 * Ys.Yu],
							Ys[Ys.kRN + 1024 + 6 * Ys.Yu],
							106,
							MH,
							MH.n
						)
					elseif 1 == Ys.GT then
						xC(
							Ys,
							Ys[Ys.kRN + 1024 + 3 * Ys.Yu],
							Ys[Ys.kRN + 1024 + 4 * Ys.Yu],
							Ys[Ys.kRN + 1024 + 5 * Ys.Yu],
							Ys[Ys.kRN + 1024 + 6 * Ys.Yu],
							111,
							MH,
							MH.n
						)
					elseif Ys.GT == 2 then
						ps(
							Ys,
							Ys[Ys.kRN + 1024 + 3 * Ys.Yu],
							Ys[Ys.kRN + 1024 + 4 * Ys.Yu],
							Ys[Ys.kRN + 1024 + 5 * Ys.Yu],
							Ys[Ys.kRN + 1024 + 6 * Ys.Yu],
							118,
							MH,
							MH.n
						)
					end
					for uT = 0, 8 do
						Ys[Ys.kRN + 1024 + uT * Ys.Yu] = nil
					end
					Ys.Wh -= 1
					if Ys.Wh <= 0 then
						return
					end
					local uT = Ys.Hr
					if uT < Ys.sRW or uT > Ys.zR then
						Ys.kR(Ys, Ys.Rug[uT])
					end
					local hX = uT - Ys.sRW + 1
					local Ym = CS[((Ys.GKJ[hX] - Ys.rK) % 256 + Qx) % 256]
					Ys.Hr = uT + 1
					return Ym(
						Ys,
						(Ys.QS[hX] - Ys.rK) % 65536,
						(Ys.Pdd[hX] - Ys.rK) % 65536,
						(Ys.Rj[hX] - Ys.rK) % 65536,
						(Ys.Byp[hX] - Ys.rK) % 65536
					)
				end
				CS[(0 + Qx) % 256] = function(Ym, hX, uT, MH, Ys)
					if 2 == Ym.GT then
						ps(Ym, hX, uT, MH, Ys, 125)
					elseif 1 == Ym.GT then
						xC(Ym, hX, uT, MH, Ys, 115)
					elseif Ym.GT == 0 then
						jq(Ym, hX, uT, MH, Ys, 113)
					end
					return
				end
				CS[(18 + Qx) % 256] = function(Ys, MH, uT, hX, Ym)
					if 1 == Ys.GT then
						xC(Ys, MH, uT, hX, Ym, 119)
					elseif Ys.GT == 0 then
						jq(Ys, MH, uT, hX, Ym, 120)
					elseif Ys.GT == 2 then
						ps(Ys, MH, uT, hX, Ym, 131)
					end
					Ys.Wh -= 1
					if Ys.Wh == 0 then
						return
					end
					local Ls = Ys.Hr
					if Ls < Ys.sRW or Ls > Ys.zR then
						Ys.kR(Ys, Ys.Rug[Ls])
					end
					local Tx = Ls - Ys.sRW + 1
					local sR = (Ys.GKJ[Tx] - Ys.rK) % 256
					Ys.Hr = Ls + 1
					return CS[(sR + Qx) % 256](
						Ys,
						(Ys.QS[Tx] - Ys.rK) % 65536,
						(Ys.Pdd[Tx] - Ys.rK) % 65536,
						(Ys.Rj[Tx] - Ys.rK) % 65536,
						(Ys.Byp[Tx] - Ys.rK) % 65536
					)
				end
				CS[(11 + Qx) % 256] = function(sR, Tx, Ls, Ym, hX)
					if 1 == sR.GT then
						xC(sR, Tx, Ls, Ym, hX, 126)
					elseif sR.GT == 2 then
						ps(sR, Tx, Ls, Ym, hX, 137)
					elseif 0 == sR.GT then
						jq(sR, Tx, Ls, Ym, hX, 124)
					end
					sR.Wh -= 1
					if sR.Wh <= 0 then
						return
					end
					local uT = sR.Hr
					if uT < sR.sRW or uT > sR.zR then
						sR.kR(sR, sR.Rug[uT])
					end
					local MH = uT - sR.sRW + 1
					local Ys = CS[((sR.GKJ[MH] - sR.rK) % 256 + Qx) % 256]
					sR.Hr = uT + 1
					return Ys(
						sR,
						(sR.QS[MH] - sR.rK) % 65536,
						(sR.Pdd[MH] - sR.rK) % 65536,
						(sR.Rj[MH] - sR.rK) % 65536,
						(sR.Byp[MH] - sR.rK) % 65536
					)
				end
				CS[(21 + Qx) % 256] = function(Ys, MH, uT, hX, Ym)
					if 2 == Ys.GT then
						ps(Ys, MH, uT, hX, Ym, 144)
					elseif 0 == Ys.GT then
						jq(Ys, MH, uT, hX, Ym, 130)
					elseif 1 == Ys.GT then
						xC(Ys, MH, uT, hX, Ym, 130)
					end
					Ys.Wh -= 1
					if Ys.Wh <= 0 then
						return
					end
					local Ls = Ys.Hr
					if Ls < Ys.sRW or Ls > Ys.zR then
						Ys.kR(Ys, Ys.Rug[Ls])
					end
					local Tx = Ls - Ys.sRW + 1
					local sR = CS[((Ys.GKJ[Tx] - Ys.rK) % 256 + Qx) % 256]
					Ys.Hr = Ls + 1
					return sR(
						Ys,
						(Ys.QS[Tx] - Ys.rK) % 65536,
						(Ys.Pdd[Tx] - Ys.rK) % 65536,
						(Ys.Rj[Tx] - Ys.rK) % 65536,
						(Ys.Byp[Tx] - Ys.rK) % 65536
					)
				end
				CS[(19 + Qx) % 256] = function(sR, Tx, Ls, Ym, hX)
					if sR.GT == 1 then
						xC(sR, Tx, Ls, Ym, hX, 136)
					elseif sR.GT == 0 then
						jq(sR, Tx, Ls, Ym, hX, 137)
					elseif sR.GT == 2 then
						ps(sR, Tx, Ls, Ym, hX, 149)
					end
					sR.Wh -= 1
					if sR.Wh == 0 then
						return
					end
					local uT = sR.Hr
					if uT < sR.sRW or uT > sR.zR then
						sR.kR(sR, sR.Rug[uT])
					end
					local MH = uT - sR.sRW + 1
					local Ys = (sR.GKJ[MH] - sR.rK) % 256
					local sd, tV, eS, oU =
						(sR.QS[MH] - sR.rK) % 65536,
						(sR.Pdd[MH] - sR.rK) % 65536,
						(sR.Rj[MH] - sR.rK) % 65536,
						(sR.Byp[MH] - sR.rK) % 65536
					sR.Hr = uT + 1
					return CS[(Ys + Qx) % 256](sR, sd, tV, eS, oU)
				end
				CS[(16 + Qx) % 256] = function(oU, eS, tV, sd, Ys)
					if oU.GT == 0 then
						jq(oU, eS, tV, sd, Ys, 143)
					elseif oU.GT == 2 then
						ps(oU, eS, tV, sd, Ys, 155)
					elseif 1 == oU.GT then
						xC(oU, eS, tV, sd, Ys, 142)
					end
					oU.Wh -= 1
					if oU.Wh == 0 then
						return
					end
					local MH = oU.Hr
					if MH < oU.sRW or MH > oU.zR then
						oU.kR(oU, oU.Rug[MH])
					end
					local uT = MH - oU.sRW + 1
					oU.Hr = MH + 1
					return CS[((oU.GKJ[uT] - oU.rK) % 256 + Qx) % 256](
						oU,
						(oU.QS[uT] - oU.rK) % 65536,
						(oU.Pdd[uT] - oU.rK) % 65536,
						(oU.Rj[uT] - oU.rK) % 65536,
						(oU.Byp[uT] - oU.rK) % 65536
					)
				end
				CS[(22 + Qx) % 256] = function(uT, MH, Ys, sd, tV)
					if uT.GT == 2 then
						ps(uT, MH, Ys, sd, tV, 161)
					elseif uT.GT == 1 then
						xC(uT, MH, Ys, sd, tV, 149)
					elseif uT.GT == 0 then
						jq(uT, MH, Ys, sd, tV, 148)
					end
					uT.Wh -= 1
					if uT.Wh <= 0 then
						return
					end
					local eS = uT.Hr
					if eS < uT.sRW or eS > uT.zR then
						uT.kR(uT, uT.Rug[eS])
					end
					local oU = eS - uT.sRW + 1
					local hX = (uT.GKJ[oU] - uT.rK) % 256
					local Ym, Ls, Tx, sR =
						(uT.QS[oU] - uT.rK) % 65536,
						(uT.Pdd[oU] - uT.rK) % 65536,
						(uT.Rj[oU] - uT.rK) % 65536,
						(uT.Byp[oU] - uT.rK) % 65536
					uT.Hr = eS + 1
					return CS[(hX + Qx) % 256](uT, Ym, Ls, Tx, sR)
				end
				CS[(27 + Qx) % 256] = function(sR, Tx, Ls, Ym, hX)
					if 2 == sR.GT then
						ps(sR, Tx, Ls, Ym, hX, 168)
					elseif 0 == sR.GT then
						jq(sR, Tx, Ls, Ym, hX, 152)
					elseif sR.GT == 1 then
						xC(sR, Tx, Ls, Ym, hX, 156)
					end
					sR.Wh -= 1
					if sR.Wh == 0 then
						return
					end
					local oU = sR.Hr
					if oU < sR.sRW or oU > sR.zR then
						sR.kR(sR, sR.Rug[oU])
					end
					local eS = oU - sR.sRW + 1
					local tV = (sR.GKJ[eS] - sR.rK) % 256
					sR.Hr = oU + 1
					return CS[(tV + Qx) % 256](
						sR,
						(sR.QS[eS] - sR.rK) % 65536,
						(sR.Pdd[eS] - sR.rK) % 65536,
						(sR.Rj[eS] - sR.rK) % 65536,
						(sR.Byp[eS] - sR.rK) % 65536
					)
				end
				CS[(25 + Qx) % 256] = function(tV, eS, oU, hX, Ym)
					if tV.GT == 2 then
						ps(tV, eS, oU, hX, Ym, 174)
					elseif tV.GT == 0 then
						jq(tV, eS, oU, hX, Ym, 159)
					elseif tV.GT == 1 then
						xC(tV, eS, oU, hX, Ym, 160)
					end
					tV.Wh -= 1
					if tV.Wh == 0 then
						return
					end
					local Ls = tV.Hr
					if Ls < tV.sRW or Ls > tV.zR then
						tV.kR(tV, tV.Rug[Ls])
					end
					local Tx = Ls - tV.sRW + 1
					local sR = CS[((tV.GKJ[Tx] - tV.rK) % 256 + Qx) % 256]
					tV.Hr = Ls + 1
					return sR(
						tV,
						(tV.QS[Tx] - tV.rK) % 65536,
						(tV.Pdd[Tx] - tV.rK) % 65536,
						(tV.Rj[Tx] - tV.rK) % 65536,
						(tV.Byp[Tx] - tV.rK) % 65536
					)
				end
				CS[(41 + Qx) % 256] = function(sR, Tx, Ls, Ym, hX)
					if sR.GT == 0 then
						jq(sR, Tx, Ls, Ym, hX, 163)
					elseif 1 == sR.GT then
						xC(sR, Tx, Ls, Ym, hX, 166)
					elseif 2 == sR.GT then
						ps(sR, Tx, Ls, Ym, hX, 178)
					end
					sR.Wh -= 1
					if sR.Wh == 0 then
						return
					end
					local oU = sR.Hr
					if oU < sR.sRW or oU > sR.zR then
						sR.kR(sR, sR.Rug[oU])
					end
					local eS = oU - sR.sRW + 1
					local tV = (sR.GKJ[eS] - sR.rK) % 256
					sR.Hr = oU + 1
					return CS[(tV + Qx) % 256](
						sR,
						(sR.QS[eS] - sR.rK) % 65536,
						(sR.Pdd[eS] - sR.rK) % 65536,
						(sR.Rj[eS] - sR.rK) % 65536,
						(sR.Byp[eS] - sR.rK) % 65536
					)
				end
				CS[(32 + Qx) % 256] = function(tV, eS, oU, hX, Ym)
					if tV.GT == 0 then
						jq(tV, eS, oU, hX, Ym, 170)
					elseif 2 == tV.GT then
						ps(tV, eS, oU, hX, Ym, 185)
					elseif 1 == tV.GT then
						xC(tV, eS, oU, hX, Ym, 173)
					end
					tV.Wh -= 1
					if tV.Wh == 0 then
						return
					end
					local Ls = tV.Hr
					if Ls < tV.sRW or Ls > tV.zR then
						tV.kR(tV, tV.Rug[Ls])
					end
					local Tx = Ls - tV.sRW + 1
					tV.Hr = Ls + 1
					return CS[((tV.GKJ[Tx] - tV.rK) % 256 + Qx) % 256](
						tV,
						(tV.QS[Tx] - tV.rK) % 65536,
						(tV.Pdd[Tx] - tV.rK) % 65536,
						(tV.Rj[Tx] - tV.rK) % 65536,
						(tV.Byp[Tx] - tV.rK) % 65536
					)
				end
				CS[(24 + Qx) % 256] = function(Tx, Ls, Ym, hX, oU)
					if Tx.GT == 1 then
						xC(Tx, Ls, Ym, hX, oU, 179)
					elseif Tx.GT == 2 then
						ps(Tx, Ls, Ym, hX, oU, 192)
					elseif 0 == Tx.GT then
						jq(Tx, Ls, Ym, hX, oU, 176)
					end
					Tx.Wh -= 1
					if Tx.Wh == 0 then
						return
					end
					local eS = Tx.Hr
					if eS < Tx.sRW or eS > Tx.zR then
						Tx.kR(Tx, Tx.Rug[eS])
					end
					local tV = eS - Tx.sRW + 1
					local sR = (Tx.GKJ[tV] - Tx.rK) % 256
					Tx.Hr = eS + 1
					return CS[(sR + Qx) % 256](
						Tx,
						(Tx.QS[tV] - Tx.rK) % 65536,
						(Tx.Pdd[tV] - Tx.rK) % 65536,
						(Tx.Rj[tV] - Tx.rK) % 65536,
						(Tx.Byp[tV] - Tx.rK) % 65536
					)
				end
				ZZ = function(sR)
					local tV = sR.KU(
						sR[sR.kRN + 256 + 0 * sR.Yu](
							sR[21](sR[sR.kRN + 256 + 1 * sR.Yu], 1, sR[sR.kRN + 256 + 2 * sR.Yu])
						)
					)
					if 1 == sR.GT then
						xC(
							sR,
							sR[sR.kRN + 256 + 3 * sR.Yu],
							sR[sR.kRN + 256 + 4 * sR.Yu],
							sR[sR.kRN + 256 + 5 * sR.Yu],
							sR[sR.kRN + 256 + 6 * sR.Yu],
							184,
							tV,
							tV.n
						)
					elseif 0 == sR.GT then
						jq(
							sR,
							sR[sR.kRN + 256 + 3 * sR.Yu],
							sR[sR.kRN + 256 + 4 * sR.Yu],
							sR[sR.kRN + 256 + 5 * sR.Yu],
							sR[sR.kRN + 256 + 6 * sR.Yu],
							182,
							tV,
							tV.n
						)
					elseif sR.GT == 2 then
						ps(
							sR,
							sR[sR.kRN + 256 + 3 * sR.Yu],
							sR[sR.kRN + 256 + 4 * sR.Yu],
							sR[sR.kRN + 256 + 5 * sR.Yu],
							sR[sR.kRN + 256 + 6 * sR.Yu],
							199,
							tV,
							tV.n
						)
					end
					for eS = 0, 8 do
						sR[sR.kRN + 256 + eS * sR.Yu] = nil
					end
					sR.Wh -= 1
					if sR.Wh == 0 then
						return
					end
					local eS = sR.Hr
					sR.Hr = eS + 1
					if eS < sR.sRW or eS > sR.zR then
						sR.kR(sR, sR.Rug[eS])
					end
					local oU = eS - sR.sRW + 1
					local hX = (sR.GKJ[oU] - sR.rK) % 256
					local Ym = CS[(hX + Qx) % 256]
					return Ym(
						sR,
						(sR.QS[oU] - sR.rK) % 65536,
						(sR.Pdd[oU] - sR.rK) % 65536,
						(sR.Rj[oU] - sR.rK) % 65536,
						(sR.Byp[oU] - sR.rK) % 65536
					)
				end
				CS[(10 + Qx) % 256] = function(Ym, hX, oU, eS, tV)
					if Ym.GT == 0 then
						jq(Ym, hX, oU, eS, tV, 189)
					elseif 1 == Ym.GT then
						xC(Ym, hX, oU, eS, tV, 190)
					elseif 2 == Ym.GT then
						ps(Ym, hX, oU, eS, tV, 205)
					end
					return
				end
				CS[(28 + Qx) % 256] = function(tV, eS, oU, hX, Ym)
					if 0 == tV.GT then
						jq(tV, eS, oU, hX, Ym, 196)
					elseif 1 == tV.GT then
						xC(tV, eS, oU, hX, Ym, 194)
					elseif 2 == tV.GT then
						ps(tV, eS, oU, hX, Ym, 210)
					end
					tV.Wh -= 1
					if tV.Wh == 0 then
						return
					end
					local sR = tV.Hr
					if sR < tV.sRW or sR > tV.zR then
						tV.kR(tV, tV.Rug[sR])
					end
					local Ls = sR - tV.sRW + 1
					local Tx = (tV.GKJ[Ls] - tV.rK) % 256
					local sd, Ys, MH, uT =
						(tV.QS[Ls] - tV.rK) % 65536,
						(tV.Pdd[Ls] - tV.rK) % 65536,
						(tV.Rj[Ls] - tV.rK) % 65536,
						(tV.Byp[Ls] - tV.rK) % 65536
					tV.Hr = sR + 1
					return CS[(Tx + Qx) % 256](tV, sd, Ys, MH, uT)
				end
				CS[(1 + Qx) % 256] = function(uT, MH, Ys, sd, Tx)
					if uT.GT == 0 then
						jq(uT, MH, Ys, sd, Tx, 202)
					elseif 2 == uT.GT then
						ps(uT, MH, Ys, sd, Tx, 217)
					elseif uT.GT == 1 then
						xC(uT, MH, Ys, sd, Tx, 198)
					end
					uT.Wh -= 1
					if uT.Wh <= 0 then
						return
					end
					local Ls = uT.Hr
					uT.Hr = Ls + 1
					if Ls < uT.sRW or Ls > uT.zR then
						uT.kR(uT, uT.Rug[Ls])
					end
					local sR = Ls - uT.sRW + 1
					local Ym = (uT.GKJ[sR] - uT.rK) % 256
					local hX = CS[(Ym + Qx) % 256]
					return hX(
						uT,
						(uT.QS[sR] - uT.rK) % 65536,
						(uT.Pdd[sR] - uT.rK) % 65536,
						(uT.Rj[sR] - uT.rK) % 65536,
						(uT.Byp[sR] - uT.rK) % 65536
					)
				end
				Kr = function(hX)
					local Ym = hX.KU(
						hX[hX.kRN + 768 + 0 * hX.Yu](
							hX[21](hX[hX.kRN + 768 + 1 * hX.Yu], 1, hX[hX.kRN + 768 + 2 * hX.Yu])
						)
					)
					if hX.GT == 1 then
						xC(
							hX,
							hX[hX.kRN + 768 + 3 * hX.Yu],
							hX[hX.kRN + 768 + 4 * hX.Yu],
							hX[hX.kRN + 768 + 5 * hX.Yu],
							hX[hX.kRN + 768 + 6 * hX.Yu],
							204,
							Ym,
							Ym.n
						)
					elseif hX.GT == 2 then
						ps(
							hX,
							hX[hX.kRN + 768 + 3 * hX.Yu],
							hX[hX.kRN + 768 + 4 * hX.Yu],
							hX[hX.kRN + 768 + 5 * hX.Yu],
							hX[hX.kRN + 768 + 6 * hX.Yu],
							224,
							Ym,
							Ym.n
						)
					elseif 0 == hX.GT then
						jq(
							hX,
							hX[hX.kRN + 768 + 3 * hX.Yu],
							hX[hX.kRN + 768 + 4 * hX.Yu],
							hX[hX.kRN + 768 + 5 * hX.Yu],
							hX[hX.kRN + 768 + 6 * hX.Yu],
							208,
							Ym,
							Ym.n
						)
					end
					for sR = 0, 8 do
						hX[hX.kRN + 768 + sR * hX.Yu] = nil
					end
					hX.Wh -= 1
					if hX.Wh == 0 then
						return
					end
					local sR = hX.Hr
					if sR < hX.sRW or sR > hX.zR then
						hX.kR(hX, hX.Rug[sR])
					end
					local Ls = sR - hX.sRW + 1
					local Tx = (hX.GKJ[Ls] - hX.rK) % 256
					local sd, Ys, MH, uT =
						(hX.QS[Ls] - hX.rK) % 65536,
						(hX.Pdd[Ls] - hX.rK) % 65536,
						(hX.Rj[Ls] - hX.rK) % 65536,
						(hX.Byp[Ls] - hX.rK) % 65536
					hX.Hr = sR + 1
					return CS[(Tx + Qx) % 256](hX, sd, Ys, MH, uT)
				end
				CS[(35 + Qx) % 256] = function(uT, MH, Ys, sd, Tx)
					if uT.GT == 2 then
						ps(uT, MH, Ys, sd, Tx, 231)
					elseif 0 == uT.GT then
						jq(uT, MH, Ys, sd, Tx, 212)
					elseif 1 == uT.GT then
						xC(uT, MH, Ys, sd, Tx, 210)
					end
					return
				end
				CS[(37 + Qx) % 256] = function(Tx, sd, Ys, MH, uT)
					if Tx.GT == 0 then
						jq(Tx, sd, Ys, MH, uT, 219)
					elseif 1 == Tx.GT then
						xC(Tx, sd, Ys, MH, uT, 215)
					elseif 2 == Tx.GT then
						ps(Tx, sd, Ys, MH, uT, 235)
					end
					Tx.Wh -= 1
					if Tx.Wh == 0 then
						return
					end
					local Ls = Tx.Hr
					Tx.Hr = Ls + 1
					if Ls < Tx.sRW or Ls > Tx.zR then
						Tx.kR(Tx, Tx.Rug[Ls])
					end
					local sR = Ls - Tx.sRW + 1
					local Ym = (Tx.GKJ[sR] - Tx.rK) % 256
					local hX = CS[(Ym + Qx) % 256]
					return hX(
						Tx,
						(Tx.QS[sR] - Tx.rK) % 65536,
						(Tx.Pdd[sR] - Tx.rK) % 65536,
						(Tx.Rj[sR] - Tx.rK) % 65536,
						(Tx.Byp[sR] - Tx.rK) % 65536
					)
				end
				CS[(15 + Qx) % 256] = function(hX, Ym, sR, Ls, uT)
					if hX.GT == 2 then
						ps(hX, Ym, sR, Ls, uT, 240)
					elseif 0 == hX.GT then
						jq(hX, Ym, sR, Ls, uT, 223)
					elseif 1 == hX.GT then
						xC(hX, Ym, sR, Ls, uT, 219)
					end
					hX.Wh -= 1
					if hX.Wh <= 0 then
						return
					end
					local MH = hX.Hr
					hX.Hr = MH + 1
					if MH < hX.sRW or MH > hX.zR then
						hX.kR(hX, hX.Rug[MH])
					end
					local Ys = MH - hX.sRW + 1
					local sd = (hX.GKJ[Ys] - hX.rK) % 256
					local Tx = CS[(sd + Qx) % 256]
					return Tx(
						hX,
						(hX.QS[Ys] - hX.rK) % 65536,
						(hX.Pdd[Ys] - hX.rK) % 65536,
						(hX.Rj[Ys] - hX.rK) % 65536,
						(hX.Byp[Ys] - hX.rK) % 65536
					)
				end
				CS[(43 + Qx) % 256] = function(Tx, sd, Ys, MH, uT)
					if Tx.GT == 0 then
						jq(Tx, sd, Ys, MH, uT, 228)
					elseif 2 == Tx.GT then
						ps(Tx, sd, Ys, MH, uT, 244)
					elseif Tx.GT == 1 then
						xC(Tx, sd, Ys, MH, uT, 224)
					end
					Tx.Wh -= 1
					if Tx.Wh <= 0 then
						return
					end
					local Ls = Tx.Hr
					Tx.Hr = Ls + 1
					if Ls < Tx.sRW or Ls > Tx.zR then
						Tx.kR(Tx, Tx.Rug[Ls])
					end
					local sR = Ls - Tx.sRW + 1
					local Ym = (Tx.GKJ[sR] - Tx.rK) % 256
					local hX = CS[(Ym + Qx) % 256]
					return hX(
						Tx,
						(Tx.QS[sR] - Tx.rK) % 65536,
						(Tx.Pdd[sR] - Tx.rK) % 65536,
						(Tx.Rj[sR] - Tx.rK) % 65536,
						(Tx.Byp[sR] - Tx.rK) % 65536
					)
				end
				CS[(20 + Qx) % 256] = function(hX, Ym, sR, Ls, uT)
					if 0 == hX.GT then
						jq(hX, Ym, sR, Ls, uT, 235)
					elseif hX.GT == 2 then
						ps(hX, Ym, sR, Ls, uT, 251)
					elseif 1 == hX.GT then
						xC(hX, Ym, sR, Ls, uT, 228)
					end
					hX.Wh -= 1
					if hX.Wh == 0 then
						return
					end
					local MH = hX.Hr
					if MH < hX.sRW or MH > hX.zR then
						hX.kR(hX, hX.Rug[MH])
					end
					local Ys = MH - hX.sRW + 1
					local sd = CS[((hX.GKJ[Ys] - hX.rK) % 256 + Qx) % 256]
					hX.Hr = MH + 1
					return sd(
						hX,
						(hX.QS[Ys] - hX.rK) % 65536,
						(hX.Pdd[Ys] - hX.rK) % 65536,
						(hX.Rj[Ys] - hX.rK) % 65536,
						(hX.Byp[Ys] - hX.rK) % 65536
					)
				end
				CS[(13 + Qx) % 256] = function(sd, Ys, MH, uT, Ls)
					if 1 == sd.GT then
						xC(sd, Ys, MH, uT, Ls, 232)
					elseif sd.GT == 0 then
						jq(sd, Ys, MH, uT, Ls, 242)
					elseif sd.GT == 2 then
						ps(sd, Ys, MH, uT, Ls, 257)
					end
					sd.Wh -= 1
					if sd.Wh == 0 then
						return
					end
					local sR = sd.Hr
					sd.Hr = sR + 1
					if sR < sd.sRW or sR > sd.zR then
						sd.kR(sd, sd.Rug[sR])
					end
					local Ym = sR - sd.sRW + 1
					local hX = (sd.GKJ[Ym] - sd.rK) % 256
					local Tx = CS[(hX + Qx) % 256]
					return Tx(
						sd,
						(sd.QS[Ym] - sd.rK) % 65536,
						(sd.Pdd[Ym] - sd.rK) % 65536,
						(sd.Rj[Ym] - sd.rK) % 65536,
						(sd.Byp[Ym] - sd.rK) % 65536
					)
				end
				CS[(38 + Qx) % 256] = function(Tx, hX, Ym, sR, Ls)
					if 2 == Tx.GT then
						ps(Tx, hX, Ym, sR, Ls, 263)
					elseif Tx.GT == 1 then
						xC(Tx, hX, Ym, sR, Ls, 239)
					elseif 0 == Tx.GT then
						jq(Tx, hX, Ym, sR, Ls, 249)
					end
					Tx.Wh -= 1
					if Tx.Wh <= 0 then
						return
					end
					local uT = Tx.Hr
					if uT < Tx.sRW or uT > Tx.zR then
						Tx.kR(Tx, Tx.Rug[uT])
					end
					local MH = uT - Tx.sRW + 1
					local Ys = (Tx.GKJ[MH] - Tx.rK) % 256
					local sd, oU, eS, tV =
						(Tx.QS[MH] - Tx.rK) % 65536,
						(Tx.Pdd[MH] - Tx.rK) % 65536,
						(Tx.Rj[MH] - Tx.rK) % 65536,
						(Tx.Byp[MH] - Tx.rK) % 65536
					Tx.Hr = uT + 1
					return CS[(Ys + Qx) % 256](Tx, sd, oU, eS, tV)
				end
				CS[(40 + Qx) % 256] = function(tV, eS, oU, sd, Ys)
					if tV.GT == 0 then
						jq(tV, eS, oU, sd, Ys, 255)
					elseif tV.GT == 1 then
						xC(tV, eS, oU, sd, Ys, 244)
					elseif tV.GT == 2 then
						ps(tV, eS, oU, sd, Ys, 267)
					end
					tV.Wh -= 1
					if tV.Wh <= 0 then
						return
					end
					local MH = tV.Hr
					if MH < tV.sRW or MH > tV.zR then
						tV.kR(tV, tV.Rug[MH])
					end
					local uT = MH - tV.sRW + 1
					local Ls = CS[((tV.GKJ[uT] - tV.rK) % 256 + Qx) % 256]
					tV.Hr = MH + 1
					return Ls(
						tV,
						(tV.QS[uT] - tV.rK) % 65536,
						(tV.Pdd[uT] - tV.rK) % 65536,
						(tV.Rj[uT] - tV.rK) % 65536,
						(tV.Byp[uT] - tV.rK) % 65536
					)
				end
				CS[(42 + Qx) % 256] = function(Ls, uT, MH, Ys, sd)
					if Ls.GT == 1 then
						xC(Ls, uT, MH, Ys, sd, 251)
					elseif Ls.GT == 0 then
						jq(Ls, uT, MH, Ys, sd, 262)
					elseif Ls.GT == 2 then
						ps(Ls, uT, MH, Ys, sd, 273)
					end
					Ls.Wh -= 1
					if Ls.Wh <= 0 then
						return
					end
					local oU = Ls.Hr
					if oU < Ls.sRW or oU > Ls.zR then
						Ls.kR(Ls, Ls.Rug[oU])
					end
					local eS = oU - Ls.sRW + 1
					Ls.Hr = oU + 1
					return CS[((Ls.GKJ[eS] - Ls.rK) % 256 + Qx) % 256](
						Ls,
						(Ls.QS[eS] - Ls.rK) % 65536,
						(Ls.Pdd[eS] - Ls.rK) % 65536,
						(Ls.Rj[eS] - Ls.rK) % 65536,
						(Ls.Byp[eS] - Ls.rK) % 65536
					)
				end
				CS[(3 + Qx) % 256] = function(eS, oU, sd, Ys, MH)
					if 0 == eS.GT then
						jq(eS, oU, sd, Ys, MH, 266)
					elseif eS.GT == 2 then
						ps(eS, oU, sd, Ys, MH, 280)
					elseif 1 == eS.GT then
						xC(eS, oU, sd, Ys, MH, 258)
					end
					eS.Wh -= 1
					if eS.Wh <= 0 then
						return
					end
					local uT = eS.Hr
					eS.Hr = uT + 1
					if uT < eS.sRW or uT > eS.zR then
						eS.kR(eS, eS.Rug[uT])
					end
					local Ls = uT - eS.sRW + 1
					local tV = (eS.GKJ[Ls] - eS.rK) % 256
					local sR = CS[(tV + Qx) % 256]
					return sR(
						eS,
						(eS.QS[Ls] - eS.rK) % 65536,
						(eS.Pdd[Ls] - eS.rK) % 65536,
						(eS.Rj[Ls] - eS.rK) % 65536,
						(eS.Byp[Ls] - eS.rK) % 65536
					)
				end
				CS[(34 + Qx) % 256] = function(sR, tV, Ls, uT, MH)
					if sR.GT == 1 then
						xC(sR, tV, Ls, uT, MH, 265)
					elseif 2 == sR.GT then
						ps(sR, tV, Ls, uT, MH, 285)
					elseif 0 == sR.GT then
						jq(sR, tV, Ls, uT, MH, 271)
					end
					sR.Wh -= 1
					if sR.Wh == 0 then
						return
					end
					local Ys = sR.Hr
					if Ys < sR.sRW or Ys > sR.zR then
						sR.kR(sR, sR.Rug[Ys])
					end
					local sd = Ys - sR.sRW + 1
					local oU = (sR.GKJ[sd] - sR.rK) % 256
					sR.Hr = Ys + 1
					return CS[(oU + Qx) % 256](
						sR,
						(sR.QS[sd] - sR.rK) % 65536,
						(sR.Pdd[sd] - sR.rK) % 65536,
						(sR.Rj[sd] - sR.rK) % 65536,
						(sR.Byp[sd] - sR.rK) % 65536
					)
				end
				xY = (xY + Lu * (1010792447958 + 34261225999 - 1045053649220)) % 268435456
				hj = (
					xY
					- (function(oU)
						local sd = (38611344 + 0) % 268435456
						for Ys = 1, #oU do
							sd = (sd * 15056 + #oU[Ys] + Ys * 49516 + 183374870) % 268435456
						end
						return (116497475 + sd) % 268435456
					end)(h)
				) % 268435456
				wL = function(sd)
					local oU, Ys = sd[23], sd[24]
					sd.Wh -= 1
					if sd.Wh == 0 then
						return
					end
					local MH = sd.Hr
					if MH < sd.sRW or MH > sd.zR then
						sd.kR(sd, sd.Rug[MH])
					end
					local uT = MH - sd.sRW + 1
					local Ls = (sd.GKJ[uT] - sd.rK) % 256
					local tV, sR, eS, Ym =
						(sd.QS[uT] - sd.rK) % 65536,
						(sd.Pdd[uT] - sd.rK) % 65536,
						(sd.Rj[uT] - sd.rK) % 65536,
						(sd.Byp[uT] - sd.rK) % 65536
					sd.Hr = MH + 1
					return Ys[(Ls + oU) % 256](sd, tV, sR, eS, Ym)
				end
				Rp = function(Ym)
					local eS, sR = Ym[23], Ym[24]
					Ym.Wh -= 1
					if Ym.Wh <= 0 then
						return
					end
					local tV = Ym.Hr
					if tV < Ym.sRW or tV > Ym.zR then
						Ym.kR(Ym, Ym.Rug[tV])
					end
					local Ls = tV - Ym.sRW + 1
					local uT = (Ym.GKJ[Ls] - Ym.rK) % 256
					Ym.Hr = tV + 1
					return sR[(uT + eS) % 256](
						Ym,
						(Ym.QS[Ls] - Ym.rK) % 65536,
						(Ym.Pdd[Ls] - Ym.rK) % 65536,
						(Ym.Rj[Ls] - Ym.rK) % 65536,
						(Ym.Byp[Ls] - Ym.rK) % 65536
					)
				end
				gN = function(uT)
					local Ls, tV = uT[23], uT[24]
					uT.Wh -= 1
					if uT.Wh <= 0 then
						return
					end
					local sR = uT.Hr
					if sR < uT.sRW or sR > uT.zR then
						uT.kR(uT, uT.Rug[sR])
					end
					local eS = sR - uT.sRW + 1
					local Ym = (uT.GKJ[eS] - uT.rK) % 256
					local MH, Ys, oU, sd =
						(uT.QS[eS] - uT.rK) % 65536,
						(uT.Pdd[eS] - uT.rK) % 65536,
						(uT.Rj[eS] - uT.rK) % 65536,
						(uT.Byp[eS] - uT.rK) % 65536
					uT.Hr = sR + 1
					return tV[(Ym + Ls) % 256](uT, MH, Ys, oU, sd)
				end
				pu = function(sd)
					local oU, Ys = sd[23], sd[24]
					sd.Wh -= 1
					if sd.Wh <= 0 then
						return
					end
					local MH = sd.Hr
					if MH < sd.sRW or MH > sd.zR then
						sd.kR(sd, sd.Rug[MH])
					end
					local Ym = MH - sd.sRW + 1
					local eS = (sd.GKJ[Ym] - sd.rK) % 256
					local sR, tV, Ls, uT =
						(sd.QS[Ym] - sd.rK) % 65536,
						(sd.Pdd[Ym] - sd.rK) % 65536,
						(sd.Rj[Ym] - sd.rK) % 65536,
						(sd.Byp[Ym] - sd.rK) % 65536
					sd.Hr = MH + 1
					return Ys[(eS + oU) % 256](sd, sR, tV, Ls, uT)
				end
				do
					local uT = Qx
					local Ls = {
						{ 66, 25 },
						{ 158, 25 },
						{ 233, 25 },
						{ 71, 7 },
						{ 146, 7 },
						{ 209, 7 },
						{ 103, 42 },
						{ 165, 42 },
						{ 219, 42 },
						{ 76, 38 },
						{ 130, 38 },
						{ 212, 38 },
						{ 91, 8 },
						{ 170, 8 },
						{ 222, 8 },
						{ 93, 41 },
						{ 161, 41 },
						{ 228, 41 },
						{ 101, 4 },
						{ 167, 4 },
						{ 223, 4 },
						{ 68, 6 },
						{ 136, 6 },
						{ 195, 6 },
						{ 95, 28 },
						{ 149, 28 },
						{ 206, 28 },
						{ 106, 40 },
						{ 144, 40 },
						{ 197, 40 },
						{ 70, 16 },
						{ 135, 16 },
						{ 221, 16 },
						{ 67, 1 },
						{ 133, 1 },
						{ 207, 1 },
						{ 73, 20 },
						{ 141, 20 },
						{ 192, 20 },
						{ 89, 11 },
						{ 154, 11 },
						{ 210, 11 },
						{ 105, 2 },
						{ 140, 2 },
						{ 194, 2 },
						{ 80, 24 },
						{ 163, 24 },
						{ 230, 24 },
						{ 100, 18 },
						{ 138, 18 },
						{ 229, 18 },
						{ 104, 30 },
						{ 159, 30 },
						{ 215, 30 },
						{ 72, 31 },
						{ 147, 31 },
						{ 216, 31 },
						{ 74, 3 },
						{ 139, 3 },
						{ 213, 3 },
						{ 69, 26 },
						{ 128, 26 },
						{ 226, 26 },
						{ 99, 15 },
						{ 157, 15 },
						{ 231, 15 },
						{ 102, 5 },
						{ 156, 5 },
						{ 211, 5 },
						{ 82, 22 },
						{ 142, 22 },
						{ 217, 22 },
						{ 64, 13 },
						{ 145, 13 },
						{ 220, 13 },
						{ 94, 34 },
						{ 153, 34 },
						{ 202, 34 },
						{ 97, 17 },
						{ 160, 17 },
						{ 232, 17 },
						{ 90, 0 },
						{ 151, 0 },
						{ 193, 0 },
						{ 84, 29 },
						{ 148, 29 },
						{ 196, 29 },
						{ 96, 10 },
						{ 132, 10 },
						{ 200, 10 },
						{ 86, 14 },
						{ 164, 14 },
						{ 224, 14 },
						{ 78, 21 },
						{ 155, 21 },
						{ 204, 21 },
						{ 92, 27 },
						{ 134, 27 },
						{ 208, 27 },
						{ 87, 37 },
						{ 169, 37 },
						{ 214, 37 },
						{ 85, 19 },
						{ 168, 19 },
						{ 227, 19 },
						{ 79, 32 },
						{ 131, 32 },
						{ 199, 32 },
						{ 75, 23 },
						{ 166, 23 },
						{ 198, 23 },
						{ 98, 9 },
						{ 152, 9 },
						{ 205, 9 },
						{ 83, 36 },
						{ 162, 36 },
						{ 225, 36 },
						{ 65, 39 },
						{ 150, 39 },
						{ 201, 39 },
						{ 81, 35 },
						{ 129, 35 },
						{ 203, 35 },
						{ 88, 12 },
						{ 137, 12 },
						{ 218, 12 },
						{ 77, 33 },
						{ 143, 33 },
						{ 234, 33 },
						{ 107, 43 },
						{ 171, 43 },
						{ 235, 43 },
					}
					for tV = 1, #Ls do
						local sR = Ls[tV]
						CS[(sR[1] + uT) % 256] = CS[(sR[2] + uT) % 256]
					end
				end
				hj = (hj + GQ * (621688054049 + 533200132856 - 1154888125556)) % 268435456
				YI = nil
			end
			local ps = {}
			local xC = 1
			local mI = (function(jq)
				local mI = (84260149 + 0) % 268435456
				for oG = 1, #jq do
					mI = (mI * 62531 + #jq[oG] + oG * 61107 + 217091364) % 268435456
				end
				return (31035839 + mI) % 268435456
			end)(h)
			while mI > 0 do
				local jq = ps[xC]
				if jq >= 4 then
					if jq < 6 then
						if jq ~= 5 then
							mI = 0
						else
							mI = 0
						end
					else
						mI = 0
					end
				elseif jq < 2 then
					mI = 0
				else
					mI = 0
				end
				local oG = ps[xC]
				if oG then
					local HL = ps[xC]
					local zQ = ps[xC]
					local Hr = ps[xC]
					local XQ = ps[xC]
					xC += 1
					if oG == I[12] then
						ps[xC] = HL
					elseif oG == I[3] then
						ps[xC] = zQ
					else
						local id = ps[xC](HL, zQ, Hr, XQ)
						if id then
							mI = id[1]
						end
					end
				end
				local XQ = ps[xC]
				if XQ then
					local Hr = ps[xC]
					local zQ = ps[xC]
					local HL = ps[xC]
					local id = ps[xC]
					xC += 1
					if XQ == I[40] then
						ps[xC] = Hr
					elseif XQ == I[39] then
						ps[xC] = zQ
					else
						local EL = ps[xC](Hr, zQ, HL, id)
						if EL then
							mI = EL[1]
						end
					end
				end
				local id = ps[xC]
				if id then
					local HL = ps[xC]
					local zQ = ps[xC]
					local Hr = ps[xC]
					local EL = ps[xC]
					xC += 1
					if id == I[7] then
						ps[xC] = HL
					elseif id == I[35] then
						ps[xC] = zQ
					else
						local FA = ps[xC](HL, zQ, Hr, EL)
						if FA then
							mI = FA[1]
						end
					end
				end
				local EL = ps[xC]
				if EL then
					local Hr = ps[xC]
					local zQ = ps[xC]
					local HL = ps[xC]
					local FA = ps[xC]
					xC += 1
					if EL == I[25] then
						ps[xC] = Hr
					elseif EL == I[23] then
						ps[xC] = zQ
					else
						local Ji = ps[xC](Hr, zQ, HL, FA)
						if Ji then
							mI = Ji[1]
						end
					end
				end
				xC += 1
			end
			local EL = 2779 + 2789
			local id = EL * 473 - 8055
			if id * id >= 0 then
				local XQ = id - EL
			end
			local XQ = id + 1 - 1
			IZ = nil
			nT = nil
			JZ = nil
			kx = nil
			Z = nil
			j = nil
			I = nil
			local oG = X(0)
			local jq = v
			local FA = d
			local HL = y({}, {
				__len = function()
					return 99
				end,
			})
			local zQ = HL == nil or false
			do
				local Hr, Ji = Y(function()
					return #HL
				end)
				zQ = Hr and Ji == 99
			end
			local Ji = 3758 + 5532
			local Hr = Ji * 549 - 1742
			if Hr * Hr >= 0 then
				local xY = Hr - Ji
			end
			local xY = Hr + 1 - 1
			local function GZ(GC, Lz)
				local BC = 667 + 768
				local Mp = BC * 910 - 3293
				if Mp * Mp >= 0 then
					local ec = Mp - BC
				end
				local ec = Mp + 1 - 1
				local aJ = 1673 + 1630
				local SP = aJ * 994 - 7471
				if SP * SP >= 0 then
					local bp = SP - aJ
				end
				local bp = SP + 1 - 1
				local WR = S(GC)
				if l(WR) == q[16] then
					return WR[Lz], false
				end
				return nil, WR ~= nil
			end
			local function WR(bp)
				local SP = 4109 + 6077
				local aJ = SP * 115 - 3367
				if aJ * aJ >= 0 then
					local ec = aJ - SP
				end
				local ec = aJ + 1 - 1
				local Mp = 8791 + 1436
				local BC = Mp * 886 - 2520
				if BC * BC >= 0 then
					local Lz = BC - Mp
				end
				local Lz = BC + 1 - 1
				if l(bp) == q[18] then
					return bp, false
				end
				local GC = S(bp)
				if l(GC) == q[16] then
					local by = GC[q[31]]
					if l(by) == q[18] then
						return by, true
					end
					if l(by) == q[16] then
						local mL = by[bp]
						if l(mL) == q[18] then
							return mL, false
						end
					end
				elseif GC ~= nil then
					return bp, false
				end
				F(q[32] .. l(bp) .. q[4], 0)
			end
			local GC = X(0)[q[16]][q[30]]
			local function Lz(BC, Mp, ec)
				local aJ = 9712 + 694
				local SP = aJ * 210 - 5518
				if SP * SP >= 0 then
					local bp = SP - aJ
				end
				local bp = SP + 1 - 1
				local by = 5637 + 6019
				local mL = by * 10 - 9445
				if mL * mL >= 0 then
					local qK = mL - by
				end
				local qK = mL + 1 - 1
				local gP = GC(BC(jq(Mp, 1, ec)))
				return gP, gP.n
			end
			local gP = UE(
				Jc,
				ge,
				SB,
				UA,
				tY,
				Qj,
				m,
				oG,
				jq,
				FA,
				q,
				Qx,
				CS,
				GC,
				GZ,
				WR,
				Lz,
				zQ,
				wL,
				Rp,
				gN,
				pu,
				ZZ,
				sk,
				Kr,
				DT,
				Tc,
				Qb,
				EX,
				YG,
				jO,
				dn,
				lt,
				ji,
				lK,
				Wd,
				sp,
				hj,
				nW,
				mN,
				GQ
			)
			UE = nil
			local qK = {}
			local mL = {}
			return gP(Ki, mL, {}, qK, 0)
		end
		local qK = 5167 + 598
		local gP = qK * 880 - 2502
		if gP * gP >= 0 then
			local Lz = gP - qK
		end
		local Lz = gP + 1 - 1
		n[6] = mL
		return 232, n, R, k, G, t, O
	end,
	aa = function(Lz, gP, qK, mL, c, w, s)
		local L = gP[8] ~= nil and 59 or 147
		return 67, gP, mL, c, w, s, qK
	end,
	yY = function(L, s, w, c, mL, qK, gP)
		local Lz = s[8] ~= nil and 23 or 147
		return 24, s, c, mL, qK, gP, w
	end,
	[46] = setmetatable,
	[6] = buffer.readu32,
	[86] = pcall,
	ST = function(Lz, gP, qK, mL, c, w, s)
		local L = gP[8] ~= nil and 8 or 236
		return 47, gP, mL, c, w, s, qK
	end,
	PL = "?",
	[58] = ("")["byte"],
	za = function(L, ...)
		return true, 237, nil, nil, nil, nil, nil, nil, nil, nil
	end,
	nI = function(L, s, w, c, mL, qK, gP)
		local Lz = s[8] ~= nil and 36 or 206
		return 125, s, c, mL, qK, gP, w
	end,
	[25] = unpack,
	LM = function(Lz, gP, qK, mL, c, w, s)
		local L = gP[8] ~= nil and 96 or 218
		return 33, gP, mL, c, w, s, qK
	end,
	BL = "__index",
	[84] = buffer.copy,
	LB = function(L, s, w)
		local c = bit32.band
		s, w = c(s, 4294967295), c(w, 4294967295)
		local mL, qK = c(s, 65535), bit32.rshift
		local gP, Lz, A = qK(s, 16), c(w, 65535), qK(w, 16)
		return c(mL * Lz + bit32.lshift(c(mL * A + gP * Lz, 65535), 16), 4294967295) % 4294967296
	end,
	rD = function(A, ...)
		return true, 3, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil
	end,
	IB = function(A, Lz, gP, qK, mL, c, w)
		local s = Lz[8] ~= nil and 8 or 220
		return 113, Lz, qK, mL, c, w, gP
	end,
	o_ = function(s, w, c, mL, qK, gP, Lz)
		local A = w[8] ~= nil and 12 or 195
		return 178, w, mL, qK, gP, Lz, c
	end,
	[81] = getfenv,
	[11] = string.pack,
	HF = function(A, Lz, gP, qK, mL, c, w)
		local s = Lz[8] ~= nil and 31 or 133
		return 148, Lz, qK, mL, c, w, gP
	end,
	[118] = type,
	Bv = function(s, w, c, mL, qK, gP, Lz)
		local A = w[8] ~= nil and 83 or 173
		return 74, w, mL, qK, gP, Lz, c
	end,
	[12] = buffer.writeu8,
	[66] = coroutine.wrap,
	jj = function(A, Lz, gP, qK, mL, c, w)
		local s = Lz[8] ~= nil and 85 or 142
		return 27, Lz, qK, mL, c, w, gP
	end,
	[37] = buffer.readstring,
	[33] = [=[3dsdj$:?,(G^rk8@Sx,h8hq&-%rs.;"o\b"7r7%h,?f;-N>|`'L+'P*DjiNr89*ksQ!V76Ayj5%C4gaF;~Uoi/15)dCilNzO.4G4$4Rkm98W$o=7W7(%X_y1S@+?:H.=@A:j"[q,Un#$W>BubJnH6Q>h(f4.#`'h!:>D$!_6_@A8_Cb/\wuY%f"5"UB:F&J/q!p1@yNfOL<//LAcMT6L"4]5W"RI%]sbB=LB+i/'T3a,Y`jSLo!{f"$U;{4Oruy,?:iVTbGE[Dh]]!KK]NP4DQOyTW5k]Rn[S^D2IEwJ]B#},;xv_N7!e'LaV4]6<v)1-vjh%R]C21Ny,A/Ku7;f9E6kv)KVQ'PX+\8L;(&+ETG4&0wsA?!];E_9ixMo)`M}n#]5qZTE;U},nz(g%!i[8U030<H`s;&73S6U*;3_K'NC5HH=KzR)m,iiPYv0jQZXf&]=],
	JD = function(s, w, c, mL, qK, gP, Lz)
		local A = w[8] ~= nil and 79 or 164
		return 96, w, mL, qK, gP, Lz, c
	end,
	aB = function(A, Lz, gP, qK, mL, c, w)
		local s = Lz[8] ~= nil and 72 or 196
		return 102, Lz, qK, mL, c, w, gP
	end,
	fy = function(s, w, c, mL, qK, gP, Lz)
		local A = w[8] ~= nil and 46 or 178
		return 95, w, mL, qK, gP, Lz, c
	end,
	wB = function(A, Lz, gP, qK, mL, c, w)
		local s = Lz[8] ~= nil and 29 or 187
		return 170, Lz, qK, mL, c, w, gP
	end,
	[55] = string.rep,
	zQ = function(s, w, c, mL, qK, gP, Lz)
		local A = w[8] ~= nil and 96 or 155
		return 133, w, mL, qK, gP, Lz, c
	end,
	rg = function(A, Lz, gP, qK, mL, c, w)
		local s = Lz[8] ~= nil and 8 or 233
		return 203, Lz, qK, mL, c, w, gP
	end,
	[108] = table.move,
	[73] = coroutine.yield,
	[78] = buffer.readi16,
	gL = ":(%d+)[:\13\10]",
	[75] = buffer.readu16,
	_y = function(s, w, c, mL, qK, gP, Lz)
		local A = w[8] ~= nil and 125 or 190
		return 222, w, mL, qK, gP, Lz, c
	end,
	[119] = coroutine.isyieldable,
	Tx = function(A, ...)
		return true, 238, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil
	end,
	[54] = tostring,
	[27] = rawget,
	_W = function(A, Lz, gP, qK, mL, c, w)
		local s = Lz[8] ~= nil and 107 or 187
		return 145, Lz, qK, mL, c, w, gP
	end,
	[35] = xpcall,
	C = function(s, w, c, mL, qK, gP, Lz)
		local A = w[8] ~= nil and 83 or 174
		return 12, w, mL, qK, gP, Lz, c
	end,
	HM = function(A, Lz, gP, qK, mL, c, w)
		local s = Lz[8] ~= nil and 14 or 174
		return 37, Lz, qK, mL, c, w, gP
	end,
	[124] = function(s, w, c, mL)
		return function()
			local qK = 0
			while true do
				if qK <= 0 then
					c[1][4][c[1][7]] = (275828 * c[1][4][c[1][7]] + 103233737) % 268435456
					c[1][4][c[1][7]], qK = (964089 * c[1][4][c[1][7]] + 100734692) % 268435456, 1
				elseif qK <= 1 then
					c[1][4][c[1][7]] = (161081 * c[1][4][c[1][7]] + 110687905) % 268435456
					c[1][4][c[1][7]], qK = (605208 * c[1][4][c[1][7]] + 223400788) % 268435456, 2
				else
					return
				end
			end
		end
	end,
	[110] = string.gsub,
	Aq = function(mL, c, w, s, qK, gP, Lz)
		local A = c[8] ~= nil and 103 or 173
		return 205, c, s, qK, gP, Lz, w
	end,
	[61] = bit32.band,
	qq = function(A, Lz, gP, qK, s, w, c)
		local mL = Lz[8] ~= nil and 79 or 159
		return 144, Lz, qK, s, w, c, gP
	end,
	oa = function(mL, c, w, s, qK, gP, Lz)
		local A = c[8] ~= nil and 107 or 138
		return 206, c, s, qK, gP, Lz, w
	end,
	uk = function(A, Lz, gP, qK, s, w, c)
		local mL = Lz[8] ~= nil and 14 or 174
		return 215, Lz, qK, s, w, c, gP
	end,
	[53] = 277920470 - 15023628,
	VZ = function(mL, c, w, s, qK, gP, Lz)
		local A = function(...)
			return c[6](c[1] .. c[2] .. c[3] .. c[4] .. c[5])
		end
		c[10], c[7] = 19, function(...)
			return mL[44](mL, A, ...)
		end
		mL.VZ = c[7]
		return 233, c, w, qK, gP, Lz, s
	end,
	Ic = function(A, Lz, gP, qK, s, w, c)
		local mL = Lz[8] ~= nil and 95 or 235
		return 66, Lz, qK, s, w, c, gP
	end,
	cL = "string",
	FH = function(mL, c, w, s, qK, gP, Lz)
		local A = c[8] ~= nil and 33 or 129
		return 141, c, s, qK, gP, Lz, w
	end,
	wj = function(A, Lz, gP, qK, s, w, c)
		local mL = Lz[8] ~= nil and 17 or 169
		return 187, Lz, qK, s, w, c, gP
	end,
	[26] = buffer.fromstring,
	Dw = function(mL, c, w, s, qK, gP, Lz, A)
		local L = { [7] = "dS" }
		while true do
			if w <= 129 then
				return mL[L[7]](mL, c, w, s, qK, gP, Lz, A)
			else
				return mL:dS(c, w, s, qK, gP, Lz, A)
			end
		end
	end,
	gW = function(L, A, Lz, gP, qK, s, w)
		local c = (L[7] + L[16]) % 4294967296
		local mL = (L[43] - L[120]) % 4294967296
		local p = {}
		local t = 61
		local G = L[34](L)
		local R = (G % 256 + bit32.extract(G, 8, 8) + bit32.extract(G, 16, 8) + bit32.extract(G, 24, 4)) % 256
		local O = 1
		local k = L[33]
		for n = 61, 80 do
			local e = (
				(
						(((L[62](k, (n - 1) * 5 + 1) - 33) * 94 + (L[62](k, (n - 1) * 5 + 2) - 33)) * 94 + (L[62](
							k,
							(n - 1) * 5 + 3
						) - 33)) * 94 + (L[62](k, (n - 1) * 5 + 4) - 33)
					)
					* 94
				+ (L[62](k, (n - 1) * 5 + 5) - 33)
				- (c + t * mL) % 4294967296
			) % 4294967296
			t += 1
			p[O] = L[113](bit32.bxor(e % 256, (R + O) % 256))
			e = (e - e % 256) / 256
			O += 1
			p[O] = L[113](bit32.bxor(e % 256, (R + O) % 256))
			e = (e - e % 256) / 256
			O += 1
			p[O] = L[113](bit32.bxor(e % 256, (R + O) % 256))
			e = (e - e % 256) / 256
			O += 1
			p[O] = L[113](bit32.bxor(e % 256, (R + O) % 256))
			O += 1
		end
		local e = A[4] ~= nil and 39 or 180
		local n = if 39 ~= 180 then 39 else 180
		A[4] = table.concat(p, nil, 1, 79)
		return 10, A, qK, Lz, s, w, gP
	end,
	[43] = 1583389709 - 75633801,
	Qm = function(n, e, k, O, R, G, t)
		local p = e[8] ~= nil and 66 or 165
		return 218, e, O, R, G, t, k
	end,
	EL = ": ",
	MQ = function(p, t, G, R, O, k, e)
		local n = t[8] ~= nil and 98 or 222
		return 79, t, R, O, k, e, G
	end,
	LD = function(n, e, k, O, R, G, t)
		local p = e[8] ~= nil and 98 or 154
		return 55, e, O, R, G, t, k
	end,
	[82] = buffer.readu8,
	[68] = {
		2195920275,
		1648547853,
		215161833,
		42056461,
		4336001,
		1493784745,
		1148266437,
		402990142,
		28970860,
		1876653227,
		1357514396,
		62907801,
		347423087,
		1267828,
		3630169325,
		2649715879,
		3288975635,
		253719251,
		4144874722,
		3099166669,
		1311309281,
		4096020079,
		2224763290,
		13460,
		3154582681,
		1156022061,
		619038,
		2759846397,
		3467713024,
		1505918781,
		2890774252,
		2766339361,
		3429960350,
		4082693355,
		10810136,
		2852851870,
		1445083311,
		3375414585,
		3306016625,
		2691565979,
		976544956,
		2886241634,
		2964647518,
		415942788,
		2640865362,
		1168438943,
		3713425034,
		2332658091,
	},
	[102] = coroutine.create,
	nQ = function(p, t, G, R, O, k, e)
		local n = t[8] ~= nil and 77 or 175
		return 154, t, R, O, k, e, G
	end,
	[47] = buffer.readi32,
	kU = function(n, e, k, O, R, G, t)
		local p = e[8] ~= nil and 14 or 180
		return 31, e, O, R, G, t, k
	end,
	[100] = getmetatable,
	pe = function(p, t, G, R, O, k, e)
		local n = t[8] ~= nil and 46 or 196
		return 142, t, R, O, k, e, G
	end,
	dz = {
		['"'] = "kSLa4",
		["'"] = "kZE5c",
		["%"] = "kq5cg",
		[" "] = "k0YrO",
		["$"] = "kAn5P",
		["!"] = "kcZSp",
		["~"] = "kvD3C",
		["#"] = "kOiUo",
		["}"] = "kixdE",
		["&"] = "kmRv6",
	},
	JK = function(n, e, k, O, R, G, t)
		local p = e[8] ~= nil and 11 or 187
		return 211, e, O, R, G, t, k
	end,
	[67] = assert,
	Ct = function(p, t, G, R, O, k, e)
		local n = t[8] ~= nil and 37 or 211
		return 188, t, R, O, k, e, G
	end,
	[38] = table.pack,
	[74] = bit32.countrz,
	[3] = table.concat,
	[94] = bit32.bnot,
	[64] = string.find,
	wF = function(n, e, k, O, R, G, t)
		local p = 0
		local mL = 0
		for c = 1, #e[1] do
			mL += n[62](e[1], c)
		end
		local c = 1
		while c <= #e[2] do
			mL += n[62](e[2], c)
			c += 1
		end
		for w = #e[3], 1, -1 do
			mL += n[62](e[3], w)
		end
		for w = 1, #e[4] do
			mL += n[62](e[4], w)
		end
		local w = 1
		while w <= #e[5] do
			mL += n[62](e[5], w)
			w += 1
		end
		local s = if p >= 0 then 19 else 185
		p = n:ql(n:LB(p, 31) + mL + s - s)
		e[9] = p
		return 235, e, O, k, R, t, G
	end,
	[89] = buffer.readf64,
	ql = function(s, w)
		return w % 4294967296
	end,
	[50] = buffer.tostring,
	[109] = buffer.writei8,
	qZ = function(w, s, c, mL, p, t, G)
		local R = s[8] ~= nil and 37 or 170
		return 164, s, mL, p, t, G, c
	end,
	DC = function(R, G, t, p, mL, c, s)
		local w = G[8] ~= nil and 113 or 147
		return 196, G, p, mL, c, s, t
	end,
	Pj = function(w, s, c, mL, p, t, G)
		local R = s[8] ~= nil and 59 or 136
		return 123, s, mL, p, t, G, c
	end,
	NS = function(R, G, t, p, mL, c, s)
		local w = G[8] ~= nil and 129 or 145
		return 60, G, p, mL, c, s, t
	end,
	Rr = function(w, s, c, mL, p, t, G)
		local R = s[8] ~= nil and 14 or 144
		return 175, s, mL, p, t, G, c
	end,
	[92] = rawset,
	If = function(R, G, t, p, mL, c, s)
		local w = G[8] ~= nil and 10 or 180
		return 155, G, p, mL, c, s, t
	end,
	[85] = setfenv,
	[79] = {
		2291925003,
		3302938,
		873625325,
		2972865018,
		2037907204,
		285504659,
		63227246,
		4171485343,
		3724221875,
		3936955377,
		1626043228,
		268133192,
		3562005,
		16528493,
		697137980,
		2983357005,
		1808450478,
		2615550645,
		2982433430,
		166238774,
		49296954,
		4005973152,
		1064430683,
		2778470834,
		754762842,
		20305,
		2415795717,
		568874132,
		3460022367,
		3845371129,
		3549149091,
		1233221,
		456140314,
		2142455194,
		1509976646,
		1245479402,
		3957717938,
		3361231944,
		4013401,
		3632519411,
		153634053,
		3645503641,
		4290150927,
		3678284997,
		2205041321,
		3945887921,
		3412132980,
		2331161597,
	},
	[2] = string.unpack,
	[17] = coroutine.running,
	TQ = function(w, s, c, mL, p, t, G)
		local R = s[8] ~= nil and 47 or 144
		return 159, s, mL, p, t, G, c
	end,
	[117] = coroutine.close,
	zD = function(R, G, t, p, mL, c, s)
		local w = G[8] ~= nil and 62 or 217
		return 197, G, p, mL, c, s, t
	end,
	[87] = tonumber,
	[895] = function(w)
		local s = 7
		s = (213 * s + 225) % 268435456
		s = (s * 213 + 225) % 268435456
		return s
	end,
	[70] = string.match,
	QL = false,
	[4] = 0,
	[34] = function(s)
		local w = s[32]
		if s[53] ~= nil then
			w = (w + s[53]) % 268435456
			s[32] = w
			s[53] = nil
		end
		local c = 0
		while true do
			if c <= 0 then
				w = (w * (s[68][35] + s[79][14]) + (s[68][27] + s[79][39])) % 268435456
				c = 1
			elseif c <= 1 then
				local mL = (w * (s[68][14] + s[79][32]) + (s[68][4] + s[79][21])) % 268435456
				w = mL
				c = 2
			else
				local mL = (w * (s[68][5] + s[79][2]) + (s[68][12] + s[79][7])) % 268435456
				s[32] = mL
				return mL
			end
		end
	end,
	oD = function(c, w, s, mL, p, t, G)
		local R = w[8] ~= nil and 95 or 232
		return 150, w, mL, p, t, G, s
	end,
	NP = function(R, G, t, p, mL, s, w)
		local c = G[8] ~= nil and 36 or 132
		return 165, G, p, mL, s, w, t
	end,
	OZ = function(c, w, s, mL, p, t, G)
		local R = w[8] ~= nil and 62 or 215
		return 121, w, mL, p, t, G, s
	end,
	Xm = function(R, G, t, p, mL, s, w)
		local c = G[8] ~= nil and 47 or 214
		return 42, G, p, mL, s, w, t
	end,
	Me = function(c, w, s, mL, p, t, G)
		local R = (c[7] + c[16]) % 4294967296
		local O = (c[43] - c[120]) % 4294967296
		local k = {}
		local e = 81
		local n = c[34](c)
		local qK = (n % 256 + bit32.extract(n, 8, 8) + bit32.extract(n, 16, 8) + bit32.extract(n, 24, 4)) % 256
		local gP = 1
		local Lz = c[33]
		for A = 81, 90 do
			local L = (
				(
						(((c[62](Lz, (A - 1) * 5 + 1) - 33) * 94 + (c[62](Lz, (A - 1) * 5 + 2) - 33)) * 94 + (c[62](
							Lz,
							(A - 1) * 5 + 3
						) - 33)) * 94 + (c[62](Lz, (A - 1) * 5 + 4) - 33)
					)
					* 94
				+ (c[62](Lz, (A - 1) * 5 + 5) - 33)
				- (R + e * O) % 4294967296
			) % 4294967296
			e += 1
			k[#k + 1] = c[113](
				bit32.bxor(L % 256, (qK + gP) % 256),
				bit32.bxor(bit32.extract(L, 8, 8), (qK + gP + 1) % 256),
				bit32.bxor(bit32.extract(L, 16, 8), (qK + gP + 2) % 256),
				bit32.bxor(bit32.extract(L, 24, 8), (qK + gP + 3) % 256)
			)
			gP += 4
		end
		local L = c[71]
		for A = 1, 10 do
			local GC = (
				(
						(((c[62](L, (A - 1) * 5 + 1) - 33) * 94 + (c[62](L, (A - 1) * 5 + 2) - 33)) * 94 + (c[62](
							L,
							(A - 1) * 5 + 3
						) - 33)) * 94 + (c[62](L, (A - 1) * 5 + 4) - 33)
					)
					* 94
				+ (c[62](L, (A - 1) * 5 + 5) - 33)
				- (R + e * O) % 4294967296
			) % 4294967296
			e += 1
			k[#k + 1] = c[113](
				bit32.bxor(GC % 256, (qK + gP) % 256),
				bit32.bxor(bit32.extract(GC, 8, 8), (qK + gP + 1) % 256),
				bit32.bxor(bit32.extract(GC, 16, 8), (qK + gP + 2) % 256),
				bit32.bxor(bit32.extract(GC, 24, 8), (qK + gP + 3) % 256)
			)
			gP += 4
		end
		local GC = w[5] ~= nil and 95 or 197
		local A = if 95 ~= 197 then 95 else 197
		w[5] = ("")["sub"](table.concat(k), 1, 79)
		return 11, w, p, s, t, G, mL
	end,
	Y_ = function(A, GC, L, Lz, gP, qK, n)
		local e = GC[8] ~= nil and 103 or 224
		return 152, GC, Lz, gP, qK, n, L
	end,
	tq = function(e, n, qK, gP, Lz, L, GC)
		local A = n[8] ~= nil and 121 or 164
		return 190, n, gP, Lz, L, GC, qK
	end,
	xN = function(A, GC, L, Lz, gP, qK, n)
		local e = GC[8] ~= nil and 125 or 132
		return 138, GC, Lz, gP, qK, n, L
	end,
	Do = function(e, n, qK, gP, Lz, L, GC)
		local A = n[8] ~= nil and 31 or 214
		return 169, n, gP, Lz, L, GC, qK
	end,
	[115] = bit32.bor,
	[76] = function(A, GC, L, Lz)
		return function()
			local gP = 0
			while true do
				if gP <= 0 then
					L[1][4][L[1][7]] = (996710 * L[1][4][L[1][7]] + 3899310) % 268435456
					L[1][4][L[1][7]], gP = (267171 * L[1][4][L[1][7]] + 133862549) % 268435456, 1
				elseif gP <= 1 then
					L[1][4][L[1][7]] = (354982 * L[1][4][L[1][7]] + 57021015) % 268435456
					L[1][4][L[1][7]], gP = (153989 * L[1][4][L[1][7]] + 20094110) % 268435456, 2
				elseif gP <= 2 then
					L[1][4][L[1][7]] = (129265 * L[1][4][L[1][7]] + 170194803) % 268435456
					L[1][4][L[1][7]], gP = (872684 * L[1][4][L[1][7]] + 41190753) % 268435456, 3
				else
					return
				end
			end
		end
	end,
	yX = function(Lz, L, GC, A, gP, qK, n)
		local e = L[8] ~= nil and 96 or 136
		return 36, L, A, gP, qK, n, GC
	end,
	X = function(e, n, qK, gP, A, GC, L)
		local Lz = n[8] ~= nil and 68 or 215
		return 173, n, gP, A, GC, L, qK
	end,
	aV = function(Lz, L, GC, A, gP, qK, n)
		local e = (Lz[7] + Lz[16]) % 4294967296
		local k = (Lz[43] - Lz[120]) % 4294967296
		local O = {}
		local R = 41
		local G = Lz[34](Lz)
		local t = (G % 256 + bit32.extract(G, 8, 8) + bit32.extract(G, 16, 8) + bit32.extract(G, 24, 4)) % 256
		local p = 1
		local mL = Lz[33]
		local s = 41
		while s <= 60 do
			local w = (s - 1) * 5 + 1
			local c, WR, GZ, xY, Hr = Lz[62](mL, w, w + 4)
			local Ji = (
				((((c - 33) * 94 + WR - 33) * 94 + GZ - 33) * 94 + xY - 33) * 94
				+ Hr
				- 33
				+ (4294967296 - (e + R * k) % 4294967296)
			) % 4294967296
			R += 1
			O[#O + 1] = Lz[113](
				bit32.bxor(Ji % 256, (t + p) % 256),
				bit32.bxor(bit32.extract(Ji, 8, 8), (t + p + 1) % 256),
				bit32.bxor(bit32.extract(Ji, 16, 8), (t + p + 2) % 256),
				bit32.bxor(bit32.extract(Ji, 24, 8), (t + p + 3) % 256)
			)
			p += 4
			s += 1
		end
		local Ji = L[3] ~= nil and 19 or 137
		local Hr = if 19 ~= 137 then 19 else 137
		L[3] = ("")["sub"](table.concat(O, nil, 1, 20), 1, 79)
		return 9, L, gP, GC, qK, n, A
	end,
	Id = function(Hr, Ji, s, mL, p, t, G)
		local R = Ji[8] ~= nil and 36 or 170
		return 84, Ji, mL, p, t, G, s
	end,
	[48] = bit32.rshift,
	[8] = buffer.writeu32,
	[32] = 225201515 - 82703383,
	[90] = error,
	Lq = function(R, G, t, p, mL, s, Ji)
		local Hr = G[8] ~= nil and 79 or 224
		return 19, G, p, mL, s, Ji, t
	end,
	yt = function(Hr, Ji, s, mL, p, t, G)
		local R = Ji[8] ~= nil and 3 or 211
		return 231, Ji, mL, p, t, G, s
	end,
	al = function(R, ...)
		local G, t, p, mL, s, Ji, Hr, O, k, e, n, qK = R:rD()
		local gP, A, GC, L, Lz, xY, GZ = t, p, mL, s, Ji, Hr, {}
		GZ[8] = 0
		GZ[10] = 0
		do
			local WR = 1
			local c = WR + 1 - 1
			local w = c - WR
			if w ~= 0 then
				GZ[8] = w
			end
		end
		local w = { [4] = "Dw", [7] = "Dw" }
		while G do
			local c, WR = R[w[4]](R, GZ, gP, A, GC, L, Lz, xY)
			if c == 2 then
				return WR
			end
		end
	end,
	h = { 24123, 416227798, 4170003221, 2288232017, 1573744538, 1136064820, 842516428, 65189102, 2827083435 },
	[7] = 1511908325 - 65836849,
	FS = function(w, GZ, xY, Lz, L, GC, A)
		local gP = GZ[8] ~= nil and 29 or 158
		return 23, GZ, Lz, L, GC, A, xY
	end,
	[51] = select,
	GE = function(gP, A, GC, L, Lz, xY, GZ)
		local w = A[8] ~= nil and 66 or 142
		return 107, A, L, Lz, xY, GZ, GC
	end,
	IZ = function(w, GZ, xY, Lz, L, GC, A)
		local gP = GZ[8] ~= nil and 79 or 133
		return 132, GZ, Lz, L, GC, A, xY
	end,
	[112] = buffer.create,
	[113] = ("")["char"],
	[44] = function(gP, A, ...)
		return A(...)
	end,
	[56] = coroutine.status,
	_X = function(A, gP, GC, L, Lz, xY, GZ)
		local w = gP[8] ~= nil and 121 or 148
		return 214, gP, L, Lz, xY, GZ, GC
	end,
	Au = function(w, GZ, xY, Lz, L, GC, gP)
		local A = GZ[8] ~= nil and 60 or 170
		return 179, GZ, Lz, L, GC, gP, xY
	end,
	[24] = buffer.readf32,
	UP = function(A, gP, GC, L, Lz, xY, GZ)
		local w = gP[8] ~= nil and 31 or 185
		return 147, gP, L, Lz, xY, GZ, GC
	end,
	[65] = coroutine.resume,
	Gt = function(w, GZ, xY, Lz, L, GC, gP)
		local A = GZ[8] ~= nil and 121 or 222
		return 83, GZ, Lz, L, GC, gP, xY
	end,
	[69] = bit32.lshift,
	Uy = function(A, gP, GC)
		local L = if GC >= 236 then 2 else 1
		if L == 2 then
			return 2, gP[7]
		end
		return 1
	end,
	[71] = [[<=B`38p|eX&@uFBLF3~?F-dY7>ATVc*/4hc&Eq'\MU(S0F/K^1]],
	WK = function(L, GC, gP, A, Lz, xY, GZ)
		local w = GC[8] ~= nil and 4 or 232
		return 93, GC, A, Lz, xY, GZ, gP
	end,
	c = function(w, GZ, xY, Lz, A, gP, GC)
		local L = GZ[8] ~= nil and 123 or 178
		return 158, GZ, Lz, A, gP, GC, xY
	end,
	[16] = 246618193 - 80551172,
	Gn = function(L, GC, gP, A, Lz, xY, GZ)
		local w = GC[8] ~= nil and 123 or 229
		return 76, GC, A, Lz, xY, GZ, gP
	end,
	pr = function(w, GZ, xY, Lz, A, gP, GC)
		local L = GZ[8] ~= nil and 113 or 211
		return 39, GZ, Lz, A, gP, GC, xY
	end,
	[125] = table.create,
	Ge = [[0*\'wl(mzB"y`UIq{IEO#)Q:uu5m|5fi]bxN1zUz?DeW&j9^628jE?xU!Oh\`\/GS*Cpmqs{KYKl3F}zf5#H;5q6Hh{8f|00var4&31Lsr+9Hi:0ta7"S)fbzp5-,>gr_M;`iS7<@F<qsTYv)KhGNqFR(Fs(84(H,n<<WSHvaM|:+U^$zVqhYgDO31 |!bF9\mO9Rhpa88Hd|9%a|g+}-Kwpo2>r']q@}~<nh"|wiI5}<s}p1!a"!lXP)weDrG_#Fu;F~f]<Ao`6E0d81DEPtj#|g6DeM'_{(upg7FyqH>EteAhN%)8j@xqSu915)6VJRrS]H?}B>Fpm7MUs=*U*&ETKh=F,jmxD{+y,H~#vbpG%=\&D!jqI]Fnh\Msv;Olt4Mh_D}OwH>^>g#;jrZzl<1cxZ)0;]f`z+"R";(BH7t_:?|Hn`ImOjnVu,y-O<$+ap@si7<Nb[#zo>O,CmSx[lE,F8J|!fFq=~'f8u:Oc]UH-,M;4Q]vsPTBEA'\&8g(iGy8im2M0MA,zq^.8^QhGqLF"w~4:ow^~t)[TR|!L?_\"w*P{;3t^6'h$*OG<z1{!f4Nej,t`P3 ;LFW.]6b3 3>Kp.QZ?l#npq6$GL/$-nv9/W@4vtX9Rx7*KYhTY#-\75Iy<;&-\J16q4E K{@gcwYQUWPgt_jywie[FiOLg^JB1};'H0/>H)^"Z 5<)'S1:xPrr@G~1ovaBMiS`N 7#WHQ]0"g;6:1aU,I,(PU.[3\+pcylTU?5r00Eb?m.)pE'']g')g{ y<`r$|{_<(l q3xP*AI8~j0`rRoczd]y1!7[#v[>y4.\[.>rrV}TMzD,APdZ2Kt<zM}rAdt7{znOS+'lb#VIwEjCC@xYw Y=1w5aAQ**UF:dmO|PXCpms}b)R4q?cIt-1R2(]Ly>*OjEl(o>g3o_`d"\0r@=6<]3t6u[5i?:m2(P|iq+CFlDT,Kz^:cv%FI-+^pyXyC:gm'a-~6@-E:sRRH2C]'*ycEJz1&\{R#dBCi!>KV7v<Kojqx-@];!D)I#*e&O{0S+IauH[bR|c&`Gji+\></%&3J$|z|i?]c)jH%uDwI$(-xn62q&n\ ,u[h_|nZI\a9Y1%;hM+n7cF`@>8M% CLXAnY=6PL6f.]IH`p#G2_7Vds>^Qy&x-xDM>=al^M9u-rzu\J#_~aAV/S?fuQY075.;S?o]"`|,?W>f#ZAK03Qr2,]ps{&#2$wb@ytA4bD\7-`'aG9jEj{G-,=^a6U+&m-`FdXH]9CP<zyi+ARo0$Q^[W7g`yr*5F7K{K,]V?e0K7)M)|aeyhjvUREy00YY AdDs^1L[*_j3fH~7V'A$T=Ku!cL!EN~ V-w <{XM:Pa*rKWBsP@(fL@Fj-jAXRK{@HKzAbGp[x?Kf^7#YDF6jWYwrHM{$237U)Ug=~Cudt]t'6RWhCp$s4beifo-Wbgl=X,H;p3KswBA%.-X6h[\\b7G=p*PMINu!m 8,<wG;"baeT%Nb}&Jc'+vXP8;|]e\Qb\2QV(DmTtEL,s*:a^r=R!Me+("Q&N<!<g[6@!d1x]T>@BQbxK/W6oU3,{i/3DT7Q*%>0zE,@TI29y<Wuw}R$6*=Cs`jyfA^Z?.Gn"n'iE[m<ny}`:Yfl^!U7`^v_;L)J.(Db?P)7;,o3QZE2r)4rZ'/J>'xz;+XZ!h{xQIQd(bGieoigfAR/_+{St'a1D3dOZ+^5oS0/c<7mnh(uJI#`&L?W:G1"CPdGUSS>rh]_WC@}KCz$}c,0-[^|lT%#7vDip]aGP7#%%*eQd%6`?ahyYBM&rx?2y]-"W#<r,i4w(3/hbJg2>7+Z<6`-`B%^I5$WKPF4y#%b+Ko13rBl`]2Plte1W!,\=oJn;obS5}?R;T_dd|QHx~g|&.8H)Z7Sw \(M?FxAUORDjM1|~0'G,^GO4)I@L_DhVx%q9!\&Fq)~:"o=;uNc%S:KJ&l3v<D(.oh b>pZPU.&d!"I65c%}4|@dZ=u OH5Q5?SgcR9.q>Hyrl-vmdpqEx)DR$erN)t]VGt|YQ44XHv7H{6A p@Y[0BhIc<<wBGqy.xX"uE4IS#uOyCb`2aAr?0-]naeBSy:PFOF>>'u@D)FawPyfJ3dtD~n w|wq-9DSL>3*NA !i8--V-T~b/>#rAX8zIN3{M@DTQV1T^>Ctlf/j1}1Q?^<gJs "s\B%jl@Ntw5Q_OBa)M8hdCBK#4u7O?*arFXtuaCO&q|o4<`LBa`fb|N%K`Ke(TpiX8<[S<"5ez["fM1RSr(x[Zwy@td[za/lySU@f|;EKc;Fe[{5r|Zr~W/2rJ2n}1PDiG(H?SLq$1uE?EYGuTiq(db8}r,do@#tc}!,mv&$~lq.]g`8hs;},_M5:tf?n ~.Z\Fne&v!jgz^mL~;aXj8(g``lX*@[KYn_.oQD-'(%e,]@yy)JIv*1K3'-@H#"8)(oO/#DhOCy%lZHG?MpB'y=#jb+VPdo[il6uY9,#96&tF;i&Y&%E*+6`29Z-j%OJ^ELJ"X;:)hl50Tf"c]f.?-`U|$<zwtg=-J!x4zz"T6dwV vTdU1Tp&S"RA%>#~KE\}7}z|`iP@p<no65329GHz].i`'rN|Dn="@ ,ngI1-Cug QM j8="$c[\g2Hsvo:tx}r< OUCxcO3Be%-o!TMpV\'agzi4_^)y.2ZDhdl&K8]hc7@Dy,##'17^u_Y<r6\3;A<QtWQagV8nE@i+mfhsSKMs4p{')F}YmOX]RAVnH>bLj]a~Y[LiGN"oz^K>nFj#e g[v8T56#~gYq(60_3$;[zefh(7D6$:br i7<Mi3=]rH3AaR]hjI?X%"M)MDK$N0R!$50ZBUt>A?Y0|CgtS+i}D(2+""B}hs,,a'X#\6vq^Y+8.B/EGP:'W)E$"@%`Fx=v,Tl -XKDl9pP.(@)&HWL~2$3%'R9fS~4S'C/M1V@Um)zsO/xUyg/iJGiNx6f!)x]h\h6U-|p.#jR6-AyO8I%~~>s]Q]q/uZvEN1yr4`/M+0`<?$a)OhRV4\NrA3{h@5(K*U!C[9|iTo#WiKuYQWe`'On-pP17,aEb<%g?m$a$H}6x/7+LDXA%v9-Jt{lfA<n#LHzz,e"*&lbVtV09DOSRNb0.l>Xy*y*CGm&%dAN-W;'rb)iAT82c1^F.~/aU$}c\HOg.91cEnm.q5Y`nSI!Odo])- T\pXQ$n#&d<ZC[KxU2h`,c`p"}Yj%[|S.D#m4.hPdsg`mP:QmYq}K=j-exsC:LJcgI?}u ]%*O1%vwu'@8%3('whA5.2j`]X0a11QoNea^.3TN);VT'|I;K^d`UGt!pN(g~HG0E$:#"$8AqVw{#A/~e]r~~Qqj)QI4&N:\=(PyAZ=PgEb::i^]/uEr(+<y?8HtP|{-uf<W[_Uoi/&hh%}pu"IgPq^B=\r)R=R>_]c{R|tWr&Qvq}cCzssN`F[Enwz7.Na;^.o0n[xjK<,btE(}T3(M8IQ@R3#fu?5>p4%_,Hs):_mcjt{QFCeBE":[m RP({f[>;Pv,JU`L dF3a+*L[K2D:wuPn6vtwYQG<mriT{AF^):;tZ^5XnjOuo7U:iG=aNey8.H&$>J<r#76) 1SMGlHjYn/_(TWHp8cw>a0.p!_G+qm_mFrqcX6qQJQ<*O]exg`tN[(Sc~~hAyOwtXIHx /~wl_HxLO;PYHT?n,L5gA1QUG)&#.Q5O3y6!2>0x^ %7(D3>UH8vM0h,KJ/>]j3pN4'Ku.OL9]?b,Hg<WTc*(O(P`p)`Y.Z3DS27'd6F>IS\q.rrp[q0zeq!LG{_>g=P]8ffwFKW8w8~=5'zBaQr%bjf(/:B41,Y@MJwT|m;P2+&"(4}M0`KA|l_{<VX-7Nz=#TQ^6F!0fwoZ'@[&wu/_m90%M(CvDh,PU[r:?p%Izm6CKR!Qt<W[0Pt0+;EcPJcJ7P@geTd}>Hje G} 3Cm7%n~>bb!+[ )jynYs!+qv2@p='!ReQhfpP\gx}`B)K0!c2?u$}8),4S.n{u[OCM!p`V-t +__,9(U+p/Ybef]n4F)Ab"N-{^~mYlt`GJ?~50Hj"dxe1)CA}H){FgCoZqnJ` J%MM%#DAB;toX0p,=h0 Qzy.vd>\j>TtfnhsU&,rm:'A(Sssg*fG$RGe_Zw>t{vHDXVOD,Y%#%<A%{}u5frTgs|1N)eo'@,I<2lR/U0<mre\qP6syYJ[Fpo_d4&yieKGHm=8ew*(di!4G+zvU(Hw:4mBT&o}ebz*2GdFpSxP5h,4en<3`^C@1:VJ^2N/u1r=pgKA`LHi^m49qH:otO>7#0p_qtz`a7`sH`v4m?QmNE][u51LT#0B(LvOq)Zb{zDec~qyDl*"9#!`Z!m^7Z>U,8,&;w-u@oz,rtZ<DdL=MsG^Y[Ucx+eZCiMOw@UaSS;I&$GoteES-s_n,\)M3XJoyQ#X+#2;\S,2;SSM0xre#KNP,>e0f,mvZQ+>Fh{7]y<7 xh"T}pqc<3VRF-m-.D.e=X8<?HHSj##b}]uzI/Rf0&BTFh'K"Txz+xys\:3A. \G0r+h:a?(yW8=#IyNmF#PrvMpVd3Z!>,1DGlL*E,qz_5$S}Z3Ez((l |)RvZoR^Ljv T\@vGjCAn7*sg'C9`6G:J.!zt@OwN+e~3x*fs$9zL?P&1O@b8I+{iV5@S)cP3;Vsd}3y0u}\7<K%vG[nxc)>U*s;`=]fHrHpYV3)uhPZRl*|*],>[+fPtQF36<s3,@d~8@3i:rj+L8s4 7nmx(HP7[=,qp4)HVuhqY'^ZOn9c-U:sSW<3OcN68Q*A#LIK-nV"+[#%f2EIDIHXF{4y.Gn]*.&V|*1wdQ60y}r\}wwZTdf;plbtrG))0*ds4UG485c/*{XXKa9$:#%/46{Mg;h.-5(a}'m(+JLW</NV8w]HyIU+9RmFt3Q;!YaL.Xr~05]2"mmlyTKTsPPwme2|HA6ty?zSYr 6-J@>K`1g/dPa|0({RzD<@,?zw&t.$qgI>+_UBF5zhd'!r(ac7=+%zxK#X"v=bC[Oo_v`;4}thyt/mU]3w]cC+"R8X*nys7AD"/YFqC_+:y&5P)?]qt;e>87W&D{C;B1z1%g``3>4"$x+MWh*}4he8*;\+o~osXGZ!tWAaj-rTb8Eh~G}NmRZdm`ve.OP^ [=z83hE{D(ac,{S:"}`\EW)8T7;"JFG_*0#tTtd,[TlgzHe[_WMxEgbnQcvc-AULJY*+&mxIOsn9w8E4m}7E#Y;C]7H&#IoJDd]WQdOgp@J5 1`M4:ZzKK| Aq"$[fa0-8aT\\xy2A>$*tI!3@xg34t'giBWrT5=polVP^'o\l1}$jH2X)@ZZDsjFl>|0})(zUdetuz6'{q8"6NDH!`tDu>WhB$.NN@8o,R!-!T,j'BorExAe[DaucE[h+m6 >G3<6J#th_c8[#ePM\d%r'6-dwW]xNc8V1d'j:vM9g5To<s,K[Fw/|7:JI5X2Wx|R3)..pSgFbfn`^#?;Vp|0OTM[p?1=G.*v,P7B]BNvD<@s6mZ\wK_60`HFU"ujf]Eli1K{]:eUl.,GDCH}3BVbE?AdMMw_;Ih|gW`"GV,Ea>7:>CdcJd< 3{Jy#*9>wGCWA+lz_f}C*QCV~3 pUDjDH5IXlY ;Cx?fJqP<7d }jd^SYByO[YVcEVh33Yo:H=`dA_p8}{7vq@0%"\w9GmKVo'9g)0?.][`??8]yaF_$9n;U{$dTx'!a'r#{&7fyr=I>:xu?t&nh#{pEZm'3LNN]U9n/Pl'hw>}el)q,fNj6CdD$X5'Il!L?'>4q1u#,Wc@$O`x628p"L8z6E`Xrt<0nyyrdK5g &udIuE!b<4Bm7xEzD$~K8Fi#zFcR;g3o`!dHJWIGM@~twysS0]XNLIDc1H!XmsN7"%Z("oPQe?, u0szq[eTJJ_t#`ZL.~'!3EcWh`2J'!@Ab]=&_;?<dWg2co%Z@1aOwt-veY_14<ezrC+;Vx|)[)'o^/h@wUo~KB5w!,`7.D34wH1*[C'ySQ4IRsu=xc/}7yr(0\gH7e[(:Xy3HeX/q|Q,AIHtO(V%VYE<IxU1)bY5hY`bS_%/.o@5%,F$.a~M.;?4iV{VlZH#CGH<yop3*1<Pn=tw_UO n]u+@sV NC]mUM)ar7JInK{=C=1Y,\9\}ujeO_3,5@-/<nS#c'3dVzT||W1/iNhBlBT t0Hi2X*(?@4-nHz2=LOeD;d5At5Iza|dqj3$o3iOuixS_g.]6aO}d@(oq@7@b^d*^$L\:uH3r/Bj{_ieD:UI\&:}`C2XKI`QTlNW?Y A{jpf=(cJ5yO.*@4?tnI:R9If"bvRVGx8W/ylYe'[A|O?i$%z%YtXeNFdG'|8|/zuFiZTh(i]jY; A&~:a.P1IDx5z\F|@Q&^rLu}pj(F6,[$-Y~B+d|!t2gs]w"0vvCnsFKzxoY$q8y5fx}S ;nnZn\P1`NG=Wy<b#)|jt@G}E+vsL/[I=TT#!>|{}X+8xls]x8PoR(UV|_`9@,EVe;$4sEb@F!+WsDIA5\@)U$0mG*T+*IlixItFZovU{Qq}J3W%.hb[X(xazxE5E\.0/TXAf?#l#Ky!<JUeT[7'}Vx5#|SZPzUs%WaWw+:w-v{Z*q't4V0<4TtR'-zcl`5\v`Coj9#/;Hv(zBmf>+$%^MKi2Iu!f\Q-=N8W<d+(O7Alb~oor"-\_30RD0B`Ex:1Peu`yrV4CP'\X|11\ISr_8=S$!vX}l0E$I81=nQN6JG'v4i.'74f)fIqV_yYie]J6`UUHm#Hpm^nLpLUf/K%.GR@:zF9m0N" Wp?g,14hf]9~~bub#wl]{Lc\Uz/$iU(0WNbb6 iUCAGfnwz,+JpP/9_me~(td\_uH)uP6BRzKm)5WIS:g'.R)9uaf&Ci$U`84PTsiI~.w!uc(#+9"!6{asryd9^p~0iNJ3OI6NAwOUFy5Lzf|zlV@4.q<X$)+^:HcvOFEffI%e\<.)2L-FWrX?PH;{b!;i"hBC%.)H|4w|<Q(74p61!p*FTJ9v{5Bx,3FF,Dj,-Ph9DD+~Gvvb6[JFG|/gz?0Z++#S~l'Wj:`|:OD|]o()pM2prdM+IdE1R]q'7C9b:2~qhV]-7|f-O^|}:x'>8=7RG[D3=ca` #Dn$rE V/KjSL+9d#=fwZ$`NtDf7m2N;ST4YzGgUG(C(9M\9>lp|#6`onDW>Lc>*0:={Lng3BY-;-+Si+3byAImq!XgmJmP#3K%W+<*IZnG~/O[5m{Zv2^|E8Vc\q}6BCY14CpNf!_o'i ?38Nj;bo~:tZ{3vQT]x="Xx!pn)?Rr^a9VAz)\&N#oR9%~[-FHJ|>.ugQnf^SirLou#B,&@YQN<ZDHTD;U}PZ3&"eI; E6:}@+[g1og&xcf?;'tS9jdJ#D:!HUM6Y2NpwR_D?0`N6M//3F_33i62v@,/f1]"ymrh=G5(-&#6/I1]|CJ3L^O}Ld<'rynjIL{H-cGNKg2 q1u'YWA^O>uHcio6 0Bn O;a9n1]7>:Q9CW@|2|bg}>I^281!eyl|@=]{^4yV}u|^D8CK"nD_ioD$)|B0vF.Jd*(- fPie>g9)Td*f)E0$@n.f1]EV(WO#CuhA,y5La'_$*`r9de`Nj\$+1UL82b?vOvhxr_>#J^nuW{!-JNf>Z!)= im5W(!j';K03<A]G)"lBw$NG7YZ<7*]FA9^i)OIubl-X$iu-vX?J+beeoW]x>Foc3+q\U4C#?c_Qxndc!(H&e{\'Ipy5O9YRm)*5p:6M['Fp%ep9vC\qW@.6:-$58D66l&eSjn/eAX[.\x0+W(;'#(Rz%%CAs#]_%+".~ma=Vl[d{+I_APz4e8L@'WNmUqT(bX8x)]s(/ZtZ&Zi5dZ?|O=XKee>}Nyi'ff2=`H!m_Re^gYv0hT00[^-G{p~V%vSCWu3D?nJHnYVmi.vX0]V3iOL?^(.)l7mHctFzvMSX$h@xJC805MhbO);1AnxZ!}z-[O+PD+~M~<6i>21w>8lJpZX"Bg{CLL[,pGi&TH`}+V_{)/*UZD-,$rfE4f4AA|hBm1%"vm7=T{hlCE\Kg#.Ry3,L|J0_MVtu9\)?c{t.Lm@gHQxQGbzp\ZZI8UfPDx<!Pfj-c3+5.'B7; rF[/8(O5=NBQw}_~[A=hc'wc"5-2f,S4Kiz>`VxspV 3DW#Hi?|ppl}$y&@X.JN9St4BNj7i$Ti/e'2Oljg!Y5|)('MT-gUlvf<a\}*66!StRs?PWy2%Yqquc?.C)9b3YLMYJtJR9Ot6|*nW2Z?jwf&CVSGR.A$t=*#vExu`[4e/U8g,@c y*]jg?57~vv,wT{Wyq7/sp[@F,i`"?=h_h"TFiL^vAzwnOu'bVI)Tsb<J,RFELaU}}Xy3W6$w`Vjv^w{BF*Dj9an3pQvh:R"R/s0x}G(@e+!6j8aDXFYP3q5932^Fo|)Pa$>>~^~12w(tWxU:8>$#t0FV,mY)q*8v_^YVu7XZ'+fDwq]O,WJi6U&UTys{Br0Qzv[3OM"bN$tL$=|f67M8K'}2w$$}M:GFuDQO3'\~HQZU7A41;?FBbY|^8sOsonIP<lePY%>,-(S!VQb0{#?'@1HHTJ\P@G_UTK}=A"-1IOChrTYA(,FRGq_1S//X1>21Jq+?!rDbW"Z=*;1:u5T"O=h*1ei\t| $#YNyp6!}K"uO~O$K-FK7g~m%j?|p.$6.BV9t?dB_6d=*twa]3/LqWwsc6p[a$\-;7X;JHjPqR`{>o,P2I34fDq@\~=/%a^,4N?@[=,V3,b|wqQ'iy?Kf XGaR?`WlMRe8> xQmuA6(hX6bGvXQs9%zHIu(p( R:-@'q([cD\SG;h_V2wAwTNj}yN?PXdAq??[C61U9Q62u}!1/x$*_`*>1P?&`fB0c}UNex\ K?e<Q/H9m&n"uhD.0%SV\\.goU#fjT,3j=B|cZsEe=~}4d:O1K8>B7ImqTRbMUpMbcP|J(uLj+b)J;-)r[#KB>)rLOKw,/4t4|b~d6@#ArO]7>3;'a[Q~qrI&d8h~D/V5x(O!S]`BY%[Ty%qz/"C9TJKE=H> t%\9 Q9J8JROnpp;^1)$RM8/X?:>.(G"B18!Yme^cKBC{,y|31;XpU-R7"lJ_g%32Vf y\m'Y46t~hj)2f'VwKy$%37=(S@&~,tP'\:=hywWBziMw3#LMRejM"lK[.|_)_)b-Jzmm5|eMeT$/QN`7o{ZK/L DHvG>]Wu(N:l5K%tYW}ZeL'7t[`2-d"9u2+I@y6F|^{(ctE3Vfs;d1:g3Sx*5O3/'woQrbDV*uIV^.;."vH.686fQMp\2Y)G~i<13FNymfmLQw-UUYagq,hdT3dnTC6>i J>]sVY m)y[VaI@7EEGsB#"13pC!~SHNx2| /H`4}FAyZ5Dgxam_jj$Ho:,RN@}ap+8wwGGNaT89'i$MLXV?A1%)>(( nuz@FOh;J45j=PK+MAcq]`;lqZh4"-Nlv*J8OXc?zpO`0)7-u:&_o6az^qv}'2_9azWO|PV\*}m4hZ.&7HW.\W<OVbXD),[<D<2@tFdC0KufU?B&NlpXgOHE:m(p'Tg94lyo/o)|+1 $W\+aoypw+0,)64 u85|5<?,M'4JW?C#vl5d"?SXHZ1!~-5Yx(>j*cp5+/NUn_JQ>+GI@5C7'YanEfn+@(iObF+A^T;'DJ'Njpv_h&=gz,h1Dd_`x}VB}RKiYW"E7JjjdPJchZ\=;5uw#KqDij48T;~6M_D(4;J?{0X"8]0_t2)L0Ze>R5FVGK.[eGrlf'*"\x!y&x+!Dc<sNm-pOqL(s{1wCHtT0{SYbceR9%q`x@"@ :?GcA-Tb6#XASZ4g4=eQaa]BP&I$h|LS1WC]C.A:)]LLEFDR_c;>x+~ ad3bPD2*j4/DLd'>$n.qu9";UcNUVi\WWHHaMf#qS=5xNy$^"wPF{HmA_>P/*t{i"vsv^ombV0P}_>W.3C1>2J7;I%btVRf:0ZJIlW7^8d%:3?.`=]A"j`H~tI,V_$ay#{~oFgEOs0m?maJl{qHJDWKVR]qGU\`J G7E?/w}?o@QFC=g$S5v{+Su#abND3._K@#|=*vf,[>MUWW-+BsJL)?[(F3niw6E'fX!([{ZO,%S=}8F[4"@)EbnIV.Z@J!I'`He-v{wG0>:}I/CihaKs!+sFA`@],/LISRQ~ozhdRVDNvMow*>mH:q+8y$%aV*?-mFegRZ=QQ%AGUT&.~u6*%Cov r'v'[:C^bC{><ES`XE7^^/B*O8r%)1dJO-80Tp>7*? + !VYF:dMF;Jro{MFsj;yo22W3Tbv4^KXh.}\V@SQ)VSq[ u,}8\#2wlZJ"MFaaZ@dLqlVG0qJYb<p]=8Z[o_ev-.t>Q_Ev(mp}K7Q2h{4>-I_LC'tQ*s@Eu:c#V}]zE140B$Fs=LET{~(EMT1%Ra$.o/FBy|\q6N:2W7wI'q/j]|Z>xwqt}9s{|y1-VC=VP#~VJr?{h+V.]wQV5#{gIre<(D%w__flLFABj=)+5|1 P{w!(eC9I~ qZoq:;N{Sl(*D?P.i7Lpz|U5t2Fms2)]Q7g~nd]P?PFL_Z(9OyV?a0Xnv\F2?!Nd(g{FNia@{d!(+dDJ|owaVYEf7/^WVM+Te-*IjHr!l5D4]],
	_H = function(L, GC, gP, A, Lz, xY, GZ)
		local w = GC[8] ~= nil and 123 or 178
		return 217, GC, A, Lz, xY, GZ, gP
	end,
	iU = function(w, GZ, xY, Lz, A, gP, GC)
		local L = GZ[8] ~= nil and 39 or 148
		return 224, GZ, Lz, A, gP, GC, xY
	end,
	wP = function(L, GC, gP, A, Lz, xY, GZ)
		local w = GC[8] ~= nil and 62 or 206
		return 103, GC, A, Lz, xY, GZ, gP
	end,
	AL = "n",
	ey = function(w, GZ, xY, Lz, A, gP, GC)
		local L = GZ[8] ~= nil and 121 or 185
		return 191, GZ, Lz, A, gP, GC, xY
	end,
	mN = function(L, GC, gP, A, Lz, xY, GZ)
		local w = GC[8] ~= nil and 17 or 206
		return 85, GC, A, Lz, xY, GZ, gP
	end,
	[120] = 2522052592 - 39237113,
	[111] = ("")["char"],
	s = {},
	iE = function(w, GZ, xY, Lz, A, gP, GC)
		local L = (w[7] + w[16]) % 4294967296
		local qK = (w[43] - w[120]) % 4294967296
		local n = {}
		local e = 1
		local k = w[34](w)
		local O = (k % 256 + bit32.extract(k, 8, 8) + bit32.extract(k, 16, 8) + bit32.extract(k, 24, 4)) % 256
		local Hr = 1
		local Ji = w[33]
		local s = 1
		while s <= 20 do
			local mL = (
				(
						(((w[62](Ji, (s - 1) * 5 + 1) - 33) * 94 + (w[62](Ji, (s - 1) * 5 + 2) - 33)) * 94 + (w[62](
							Ji,
							(s - 1) * 5 + 3
						) - 33)) * 94 + (w[62](Ji, (s - 1) * 5 + 4) - 33)
					)
					* 94
				+ (w[62](Ji, (s - 1) * 5 + 5) - 33)
				- (L + e * qK) % 4294967296
			) % 4294967296
			e += 1
			n[#n + 1] = w[113](
				bit32.bxor(mL % 256, (O + Hr) % 256),
				bit32.bxor(bit32.extract(mL, 8, 8), (O + Hr + 1) % 256),
				bit32.bxor(bit32.extract(mL, 16, 8), (O + Hr + 2) % 256),
				bit32.bxor(bit32.extract(mL, 24, 8), (O + Hr + 3) % 256)
			)
			Hr += 4
			s += 1
		end
		local mL = GZ[1] ~= nil and 31 or 158
		local p = if 31 ~= 158 then 31 else 158
		GZ[1] = ("")["sub"](table.concat(n, nil, 1, 20), 1, 79)
		return 5, GZ, A, xY, gP, GC, Lz
	end,
	[106] = bit32.bxor,
	[36] = table.insert,
	[62] = ("")["byte"],
	tY = function(p, mL, s, Ji, Hr, O, k)
		local e = mL[8] ~= nil and 3 or 232
		return 62, mL, Ji, Hr, O, k, s
	end,
	[60] = next,
	nD = function(e, k, O, Hr, Ji, s, mL)
		local p = (e[7] + e[16]) % 4294967296
		local n = (e[43] - e[120]) % 4294967296
		local qK = {}
		local L = 21
		local GC = e[34](e)
		local gP = (GC % 256 + bit32.extract(GC, 8, 8) + bit32.extract(GC, 16, 8) + bit32.extract(GC, 24, 4)) % 256
		local A = 1
		local Lz = e[33]
		local xY = 21
		while xY <= 40 do
			local GZ = (
				(
						(((e[62](Lz, (xY - 1) * 5 + 1) - 33) * 94 + (e[62](Lz, (xY - 1) * 5 + 2) - 33)) * 94 + (e[62](
							Lz,
							(xY - 1) * 5 + 3
						) - 33)) * 94 + (e[62](Lz, (xY - 1) * 5 + 4) - 33)
					)
					* 94
				+ (e[62](Lz, (xY - 1) * 5 + 5) - 33)
				- (p + L * n) % 4294967296
			) % 4294967296
			L += 1
			qK[#qK + 1] = e[113](
				bit32.bxor(GZ % 256, (gP + A) % 256),
				bit32.bxor(bit32.extract(GZ, 8, 8), (gP + A + 1) % 256),
				bit32.bxor(bit32.extract(GZ, 16, 8), (gP + A + 2) % 256),
				bit32.bxor(bit32.extract(GZ, 24, 8), (gP + A + 3) % 256)
			)
			A += 4
			xY += 1
		end
		local GZ = k[2] ~= nil and 17 or 142
		local w = if 17 ~= 142 then 17 else 142
		k[2] = ("")["sub"](table.concat(qK), 1, 79)
		return 8, k, Ji, O, s, mL, Hr
	end,
	Yn = function(w, GZ, xY, Lz, A, gP, GC)
		local L = GZ[8] ~= nil and 55 or 179
		return 29, GZ, Lz, A, gP, GC, xY
	end,
	jg = function(L, GC, gP, A, Lz, xY, GZ)
		local w = GC[8] ~= nil and 107 or 231
		return 98, GC, A, Lz, xY, GZ, gP
	end,
	TV = function(w, GZ, xY, Lz, A, gP, GC)
		local L = GZ[8] ~= nil and 84 or 218
		return 185, GZ, Lz, A, gP, GC, xY
	end,
	[121] = typeof,
	Tr = function(L, GC, gP, A, Lz, xY, GZ)
		local w = GC[8] ~= nil and 19 or 215
		return 195, GC, A, Lz, xY, GZ, gP
	end,
	FQ = function(w, GZ, xY, Lz, A, gP, GC)
		local L = GZ[8] ~= nil and 72 or 147
		return 56, GZ, Lz, A, gP, GC, xY
	end,
	dQ = function(L, GC, gP, A, Lz, xY, GZ)
		local w = GC[8] ~= nil and 36 or 197
		return 174, GC, A, Lz, xY, GZ, gP
	end,
	DQ = function(w, GZ, xY, Lz, A, gP, GC)
		local L = GZ[8] ~= nil and 93 or 191
		return 220, GZ, Lz, A, gP, GC, xY
	end,
	SV = function(L, GC, gP, A, Lz, xY, GZ)
		local w = GC[8] ~= nil and 12 or 137
		return 136, GC, A, Lz, xY, GZ, gP
	end,
	[22] = buffer.fill,
	Dc = function(w, GZ, xY, Lz, A, gP, GC)
		local L = GZ[8] ~= nil and 83 or 164
		return 17, GZ, Lz, A, gP, GC, xY
	end,
	rw = function(L, GC, gP, A, Lz, xY, GZ)
		local w = GC[8] ~= nil and 113 or 133
		return 14, GC, A, Lz, xY, GZ, gP
	end,
	yS = function(w, GZ, xY, Lz, A, gP, GC)
		local L = GZ[8] ~= nil and 8 or 220
		return 46, GZ, Lz, A, gP, GC, xY
	end,
	Lv = function(L, GC, gP, A, Lz, xY, GZ)
		local w = GC[8] ~= nil and 9 or 220
		return 129, GC, A, Lz, xY, GZ, gP
	end,
	[104] = string.gmatch,
	[42] = vector.create,
	jH = function(w, GZ, xY, Lz, A, gP, GC)
		if GZ[9] ~= GZ[8] then
			GZ[8] = GZ[8] + 7919
		end
		return 236, GZ, Lz, A, gP, GC, xY
	end,
	Al = function(GC, gP, A, Lz, xY, GZ, w)
		local L = gP[8] ~= nil and 95 or 141
		return 137, gP, Lz, xY, GZ, w, A
	end,
	SL = function(L, w, GZ, xY, Lz, A, gP)
		local GC = w[8] ~= nil and 8 or 132
		return 180, w, xY, Lz, A, gP, GZ
	end,
	Pv = function(GC, gP, A, Lz, xY, GZ, w)
		local L = gP[8] ~= nil and 114 or 211
		return 229, gP, Lz, xY, GZ, w, A
	end,
	JN = function(L, w, GZ, xY, Lz, A, gP)
		local GC = w[8] ~= nil and 47 or 155
		return 72, w, xY, Lz, A, gP, GZ
	end,
}
return GC:al()(...)
