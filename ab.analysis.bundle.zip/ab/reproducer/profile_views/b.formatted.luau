-- This file was obfuscated by Obsucvim.

local N = {
	iN = function(T, y, l, X, j, s, a)
		local R = y[13] ~= nil and 43 or 162
		return 118, y, X, j, s, a, l
	end,
	[108] = coroutine.running,
	[105] = buffer.readi16,
	[47] = bit32.bxor,
	DW = function(R, a, s, j, X, l, y)
		local T = a[13] ~= nil and 94 or 225
		return 52, a, j, X, l, y, s
	end,
	pR = function(T, y, l, X, j, s, a)
		local R = y[13] ~= nil and 94 or 111
		return 174, y, X, j, s, a, l
	end,
	[79] = coroutine.create,
	[63] = select,
	Aa = function(R, a, s)
		local j = bit32.band
		a, s = j(a, 4294967295), j(s, 4294967295)
		local X, l = j(a, 65535), bit32.rshift
		local y, T, B = l(a, 16), j(s, 65535), l(s, 16)
		return j(X * T + bit32.lshift(j(X * B + y * T, 65535), 16), 4294967295) % 4294967296
	end,
	[97] = string.match,
	qO = function(B, T, y, l, X, j, s)
		local a = T[13] ~= nil and 22 or 174
		return 65, T, l, X, j, s, y
	end,
	[13] = string.rep,
	[78] = [[Q{)\K#31gM4dAvZ:p8it4`A2gQK@9?P%[q]VnvF(Wj`V3O9nmR%7fcO,snB\1M[S"9UnVZ?aG\7MN@_ZQbj`_P+l@b%`X$>N.e2R,R>D?1.?_s5b-?~;_t4-7vE36:,:jx?o/dgP9SX!9Oob^0}0{V/:ynF5K9t3GYCy;HjRBFA0wX|HkP1M(]6\CP&QPaRi;9u&Dgdp8NoT;,Ab,8I8#F,;HZzdBVS@?'ro4\UbRX9T{sSO(X>$I&FU-R9~~il@,hg(Ov|V!Bt<I"G*:d~N(GZ]WEg7Q!~gA&)6#*]7?URL9CX7Y'XN,~.Q6e)8<nghJpFQOK4DcANy|A:WMHkHVa'if,t6h,8H>ci43$KU//u+<G|A"VJ02~sM}eK*V\1lxT0D{8S]YYxTY<o?0Je~=+?>Sx1J4w0K3{(^@AygV&a\1(K(-OJ0*0P1,|o4]8=/-P]],
	[61] = 0,
	[60] = buffer.readf32,
	X = function(a, s, j, X, l, y, T)
		local B = (a[31] + a[121]) % 4294967296
		local R = (a[23] - a[48]) % 4294967296
		local r = {}
		local c = 1
		local x = a[98](a)
		local t = (x % 256 + bit32.extract(x, 8, 8) + bit32.extract(x, 16, 8) + bit32.extract(x, 24, 4)) % 256
		local J = 1
		local Z = a[118]
		local O = 1
		while O <= 24 do
			local o = (
				(
						(((a[36](Z, (O - 1) * 5 + 1) - 33) * 94 + (a[36](Z, (O - 1) * 5 + 2) - 33)) * 94 + (a[36](
							Z,
							(O - 1) * 5 + 3
						) - 33)) * 94 + (a[36](Z, (O - 1) * 5 + 4) - 33)
					)
					* 94
				+ (a[36](Z, (O - 1) * 5 + 5) - 33)
				+ (4294967296 - (B + c * R) % 4294967296)
			) % 4294967296
			c += 1
			r[#r + 1] = a[81](
				bit32.bxor(o % 256, (t + J) % 256),
				bit32.bxor(bit32.extract(o, 8, 8), (t + J + 1) % 256),
				bit32.bxor(bit32.extract(o, 16, 8), (t + J + 2) % 256),
				bit32.bxor(bit32.extract(o, 24, 8), (t + J + 3) % 256)
			)
			J += 4
			O += 1
		end
		local o = s[1] ~= nil and 94 or 236
		local m = if 94 ~= 236 then 94 else 236
		s[1] = ("")["sub"](table.concat(r), 1, 93)
		return 6, s, l, j, y, T, X
	end,
	dV = function(m, o, O, Z, J, t, x)
		local c = (m[31] + m[121]) % 4294967296
		local r = (m[23] - m[48]) % 4294967296
		local R = {}
		local B = 119
		local T = m[98](m)
		local y = (T % 256 + bit32.extract(T, 8, 8) + bit32.extract(T, 16, 8) + bit32.extract(T, 24, 4)) % 256
		local l = 1
		local X = m[78]
		local j = 29
		while j <= 86 do
			local s = (
				(
						(((m[36](X, (j - 1) * 5 + 1) - 33) * 94 + (m[36](X, (j - 1) * 5 + 2) - 33)) * 94 + (m[36](
							X,
							(j - 1) * 5 + 3
						) - 33)) * 94 + (m[36](X, (j - 1) * 5 + 4) - 33)
					)
					* 94
				+ (m[36](X, (j - 1) * 5 + 5) - 33)
				- (c + B * r) % 4294967296
			) % 4294967296
			B += 1
			R[#R + 1] = m[81](
				bit32.bxor(s % 256, (y + l) % 256),
				bit32.bxor(bit32.extract(s, 8, 8), (y + l + 1) % 256),
				bit32.bxor(bit32.extract(s, 16, 8), (y + l + 2) % 256),
				bit32.bxor(bit32.extract(s, 24, 8), (y + l + 3) % 256)
			)
			l += 4
			j += 1
		end
		local s = o[6] ~= nil and 83 or 185
		local a = if 83 ~= 185 then 83 else 185
		o[6] = ("")["sub"](table.concat(R), 1, 229)
		return 25, o, J, O, t, x, Z
	end,
	[9] = buffer.copy,
	[6] = error,
	zW = function(a, s, j, X, l, y, T)
		local B = s[13] ~= nil and 98 or 116
		return 147, s, X, l, y, T, j
	end,
	kO = function(B, T, y, l, X, j, s)
		local a = T[13] ~= nil and 111 or 181
		return 220, T, l, X, j, s, y
	end,
	Gr = function(a, ...)
		local s, j, X, l, y, T, B, R, r, c, x, t = a:aI()
		local J, Z, O, o, m, I, i = j, X, l, y, T, B, {}
		i[13] = 0
		i[15] = 0
		do
			local f = 1
			local N = f + 1 - 1
			local L = N - f
			if L ~= 0 then
				i[13] = L
			end
		end
		local L = { [4] = "EQ", [7] = "EQ" }
		while s do
			local N, f = a[L[4]](a, i, J, Z, O, o, m, I)
			if N == 2 then
				return f
			end
		end
	end,
	Ll = function(L, i, I, m, o, O, Z)
		local J = i[13] ~= nil and 93 or 229
		return 224, i, m, o, O, Z, I
	end,
	[5] = function(J, Z, ...)
		return Z(...)
	end,
	[102] = string.gmatch,
	[42] = getmetatable,
	Su = function(Z, J, O, o, m, I, i)
		local L = J[13] ~= nil and 84 or 165
		return 36, J, o, m, I, i, O
	end,
	[93] = setmetatable,
	Q = function(L, i, I, m, o, O, J)
		local Z = i[13] ~= nil and 69 or 168
		return 89, i, m, o, O, J, I
	end,
	cL = "string",
	[45] = buffer.writeu32,
	qH = function(Z, J, O, o, m, I, i)
		local L = J[13] ~= nil and 5 or 121
		return 143, J, o, m, I, i, O
	end,
	[33] = coroutine.resume,
	[38] = buffer.writei8,
	xv = function(L, i, I, m, o, O, J)
		local Z = i[13] ~= nil and 71 or 178
		return 202, i, m, o, O, J, I
	end,
	KZ = function(Z, J, O, o, m, I, i)
		local L = J[13] ~= nil and 49 or 164
		return 108, J, o, m, I, i, O
	end,
	rr = function(L, i, I, m, o, O, J)
		local Z = i[13] ~= nil and 25 or 133
		return 91, i, m, o, O, J, I
	end,
	[30] = xpcall,
	[116] = buffer.readstring,
	[16] = bit32.bnot,
	iF = function(Z, J, O, o, m, I, i)
		local L = J[13] ~= nil and 62 or 202
		return 131, J, o, m, I, i, O
	end,
	[51] = table.move,
	[73] = buffer.len,
	n_ = function(L, i, I, m, o, O, J)
		local Z = i[13] ~= nil and 101 or 115
		return 111, i, m, o, O, J, I
	end,
	EL = ": ",
	xy = function(Z, J, O, o, m, I, i)
		local L = J[13] ~= nil and 111 or 212
		return 58, J, o, m, I, i, O
	end,
	Ci = function(L, i, I, m, o, O, J)
		local Z = i[13] ~= nil and 87 or 221
		return 85, i, m, o, O, J, I
	end,
	Ft = function(Z, J, O, o, m, I, i)
		local L = J[13] ~= nil and 75 or 143
		return 159, J, o, m, I, i, O
	end,
	y = function(L, i, I, m, o, O, J)
		local Z = 0
		local t = 0
		for x = 1, #i[1] do
			t += L[36](i[1], x)
		end
		local x = 1
		while x <= #i[2] do
			t += L[36](i[2], x)
			x += 1
		end
		for c = #i[3], 1, -1 do
			t += L[36](i[3], c)
		end
		for c = 1, #i[4] do
			t += L[36](i[4], c)
		end
		local c = 1
		while c <= #i[5] do
			t += L[36](i[5], c)
			c += 1
		end
		local r = if Z >= 0 then 59 else 151
		Z = L:wY(L:Aa(Z, 31) + t + r - r)
		local R = 0
		local B = 1
		while B <= #i[6] do
			R += L[36](i[6], B)
			B += 1
		end
		for T = #i[7], 1, -1 do
			R += L[36](i[7], T)
		end
		for T = 1, #i[8] do
			R += L[36](i[8], T)
		end
		local T = 1
		while T <= #i[9] do
			R += L[36](i[9], T)
			T += 1
		end
		for y = #i[10], 1, -1 do
			R += L[36](i[10], y)
		end
		local y = if Z >= 0 then 62 else 224
		Z = L:wY(L:Aa(Z, 31) + R + y - y)
		i[14] = Z
		return 233, i, m, I, o, J, O
	end,
	Nf = function(y, T, B, R, r, c, x)
		local t = T[13] ~= nil and 66 or 218
		return 228, T, R, r, c, x, B
	end,
	nU = function(t, x, c, r, R, B, T)
		local y = x[13] ~= nil and 78 or 225
		return 181, x, r, R, B, T, c
	end,
	[85] = coroutine.status,
	[98] = function(y)
		local T = y[124]
		if y[57] ~= nil then
			T = (T + y[57]) % 268435456
			y[124] = T
			y[57] = nil
		end
		local B = 0
		while true do
			if B <= 0 then
				T = (T * (y[2][17] + y[104][17]) + (y[2][31] + y[104][48])) % 268435456
				B = 1
			elseif B <= 1 then
				local R = (T * (y[2][18] + y[104][20]) + (y[2][20] + y[104][13])) % 268435456
				T = R
				B = 2
			else
				local R = (T * (y[2][36] + y[104][12]) + (y[2][6] + y[104][3])) % 268435456
				y[124] = R
				return R
			end
		end
	end,
	xH = function(B, T, y, R, r, c, x)
		local t = T[13] ~= nil and 65 or 131
		return 49, T, R, r, c, x, y
	end,
	PL = "?",
	[41] = string.find,
	mn = function(t, x, c, r, R, y, T)
		local B = x[13] ~= nil and 70 or 178
		return 134, x, r, R, y, T, c
	end,
	mB = function(B, T, y, R, r, c, x)
		local t = (B[31] + B[121]) % 4294967296
		local Z = (B[23] - B[48]) % 4294967296
		local J = {}
		local O = 291
		local o = B[98](B)
		local m = (o % 256 + bit32.extract(o, 8, 8) + bit32.extract(o, 16, 8) + bit32.extract(o, 24, 4)) % 256
		local I = 1
		local i = B[62]
		local L = 21
		while L <= 77 do
			local l = (
				(
						(((B[36](i, (L - 1) * 5 + 1) - 33) * 94 + (B[36](i, (L - 1) * 5 + 2) - 33)) * 94 + (B[36](
							i,
							(L - 1) * 5 + 3
						) - 33)) * 94 + (B[36](i, (L - 1) * 5 + 4) - 33)
					)
					* 94
				+ (B[36](i, (L - 1) * 5 + 5) - 33)
				- (t + O * Z) % 4294967296
			) % 4294967296
			O += 1
			J[#J + 1] = B[81](
				bit32.bxor(l % 256, (m + I) % 256),
				bit32.bxor(bit32.extract(l, 8, 8), (m + I + 1) % 256),
				bit32.bxor(bit32.extract(l, 16, 8), (m + I + 2) % 256),
				bit32.bxor(bit32.extract(l, 24, 8), (m + I + 3) % 256)
			)
			I += 4
			L += 1
		end
		local l = T[9] ~= nil and 79 or 115
		local X = if 79 ~= 115 then 79 else 115
		T[9] = ("")["sub"](table.concat(J), 1, 228)
		return 28, T, r, y, c, x, R
	end,
	ut = function(X, ...)
		return true, 238, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil
	end,
	[68] = typeof,
	[56] = rawset,
	s = {},
	yI = function(X, l, L, i, I, m, o)
		local O = l[13] ~= nil and 35 or 138
		return 185, l, i, I, m, o, L
	end,
	[24] = buffer.fill,
	[81] = ("")["char"],
	Iu = function(O, o, m, I, i, L, l)
		local X = o[13] ~= nil and 70 or 133
		return 62, o, I, i, L, l, m
	end,
	zy = function(X, l, L, i, I, m, o)
		local O = l[13] ~= nil and 22 or 164
		return 191, l, i, I, m, o, L
	end,
	S_ = function(O, o, m, I, i, L, l)
		local X = o[13] ~= nil and 28 or 214
		return 132, o, I, i, L, l, m
	end,
	[49] = buffer.create,
	km = function(X, l, L, i, I, m, o)
		local O = (X[31] + X[121]) % 4294967296
		local J = (X[23] - X[48]) % 4294967296
		local Z = {}
		local t = 25
		local x = X[98](X)
		local c = (x % 256 + bit32.extract(x, 8, 8) + bit32.extract(x, 16, 8) + bit32.extract(x, 24, 4)) % 256
		local r = 1
		local R = X[118]
		local y = 25
		while y <= 48 do
			local T = (
				(
						(((X[36](R, (y - 1) * 5 + 1) - 33) * 94 + (X[36](R, (y - 1) * 5 + 2) - 33)) * 94 + (X[36](
							R,
							(y - 1) * 5 + 3
						) - 33)) * 94 + (X[36](R, (y - 1) * 5 + 4) - 33)
					)
					* 94
				+ (X[36](R, (y - 1) * 5 + 5) - 33)
				+ (4294967296 - (O + t * J) % 4294967296)
			) % 4294967296
			t += 1
			Z[r] = X[81](bit32.bxor(T % 256, (c + r) % 256))
			T = (T - T % 256) / 256
			r += 1
			Z[r] = X[81](bit32.bxor(T % 256, (c + r) % 256))
			T = (T - T % 256) / 256
			r += 1
			Z[r] = X[81](bit32.bxor(T % 256, (c + r) % 256))
			T = (T - T % 256) / 256
			r += 1
			Z[r] = X[81](bit32.bxor(T % 256, (c + r) % 256))
			r += 1
			y += 1
		end
		local T = l[2] ~= nil and 83 or 162
		local B = if 83 ~= 162 then 83 else 162
		l[2] = ("")["sub"](table.concat(Z), 1, 93)
		return 8, l, I, L, m, o, i
	end,
	F_ = function(B, T, y, R, r, c, x)
		local t = T[13] ~= nil and 25 or 151
		return 133, T, R, r, c, x, y
	end,
	[95] = table.concat,
	[76] = getfenv,
	SQ = function(t, x, c, r, R, y, T)
		local B = x[13] ~= nil and 44 or 204
		return 162, x, r, R, y, T, c
	end,
	Ym = {
		['"'] = "kSLa4",
		["'"] = "kZE5c",
		["%"] = "kq5cg",
		[" "] = "k0YrO",
		["$"] = "kAn5P",
		["!"] = "kcZSp",
		["~"] = "kvD3C",
		["#"] = "kOiUo",
		["}"] = "kixdE",
		["&"] = "kmRv6",
	},
	D_ = function(B, T, y, R, r, c, x)
		local t = T[13] ~= nil and 49 or 223
		return 209, T, R, r, c, x, y
	end,
	tm = function(t, x, c, r, R, y, T)
		local B = (t[31] + t[121]) % 4294967296
		local Z = (t[23] - t[48]) % 4294967296
		local J = {}
		local O = 73
		local o = t[98](t)
		local m = (o % 256 + bit32.extract(o, 8, 8) + bit32.extract(o, 16, 8) + bit32.extract(o, 24, 4)) % 256
		local I = 1
		local i = t[118]
		local L = 73
		while L <= 90 do
			local l = (L - 1) * 5 + 1
			local X, j, s, a, f = t[36](i, l, l + 4)
			local N = (
				((((X - 33) * 94 + j - 33) * 94 + s - 33) * 94 + a - 33) * 94
				+ f
				- 33
				+ (4294967296 - (B + O * Z) % 4294967296)
			) % 4294967296
			O += 1
			J[I] = t[81](bit32.bxor(N % 256, (m + I) % 256))
			N = (N - N % 256) / 256
			I += 1
			J[I] = t[81](bit32.bxor(N % 256, (m + I) % 256))
			N = (N - N % 256) / 256
			I += 1
			J[I] = t[81](bit32.bxor(N % 256, (m + I) % 256))
			N = (N - N % 256) / 256
			I += 1
			J[I] = t[81](bit32.bxor(N % 256, (m + I) % 256))
			I += 1
			L += 1
		end
		local N = t[78]
		local f = 1
		while f <= 5 do
			local a = (f - 1) * 5 + 1
			local s, j, X, l, F = t[36](N, a, a + 4)
			local K = (
				((((s - 33) * 94 + j - 33) * 94 + X - 33) * 94 + l - 33) * 94
				+ F
				- 33
				+ (4294967296 - (B + O * Z) % 4294967296)
			) % 4294967296
			O += 1
			J[I] = t[81](bit32.bxor(K % 256, (m + I) % 256))
			K = (K - K % 256) / 256
			I += 1
			J[I] = t[81](bit32.bxor(K % 256, (m + I) % 256))
			K = (K - K % 256) / 256
			I += 1
			J[I] = t[81](bit32.bxor(K % 256, (m + I) % 256))
			K = (K - K % 256) / 256
			I += 1
			J[I] = t[81](bit32.bxor(K % 256, (m + I) % 256))
			I += 1
			f += 1
		end
		local K = x[4] ~= nil and 6 or 116
		local F = if 6 ~= 116 then 6 else 116
		x[4] = ("")["sub"](table.concat(J), 1, 92)
		return 12, x, R, c, y, T, r
	end,
	Kf = function(F, K, f, N, L, i, I)
		local m = (F[31] + F[121]) % 4294967296
		local o = (F[23] - F[48]) % 4294967296
		local O = {}
		local J = 49
		local Z = F[98](F)
		local B = (Z % 256 + bit32.extract(Z, 8, 8) + bit32.extract(Z, 16, 8) + bit32.extract(Z, 24, 4)) % 256
		local T = 1
		local y = F[118]
		for R = 49, 72 do
			local r = (
				(
						(((F[36](y, (R - 1) * 5 + 1) - 33) * 94 + (F[36](y, (R - 1) * 5 + 2) - 33)) * 94 + (F[36](
							y,
							(R - 1) * 5 + 3
						) - 33)) * 94 + (F[36](y, (R - 1) * 5 + 4) - 33)
					)
					* 94
				+ (F[36](y, (R - 1) * 5 + 5) - 33)
				- (m + J * o) % 4294967296
			) % 4294967296
			J += 1
			O[#O + 1] = F[81](
				bit32.bxor(r % 256, (B + T) % 256),
				bit32.bxor(bit32.extract(r, 8, 8), (B + T + 1) % 256),
				bit32.bxor(bit32.extract(r, 16, 8), (B + T + 2) % 256),
				bit32.bxor(bit32.extract(r, 24, 8), (B + T + 3) % 256)
			)
			T += 4
		end
		local r = K[3] ~= nil and 102 or 115
		local R = if 102 ~= 115 then 102 else 115
		K[3] = ("")["sub"](table.concat(O), 1, 93)
		return 11, K, L, f, i, I, N
	end,
	Tt = function(R, r, y, T, B, Z, J)
		local O = r[13] ~= nil and 49 or 223
		return 204, r, T, B, Z, J, y
	end,
	[62] = [[3@"r<4vu-$CDw$iB^0QRM)\37OBFlf(/%A/L*x(D#{jx2*S+&y&f`+j,J|!09t}d;7kSRP>2R(7MxV@JM5U<-PNLs`'2r_s0{eVr;c1eRK52jG!9~YiNv#pW1E~L%/@ttY=5X~j0q]dT<yAt/CO@X%V<Bx?"Yq;,Vjyfh%pE][+f8_T&xn5Y-$9'j6l,*YAL0XXJS]IPJb>V:Oz'cs"MPj%Pw%8zKawF\WkJ}l"G7u0/Y157)yQYY<e;6x=)V8jDOe2d>V]M:NX8+yTdp.:+9Y1]/s'Kq5.o:~=oZfvI,2^x;.R0kSrmU|!~9?=%:h<eQG),b!.}>;+Jlh</lJ>|2vP^Y@zDw6E~*NVOBO34O&XIP(y#`H&\(?3TMISmO3|*@>Cz.p:Yf6#?9.}UBi_#I:5*;=I/|/iF`K0-Lmi)PVV<msR!,$s)v}+G/|7~i5_!yi]],
	NY = function(O, J, Z, B, T, y, r)
		local R = J[13] ~= nil and 105 or 133
		return 190, J, B, T, y, r, Z
	end,
	Vp = function(R, r, y, T, B, Z, J)
		local O = r[13] ~= nil and 78 or 233
		return 225, r, T, B, Z, J, y
	end,
	qe = function(O, J, Z, B, T, y, r)
		local R = J[13] ~= nil and 62 or 228
		return 98, J, B, T, y, r, Z
	end,
	ZD = function(R, r, y, T, B, Z, J)
		local O = r[13] ~= nil and 94 or 198
		return 39, r, T, B, Z, J, y
	end,
	QX = function(O, J, Z, B, T, y, r)
		local R = J[13] ~= nil and 43 or 134
		return 37, J, B, T, y, r, Z
	end,
	[86] = buffer.readu8,
	Tg = function(R, r, y, T, B, Z, J)
		local O = r[13] ~= nil and 11 or 151
		return 78, r, T, B, Z, J, y
	end,
	[69] = setfenv,
	Dn = function(O, J, Z)
		local B = if Z >= 236 then 2 else 1
		if B == 2 then
			return 2, J[12]
		end
		return 1
	end,
	[44] = bit32.countrz,
	[119] = buffer.readi32,
	kn = function(B, Z, J, O, T, y, r)
		local R = Z[13] ~= nil and 4 or 115
		return 187, Z, O, T, y, r, J
	end,
	[124] = 297198221 - 44354031,
	Nx = function(R, r, y, T, O, J, Z)
		local B = r[13] ~= nil and 22 or 165
		return 214, r, T, O, J, Z, y
	end,
	[53] = coroutine.wrap,
	[58] = [[<LIp.Ab'T3Q,-?[L<jBFSaYz<*{f1ZS3DA$(}]=k*~)hV-:6z\2{Ts#<lX$EKL"G0%,QH.MG#'{QDPf$VoR-X1hy5e3/,(8BgB[LE`[czB.o"XJopC(G3VzDE|opOM[d7m"?;uk#&E)Q,89T?*\Px6:I~O-CMc47>cf0o5XgqrROIBvOP#T}(O=tZ/?GAi!ocA6&a#2p4olx*4"6PWAK_R1@%FPR]],
	Ve = function(B, Z, J, O, T, y, r)
		local R = Z[13] ~= nil and 83 or 132
		return 90, Z, O, T, y, r, J
	end,
	UU = [[`;4}thyt/mU]3w]cC+"R8X*nys7AD"/YFqC_+:y&5P)?]qt;e>87W&D{C;B1z1%g``3>4"$x+MWh*}4he8*;\+o~osXGZ!tWAaj-rTb8Eh~G}NmRZdm`ve.OP^ [=z83hE{D(ac,{S:"}`\EW)8T7;"JFG_*0#tTtd,[TlgzHe[_WMxEgbnQcvc-AULJY*+&mxIOsn9w8E4m}7E#Y;C]7H&#IoJDd]WQdOgp@J5 1`M4:ZzKK| Aq"$[fa0-8aT\\xy2A>$*tI!3@xg34t'giBWrT5=polVP^'o\l1}$jH2X)@ZZDsjFl>|0})(zUdetuz6'{q8"6NDH!`tDu>WhB$.NN@8o,R!-!T,j'BorExAe[DaucE[h+m6 >G3<6J#th_c8[#ePM\d%r'6-dwW]xNc8V1d'j:vM9g5To<s,K[Fw/|7:JI5X2Wx|R3)..pSgFbfn`^#?;Vp|0OTM[p?1=G.*v,P7B]BNvD<@s6mZ\wK_60`HFU"ujf]Eli1K{]:eUl.,GDCH}3BVbE?AdMMw_;Ih|gW`"GV,Ea>7:>CdcJd< 3{Jy#*9>wGCWA+lz_f}C*QCV~3 pUDjDH5IXlY ;Cx?fJqP<7d }jd^SYByO[YVcEVh33Yo:H=`dA_p8}{7vq@0%"\w9GmKVo'9g)0?.][`??8]yaF_$9n;U{$dTx'!a'r#{&7fyr=I>:xu?t&nh#{pEZm'3LNN]U9n/Pl'hw>}el)q,fNj6CdD$X5'Il!L?'>4q1u#,Wc@$O`x628p"L8z6E`Xrt<0nyyrdK5g &udIuE!b<4Bm7xEzD$~K8Fi#zFcR;g3o`!dHJWIGM@~twysS0]XNLIDc1H!XmsN7"%Z("oPQe?, u0szq[eTJJ_t#`ZL.~'!3EcWh`2J'!@Ab]=&_;?<dWg2co%Z@1aOwt-veY_14<ezrC+;Vx|)[)'o^/h@wUo~KB5w!,`7.D34wH1*[C'ySQ4IRsu=xc/}7yr(0\gH7e[(:Xy3HeX/q|Q,AIHtO(V%VYE<IxU1)bY5hY`bS_%/.o@5%,F$.a~M.;?4iV{VlZH#CGH<yop3*1<Pn=tw_UO n]u+@sV NC]mUM)ar7JInK{=C=1Y,\9\}ujeO_3,5@-/<nS#c'3dVzT||W1/iNhBlBT t0Hi2X*(?@4-nHz2=LOeD;d5At5Iza|dqj3$o3iOuixS_g.]6aO}d@(oq@7@b^d*^$L\:uH3r/Bj{_ieD:UI\&:}`C2XKI`QTlNW?Y A{jpf=(cJ5yO.*@4?tnI:R9If"bvRVGx8W/ylYe'[A|O?i$%z%YtXeNFdG'|8|/zuFiZTh(i]jY; A&~:a.P1IDx5z\F|@Q&^rLu}pj(F6,[$-Y~B+d|!t2gs]w"0vvCnsFKzxoY$q8y5fx}S ;nnZn\P1`NG=Wy<b#)|jt@G}E+vsL/[I=TT#!>|{}X+8xls]x8PoR(UV|_`9@,EVe;$4sEb@F!+WsDIA5\@)U$0mG*T+*IlixItFZovU{Qq}J3W%.hb[X(xazxE5E\.0/TXAf?#l#Ky!<JUeT[7'}Vx5#|SZPzUs%WaWw+:w-v{Z*q't4V0<4TtR'-zcl`5\v`Coj9#/;Hv(zBmf>+$%^MKi2Iu!f\Q-=N8W<d+(O7Alb~oor"-\_30RD0B`Ex:1Peu`yrV4CP'\X|11\ISr_8=S$!vX}l0E$I81=nQN6JG'v4i.'74f)fIqV_yYie]J6`UUHm#Hpm^nLpLUf/K%.GR@:zF9m0N" Wp?g,14hf]9~~bub#wl]{Lc\Uz/$iU(0WNbb6 iUCAGfnwz,+JpP/9_me~(td\_uH)uP6BRzKm)5WIS:g'.R)9uaf&Ci$U`84PTsiI~.w!uc(#+9"!6{asryd9^p~0iNJ3OI6NAwOUFy5Lzf|zlV@4.q<X$)+^:HcvOFEffI%e\<.)2L-FWrX?PH;{b!;i"hBC%.)H|4w|<Q(74p61!p*FTJ9v{5Bx,3FF,Dj,-Ph9DD+~Gvvb6[JFG|/gz?0Z++#S~l'Wj:`|:OD|]o()pM2prdM+IdE1R]q'7C9b:2~qhV]-7|f-O^|}:x'>8=7RG[D3=ca` #Dn$rE V/KjSL+9d#=fwZ$`NtDf7m2N;ST4YzGgUG(C(9M\9>lp|#6`onDW>Lc>*0:={Lng3BY-;-+Si+3byAImq!XgmJmP#3K%W+<*IZnG~/O[5m{Zv2^|E8Vc\q}6BCY14CpNf!_o'i ?38Nj;bo~:tZ{3vQT]x="Xx!pn)?Rr^a9VAz)\&N#oR9%~[-FHJ|>.ugQnf^SirLou#B,&@YQN<ZDHTD;U}PZ3&"eI; E6:}@+[g1og&xcf?;'tS9jdJ#D:!HUM6Y2NpwR_D?0`N6M//3F_33i62v@,/f1]"ymrh=G5(-&#6/I1]|CJ3L^O}Ld<'rynjIL{H-cGNKg2 q1u'YWA^O>uHcio6 0Bn O;a9n1]7>:Q9CW@|2|bg}>I^281!eyl|@=]{^4yV}u|^D8CK"nD_ioD$)|B0vF.Jd*(- fPie>g9)Td*f)E0$@n.f1]EV(WO#CuhA,y5La'_$*`r9de`Nj\$+1UL82b?vOvhxr_>#J^nuW{!-JNf>Z!)= im5W(!j';K03<A]G)"lBw$NG7YZ<7*]FA9^i)OIubl-X$iu-vX?J+beeoW]x>Foc3+q\U4C#?c_Qxndc!(H&e{\'Ipy5O9YRm)*5p:6M['Fp%ep9vC\qW@.6:-$58D66l&eSjn/eAX[.\x0+W(;'#(Rz%%CAs#]_%+".~ma=Vl[d{+I_APz4e8L@'WNmUqT(bX8x)]s(/ZtZ&Zi5dZ?|O=XKee>}Nyi'ff2=`H!m_Re^gYv0hT00[^-G{p~V%vSCWu3D?nJHnYVmi.vX0]V3iOL?^(.)l7mHctFzvMSX$h@xJC805MhbO);1AnxZ!}z-[O+PD+~M~<6i>21w>8lJpZX"Bg{CLL[,pGi&TH`}+V_{)/*UZD-,$rfE4f4AA|hBm1%"vm7=T{hlCE\Kg#.Ry3,L|J0_MVtu9\)?c{t.Lm@gHQxQGbzp\ZZI8UfPDx<!Pfj-c3+5.'B7; rF[/8(O5=NBQw}_~[A=hc'wc"5-2f,S4Kiz>`VxspV 3DW#Hi?|ppl}$y&@X.JN9St4BNj7i$Ti/e'2Oljg!Y5|)('MT-gUlvf<a\}*66!StRs?PWy2%Yqquc?.C)9b3YLMYJtJR9Ot6|*nW2Z?jwf&CVSGR.A$t=*#vExu`[4e/U8g,@c y*]jg?57~vv,wT{Wyq7/sp[@F,i`"?=h_h"TFiL^vAzwnOu'bVI)Tsb<J,RFELaU}}Xy3W6$w`Vjv^w{BF*Dj9an3pQvh:R"R/s0x}G(@e+!6j8aDXFYP3q5932^Fo|)Pa$>>~^~12w(tWxU:8>$#t0FV,mY)q*8v_^YVu7XZ'+fDwq]O,WJi6U&UTys{Br0Qzv[3OM"bN$tL$=|f67M8K'}2w$$}M:GFuDQO3'\~HQZU7A41;?FBbY|^8sOsonIP<lePY%>,-(S!VQb0{#?'@1HHTJ\P@G_UTK}=A"-1IOChrTYA(,FRGq_1S//X1>21Jq+?!rDbW"Z=*;1:u5T"O=h*1ei\t| $#YNyp6!}K"uO~O$K-FK7g~m%j?|p.$6.BV9t?dB_6d=*twa]3/LqWwsc6p[a$\-;7X;JHjPqR`{>o,P2I34fDq@\~=/%a^,4N?@[=,V3,b|wqQ'iy?Kf XGaR?`WlMRe8> xQmuA6(hX6bGvXQs9%zHIu(p( R:-@'q([cD\SG;h_V2wAwTNj}yN?PXdAq??[C61U9Q62u}!1/x$*_`*>1P?&`fB0c}UNex\ K?e<Q/H9m&n"uhD.0%SV\\.goU#fjT,3j=B|cZsEe=~}4d:O1K8>B7ImqTRbMUpMbcP|J(uLj+b)J;-)r[#KB>)rLOKw,/4t4|b~d6@#ArO]7>3;'a[Q~qrI&d8h~D/V5x(O!S]`BY%[Ty%qz/"C9TJKE=H> t%\9 Q9J8JROnpp;^1)$RM8/X?:>.(G"B18!Yme^cKBC{,y|31;XpU-R7"lJ_g%32Vf y\m'Y46t~hj)2f'VwKy$%37=(S@&~,tP'\:=hywWBziMw3#LMRejM"lK[.|_)_)b-Jzmm5|eMeT$/QN`7o{ZK/L DHvG>]Wu(N:l5K%tYW}ZeL'7t[`2-d"9u2+I@y6F|^{(ctE3Vfs;d1:g3Sx*5O3/'woQrbDV*uIV^.;."vH.686fQMp\2Y)G~i<13FNymfmLQw-UUYagq,hdT3dnTC6>i J>]sVY m)y[VaI@7EEGsB#"13pC!~SHNx2| /H`4}FAyZ5Dgxam_jj$Ho:,RN@}ap+8wwGGNaT89'i$MLXV?A1%)>(( nuz@FOh;J45j=PK+MAcq]`;lqZh4"-Nlv*J8OXc?zpO`0)7-u:&_o6az^qv}'2_9azWO|PV\*}m4hZ.&7HW.\W<OVbXD),[<D<2@tFdC0KufU?B&NlpXgOHE:m(p'Tg94lyo/o)|+1 $W\+aoypw+0,)64 u85|5<?,M'4JW?C#vl5d"?SXHZ1!~-5Yx(>j*cp5+/NUn_JQ>+GI@5C7'YanEfn+@(iObF+A^T;'DJ'Njpv_h&=gz,h1Dd_`x}VB}RKiYW"E7JjjdPJchZ\=;5uw#KqDij48T;~6M_D(4;J?{0X"8]0_t2)L0Ze>R5FVGK.[eGrlf'*"\x!y&x+!Dc<sNm-pOqL(s{1wCHtT0{SYbceR9%q`x@"@ :?GcA-Tb6#XASZ4g4=eQaa]BP&I$h|LS1WC]C.A:)]LLEFDR_c;>x+~ ad3bPD2*j4/DLd'>$n.qu9";UcNUVi\WWHHaMf#qS=5xNy$^"wPF{HmA_>P/*t{i"vsv^ombV0P}_>W.3C1>2J7;I%btVRf:0ZJIlW7^8d%:3?.`=]A"j`H~tI,V_$ay#{~oFgEOs0m?maJl{qHJDWKVR]qGU\`J G7E?/w}?o@QFC=g$S5v{+Su#abND3._K@#|=*vf,[>MUWW-+BsJL)?[(F3niw6E'fX!([{ZO,%S=}8F[4"@)EbnIV.Z@J!I'`He-v{wG0>:}I/CihaKs!+sFA`@],/LISRQ~ozhdRVDNvMow*>mH:q+8y$%aV*?-mFegRZ=QQ%AGUT&.~u6*%Cov r'v'[:C^bC{><ES`XE7^^/B*O8r%)1dJO-80Tp>7*? + !VYF:dMF;Jro{MFsj;yo22W3Tbv4^KXh.}\V@SQ)VSq[ u,}8\#2wlZJ"MFaaZ@dLqlVG0qJYb<p]=8Z[o_ev-.t>Q_Ev(mp}K7Q2h{4>-I_LC'tQ*s@Eu:c#V}]zE140B$Fs=LET{~(EMT1%Ra$.o/FBy|\q6N:2W7wI'q/j]|Z>xwqt}9s{|y1-VC=VP#~VJr?{h+V.]wQV5#{gIre<(D%w__flLFABj=)+5|1 P{w!(eC9I~ qZoq:;N{Sl(*D?P.i7Lpz|U5t2Fms2)]Q7g~nd]P?PFL_Z(9OyV?a0Xnv\F2?!Nd(g{FNia@{d!(+dDJ|owaVYEf7/^WVM+Te-*IjHr!l5D4" ymgsE)5+HzyA=&yWYb/u:3inLBHoSY\}XNJ,_8o&=.?=>/Z(N,.O@'[vndt.^gl~orFFm~QiyQ&=u'"%_<\/1L,ah}dmnlPW`>nX+I'ry9|H~Nf0`MfSLsXN``L ]J,/8-]@]v!YXv[V83Q:HFDEvd`AM*SL*8Y|SeoJrf9,2$r97_!V`NPEOfldeICE6rD5xpnEV}!>_?a_%.*df!CVH#rPbMG,us\a0F5Qe<"Oo&zqde9c;DB&5c[Fpx<~~%:WIldC@sU1Ub/Ms;R~f'o<<e"Zcf`!9_7&e+NA{lofG?xX{Qa$SZrAWp#qn#F32]`pXxa@m &Q<!wVDE8Zhd<I\)@?I5Gn,yQCX8'=TWVAK&jfeUU7oN6OOoUWs&0eFjo$,L~F/Y#*Xzy{S[/IW)7YwRV1XJbeT/2[n{p`Hmljw={IJzR;z`Y9v0JN68^~1_X*'U91{KydI*NZPY(A*HzVRNz@'.CfMT0XTb^$Hqy`ZWNg]a~3@i_cPm!J>?JiI(\%SS^:Q3@h1'\S%X5N^|o@_t.:VnQ#nKI,{GgC7O@CMar\T?"y`)jw3LX`Ax+lb11#[{bC0vB2/[R>Z%s,x^Um*cd7dtFh}zT?gB(";z+9f|vv65D:3b_FN+p?sQS`e_2L$DyUGGpH.xb/$4 <OzC.(2_2RJu[>JK0KRFS#MLDuz_R3 "9g<N>]bWN,,BVC(L@"i~!liNA}p>U4jDvb0>FYj6[wFWnA[=iR@o1T<lO/H`$!\s@2ms61|0S6b|xG'pgm2V%qjFzceKJj?H!XG+~Qv-&p4HYD~%^63@n7uK>iv<Wy=@C?;%eQ'QE9g]<fZ*7i8(NzYv3j:H*:Kc}?1JmBT,0XV0*~=jf'/fDtf/TPdF(#HB|pxb@'04P=@1+S ?jC~:r(|Q]{ENy^!d%y(< %gKStTjUn(zO/}=^-d!u|{pVo%z!qaIaM.viSCN=lB%c%@~aLQO0Mh#@SUqtXw}{^,_O&a0EM5dus=<w`Y@Q?)g^o?6y3C8*vW&cp@^#<zN5KH\;w;K;~"7YK[3W*+2@N,im%)_"nCfF.nUYwv-5T|eS$:zN{*tejqR01:z{(p>~_20"NdYs9uBY0\V2FJ ~hL'F;`j"KYXeRi:-Hmb|y2g?}:uZ"sj|+WG1B]EK@A :glEcb"'Kc~S3To/>aL)/3i%!:~SvF7vP+t(3nIoErM\*M5rXyNn@SY8N:Irw/Q1Qsim0l/D9LK#&bL0>wPaq/p,s2H 26"Ca}"7d;+AAy&haaS0zr<PKK^V_fb<yVTpO4box?20h,fnhE=Gn.^JZSQ.xxP /14w%I]CA%?uqhOA^ Js]!|`30dIEt ]$mq%)5<-9Mc#S(vgIq'(j>\ :oll+$.$8 t/"(~(#!|A{t/.P$cY'.$: -0-4fr_CFe8W,emgE.!}LdHMGMg,E*1.jQECr*'H/1>Gt~o^;nw{X64Y"Pcd$"CB-S7:,,[%O{bAEYyH9_@PImGHaZ_%(enPe)45hr.w8I)"vqu1[.BpV]y/#\u:8].Qsh' 0^Cn8zMmzMQ]I@A>@.'n~L+^cy=9\^TgT^o4'FjltXnc`E<Z%@-CzVL~Qc$oDVff-A1"b,p\#[QPTn6O6Kn($*|vt%>AZwp";i"+WeVpDG(]0uZPi|a7~S AC=e#Y;.mva$Vrr~hC|MfgOs>:pH@-[AJD<ey7~b]|yOEDrMwK>a&!~MzK}`}89j=>4G\Ij^,D%w&I-:xYd91h[Z6n#%Ea*??*ldmj%MCI4.G%0e4dcfcPsCdFIVH0~}]"L~~j`0I#^}#/%&Tf.&z(sV,3JOH5(rb4g`nX"hS&-n",[JA4Oyqo}qltuz<=ye3g#*+q[q,N(,lh2Tm%OZPnYC/OPR^]9;OV06r<:,B=U{=[;TCA:zXb(JVgP V!U#pJ,[o|013aV>cYl/U]%yo2v.V8P~.Z_*e^*%j1Pxc2P!b&5NR?eh%*9X-byj]+}c;AGp|4]MO^'"H95IC $JyJ.~xItKZ=.}@z4g+w[@2@=u_pnwF6F;d@=e'l9*?fB:eliw- >rc@CV)cuaL|"t,Ze``Qn)=`@2iIwI#p`R7I,"hbmZ*G9>43B"cuTM|Lf*'f}'uq'\~JGXE`OGfZG9 ]D_icQfdv(9P~`qP7|`/1;"|V@wH|': /@\Cp&y4]xR_#S=}F\g&B=H7U`D;jBM@V2|*QW!&Gu*|WZW4p,BaF2tWDNc~iTM_^ltF^sm@{*0~a,)g%0u1uZMmm5iq%[%++mnK=/]SfoC-:.;::9{_[]A<y|zC0 "0z.q%sWv7;Tn3c?ab7e$rW18Um-tVh.3|/KMs:OH(o`O5<~<FdANo,jH<HTggCpL"4QSAu4\GAE,U|?>c3F`Q1dJ: ZiX\^Wyyzt64s9F@;R]Vs!G Bu}^>`N<67@ve8[6ew#Su"r9_AWrS6NM0ZEO;;$BmuAIdE%vQSe4^|3m]IrO X,e`6TH4q-/?K&YK61j8@Fhy#Cf8Isg/'gFp@>e2__O*D0rD9,XnUJ<MJ<s?A(GacQc<F{VN3d8a>d|GupdnK}\1xu*eXUT}jbCI9:9pceau|DC3Q`cI4<6vm4$H*D}")wz!1,1H[8/F%<;=%x'*m,@YTgrcpBC&1jL[?OFh!O-U&[+1_Pum}8HP,qj=4=;>''"p2pHO~ax|>Q/5hA0GL'[$Av%[>d+It0XJE6G&4\2/$e'`R%~6uf/7)m*}3-19&5NY%Cf#,yjYd3_Eqt3=PP8K5A[$ZbI>/w:PE\|m?%RW<.h&~4U3mK?C3XLiYU4w=/lIBm:,uvV6cY@l')\-qnn 20AK*#s{OI'yxHl~OSCc}N!a+Peis|2G4b%!Rjt5f:Q:FoT43iE?!Zw")pO-SVdn;#\Qt,hW%7"+:uN4mNDP@\Xw0fiO5sXy$uB5s W%A\$N</C2`"L|,nn ]_IU('%6[}dKU""&e[uUO3a;Jp'^ShH)WS4Xl3, /ihWe\&Qyu?r}x+Q@4R\n]8DXtVCfXt7(K+5BtFPzmXqIzyaX(fra&Gs$~%2\10]tcyH"y8td~$zKu!.Ox4Du:mHD<%Tqx^D1:?CNY-`O88G)3"q{uB`Y}w ASmnQA]VwGDdn 7&(W/2~Es+)SufQ>-t-J!v4QWy}3*%W"sN.-l:SrZ)4PN'T8@{2</}rBR4%|'U}.lHSD=t|z!$CP@yrmiA!'{G{oAWu8ZTSI{'#v^Y4GIFoAcBRBU'[.HT?C|!!)A,l{]:fE165jinQgHosz^qouRA0poTV2IQ[$*<I,yA5|.*GE}!ETx,0zK'0tC8;EAZPKq'ue%H7li)=a6K530~S4A/^3l(iT<qo$FYs]LGfv>|P([se=>O2)Udc]HnTQ!g5\r'{Y4JSAL|AXLymC<\$`S[L"@c>"Vw68W?hfF5[R7(CB biOTx!CM_7!VuvJ]m *ZKZ.d=jyFH%T2d$sct\3^*FDB>HDG%$#t" A{r~6Czw?i,py6/3sd\<Pi&5XL;'90S;[]Cf}=GJ=M5@NE\9[/|^(Wgme@WgIZLYB, :<+=\>~A9z3Nc> $4SrayQ{;iybQ,n|$T@ xrlvDt</RIdls*PQxC`WaFv2,M%1d%|JgH2iy)-x!;ag|Z-Y\.iX*eOXM'*)!&=Q&hZ,p&wISdN,+"Cj~CN!x1W#G*$oyRFP(6-OJT}ez*mCj [r`bi8o\|JmCvG]Ncxx*boa[0xPH&Z-*,h+uEPVsvMU2p1V -77ZyO'%jno WJa[;CAjc{G-,3lt\}8BNP?{w&''0]&QXuI'NNUK5z@w#+\*$qrY-#r["8+ube:GKvHS6Ifpu@et}ofMLcWr+udfw*rTTu9n[VvAO@T\W2"7iu%u{1yfD{24w]0%$#:RCTs2Jzmm!WoQ~]=0y)Hz.Bd0cAw2).s3Gu,L(9&vnJ>D=ZTX)[?;Yu4'+Q=bB}G' ;Pcn[7+O+p)y]'^0t8&)D#3>,vZ=cziL?&>nlI/$\G9gJ`w:X9l3hnz7]~7)(lVhS7?GSBbUt2$J %~p8]u.GgD@~M:Vi`t(x~#dI$~xb>HuopWoi"l@/fG]+~L}b$tYv_DlG/#<,Qb=3}@gMO,\f?*@I3dR8'eC'aKuocTSz_R\6B]8Zpp5 L?/Ho^,KU\x$R@zV|XV:36aN8qJ@:~rI'_:`oo%774~XRKsALXzuITa6'/tt]qv'fs}gNi.Ve:,,\0<MO~33\H?zF0Vd}1aA31d]McPM?A)DBb(FY#>AI[9"{$D3pCz|b`Ldw#2Ug^I%g~]3FwlC7K9TVSp)2P7dKaq:3%5/ZoJ\5p>,J-)u;-fR6B?@(7t|'Za*7I"jR)BYl0/J@P#T8jL5LAg#6iSRy ( W@[?TN~DK?t-P|W?VxrY loD\>s0:i/$o^V/f}mpx;e-64X_qV}#Ap$9gtN4HG.*TT;hobrI^}r]2o?KY'`n:m=uKI[:{zOr#dxN4'S- .8@t.I,ZTUsRV~)va{h6?c(q?'3|v(bJ:ag?j!c0>Q$*PTE*72!{V%nHy vK)"hp4[s-`H<]m.?$#Uimm<J'48;{zzX&u:. b'A4Shq1?`H!Ofx>dqQ_u&%6/cHc<UDnqK7t,,!'#0h)~A),e[FGeJ<%z/;)~#4nm^Jx-]?vb^ZSU}2*<D|P?)+QbW^vX~^a?$MV#S^RmKP@+vF<7o%T3p6/UfeE*!=2l!`p/>V 2!bWxlfLH%%K}^|"AK"~0@~&.XXEX59,D57\\!!%.`;X_&8w1`nZe" 4\N,Kii/ss Enq[eC*n#(]CHXVybodRw"AZsal+hj@GiojxHfQ1>[hgTv1<:~Fdp'5(^1|u{B<yQqaJf,lAi53WS=*q(IB,a#_~3{D}7&,<Lh(P.'2s:\v"U~a@$9<53+m&e9a;Nd5PLhXv?S$4BW()< Gx(-1rAV<&3`p6TES<b;Q]O\>q\Ehfj|^AI i/V&&+p9CJ5F)U6>7by|q>goZ>*@Fx`7R(.tY|9:|T@6v'n/8Nbjbfs0V+'>V( +3.*l/)5,W1S:]],
	vP = function(R, r, y, T, O, J, Z)
		local B = r[13] ~= nil and 79 or 209
		return 75, r, T, O, J, Z, y
	end,
	NK = function(B, Z, J, O, T, y, r)
		local R = Z[13] ~= nil and 65 or 225
		return 164, Z, O, T, y, r, J
	end,
	gL = ":(%d+)[:\13\10]",
	pv = function(R, r, y, T, O, J, Z)
		local B = r[13] ~= nil and 102 or 233
		return 150, r, T, O, J, Z, y
	end,
	Jr = function(B, Z, J, O, T, y, r)
		local R = Z[13] ~= nil and 104 or 131
		return 109, Z, O, T, y, r, J
	end,
	rA = function(R, r, y, T, O, J, Z)
		local B = r[13]
		local o = if r[13] >= 0 then 22 else 191
		r[13] = R:wY(R:Aa(B, 31) + (R[2][12] + R[104][32]))
		return 5, r, T, O, J, Z, y
	end,
	[87] = rawget,
	[25] = string.gsub,
	te = function(o, B, Z, J, O, T, y)
		local r = B[13] ~= nil and 89 or 202
		return 95, B, J, O, T, y, Z
	end,
	xN = function(r, y, T, O, J, Z, B)
		local o = y[13] ~= nil and 65 or 121
		return 115, y, O, J, Z, B, T
	end,
	[27] = type,
	[29] = table.insert,
	[114] = coroutine.isyieldable,
	ID = function(o, B, Z, J, O, T, y)
		local r = B[13] ~= nil and 78 or 231
		return 121, B, J, O, T, y, Z
	end,
	fY = function(r, y, T, O, J, Z, B)
		local o = y[13]
		local R = if y[13] >= 0 then 104 else 180
		y[13] = r:wY(r:Aa(o, 31) + (r[2][24] + r[104][47]))
		return 22, y, O, J, Z, B, T
	end,
	wY = function(R, o)
		return o % 4294967296
	end,
	[39] = bit32.bor,
	um = function(o, R, B, Z, J, O, T)
		local y = R[13] ~= nil and 59 or 179
		return 79, R, Z, J, O, T, B
	end,
	yK = function(y, T, O, J, Z, B, R)
		local o = (y[31] + y[121]) % 4294967296
		local r = (y[23] - y[48]) % 4294967296
		local m = {}
		local I = 234
		local i = y[98](y)
		local L = (i % 256 + bit32.extract(i, 8, 8) + bit32.extract(i, 16, 8) + bit32.extract(i, 24, 4)) % 256
		local N = 1
		local f = y[12]
		local K = 54
		while K <= 90 do
			local F = (K - 1) * 5 + 1
			local c, x, t, l, X = y[36](f, F, F + 4)
			local j = (
				((((c - 33) * 94 + x - 33) * 94 + t - 33) * 94 + l - 33) * 94
				+ X
				- 33
				- (o + I * r) % 4294967296
			) % 4294967296
			I += 1
			m[#m + 1] = y[81](
				bit32.bxor(j % 256, (L + N) % 256),
				bit32.bxor(bit32.extract(j, 8, 8), (L + N + 1) % 256),
				bit32.bxor(bit32.extract(j, 16, 8), (L + N + 2) % 256),
				bit32.bxor(bit32.extract(j, 24, 8), (L + N + 3) % 256)
			)
			N += 4
			K += 1
		end
		local j = y[62]
		local X = 1
		while X <= 20 do
			local l = (X - 1) * 5 + 1
			local t, x, c, F, s = y[36](j, l, l + 4)
			local a = (
				((((t - 33) * 94 + x - 33) * 94 + c - 33) * 94 + F - 33) * 94
				+ s
				- 33
				- (o + I * r) % 4294967296
			) % 4294967296
			I += 1
			m[#m + 1] = y[81](
				bit32.bxor(a % 256, (L + N) % 256),
				bit32.bxor(bit32.extract(a, 8, 8), (L + N + 1) % 256),
				bit32.bxor(bit32.extract(a, 16, 8), (L + N + 2) % 256),
				bit32.bxor(bit32.extract(a, 24, 8), (L + N + 3) % 256)
			)
			N += 4
			X += 1
		end
		local a = T[8] ~= nil and 91 or 111
		local s = if 91 ~= 111 then 91 else 111
		T[8] = ("")["sub"](table.concat(m), 1, 228)
		return 27, T, Z, O, B, R, J
	end,
	dW = function(s, a, X, j, K, f, N)
		local L = a[13] ~= nil and 12 or 180
		return 106, a, j, K, f, N, X
	end,
	[117] = function(L, N, f, K, j, X, a)
		local s = 1580 + 643
		local i = s * 185 - 1697
		if i * i >= 0 then
			local I = i - s
		end
		local I = i + 1 - 1
		local m = 1445 + 5929
		local r = m * 60 - 3889
		if r * r >= 0 then
			local o = r - m
		end
		local o = r + 1 - 1
		local pM = function(R, B)
			local Z = 953 + 3148
			local J = Z * 39 - 2993
			if J * J >= 0 then
				local O = J - Z
			end
			local O = J + 1 - 1
			local T = 5821 + 6999
			local y = T * 348 - 8668
			if y * y >= 0 then
				local F = y - T
			end
			local F = y + 1 - 1
			local c = { R, B }
			local x = {}
			do
				local t = {
					30,
					19,
					19,
					219,
					5,
					223,
					26,
					122,
					40,
					174,
					27,
					16,
					22,
					210,
					3,
					142,
					32,
					110,
					31,
					193,
					15,
					84,
					4,
					23,
					33,
					31,
					6,
					97,
					21,
					53,
					39,
					11,
					25,
					228,
					7,
					10,
					14,
					151,
					9,
					122,
					41,
					62,
					16,
					245,
					36,
					6,
					20,
					153,
					24,
					40,
					42,
					250,
					11,
					161,
					23,
					138,
					17,
					168,
					18,
					80,
					34,
					180,
					10,
					9,
					0,
					140,
					1,
					33,
					12,
					91,
					2,
					235,
					8,
					199,
					37,
					159,
					35,
					104,
					38,
					97,
					28,
					212,
					13,
					249,
					29,
					104,
				}
				local l = 1
				while l <= #t do
					local n = t[l]
					x[n] = (
						t[l + 1]
						- (
								(function(k)
									local q = (87952462 + #t) % 268435456
									for W = 1, #k do
										q = (q * 60221 + #k[W] + W * 23371 + 200698433) % 268435456
									end
									return (69939124 + q) % 268435456
								end)(c)
								+ n
									* (function(q)
										local k = (78474915 + #t) % 268435456
										for W = 1, #q do
											k = (k * 41585 + #q[W] + W * 22639 + 243731750) % 268435456
										end
										return (140782129 + k) % 268435456
									end)(c)
							)
							% 65536
					) % 256
					l += 2
				end
			end
			local t = (function(l)
				local t = (186156228 + 0) % 268435456
				for n = 1, #l do
					t = (t * 17379 + #l[n] + n * 5983 + 223770790) % 268435456
				end
				return (207290994 + t) % 268435456
			end)(c) % 256
			local l = {}
			local n = {}
			n[17] = ("")["byte"]
			n[70] = setmetatable
			n[16] = getfenv
			n[9] = type
			local k = 9005 + 3724
			local q = k * 876 - 8162
			if q * q >= 0 then
				local W = q - k
			end
			local W = q + 1 - 1
			n[50] = tonumber
			n[18] = ("")["char"]
			n[12] = pcall
			n[60] = rawset
			n[77] = getmetatable
			n[59] = error
			n[38] = math.floor
			n[29] = select
			local z = 857 + 2949
			local H = z * 362 - 5451
			if H * H >= 0 then
				local A = H - z
			end
			local A = H + 1 - 1
			n[58] = rawget
			n[67] = unpack
			n[26] = ("")["sub"]
			local w = 6909 + 6055
			local Y = w * 408 - 8389
			if Y * Y >= 0 then
				local G = Y - w
			end
			local G = Y + 1 - 1
			local g, S, h, M, v, Q, d, P, U, e, D, p, u, wY, TE =
				n[17], n[70], n[16], n[9], n[50], n[18], n[12], n[60], n[77], n[59], n[38], n[29], n[58], n[67], n[26]
			local pT = {}
			local Ab = 9103 + 5384
			local Xc = Ab * 611 - 4390
			if Xc * Xc >= 0 then
				local SP = Xc - Ab
			end
			local SP = Xc + 1 - 1
			pT[1] = Q(110, 117, 109, 98, 101, 114)
			pT[2] = Q(95, 95, 112, 111, 119)
			pT[3] = Q(
				97,
				116,
				116,
				101,
				109,
				112,
				116,
				32,
				116,
				111,
				32,
				112,
				101,
				114,
				102,
				111,
				114,
				109,
				32,
				97,
				114,
				105,
				116,
				104,
				109,
				101,
				116,
				105,
				99,
				32,
				111,
				110,
				32,
				97,
				32
			)
			pT[4] = Q(32, 118, 97, 108, 117, 101)
			pT[5] = Q(95, 95, 115, 117, 98)
			pT[6] = Q(95, 95, 97, 100, 100)
			pT[7] = Q(115, 116, 114, 105, 110, 103)
			pT[8] = Q(95, 95, 108, 101)
			pT[9] = Q(97, 116, 116, 101, 109, 112, 116, 32, 116, 111, 32, 99, 111, 109, 112, 97, 114, 101, 32)
			pT[10] = Q(32, 119, 105, 116, 104, 32)
			pT[11] = Q(95, 95, 109, 117, 108)
			pT[12] = Q(98, 111, 111, 108, 101, 97, 110)
			pT[13] = Q(110, 105, 108)
			pT[14] = Q(95, 95, 101, 113)
			pT[15] = Q(116, 97, 98, 108, 101)
			pT[16] = Q(95, 95, 105, 110, 100, 101, 120)
			local bu = 8286 + 9923
			local xa = bu * 441 - 1635
			if xa * xa >= 0 then
				local oq = xa - bu
			end
			local oq = xa + 1 - 1
			pT[17] = Q(102, 117, 110, 99, 116, 105, 111, 110)
			pT[18] = Q(97, 116, 116, 101, 109, 112, 116, 32, 116, 111, 32, 105, 110, 100, 101, 120, 32, 97, 32)
			pT[19] = Q(95, 95, 109, 111, 100)
			pT[20] = Q(95, 95, 108, 116)
			pT[21] = Q(95, 95, 99, 111, 110, 99, 97, 116)
			pT[22] = Q(
				97,
				116,
				116,
				101,
				109,
				112,
				116,
				32,
				116,
				111,
				32,
				112,
				101,
				114,
				102,
				111,
				114,
				109,
				32,
				99,
				111,
				110,
				99,
				97,
				116,
				101,
				110,
				97,
				116,
				105,
				111,
				110,
				32,
				111,
				110,
				32,
				97,
				32
			)
			pT[23] = Q(95, 95, 117, 110, 109)
			pT[24] = Q(95, 95, 108, 101, 110)
			pT[25] = Q(95, 95, 110, 101, 119, 105, 110, 100, 101, 120)
			pT[26] = Q(95, 95, 100, 105, 118)
			pT[27] = Q(99, 104, 97, 114)
			pT[28] = Q(98, 121, 116, 101)
			pT[29] = Q()
			pT[30] = Q(112, 97, 99, 107)
			pT[31] = Q(95, 95, 99, 97, 108, 108)
			pT[32] = Q(97, 116, 116, 101, 109, 112, 116, 32, 116, 111, 32, 99, 97, 108, 108, 32, 97, 32)
			local jU = {
				145,
				193,
				50,
				198,
				51,
				62,
				221,
				76,
				138,
				32,
				95,
				150,
				225,
				51,
				255,
				111,
				114,
				115,
				82,
				153,
				227,
				25,
				150,
				199,
				181,
				189,
				158,
				177,
				139,
				222,
				34,
				24,
				11,
				114,
				151,
				159,
				68,
				163,
				190,
				224,
				167,
				86,
				242,
				165,
				128,
				202,
				199,
				214,
				54,
				28,
				23,
				134,
				145,
				77,
				99,
				228,
				95,
				191,
				42,
				143,
				92,
				38,
				72,
				84,
				52,
				32,
				141,
				67,
				45,
				77,
				242,
				182,
				145,
				243,
				238,
				31,
				195,
				14,
				36,
				148,
				172,
				82,
				249,
				57,
				84,
				251,
				250,
				63,
				47,
				110,
				139,
				251,
				17,
				64,
			}
			local wT = {}
			do
				local nP = (function(RD)
					local nP = (242568347 + #jU) % 268435456
					for qP = 1, #RD do
						nP = (nP * 32000 + #RD[qP] + qP * 8246 + 23962750) % 268435456
					end
					return (21546258 + nP) % 268435456
				end)(c)
				for RD = 1, 94 do
					nP = (
						(function(qP)
								local da = (17537952 + #jU) % 268435456
								for TA = 1, #qP do
									da = (da * 48287 + #qP[TA] + TA * 22759 + 220415671) % 268435456
								end
								return (78734678 + da) % 268435456
							end)(c)
							* nP
						+ (function(da)
							local qP = (245585370 + #jU) % 268435456
							for TA = 1, #da do
								qP = (qP * 1432 + #da[TA] + TA * 31097 + 222319427) % 268435456
							end
							return (155555989 + qP) % 268435456
						end)(c)
					) % 268435456
					wT[(jU[RD] - (nP % 256 + D(nP / 256) % 256 + D(nP / 65536) % 256 + D(nP / 16777216)) % 256) % 256] = RD
						- 1
				end
			end
			local nP = {
				105,
				37,
				216,
				72,
				220,
				90,
				12,
				128,
				237,
				25,
				57,
				150,
				9,
				140,
				65,
				106,
				100,
				240,
				255,
				75,
				92,
				83,
				173,
				66,
				69,
				41,
				48,
				144,
				253,
				129,
				192,
				181,
				211,
				17,
				85,
				145,
				182,
				39,
				235,
				35,
				146,
				59,
				68,
				110,
				21,
				0,
				146,
				103,
				85,
				64,
				244,
				173,
				133,
				117,
				131,
				155,
				204,
				59,
				56,
				104,
			}
			local RD = {}
			do
				local da = (function(qP)
					local da = (42580609 + #nP) % 268435456
					for TA = 1, #qP do
						da = (da * 65127 + #qP[TA] + TA * 11764 + 73009434) % 268435456
					end
					return (38147090 + da) % 268435456
				end)(c)
				local qP = {}
				for TA = 1, 60 do
					da = (
						(function(To)
								local vY = (217735954 + #nP) % 268435456
								for Dv = 1, #To do
									vY = (vY * 2793 + #To[Dv] + Dv * 65005 + 75565428) % 268435456
								end
								return (72744900 + vY) % 268435456
							end)(c)
							* da
						+ (function(vY)
							local To = (117806592 + #nP) % 268435456
							for Dv = 1, #vY do
								To = (To * 25869 + #vY[Dv] + Dv * 39266 + 264727391) % 268435456
							end
							return (23292573 + To) % 268435456
						end)(c)
					) % 268435456
					qP[TA] = (nP[TA] - (da % 256 + D(da / 256) % 256 + D(da / 65536) % 256 + D(da / 16777216)) % 256)
						% 256
				end
				for TA = 0, 9 do
					RD[Q(qP[TA * 5 + 1], qP[TA * 5 + 2], qP[TA * 5 + 3], qP[TA * 5 + 4], qP[TA * 5 + 5])] =
						Q(qP[50 + TA + 1])
				end
			end
			local function qP(da, TA)
				local To = 1931 + 3060
				local vY = To * 12 - 7262
				if vY * vY >= 0 then
					local Dv = vY - To
				end
				local Dv = vY + 1 - 1
				local Px = 8695 + 9064
				local Fq = Px * 287 - 8235
				if Fq * Fq >= 0 then
					local TH = Fq - Px
				end
				local TH = Fq + 1 - 1
				return g(da, TA) + g(da, TA + 1) * 256
			end
			local function TH(Fq, Px)
				local Dv = 6850 + 7887
				local vY = Dv * 352 - 5700
				if vY * vY >= 0 then
					local To = vY - Dv
				end
				local To = vY + 1 - 1
				local TA = 6913 + 9210
				local da = TA * 242 - 8675
				if da * da >= 0 then
					local pQ = da - TA
				end
				local pQ = da + 1 - 1
				local Tl = g(Fq, Px)
				if Tl < 128 then
					return Tl, Px + 1
				end
				local og = g(Fq, Px + 1)
				if og < 128 then
					return Tl - 128 + og * 128, Px + 2
				end
				local dQ = g(Fq, Px + 2)
				if dQ < 128 then
					local JN = Tl - 128 + (og - 128) * 128 + dQ * 16384
					if JN >= 2147483648 then
						JN -= 4294967296
					end
					return JN, Px + 3
				end
				local JN = g(Fq, Px + 3)
				local nL = Tl - 128 + (og - 128) * 128 + (dQ - 128) * 16384 + JN * 2097152
				if nL >= 2147483648 then
					nL -= 4294967296
				end
				return nL, Px + 4
			end
			local function nL(JN)
				local dQ = 335 + 7507
				local og = dQ * 295 - 7029
				if og * og >= 0 then
					local Tl = og - dQ
				end
				local Tl = og + 1 - 1
				local pQ = 7033 + 1480
				local da = pQ * 455 - 4372
				if da * da >= 0 then
					local TA = da - pQ
				end
				local TA = da + 1 - 1
				local To = ""
				local vY = 1
				local Dv = #JN
				local Px = 250 + 9765
				local Fq = Px * 381 - 2467
				if Fq * Fq >= 0 then
					local yY = Fq - Px
				end
				local yY = Fq + 1 - 1
				local Og = 107
				local Lb = 3387 + 8549
				local ms = Lb * 959 - 9090
				if ms * ms >= 0 then
					local CS = ms - Lb
				end
				local CS = ms + 1 - 1
				while vY <= Dv do
					if g(JN, vY) == Og then
						To = To .. (RD[TE(JN, vY, vY + 4)] or "")
						vY += 5
					else
						To = To .. TE(JN, vY, vY)
						vY += 1
					end
				end
				local vC = ""
				Dv = #To
				for dd = 1, Dv, 5 do
					local MI = 0
					MI = MI * 94 + wT[g(To, dd)]
					MI = MI * 94 + wT[g(To, dd + 1)]
					MI = MI * 94 + wT[g(To, dd + 2)]
					MI = MI * 94 + wT[g(To, dd + 3)]
					MI = MI * 94 + wT[g(To, dd + 4)]
					local ns = MI % 256
					MI = D(MI / 256)
					local AW = MI % 256
					MI = D(MI / 256)
					local cf = MI % 256
					MI = D(MI / 256)
					local uM = MI % 256
					vC = vC .. Q(ns, AW, cf, uM)
				end
				local uM = g(vC, 1) + g(vC, 2) * 256 + g(vC, 3) * 65536 + g(vC, 4) * 16777216
				return TE(vC, 5, 4 + uM)
			end
			local vC = (function(uM)
				local vC = (99515640 + 0) % 268435456
				for CS = 1, #uM do
					vC = (vC * 16544 + #uM[CS] + CS * 51003 + 18962789) % 268435456
				end
				return (194422591 + vC) % 268435456
			end)(c)
			local CS = (function(uM)
				local CS = (256336842 + 0) % 268435456
				for ms = 1, #uM do
					CS = (CS * 25401 + #uM[ms] + ms * 23458 + 218085004) % 268435456
				end
				return (245863733 + CS) % 268435456
			end)(c)
			local ms = (function(uM)
				local ms = (216420659 + 0) % 268435456
				for Lb = 1, #uM do
					ms = (ms * 34062 + #uM[Lb] + Lb * 45563 + 235513875) % 268435456
				end
				return (170745419 + ms) % 268435456
			end)(c)
			local uM = 6447 + 8132
			local Lb = uM * 59 - 3063
			if Lb * Lb >= 0 then
				local Og = Lb - uM
			end
			local Og = Lb + 1 - 1
			local Fq = (function(yY)
				local Fq = (248727954 + 0) % 268435456
				for Px = 1, #yY do
					Fq = (Fq * 8633 + #yY[Px] + Px * 63086 + 114909712) % 268435456
				end
				return (192439185 + Fq) % 268435456
			end)(c)
			local Px = (function(yY)
				local Px = (124919410 + 0) % 268435456
				for Dv = 1, #yY do
					Px = (Px * 29244 + #yY[Dv] + Dv * 7072 + 232752377) % 268435456
				end
				return (40420725 + Px) % 268435456
			end)(c)
			local Dv = (function(yY)
				local Dv = (92438076 + 0) % 268435456
				for vY = 1, #yY do
					Dv = (Dv * 35333 + #yY[vY] + vY * 14827 + 125921352) % 268435456
				end
				return (118879262 + Dv) % 268435456
			end)(c)
			local vY = (function(yY)
				local vY = (165567082 + 0) % 268435456
				for To = 1, #yY do
					vY = (vY * 55758 + #yY[To] + To * 60623 + 141028744) % 268435456
				end
				return (65135658 + vY) % 268435456
			end)(c)
			local yY = { 94, 110, 131, 217, 159, 142, 21, 94, 180, 66, 115, 142, 168, 152, 179, 36 }
			local To = 111566091827 + 1098377407999 - 1209689161470
			for TA = 1, 16 do
				To = (
					(225658556009 + 1001972365266 - 1227627659052) * To + (890561172382 + 672240927033 - 1562722553054)
				) % 268435456
				yY[TA] = (yY[TA] - (To % 256 + D(To / 256) % 256 + D(To / 65536) % 256 + D(To / 16777216)) % 256) % 256
			end
			local TA = Q(yY[1], yY[2], yY[3], yY[1], yY[4], yY[5], yY[6], yY[7])
			local da = Q(yY[8], yY[2], yY[9], yY[10], yY[3], yY[1], yY[4], yY[5], yY[6], yY[7])
			local pQ = Q(yY[10], yY[11], yY[12], yY[13], yY[7])
			local Tl = Q(yY[5], yY[6], yY[14], yY[2])
			local og = Q(yY[3])
			local dQ = Q(yY[2], yY[3])
			local JN = Q(yY[15], yY[8], yY[2], yY[15], yY[16])
			local cf = {}
			local AW
			local ns
			local MI = 4527 + 7782
			local dd = MI * 218 - 5957
			if dd * dd >= 0 then
				local DE = dd - MI
			end
			local DE = dd + 1 - 1
			local Ja = 0
			local My = {}
			local rm, gS, Zw, iR
			local NF, ug, zb, Am
			local RQ
			local cX
			local RY
			local Kg, Kj, CQ, ei, ri, jt, NC, BL, TJ, vy, Cm
			local PP
			local kS
			local jY
			local bR = 0
			local FJ, pH
			local vr
			local qX = function()
				local vG = 4530 + 3315
				local Gq = vG * 316 - 7133
				if Gq * Gq >= 0 then
					local CM = Gq - vG
				end
				local CM = Gq + 1 - 1
				local Lw = 1123 + 206
				local Vz = Lw * 17 - 6546
				if Vz * Vz >= 0 then
					local qV = Vz - Lw
				end
				local qV = Vz + 1 - 1
				local fA, qX = 0, 1
				while fA < 4294967296 do
					fA = (fA * 1103515245 + 12345) % 268435456
					qX = (qX * 80659 + 95050511) % 268435456
					if fA == qX and fA == 123456789 then
						break
					end
				end
			end
			local fA
			local qV
			local Vz
			local Lw, CM
			local Gq
			AW = function(
				vG,
				zl,
				nn,
				sl,
				mn,
				Mk,
				TD,
				ml,
				nH,
				Gz,
				wW,
				io,
				wj,
				aT,
				xQ,
				bv,
				Hj,
				nx,
				oO,
				kg,
				Pp,
				Yj,
				eG,
				Pe,
				tV
			)
				local HF, Ie, dT, iW, mo, RW, GM, VD, fp, qI, br, cw, wi, LB, AV, OR, qt, Ew, Qb, rH, an, FA, qs, Dh, Xj =
					Hj, oO, vG, nn, Gz, TD, nx, wj, sl, kg, eG, zl, xQ, io, Yj, nH, Mk, aT, mn, wW, Pe, bv, Pp, tV, ml
				local Tz = (function()
					local Dl = qI and qI[dT(116, 121, 112, 101)] or type
					local je = qI and qI[dT(112, 99, 97, 108, 108)] or pcall
					local tw = qI and qI[dT(120, 112, 99, 97, 108, 108)] or xpcall
					local tM = qI and qI[dT(101, 114, 114, 111, 114)] or error
					local mv = qI and qI[dT(114, 97, 119, 103, 101, 116)] or rawget
					local lF = qI and qI[dT(114, 97, 119, 115, 101, 116)] or rawset
					local hl = qI and qI[dT(103, 101, 116, 109, 101, 116, 97, 116, 97, 98, 108, 101)] or getmetatable
					local BF = qI and qI[dT(115, 101, 116, 109, 101, 116, 97, 116, 97, 98, 108, 101)] or setmetatable
					local yo = qI and qI[dT(116, 111, 115, 116, 114, 105, 110, 103)] or tostring
					local eB = qI and qI[dT(116, 111, 110, 117, 109, 98, 101, 114)] or tonumber
					local pj = qI
							and qI[dT(115, 116, 114, 105, 110, 103)]
							and qI[dT(115, 116, 114, 105, 110, 103)][dT(103, 109, 97, 116, 99, 104)]
						or _G[dT(115, 116, 114, 105, 110, 103)]
							and _G[dT(115, 116, 114, 105, 110, 103)][dT(103, 109, 97, 116, 99, 104)]
					local iX = qI and qI[dT(117, 110, 112, 97, 99, 107)]
						or _G[dT(117, 110, 112, 97, 99, 107)]
						or _G[dT(116, 97, 98, 108, 101)] and _G[dT(116, 97, 98, 108, 101)][dT(117, 110, 112, 97, 99, 107)]
					local JA = qI and qI[dT(112, 114, 105, 110, 116)] or print
					local dD = qI and qI[dT(119, 97, 114, 110)] or _G and _G[dT(119, 97, 114, 110)]
					local Tn = qI[dT(110, 101, 119, 112, 114, 111, 120, 121)]
					local iC = qI and qI[dT(100, 101, 98, 117, 103)] and qI[dT(100, 101, 98, 117, 103)][dT(
						105,
						110,
						102,
						111
					)] or _G[dT(100, 101, 98, 117, 103)] and _G[dT(100, 101, 98, 117, 103)][dT(105, 110, 102, 111)]
					local jJ = false
					local function Hl()
						local tN = 0
						local EA
						repeat
							tN += 1
						until tN == EA
						return (nil)[1]
					end
					local function EA()
						jJ = true
						Hl()
					end
					local tN = {}
					local gb
					local function xB()
						local kc = qI and qI[dT(103, 101, 116, 102, 101, 110, 118)] or getfenv
						if Dl(kc) == dT(102, 117, 110, 99, 116, 105, 111, 110) then
							local IF, Hz = je(kc)
							if IF then
								gb = Hz
							end
						end
						if gb == nil then
							gb = qI and qI[dT(95, 71)] or _G
						end
						if
							Dl(gb) ~= dT(116, 97, 98, 108, 101)
							or Dl(JA) ~= dT(102, 117, 110, 99, 116, 105, 111, 110)
							or dD ~= nil and Dl(dD) ~= dT(102, 117, 110, 99, 116, 105, 111, 110)
						then
							jJ = true
						end
						local Hz = {}
						local IF = function() end
						local oG = je(lF, Hz, -271823, IF)
						if not oG or mv(Hz, -271823) ~= IF then
							jJ = true
						end
						lF(Hz, -271823, nil)
						if mv(Hz, -271823) ~= nil or je(tM) then
							jJ = true
						end
					end
					local function oG()
						if Dl(iX) == dT(102, 117, 110, 99, 116, 105, 111, 110) then
							local IF = je(iX, {}, 0, 64)
							if not IF then
								jJ = true
							end
						end
						if Dl(gb) == dT(116, 97, 98, 108, 101) then
							if Dl(JA) == dT(102, 117, 110, 99, 116, 105, 111, 110) and gb.print ~= JA then
								jJ = true
							end
							if Dl(dD) == dT(102, 117, 110, 99, 116, 105, 111, 110) and gb.warn ~= dD then
								jJ = true
							end
						end
					end
					local function IF()
						if
							Dl(Dl) ~= dT(102, 117, 110, 99, 116, 105, 111, 110)
							or Dl(je) ~= dT(102, 117, 110, 99, 116, 105, 111, 110)
							or Dl(tw) ~= dT(102, 117, 110, 99, 116, 105, 111, 110)
							or Dl(tM) ~= dT(102, 117, 110, 99, 116, 105, 111, 110)
							or Dl(mv) ~= dT(102, 117, 110, 99, 116, 105, 111, 110)
							or Dl(lF) ~= dT(102, 117, 110, 99, 116, 105, 111, 110)
							or Dl(hl) ~= dT(102, 117, 110, 99, 116, 105, 111, 110)
							or Dl(BF) ~= dT(102, 117, 110, 99, 116, 105, 111, 110)
						then
							Hl()
						end
					end
					local function Hz()
						if Dl(Tn) == dT(102, 117, 110, 99, 116, 105, 111, 110) then
							local kc, Tz = je(Tn, true)
							if not kc or Tz == nil then
								jJ = true
							else
								local zw, pv = je(hl, Tz)
								if not zw or Dl(pv) ~= dT(116, 97, 98, 108, 101) then
									jJ = true
								else
									pv[dT(95, 95, 116, 111, 115, 116, 114, 105, 110, 103)] = EA
									pv[dT(95, 95, 99, 111, 110, 99, 97, 116)] = EA
									pv[dT(95, 95, 99, 97, 108, 108)] = EA
									tN[#tN + 1] = Tz
								end
							end
						end
						local function Tz(kc)
							local pv = {}
							local zw = {
								[dT(95, 95, 109, 101, 116, 97, 116, 97, 98, 108, 101)] = kc,
								[dT(95, 95, 116, 111, 115, 116, 114, 105, 110, 103)] = EA,
								[dT(95, 95, 99, 111, 110, 99, 97, 116)] = EA,
								[dT(95, 95, 105, 116, 101, 114)] = EA,
							}
							local YP, lr = je(BF, pv, zw)
							if not YP or lr ~= pv then
								jJ = true
								return
							end
							local QZ, KA = je(hl, pv)
							if not QZ or KA ~= kc then
								jJ = true
							end
							tN[#tN + 1] = pv
						end
						Tz(dT(116, 100, 100, 120, 104, 112, 102, 99, 112, 105))
						Tz(dT(108, 115, 112, 104, 104, 102, 115, 116, 100, 109))
						Tz(dT(118, 121, 109, 103, 103, 108, 107, 104, 113, 114))
					end
					local function Tz()
						local function KA()
							return (nil)[1]
						end
						if
							Dl(iC) == dT(102, 117, 110, 99, 116, 105, 111, 110)
							and Dl(pj) == dT(102, 117, 110, 99, 116, 105, 111, 110)
							and Dl(yo) == dT(102, 117, 110, 99, 116, 105, 111, 110)
							and Dl(eB) == dT(102, 117, 110, 99, 116, 105, 111, 110)
						then
							local QZ, lr = je(iC, KA, dT(108))
							local YP, zw = je(iC, KA, dT(115))
							local pv
							local kc = tw(KA, function(kc)
								for iE in pj(yo(kc), dT(58, 40, 37, 100, 43, 41, 58)) do
									pv = eB(iE)
								end
								return kc
							end)
							if
								kc
								or not QZ
								or Dl(lr) ~= dT(110, 117, 109, 98, 101, 114)
								or not YP
								or Dl(zw) ~= dT(115, 116, 114, 105, 110, 103)
								or zw == dT(91, 67, 93)
								or Dl(pv) ~= dT(110, 117, 109, 98, 101, 114)
								or lr ~= pv
							then
								jJ = true
							end
							local iE, dr = je(iC, tM, dT(115))
							if iE and Dl(dr) == dT(115, 116, 114, 105, 110, 103) and dr ~= dT(91, 67, 93) then
								jJ = true
							end
						end
						if Dl(iC) == dT(102, 117, 110, 99, 116, 105, 111, 110) then
							local function dr(iE)
								if Dl(iE) ~= dT(102, 117, 110, 99, 116, 105, 111, 110) then
									return false
								end
								local kc, pv = je(iC, iE, dT(115))
								return kc and Dl(pv) == dT(115, 116, 114, 105, 110, 103) and pv == dT(91, 67, 93)
							end
							local pv = qI and qI[dT(95, 71)] or _G
							if Dl(pv) == dT(116, 97, 98, 108, 101) then
								local kc = mv(pv, dT(108, 111, 97, 100, 115, 116, 114, 105, 110, 103))
								local iE = mv(pv, dT(108, 111, 97, 100))
								if Dl(kc) == dT(102, 117, 110, 99, 116, 105, 111, 110) and not dr(kc) then
									jJ = true
								end
								if Dl(iE) == dT(102, 117, 110, 99, 116, 105, 111, 110) and not dr(iE) then
									jJ = true
								end
							end
						end
					end
					xB()
					oG()
					IF()
					Hz()
					Tz()
					if jJ then
						Hl()
					end
					return tN
				end)()
				local Hz, IF, oG, xB, gb, tN, EA, Hl = Dh(Xj)
				local jJ = Hl
				local iC = Hl * 257
				local Tn = { 48, 10, 85 }
				local dD = 0
				dD = (dD * 257 + 224) % 268435456
				dD = (dD * 257 + 49) % 268435456
				for JA = 1, #Tn do
					dD = (dD * 257 + Tn[JA]) % 268435456
				end
				local iX = (
					dD
					- (function(JA)
						local iX = (14433758 + 0) % 268435456
						for pj = 1, #JA do
							iX = (iX * 34770 + #JA[pj] + pj * 22589 + 220806677) % 268435456
						end
						return (173554322 + iX) % 268435456
					end)(br)
				) % 268435456
				jJ = (jJ + iX) % 268435456
				iC = (iC + iX * (224 + 1)) % 268435456
				local JA, pj, eB, yo
				local BF = 0
				local hl = 1
				while hl <= #Tn do
					local lF = (Tn[hl] - (224 + hl * 49) % 256) % 256
					if lF == 226 then
						BF = 1
					elseif 200 == lF then
						pj, eB, yo = JA(br, cw, Hz, IF, oG, xB, (gb + jJ) % 268435456, tN)
					elseif 31 == lF then
						JA = EA(Ie, dT, iW, mo, HF, wi, LB, AV, OR, qt, Ew, Qb, rH, an, FA, qs)
					else
						jJ = (
							jJ
							+ (function(mv)
								local tM = (60936731 + 0) % 268435456
								for tw = 1, #mv do
									tM = (tM * 56108 + #mv[tw] + tw * 6090 + 100682378) % 268435456
								end
								return (94260048 + tM) % 268435456
							end)(br)
						) % 268435456
						iC = (
							iC
							+ (function(tM)
									local mv = (60936731 + 0) % 268435456
									for tw = 1, #tM do
										mv = (mv * 56108 + #tM[tw] + tw * 6090 + 100682378) % 268435456
									end
									return (94260048 + mv) % 268435456
								end)(br)
								* (224 + 1)
						) % 268435456
					end
					hl += 1
				end
				if BF ~= 1 then
					jJ = (
						jJ
						+ (function(lF)
							local mv = (60936731 + 0) % 268435456
							for tM = 1, #lF do
								mv = (mv * 56108 + #lF[tM] + tM * 6090 + 100682378) % 268435456
							end
							return (94260048 + mv) % 268435456
						end)(br)
					) % 268435456
					iC = (
						iC
						+ (function(mv)
								local lF = (60936731 + 0) % 268435456
								for tM = 1, #mv do
									lF = (lF * 56108 + #mv[tM] + tM * 6090 + 100682378) % 268435456
								end
								return (94260048 + lF) % 268435456
							end)(br)
							* (49 + 1)
					) % 268435456
				end
				Tn = nil
				local lF = {}
				local tM = (
					(function(mv)
						local tM = (208161179 + 0) % 268435456
						for tw = 1, #mv do
							tM = (tM * 17846 + #mv[tw] + tw * 34797 + 201388635) % 268435456
						end
						return (160089339 + tM) % 268435456
					end)(br) + jJ
				) % 67108859
				local tw = (
					(function(mv)
						local tw = (109201027 + 0) % 268435456
						for je = 1, #mv do
							tw = (tw * 59642 + #mv[je] + je * 46435 + 87621929) % 268435456
						end
						return (156092502 + tw) % 268435456
					end)(br) + iC
				) % 67108819
				local mv, je, Dl, KA, pv, dr, iE = lF, pj, eB, tM, tw, yo, Tz
				lF, pj, eB, tM, tw, yo, Tz = nil, nil, nil, nil, nil, nil, nil
				return function()
					return mv, je, Dl, KA, pv, dr, iE
				end
			end
			cX = function()
				local iE = {
					204,
					251,
					10,
					222,
					164,
					104,
					65,
					7,
					23,
					183,
					9,
					87,
					187,
					254,
					96,
					101,
					135,
					160,
					213,
					243,
					186,
					201,
					89,
					97,
					78,
					184,
					58,
					225,
					110,
					79,
					32,
					64,
					70,
					92,
					123,
					148,
					174,
					198,
					217,
					226,
					181,
					241,
					75,
					226,
					138,
					28,
					173,
					85,
					219,
					135,
					13,
					167,
					74,
					220,
					224,
					0,
					183,
					33,
					148,
					246,
					105,
					226,
					120,
					126,
					125,
					31,
					213,
					148,
					66,
					24,
					53,
					23,
					25,
					61,
					118,
					161,
					209,
					20,
					114,
					164,
					103,
					51,
					252,
					194,
					129,
					78,
					15,
					51,
					224,
					239,
					96,
					171,
					208,
					163,
					118,
					54,
					17,
					225,
					58,
					118,
					168,
					222,
					28,
					75,
					119,
					177,
					245,
					81,
					10,
					99,
					68,
					16,
					58,
					144,
					227,
					47,
					137,
					215,
					185,
					201,
					42,
					140,
					192,
					4,
					191,
					36,
					25,
					60,
					112,
					131,
					71,
					228,
					164,
					56,
					237,
					150,
					248,
					215,
					72,
					224,
					94,
					210,
					99,
					245,
					30,
					25,
					241,
					3,
					9,
					39,
					63,
					245,
					227,
					38,
					52,
					175,
					233,
					249,
					245,
					30,
					66,
					93,
					103,
					120,
					145,
					149,
					210,
					103,
					118,
					221,
					244,
					112,
					219,
					68,
					191,
					52,
					170,
					30,
					141,
					242,
					28,
					163,
					103,
					40,
					230,
					167,
					141,
					140,
					24,
					147,
					33,
					153,
					25,
					87,
					250,
					67,
					141,
					211,
					29,
					82,
					74,
					110,
					58,
					163,
					20,
					150,
					10,
					120,
					241,
					79,
					205,
					73,
					172,
					45,
					121,
					128,
					172,
					93,
					119,
					40,
					245,
					180,
					111,
					41,
					153,
					14,
					60,
					228,
					120,
					52,
					167,
					254,
					75,
					93,
					187,
					66,
					188,
					44,
					165,
					51,
					69,
					195,
					97,
					240,
					79,
					225,
					110,
					242,
					101,
					223,
					97,
					149,
					195,
					10,
					46,
					247,
					45,
					127,
					195,
					3,
					66,
					55,
					131,
					51,
					42,
					36,
					8,
					200,
					234,
					4,
					31,
					68,
					89,
					116,
					156,
					185,
					207,
					249,
					189,
					126,
					204,
					43,
					119,
					201,
					22,
					107,
					182,
					10,
					254,
					41,
					92,
					121,
					146,
					199,
					224,
					10,
					45,
					117,
					55,
					113,
					132,
					176,
					217,
					251,
					43,
					79,
					250,
					191,
					72,
					245,
					0,
					44,
					43,
					48,
					61,
					71,
					64,
					65,
					88,
					72,
					95,
					80,
					82,
					104,
					107,
					106,
					113,
					108,
					245,
					27,
					196,
					47,
					140,
					231,
					217,
					199,
					40,
					51,
					92,
					136,
					178,
					189,
					57,
					223,
					215,
					74,
					211,
					119,
					240,
					97,
					65,
					108,
					190,
					232,
					48,
					112,
					152,
					223,
					170,
					129,
					218,
					201,
					76,
					207,
					80,
					223,
					231,
					70,
					13,
					183,
					204,
					208,
					229,
					6,
					25,
					41,
					50,
					73,
					84,
					84,
					88,
					74,
					48,
					49,
					23,
					8,
					15,
					240,
					202,
					58,
					198,
					70,
					235,
					113,
					126,
					2,
					143,
					46,
					185,
					159,
					95,
					74,
					65,
					41,
					14,
					1,
					254,
					138,
					33,
					163,
					87,
					127,
					170,
					217,
					253,
					72,
					109,
					160,
					228,
					173,
					155,
					229,
					141,
					122,
					132,
					128,
					118,
					119,
					93,
					99,
					103,
					82,
					213,
					240,
					141,
					51,
					235,
					136,
					106,
					244,
					165,
					150,
					103,
					52,
					237,
					198,
					135,
					85,
					238,
					102,
					143,
					211,
					98,
					45,
					134,
					149,
					229,
					21,
					51,
					103,
					156,
					105,
					115,
					234,
					63,
					165,
					235,
					78,
					164,
					0,
					88,
					156,
					0,
					93,
					179,
					238,
					21,
					105,
					1,
					108,
					222,
					97,
					202,
					67,
					175,
					44,
					85,
					28,
					230,
					141,
					35,
					53,
					151,
					20,
					107,
					214,
					74,
					184,
					39,
					148,
					252,
					90,
					2,
					78,
					162,
					237,
					82,
					174,
					232,
					29,
					101,
					166,
					252,
					43,
					114,
					193,
					43,
					9,
					125,
					198,
					241,
					79,
					193,
					60,
					166,
					105,
					50,
					13,
					228,
					120,
					29,
					165,
					58,
					217,
					119,
					40,
					136,
					169,
					16,
					42,
					140,
					186,
					5,
					62,
					82,
					158,
					227,
					20,
					107,
					4,
					40,
					87,
					147,
					196,
					154,
					99,
					211,
					9,
					100,
					220,
					79,
					142,
					218,
					97,
					121,
					20,
					47,
					152,
					18,
					110,
					31,
					23,
					10,
					61,
					189,
					78,
					204,
					80,
					207,
					86,
					211,
					177,
					219,
					89,
					244,
					121,
					253,
					152,
					17,
					176,
					41,
					182,
					76,
					209,
					18,
					79,
					218,
					237,
					185,
					120,
					72,
					1,
					11,
					215,
					192,
					42,
					221,
					161,
					73,
					252,
					186,
					119,
					217,
					16,
					118,
					251,
					97,
					108,
					120,
					8,
				}
				local dr = {
					[1857113302] = { 521, 5, 12, 113 },
					[663541585] = { 138, 6, 227, 130 },
					[1848702529] = { 242, 10, 252, 128 },
					[199520174] = { 93, 6, 153, 206 },
					[374742625] = { 256, 8, 66, 67 },
					[143451626] = { 346, 3, 74, 146 },
					[1264191606] = { 65, 5, 84, 181 },
					[1552716263] = { 100, 8, 203, 55 },
					[1177422361] = { 402, 6, 236, 240 },
					[1999435623] = { 464, 12, 44, 87 },
					[2057968326] = { 434, 5, 223, 165 },
					[1317319746] = { 130, 7, 139, 168 },
					[331694728] = { 290, 8, 159, 36 },
					[1611647199] = { 113, 6, 114, 85 },
					[2120484867] = { 423, 10, 31, 251 },
					[824337752] = { 156, 10, 70, 23 },
					[175413298] = { 188, 7, 185, 125 },
					[1292572797] = { 268, 11, 72, 29 },
					[1504285794] = { 409, 3, 44, 154 },
					[1963027132] = { 3, 6, 199, 207 },
					[695898882] = { 390, 5, 56, 143 },
					[762677727] = { 219, 7, 71, 190 },
					[789186256] = { 557, 14, 35, 89 },
					[41008819] = { 351, 8, 147, 60 },
					[1519447095] = { 122, 3, 248, 51 },
					[409328589] = { 507, 10, 174, 67 },
					[1896288677] = { 31, 10, 161, 22 },
					[2105095196] = { 614, 4, 49, 114 },
					[2063172961] = { 583, 12, 220, 140 },
					[1372314137] = { 454, 8, 181, 47 },
					[785423887] = { 480, 7, 145, 116 },
					[413497413] = { 550, 5, 99, 49 },
					[161414251] = { 606, 7, 14, 181 },
					[261621004] = { 147, 4, 129, 13 },
					[235993862] = { 73, 6, 116, 50 },
					[1724889003] = { 301, 6, 230, 43 },
					[822827564] = { 574, 8, 84, 130 },
					[332136910] = { 337, 4, 144, 33 },
					[888077951] = { 396, 4, 8, 147 },
					[1391455446] = { 17, 4, 247, 34 },
					[2071893755] = { 362, 5, 227, 130 },
					[1364131418] = { 280, 9, 199, 80 },
					[48363945] = { 529, 7, 231, 150 },
					[1942269852] = { 414, 6, 50, 53 },
					[587586232] = { 441, 8, 144, 204 },
					[670140512] = { 370, 10, 57, 18 },
					[73726565] = { 10, 5, 2, 81 },
					[1469937604] = { 198, 3, 24, 72 },
					[1394486408] = { 171, 10, 25, 114 },
					[1243419374] = { 80, 8, 104, 200 },
					[742903341] = { 204, 11, 201, 115 },
					[622639710] = { 182, 5, 127, 190 },
					[1421249581] = { 540, 9, 174, 57 },
					[309064376] = { 381, 8, 239, 244 },
					[71606856] = { 492, 11, 92, 107 },
					[258784285] = { 598, 4, 189, 199 },
					[1104904612] = { 235, 6, 221, 123 },
					[860624040] = { 331, 4, 234, 102 },
					[1444789688] = { 57, 6, 209, 113 },
					[1011817981] = { 230, 4, 118, 92 },
					[1523554301] = { 43, 12, 75, 153 },
					[1008672087] = { 312, 16, 191, 4 },
					[586479505] = { 26, 4, 175, 149 },
				}
				local pv = {}
				local KA
				local Dl = ""
				do
					local function je(mv)
						local tw = coroutine.wrap(function()
							return mv(65)
						end)
						local tM, lF = pcall(tw)
						if not tM or lF ~= "A" then
							return "65:" .. tostring(lF)
						end
						local hl = coroutine.wrap(function()
							return mv(90)
						end)
						local BF, yo = pcall(hl)
						if not BF or yo ~= "Z" then
							return "90:" .. tostring(yo)
						end
						local eB = coroutine.wrap(function()
							return mv(48)
						end)
						local pj, JA = pcall(eB)
						if not pj or JA ~= "0" then
							return "48:" .. tostring(JA)
						end
						local iX = coroutine.wrap(function()
							return mv(95)
						end)
						local dD, Tn = pcall(iX)
						if not dD or Tn ~= "_" then
							return "95:" .. tostring(Tn)
						end
						return nil
					end
					local function Tn(dD)
						for iX, JA in pairs(dD) do
							if type(JA) == "function" then
								local pj = je(JA)
								if pj == nil then
									return JA
								end
							end
						end
						return nil
					end
					local dD, JA = pcall(getmetatable, "")
					Dl = "M=" .. tostring(dD) .. "/" .. type(JA)
					if dD and type(JA) == "table" then
						local iX, eB = pcall(function()
							local iX = Tn(JA)
							if not iX then
								for pj, eB in pairs(JA) do
									if type(eB) == "table" then
										iX = Tn(eB)
										if iX then
											break
										end
									end
								end
							end
							return iX
						end)
						if iX then
							KA = eB
						end
					end
					if not KA then
						local eB, iX = pcall(getfenv, 0)
						if eB and type(iX) == "table" then
							local yo, pj = pcall(function()
								for pj, yo in pairs(iX) do
									if type(yo) == "table" then
										local BF = Tn(yo)
										if BF then
											return BF
										end
									end
								end
								return nil
							end)
							if yo then
								KA = pj
							end
						end
					end
					if not KA then
						local iX, eB = pcall(function()
							return ("\0")["char"]
						end)
						if iX and type(eB) == "function" then
							local pj = je(eB)
							if pj == nil then
								KA = eB
							else
								Dl = Dl .. ";L=" .. pj
							end
						else
							Dl = Dl .. ";L=" .. tostring(iX) .. "/" .. type(eB)
						end
					end
				end
				if not KA then
					return {
						0,
						function()
							return 0
						end,
					}
				end
				local JA, dD, Tn = pcall, type, rawget
				local function je(eB, iX)
					local pj = dD(eB)
					local yo = nil
					if pj == "table" then
						local BF, hl = JA(Tn, eB, iX)
						if BF then
							yo = hl
						end
					end
					if yo ~= nil then
						return yo
					end
					local hl, BF = JA(function()
						return eB[iX]
					end)
					if hl then
						return BF
					end
					return nil
				end
				local function BF(hl)
					local yo = pv[hl]
					if yo then
						return yo
					end
					local pj = dr[hl]
					if not pj then
						return nil
					end
					local iX = ""
					for eB = 1, pj[2] do
						iX = iX .. KA((iE[pj[1] + eB - 1] - pj[3] - eB * pj[4]) % 256)
					end
					pv[hl] = iX
					return iX
				end
				local iX, pj = pcall(getfenv, 0)
				if not iX or type(pj) ~= "table" then
					pj = nil
				end
				local function yo(hl, eB)
					if type(hl) ~= "table" then
						return nil
					end
					local lF = rawget(hl, eB)
					if lF ~= nil then
						return lF
					end
					local tM, tw = pcall(function()
						return hl[eB]
					end)
					if tM then
						return tw
					end
					return nil
				end
				local tw = yo(pj, BF(161414251))
				local tM, lF = false, nil
				if type(tw) == "function" then
					tM, lF = pcall(tw)
				end
				if not tM or type(lF) ~= "table" then
					lF = nil
				end
				local function eB(hl)
					local mv = yo(lF, hl)
					if mv == nil then
						mv = yo(pj, hl)
					end
					return mv
				end
				local mv = yo(pj, BF(1724889003))
				local hl = yo(pj, BF(1264191606))
				local iC = yo(pj, BF(2105095196))
				local jJ = eB(BF(73726565))
				local Hl = eB(BF(413497413))
				local EA = eB(BF(860624040))
				local tN = eB(BF(1942269852))
				local gb = eB(BF(663541585))
				local xB = eB(BF(41008819))
				local oG = eB(BF(1391455446))
				local IF = eB(BF(235993862))
				local Hz = eB(BF(1552716263))
				local Tz = eB(BF(1243419374))
				local Xj = eB(BF(2063172961))
				local Dh = eB(BF(1523554301))
				local qs = eB(BF(1444789688))
				local FA = iC and yo(iC, BF(622639710))
				local an = iC and yo(iC, BF(1519447095))
				local rH = iC and yo(iC, BF(2057968326))
				local Qb = mv and yo(mv, BF(1011817981))
				local Ew = mv and yo(mv, BF(261621004))
				local qt = mv and yo(mv, BF(1469937604))
				local OR = hl and yo(hl, BF(1104904612))
				local AV = hl and yo(hl, BF(199520174))
				local LB = hl and yo(hl, BF(1444789688))
				local wi = eB(BF(1008672087))
				local cw = eB(BF(1292572797))
				local br = eB(BF(1896288677))
				local qI = eB(BF(1394486408))
				local fp = eB(BF(71606856))
				local VD = eB(BF(670140512))
				local GM = eB(BF(1963027132))
				local RW = eB(BF(888077951))
				local mo = eB(BF(587586232))
				local iW = eB(BF(175413298))
				local dT = eB(BF(586479505))
				local Ie = jJ and yo(jJ, BF(785423887))
				local HF = jJ and yo(jJ, BF(258784285))
				local tV = jJ and yo(jJ, BF(1999435623))
				local Pe = jJ and yo(jJ, BF(742903341))
				local eG = jJ and yo(jJ, BF(822827564))
				local Yj = jJ and yo(jJ, BF(1364131418))
				local Pp = jJ and yo(jJ, BF(2120484867))
				local kg = EA and EA(HF) == "function" and HF or Ie
				local oO = BF(762677727)
				JA, dD, Tn = Hl, EA, tN
				do
					local nx = ""
					local function Hj(bv, xQ)
						if EA(xQ) ~= "function" then
							nx = nx .. bv .. ","
						end
					end
					Hj("identifyexecutor", wi)
					Hj("checkcaller", cw)
					Hj("iscclosure", br)
					Hj("islclosure", qI)
					Hj("newcclosure", fp)
					Hj("loadstring", VD)
					Hj("typeof", GM)
					if EA(Ie) ~= "function" and EA(HF) ~= "function" then
						nx = nx .. "debug.info,"
					end
					Hj("debug.getconstants", tV)
					Hj("debug.getupvalues", Pe)
					if EA(eG) ~= "function" and EA(Yj) ~= "function" then
						nx = nx .. "debug.getproto,"
					end
					Hj("debug.setupvalue", Pp)
					if EA(RW) ~= "table" and EA(RW) ~= "userdata" then
						nx = nx .. "game,"
					end
					if EA(mo) ~= "table" then
						nx = nx .. "Instance,"
					end
					if EA(iW) ~= "table" then
						nx = nx .. "Vector3,"
					end
					if EA(dT) ~= "table" then
						nx = nx .. "task,"
					end
					if nx ~= "" then
						error(
							"[Obsucvim] this executor lacks APIs the hardened build requires: "
								.. nx
								.. " - use the compatible build (--no-bind-executor) here, or a Synapse-class executor",
							0
						)
					end
				end
				local Hj = 0
				local nx = 1
				local xQ = 0
				local bv = 647146562 % 2147483647
				local aT = 0
				local wj = (bv * 65599 + 1223746293 + aT) % 2147483647
				local io = (bv * 4099 + 1114565040 + aT % 104729) % 2147483647
				local wW = (bv * 8191 + 261237549 + aT % 65521 * 131) % 2147483647
				local Gz = false
				local nH = false
				local ml = 767297166
				local TD = 0
				local Mk = 0
				local mn = false
				local sl = 123974875
				local nn = -1
				local zl = -1
				local vG = -1
				local kc = 767297166
				local function zw()
					Gz = true
					aT = 0
					ml = kc
				end
				local function YP(lr, QZ)
					lr %= 2147483648
					QZ %= 2147483648
					local Mo = 0
					local Nm = 1
					for vc = 0, 30 do
						local pM = lr % 2
						local za = QZ % 2
						if pM ~= za then
							Mo += Nm
						end
						lr = (lr - pM) / 2
						QZ = (QZ - za) / 2
						Nm *= 2
					end
					return Mo
				end
				local function Nm()
					local Mo = TD % 65536
					local QZ = (TD - Mo) / 65536
					return (Mo * 65599 + QZ * 257 + bv * 4099 + wj + io + wW + aT + 841231973) % 2147483647
				end
				local function QZ()
					wj = (bv * 65599 + 1223746293 + aT) % 2147483647
					io = (bv * 4099 + 1114565040 + aT % 104729) % 2147483647
					wW = (bv * 8191 + 261237549 + aT % 65521 * 131) % 2147483647
				end
				local function Mo()
					if EA == nil then
						return false
					end
					if
						yo(pj, BF(1724889003)) ~= mv
						or yo(pj, BF(1264191606)) ~= hl
						or yo(pj, BF(2105095196)) ~= iC
						or yo(pj, BF(73726565)) ~= jJ and yo(lF, BF(73726565)) ~= jJ
						or yo(pj, BF(413497413)) ~= Hl
						or yo(pj, BF(860624040)) ~= EA
						or yo(pj, BF(1942269852)) ~= tN
						or yo(pj, BF(663541585)) ~= gb
						or yo(pj, BF(1391455446)) ~= oG
						or yo(pj, BF(1523554301)) ~= Dh
						or yo(pj, BF(2063172961)) ~= Xj
						or yo(pj, BF(41008819)) ~= xB
						or yo(pj, BF(1243419374)) ~= Tz
						or yo(pj, BF(235993862)) ~= IF
						or yo(pj, BF(1552716263)) ~= Hz
						or yo(mv, BF(1011817981)) ~= Qb
						or yo(mv, BF(261621004)) ~= Ew
						or yo(mv, BF(1469937604)) ~= qt
						or yo(hl, BF(1104904612)) ~= OR
						or yo(hl, BF(199520174)) ~= AV
						or yo(iC, BF(2057968326)) ~= rH
					then
						return false
					end
					if not pj or EA(tw) ~= "function" or yo(pj, BF(161414251)) ~= tw then
						return false
					end
					local lr, za = Hl(tw)
					if not lr or za ~= lF then
						return false
					end
					if
						eB(BF(1008672087)) ~= wi
						or eB(BF(1292572797)) ~= cw
						or eB(BF(1896288677)) ~= br
						or eB(BF(1394486408)) ~= qI
						or eB(BF(71606856)) ~= fp
						or eB(BF(670140512)) ~= VD
						or eB(BF(1963027132)) ~= GM
						or eB(BF(888077951)) ~= RW
						or eB(BF(587586232)) ~= mo
						or eB(BF(175413298)) ~= iW
						or eB(BF(586479505)) ~= dT
					then
						return false
					end
					if
						not jJ
						or yo(jJ, BF(785423887)) ~= Ie
						or yo(jJ, BF(258784285)) ~= HF
						or yo(jJ, BF(1999435623)) ~= tV
						or yo(jJ, BF(742903341)) ~= Pe
						or yo(jJ, BF(822827564)) ~= eG
						or yo(jJ, BF(1364131418)) ~= Yj
						or yo(jJ, BF(2120484867)) ~= Pp
					then
						return false
					end
					return true
				end
				local function za(lr, pM)
					if EA(lr) ~= "table" then
						return false
					end
					for vc, Wn in oG, lr do
						if Wn == pM then
							return true
						end
					end
					return false
				end
				local function pM(lr)
					return EA(lr) == "table" and oG(lr) == nil
				end
				local function lr(Wn, vc)
					if EA(Wn) ~= "function" then
						return false
					end
					local OM, hU = Hl(br, Wn)
					local bS, mV = Hl(qI, Wn)
					return OM and bS and hU == vc and mV == not vc
				end
				local function mV()
					if
						EA(wi) ~= "function"
						or EA(cw) ~= "function"
						or EA(br) ~= "function"
						or EA(qI) ~= "function"
						or EA(fp) ~= "function"
						or EA(VD) ~= "function"
						or EA(GM) ~= "function"
						or EA(kg) ~= "function"
						or EA(tV) ~= "function"
						or EA(Pe) ~= "function"
						or EA(eG) ~= "function" and EA(Yj) ~= "function"
						or EA(Pp) ~= "function"
					then
						return false, 0
					end
					if lF == pj then
						return false, 0
					end
					local bS = yo(pj, BF(789186256))
					local hU = yo(lF, BF(789186256))
					local OM, vc = {}, {}
					local Wn, pw = false, false
					local SR = Hl(function()
						gb(pj, BF(789186256), OM)
						Wn = yo(lF, BF(789186256)) ~= OM
						gb(lF, BF(789186256), vc)
						local NO, SR = Hl(tw)
						pw = NO and SR == lF and yo(SR, BF(789186256)) == vc
					end)
					local NO = Hl(gb, pj, BF(789186256), bS)
					local bT = Hl(gb, lF, BF(789186256), hU)
					if not SR or not NO or not bT or not Wn or not pw then
						return false, 0
					end
					local bp, HK, He = Hl(wi)
					local pg, zP, Bj = Hl(wi)
					if
						not bp
						or not pg
						or EA(HK) ~= "string"
						or EA(He) ~= "string"
						or EA(Bj) ~= "string"
						or #HK < 1
						or #HK > 128
						or #He > 128
						or HK ~= zP
						or He ~= Bj
					then
						return false, 0
					end
					local RJ, qU = Hl(cw)
					if not RJ or qU ~= true then
						return false, 0
					end
					if
						EA(RW) ~= "table" and EA(RW) ~= "userdata"
						or EA(mo) ~= "table"
						or EA(iW) ~= "table"
						or EA(dT) ~= "table"
					then
						return false, 0
					end
					local Vm, Lo, dX = Hl(function()
						local wU = ""
						wU = wU .. "g:" .. EA(RW)
						local sp = yo(RW, BF(1848702529))
						local et, Qx = Hl(function()
							return RW[BF(1848702529)]
						end)
						wU = wU .. ",rp:" .. tostring(et) .. "/" .. EA(Qx) .. ",er:" .. EA(sp)
						if sp == nil and et then
							sp = Qx
						end
						wU = wU .. ",gs:" .. EA(sp)
						local Kw, cW = Hl(sp, RW, BF(1317319746))
						wU = wU .. ",pl:" .. tostring(Kw) .. "/" .. EA(cW)
						local pr = nil
						if cW ~= nil then
							local mC, rM = Hl(function()
								return yo(cW, BF(1421249581))
							end)
							if mC then
								pr = rM
							end
							if pr == nil then
								local qG, fW = Hl(function()
									return cW[BF(1421249581)]
								end)
								if qG then
									pr = fW
								end
							end
						end
						wU = wU .. ",cn:" .. tostring(pr)
						local rM = yo(iW, BF(143451626))
						if rM == nil then
							local mC, fW = Hl(function()
								return iW[BF(143451626)]
							end)
							if mC then
								rM = fW
							end
						end
						wU = wU .. ",vn:" .. EA(rM)
						local fW, mC = Hl(rM)
						wU = wU .. ",v3:" .. tostring(fW) .. "/" .. GM(mC)
						local qG = GM(Xj({}, {}))
						wU = wU .. ",smt:" .. tostring(qG)
						local iL = yo(mo, BF(143451626))
						if iL == nil then
							local dX, xC = Hl(function()
								return mo[BF(143451626)]
							end)
							if dX then
								iL = xC
							end
						end
						wU = wU .. ",in:" .. EA(iL)
						local xC = yo(dT, BF(332136910))
						local dX = yo(dT, BF(695898882))
						local Lo = yo(dT, BF(2071893755))
						wU = wU .. ",tw:" .. EA(xC) .. ",tsp:" .. EA(dX) .. ",tdf:" .. EA(Lo)
						local Vm = Kw == true
							and cW ~= nil
							and pr == BF(1317319746)
							and fW == true
							and GM(mC) == BF(175413298)
							and qG == "table"
							and EA(iL) == "function"
							and EA(xC) == "function"
							and EA(dX) == "function"
							and EA(Lo) == "function"
						return Vm == true, wU
					end)
					if not Vm or Lo ~= true then
						return false, 0
					end
					local xC = { Qb, Ew, qt, OR, AV, rH, IF, Hl, EA, Tz, Hz, tN, gb, xB, oG, Xj, Dh, LB or qs, kg }
					for iL = 1, #xC do
						if not lr(xC[iL], true) then
							return false, 0
						end
					end
					local function iL(qG)
						return qG
					end
					if not lr(iL, false) then
						return false, 0
					end
					local qG = Hl(tV, Qb)
					local mC, fW = Hl(Pe, Qb)
					local rM = Hl(Pp, Qb, 1, 0)
					if qG or rM or mC and not pM(fW) then
						return false, 0
					end
					if EA(eG) == "function" then
						local pr = Hl(eG, Qb, 1)
						if pr then
							return false, 0
						end
					end
					if EA(Yj) == "function" then
						local pr = Hl(Yj, Qb)
						if pr then
							return false, 0
						end
					end
					local pr = 1864066046
					local function cW(Kw)
						pr = (pr * 31 + Kw) % 4294967296
					end
					local function Kw()
						return 684228231
					end
					local Qx, et = Hl(tV, Kw)
					if not Qx or EA(et) ~= "table" then
						return false, 0
					end
					cW(684228231)
					local function sp(wU)
						sl = (sl + wU) % 2147483647
						return sl
					end
					local wU, Uc = Hl(Pe, sp)
					if not wU or EA(Uc) ~= "table" then
						return false, 0
					end
					cW(123974875)
					local Kf = Hl(Pp, sp, 1, 63192510)
					local hG = Hl(Pp, sp, 1, 123974875)
					if not Kf or not hG or sp(0) ~= 123974875 then
						return false, 0
					end
					cW(63192510)
					local function MQ()
						local function gU(AG)
							return (AG + 100666374) % 2147483647
						end
						return gU
					end
					local gU = MQ()
					local AG, iU = Hl(gU, 81324)
					if not AG or iU ~= 100747698 or not lr(gU, false) then
						return false, 0
					end
					local AU = false
					if EA(eG) == "function" then
						local wr = Hl(eG, MQ, 1)
						if not wr then
							return false, 0
						end
						AU = true
						local PW, rq = Hl(eG, MQ, 1, true)
						if not PW or EA(rq) ~= "table" then
							return false, 0
						end
					end
					if EA(Yj) == "function" then
						local rq, PW = Hl(Yj, MQ)
						if not rq or EA(PW) ~= "table" then
							return false, 0
						end
						AU = true
					end
					if not AU then
						return false, 0
					end
					cW(100747698)
					local PW, rq, wr = Hl(VD, BF(374742625), BF(409328589))
					if not PW or rq ~= nil or EA(wr) ~= "string" or #wr < 1 then
						return false, 0
					end
					local MZ = oO .. Tz(279946158)
					local GF, gR = Hl(VD, MZ)
					if not GF or EA(gR) ~= "function" then
						return false, 0
					end
					local QH, SQ = Hl(gR)
					if not QH or SQ ~= 279946158 or not lr(gR, false) then
						return false, 0
					end
					local EN, rL = Hl(tV, gR)
					if not EN or not za(rL, 279946158) then
						return false, 0
					end
					cW(279946158)
					local function mB(Gr)
						return an(Gr)
					end
					local Gr, Bf = Hl(fp, mB)
					if not Gr or EA(Bf) ~= "function" then
						return false, 0
					end
					local MP, fT = Hl(Bf, -49360)
					if not MP or fT ~= 49360 or not lr(Bf, true) then
						return false, 0
					end
					local xx, IB = Hl(Pe, Bf)
					if xx and not pM(IB) then
						return false, 0
					end
					cW(49360)
					local jZ = 0
					local Fp = 0
					local jg = 0
					local Rb = Hl(function()
						local function hv(ij)
							local BT = 7
							for Ol = 1, #ij do
								BT = (BT * 31 + Qb(ij, Ol)) % 2147483647
							end
							return BT
						end
						local BT = yo(iW, BF(143451626))
						if BT == nil then
							BT = iW[BF(143451626)]
						end
						local ij = BT(1, 2, 3)
						jZ = hv(Tz(ij))
						Fp = hv(GM(ij))
						local Ol = yo(RW, BF(1848702529))
						if Ol == nil then
							Ol = RW[BF(1848702529)]
						end
						local EL = Ol(RW, BF(824337752))
						local uj = yo(EL, BF(1372314137))
						if uj == nil then
							uj = EL[BF(1372314137)]
						end
						local Yg = uj(EL) == true and 1 or 0
						local yd, JT = Hl(cw)
						local Rb = yd and JT == true and 1 or 0
						jg = Yg + Rb * 2 + #HK * 4
					end)
					if not Rb then
						jZ, Fp, jg = 0, 0, 0
					end
					nn, zl, vG = jZ, Fp, jg
					cW(jZ)
					cW(Fp)
					cW(jg)
					return true, pr
				end
				local fT = function(Rb, jg)
					Hj += 1
					if Gz then
						return kc
					end
					if mn and Mk ~= Nm() then
						zw()
						return kc
					end
					local Fp = Rb % 65536
					local jZ = (Rb - Fp) / 65536
					TD = (TD * 4093 + Fp * 257 + jZ * 17 + Hj * 31 + bv + aT + 724437904) % 2147483647
					TD = YP(TD, Rb % 2147483648) % 2147483647
					mn = true
					bv = (bv + TD % 65521 + Hj * 17 + xQ) % 2147483647
					QZ()
					Mk = Nm()
					if not jg and Hj < nx then
						return ml
					end
					if io ~= (bv * 4099 + 1114565040 + aT % 104729) % 2147483647 then
						zw()
						return kc
					end
					xQ += 1
					local IB = jg or not nH or xQ % 5 == 0
					local xx = Mo()
					local fT = 4200176864
					if xx and IB then
						xx, fT = mV()
					end
					if xx and fT ~= 4200176864 then
						xx = false
					end
					if not xx then
						zw()
						return kc
					end
					if wW ~= (bv * 8191 + 261237549 + aT % 65521 * 131) % 2147483647 then
						zw()
						return kc
					end
					if not nH then
						aT = (fT + 2670533853) % 4294967296
						nH = true
					end
					if aT ~= 2575743421 then
						zw()
						return kc
					end
					ml = aT
					bv = (bv * 48271 + Hj + xQ * 17 + aT % 65521) % 2147483647
					QZ()
					if mn then
						Mk = Nm()
					end
					nx = Hj + 28 + bv % 9
					return ml
				end
				fT(0, true)
				return { ml, fT }
			end
			RY = function()
				local fT = bit32
				local mV = buffer
				local lr = string
				local pM = table
				local za = math
				local Mo = coroutine
				local QZ = loadstring
				local Nm = select
				local YP = pcall
				local zw = setmetatable
				local kc = rawequal
				local vG = rawget
				local zl = tostring
				local nn = bit32.bxor
				local sl = buffer.create
				local mn = string.byte
				local Mk = coroutine.resume
				local TD = 0
				local ml = game
				local nH = Enum
				local Gz = Instance
				local wW = Random
				local io = task
				local wj = game.GetService
				local aT = Enum.HumanoidRigType
				local bv = Instance.new
				local xQ = Random.new
				local nx = task.spawn
				local Hj = Random.new(51018400)
				local oO = Hj["NextNumber"](Hj)
				local kg = type(oO) == "number" and oO >= 0 and oO < 1
				TD = (TD * 16351 + (kg and 0 or 1)) % 268435456
				local Pp = Hj["NextInteger"](Hj, 189, 1164)
				local Yj = type(Pp) == "number" and math.floor(Pp) == Pp and Pp >= 189 and Pp <= 1164
				TD = (TD * 18003 + (Yj and 0 or 1)) % 268435456
				local eG = Hj["NextNumber"](Hj)
				local Pe = type(eG) == "number" and eG >= 0 and eG < 1 and eG ~= oO
				TD = (TD * 8005 + (Pe and 0 or 1)) % 268435456
				local tV = Random.new(1514927986)
				local HF = Random.new(1514927986)
				local Ie = tV["NextNumber"](tV) == HF["NextNumber"](HF)
				TD = (TD * 65359 + (Ie and 0 or 1)) % 268435456
				local dT = Random.new(975664562)
				dT["NextNumber"](dT)
				local iW = dT["Clone"](dT)
				local mo = iW["NextNumber"](iW)
				local RW = iW["Clone"](iW)
				local GM = RW["NextNumber"](RW)
				local VD = iW["NextNumber"](iW)
				local fp = GM == VD
				TD = (TD * 9497 + (fp and 0 or 1)) % 268435456
				local qI = Random.new(1987693592)
				local br = Random.new(1987693592 + 1)
				local cw = qI["NextNumber"](qI) ~= br["NextNumber"](br)
				TD = (TD * 60737 + (cw and 0 or 1)) % 268435456
				local wi = true
				local AV = coroutine.create(function(LB)
					local AV = coroutine.yield(LB + 1)
					return AV + 2
				end)
				local LB, OR = coroutine.resume(AV, 9)
				local qt, Ew = coroutine.resume(AV, 11)
				wi = LB and OR == 10 and qt and Ew == 13 and coroutine.status(AV) == "dead"
				local Qb = 0
				local rH = coroutine.create(function()
					for rH = 1, 3 do
						coroutine.yield(rH)
					end
				end)
				for an = 1, 3 do
					local FA, qs = coroutine.resume(rH)
					if FA and qs == an then
						Qb += 1
					end
				end
				wi = wi and Qb == 3 and coroutine.close(rH)
				TD = (TD * 9301 + (wi and 0 or 1)) % 268435456
				local qs = false
				local FA = task.spawn(function()
					qs = true
				end)
				local an = qs and type(FA) == "thread"
				TD = (TD * 48007 + (an and 0 or 1)) % 268435456
				local Dh = false
				local Xj = task.delay(86400, function()
					Dh = true
				end)
				local Tz, Hz = pcall(task.cancel, Xj)
				local IF = type(Xj) == "thread" and not Dh and Tz
				TD = (TD * 49877 + (IF and 0 or 1)) % 268435456
				local oG = not pcall(task.wait, {})
				TD = (TD * 23785 + (oG and 0 or 1)) % 268435456
				local gb = {
					__index = function()
						return "AA"
					end,
					__add = function(xB, gb)
						return xB.ir + gb.ir
					end,
					__tostring = function()
						return "o"
					end,
				}
				local xB = setmetatable({ ir = 13 }, gb)
				local tN = setmetatable({ ir = 7 }, gb)
				local EA = xB.NVR == "AA"
					and xB + tN == 20
					and tostring(xB) == "o"
					and rawequal(xB, xB)
					and not rawequal(xB, tN)
					and xB.ir == 13
					and rawget(xB, "zz") == nil
				TD = (TD * 44235 + (EA and 0 or 1)) % 268435456
				local Hl = {}
				for jJ = 1, 3 do
					local iC = jJ * 10
					Hl[jJ] = function(hl)
						iC += hl
						return iC
					end
				end
				local iC = Hl[1](4) == 14 and Hl[1](2) == 16 and Hl[2](1) == 21 and Hl[3](0) == 30
				TD = (TD * 7061 + (iC and 0 or 1)) % 268435456
				local jJ = true
				if type(_G["clonefunction"]) == "function" then
					local hl = _G["clonefunction"](pcall)
					local mv, eB = hl(function()
						return 37
					end)
					jJ = type(hl) == "function" and mv and eB == 37
				end
				TD = (TD * 3393 + (jJ and 0 or 1)) % 268435456
				local eB = true
				local mv = buffer.fromstring("_\192\1\137")
				eB = eB and buffer.len(mv) == 4 and buffer.readu8(mv, 0) == 95 and buffer.readu8(mv, 3) == 137
				eB = eB and buffer.readu16(mv, 1) == 448 and buffer.readu32(mv, 0) == 2298593375
				eB = eB and buffer.tostring(mv) == "_\192\1\137"
				local hl = buffer.create(8)
				buffer.writeu16(hl, 0, 25227)
				buffer.writeu32(hl, 2, 1822000464)
				eB = eB and buffer.readu8(hl, 0) == 139 and buffer.readu8(hl, 1) == 98
				eB = eB and buffer.readu8(hl, 2) == 80 and buffer.readu8(hl, 5) == 108
				buffer.writef64(hl, 0, -0.25)
				eB = eB and buffer.readf64(hl, 0) == -0.25
				buffer.writestring(hl, 0, "Az")
				eB = eB and buffer.readstring(hl, 0, 2) == "Az"
				buffer.fill(hl, 0, 7, 4)
				eB = eB and buffer.readu8(hl, 0) == 7 and buffer.readu8(hl, 3) == 7
				local lF = buffer.create(4)
				buffer.writebits(lF, 3, 5, 28)
				eB = eB and buffer.readbits(lF, 3, 5) == 28
				local tM = buffer.fromstring("Az")
				buffer.copy(tM, 0, mv, 0, 2)
				eB = eB and buffer.tostring(tM) == "_\192"
				eB = eB
					and not pcall(buffer.readu8, mv, 99)
					and not pcall(buffer.writeu8, hl, -1, 0)
					and not pcall(buffer.readstring, mv, 3, 2)
				TD = (TD * 62769 + (eB and 0 or 1)) % 268435456
				local tw = Instance.new("Folder")
				local yo = Instance.new("Folder")
				yo["Parent"] = tw
				local pj = typeof(tw) == "Instance"
					and tw["ClassName"] == "Folder"
					and type(tw["Name"]) == "string"
					and #tw["GetChildren"](tw) == 1
				TD = (TD * 9713 + (pj and 0 or 1)) % 268435456
				local iX = tw["ChildRemoved"]
				local BF = iX["Connect"](iX, function() end)
				local je = BF["Connected"] == true
				BF["Disconnect"](BF)
				je = je and BF["Connected"] == false
				TD = (TD * 62367 + (je and 0 or 1)) % 268435456
				tw["Destroy"](tw)
				local Tn, dD = pcall(function()
					yo["Parent"] = tw
				end)
				local JA = not Tn and type(dD) == "string" and #dD > 0
				TD = (TD * 42653 + (JA and 0 or 1)) % 268435456
				local Dl = true
				local KA = loadstring("return 291, nil, 976")
				Dl = type(KA) == "function" and select("#", KA()) == 3 and select(3, KA()) == 976
				local pv, dr = loadstring("local =")
				Dl = Dl and pv == nil and type(dr) == "string"
				TD = (TD * 47145 + (Dl and 0 or 1)) % 268435456
				local iE = game:GetService("RunService")
				local xx, IB = pcall(function()
					return iE["IsStudio"](nil)
				end)
				local jZ = not xx and type(IB) == "string" and #IB > 0
				TD = (TD * 31259 + (jZ and 0 or 1)) % 268435456
				local Fp, jg = pcall(function()
					return iE["IsStudio"](iE)
				end)
				local Rb = Fp and type(jg) == "boolean"
				TD = (TD * 62815 + (Rb and 0 or 1)) % 268435456
				local MP, Bf = pcall(function()
					return game.GetChildren(nil)
				end)
				local Gr = not MP and type(Bf) == "string" and #Bf > 0
				TD = (TD * 34937 + (Gr and 0 or 1)) % 268435456
				local mB = string.char(65, 0, 90)
				local rL = mB == "A\0Z"
				TD = (TD * 5703 + (rL and 0 or 1)) % 268435456
				local EN = string.sub("abcdef", 2, -2)
				TD = (TD * 37441 + (EN == "bcde" and 0 or 1)) % 268435456
				local SQ = string.rep("xy", 5)
				TD = (TD * 14941 + (SQ == "xyxyxyxyxy" and 0 or 1)) % 268435456
				local QH = #mB
				TD = (TD * 65107 + (QH - 3)) % 268435456
				local gR = string.byte(mB, 2)
				TD = (TD * 36779 + gR) % 268435456
				local GF = select("#", "h", nil, "t")
				TD = (TD * 61113 + (GF - 3)) % 268435456
				local MZ = -17 % 5
				TD = (TD * 45123 + (MZ - 3)) % 268435456
				local wr = math.floor(-1.25)
				TD = (TD * 42159 + (wr + 2)) % 268435456
				local rq = bit32.bxor(3969676057, 267077366)
				TD = (TD * 20209 + (rq - 3816240623)) % 268435456
				local PW = bit32.band(2894684893, 1163446030)
				TD = (TD * 22037 + (PW - 67650060)) % 268435456
				local AU = type(table.freeze) == "function"
				local iU = table.freeze({})
				local AG = pcall(function()
					iU[1] = 1
				end)
				AU = AU and not AG
				TD = (TD * 17665 + (AU and 0 or 1)) % 268435456
				local gU = Enum.HumanoidRigType
				local MQ = gU["FromName"](gU, "R6")
				local hG = gU["FromName"](gU, "R6")
				local Kf = gU["FromValue"](gU, 0)
				local Uc = gU["R6"]
				local wU = MQ == hG
					and MQ == Kf
					and MQ == Uc
					and MQ["Name"] == "R6"
					and MQ["Value"] == 0
					and MQ["EnumType"] == gU
				TD = (TD * 54915 + (wU and 0 or 1)) % 268435456
				local sp = typeof(Enum) == "Enums"
					and typeof(gU) == "Enum"
					and typeof(MQ) == "EnumItem"
					and getmetatable(Enum) == "The metatable is locked"
					and getmetatable(gU) == "The metatable is locked"
					and getmetatable(MQ) == "The metatable is locked"
				TD = (TD * 62115 + (sp and 0 or 1)) % 268435456
				local et = bit32 == fT
					and buffer == mV
					and string == lr
					and table == pM
					and math == za
					and coroutine == Mo
					and loadstring == QZ
					and select == Nm
					and pcall == YP
					and setmetatable == zw
					and rawequal == kc
					and rawget == vG
					and tostring == zl
					and bit32.bxor == nn
					and buffer.create == sl
					and string.byte == mn
					and coroutine.resume == Mk
				TD = (TD * 64611 + (et and 0 or 1)) % 268435456
				local Qx = game == ml
					and Enum == nH
					and Instance == Gz
					and Random == wW
					and task == io
					and game.GetService == wj
					and Enum.HumanoidRigType == aT
					and Instance.new == bv
					and Random.new == xQ
					and task.spawn == nx
				TD = (TD * 30319 + (Qx and 0 or 1)) % 268435456
				return TD
			end
			do
				local Qx = h(0)[da]
				local et = h(0)[TA]
				local sp = h(0)[pQ]
				local wU = sp and sp[Tl]
				local Uc = h(0)[dQ]
				qV = Uc and Uc[JN]
				local Kf = 0
				local hG = 0
				do
					local MQ, gU = d(function()
						return wU(Qx, og)
					end)
					if MQ and M(gU) == pT[7] then
						for AG = 1, #gU do
							Kf = (Kf * 31 + g(gU, AG)) % 268435456
						end
					end
					Kf = (
						Kf
						+ (
							MQ and 0
							or (function(AG)
								local iU = (65399256 + 0) % 268435456
								for AU = 1, #AG do
									iU = (iU * 21298 + #AG[AU] + AU * 18267 + 228536860) % 268435456
								end
								return (47371549 + iU) % 268435456
							end)(c)
						)
					) % 268435456
				end
				local gU = {}
				do
					local MQ = h(1)
					if M(MQ) == "table" then
						local iU, AG = next(MQ)
						while iU ~= nil do
							gU[iU] = AG
							iU, AG = next(MQ, iU)
						end
					end
				end
				do
					local MQ = qV and qV() or 0
					local AG = D(MQ * (975094531014 + 894344744864 - 1869432595931))
					for iU = 1, 5 do
						Ja = (Ja * (891249701279 + 922870448045 - 1814120149285) + AG % 256) % 268435456
						AG = D(AG / 256)
					end
					local iU = {}
					local AU = et(iU)
					for PW = 1, #AU do
						Ja = (Ja * (143743283778 + 713680026444 - 857423310204) + g(AU, PW)) % 268435456
					end
					local PW = function() end
					local rq = et(PW)
					for wr = 1, #rq do
						Ja = (Ja * (715309513037 + 741856763737 - 1457166276753) + g(rq, wr)) % 268435456
					end
				end
				PP = (
					(
							(function(rq)
								local PW = (202242468 + 0) % 268435456
								for AU = 1, #rq do
									PW = (PW * 62017 + #rq[AU] + AU * 16647 + 28200173) % 268435456
								end
								return (255944489 + PW) % 268435456
							end)(c)
							+ Kf % 65536 * (function(PW)
								local rq = (99347205 + 0) % 268435456
								for AU = 1, #PW do
									rq = (rq * 62994 + #PW[AU] + AU * 50061 + 18829247) % 268435456
								end
								return (25013811 + rq) % 268435456
							end)(c)
							+ D(Kf / 65536)
								* (function(rq)
									local PW = (79316658 + 0) % 268435456
									for AU = 1, #rq do
										PW = (PW * 65413 + #rq[AU] + AU * 38402 + 18338835) % 268435456
									end
									return (101311646 + PW) % 268435456
								end)(c)
						)
						% 268435456
					- (function(PW)
						local rq = (146349968 + 0) % 268435456
						for AU = 1, #PW do
							rq = (rq * 10814 + #PW[AU] + AU * 45147 + 96466526) % 268435456
						end
						return (104329310 + rq) % 268435456
					end)(c)
				) % 268435456
				local PW = (function(rq)
					local PW = (225380197 + 0) % 268435456
					for AU = 1, #rq do
						PW = (PW * 42899 + #rq[AU] + AU * 24243 + 7323137) % 268435456
					end
					return (104964676 + PW) % 268435456
				end)(c)
				local AU = (function(rq)
					local AU = (223002249 + 0) % 268435456
					for iU = 1, #rq do
						AU = (AU * 3016 + #rq[iU] + iU * 11522 + 113373245) % 268435456
					end
					return (239466388 + AU) % 268435456
				end)(c)
				ns = function(rq, iU, AG, MQ, wr, MZ, GF, gR, QH, SQ, EN, rL, mB, Gr, Bf, MP)
					local Rb = { 467561971417 + 8738947076 - 476300870202, 724760870737 + 671018792760 - 1395778845783 }
					local jg =
						{ 235102687341 + 582310384399 - 817411383915, 789312866159 + 644436693804 - 1433644557799 }
					local function Fp(jZ, IB)
						jZ = GF(jZ)
						local xx = #jZ
						local iE = xx
						if iE > 64 then
							iE = 64
						end
						local dr = {}
						local pv = (mB + (IB - 1) * Gr) % 268435456
						for KA = 1, iE do
							pv = (EN * pv + rL) % 268435456
							dr[KA] = iU(
								(
									rq(jZ, KA) - (pv % 256 + AG(pv / 256) % 256 + AG(pv / 65536) % 256 + AG(
										pv / 16777216
									)) % 256
								) % 256
							)
						end
						local KA = 0
						for Dl = 1, iE do
							KA = (KA * 31 + rq(jZ, Dl)) % 268435456
						end
						pv = (mB + (IB - 1) * Gr + KA) % 268435456
						for Dl = iE + 1, xx do
							pv = (EN * pv + rL) % 268435456
							dr[Dl] = iU(
								(
									rq(jZ, Dl) - (pv % 256 + AG(pv / 256) % 256 + AG(pv / 65536) % 256 + AG(
										pv / 16777216
									)) % 256
								) % 256
							)
						end
						jZ = table.concat(dr)
						local Dl = 63
						local JA = 227
						local dD = 22
						local Tn = 104
						local je = 121
						local BF = 106
						local iX = 7
						local pj = 137
						local yo = 1
						local tw = 0
						local tM = 0
						local lF = 1
						local hl, mv, eB, jJ, iC, Hl, EA, tN, xB, gb, oG, IF, Hz, Tz, Xj, Dh, an, FA, qs
						while lF <= 2 do
							if lF == 1 then
								local rH = rq(jZ, yo)
								yo += 1
								if rH == Dl then
									local Qb
									Qb, yo = gR(jZ, yo)
									hl = Qb
									Qb, yo = gR(jZ, yo)
									mv = Qb
									Qb, yo = gR(jZ, yo)
									eB = Qb
									tw += 1
								elseif rH == JA then
									local Qb
									Qb, yo = gR(jZ, yo)
									jJ = Qb
									qs = (
										Qb * (308768240271 + 671611655480 - 980379846850)
										+ (265876735611 + 636185316136 - 902061999135)
									) % 65536
									tw += 1
								elseif rH == dD then
									local Qb
									Qb, yo = gR(jZ, yo)
									Hl = {}
									for Ew = 1, Qb do
										local qt
										qt, yo = gR(jZ, yo)
										Hl[Ew] = qt
									end
									tw += 1
								elseif rH == Tn then
									local Qb
									Qb, yo = gR(jZ, yo)
									EA = Qb
									Qb, yo = gR(jZ, yo)
									iC = Qb
									tM = yo
									yo += iC
									tw += 1
								elseif rH == je then
									local Qb
									Qb, yo = gR(jZ, yo)
									xB = {}
									for qt = 1, Qb do
										local Ew
										Ew, yo = gR(jZ, yo)
										xB[qt] = Ew
									end
									tw += 1
								elseif rH == BF then
									local Qb
									Qb, yo = gR(jZ, yo)
									yo += Qb
								elseif rH == pj then
									local Qb
									Qb, yo = gR(jZ, yo)
									FA = {}
									for Ew = 1, Qb do
										local qt
										qt, yo = gR(jZ, yo)
										FA[Ew] = qt
									end
									tw += 1
								else
									local Qb
									Qb, yo = gR(jZ, yo)
									gb = Qb
									oG = {}
									for qt = 1, gb do
										oG[qt] = rq(jZ, yo)
										yo += 1
									end
									local qt = yo
									IF = {}
									for Ew = 1, gb do
										local OR = rq(jZ, yo)
										if OR < 128 then
											IF[Ew] = OR
											yo += 1
										else
											local LB = rq(jZ, yo + 1)
											if LB < 128 then
												IF[Ew] = OR - 128 + LB * 128
												yo += 2
											else
												local AV = rq(jZ, yo + 2)
												if AV < 128 then
													local wi = OR - 128 + (LB - 128) * 128 + AV * 16384
													if wi >= 2147483648 then
														wi -= 4294967296
													end
													IF[Ew] = wi
													yo += 3
												else
													local wi = rq(jZ, yo + 3)
													local cw = OR
														- 128
														+ (LB - 128) * 128
														+ (AV - 128) * 16384
														+ wi * 2097152
													if cw >= 2147483648 then
														cw -= 4294967296
													end
													IF[Ew] = cw
													yo += 4
												end
											end
										end
									end
									Hz = {}
									for OR = 1, gb do
										local Ew = rq(jZ, yo)
										if Ew < 128 then
											Hz[OR] = Ew
											yo += 1
										else
											local LB = rq(jZ, yo + 1)
											if LB < 128 then
												Hz[OR] = Ew - 128 + LB * 128
												yo += 2
											else
												local AV = rq(jZ, yo + 2)
												if AV < 128 then
													local cw = Ew - 128 + (LB - 128) * 128 + AV * 16384
													if cw >= 2147483648 then
														cw -= 4294967296
													end
													Hz[OR] = cw
													yo += 3
												else
													local cw = rq(jZ, yo + 3)
													local wi = Ew
														- 128
														+ (LB - 128) * 128
														+ (AV - 128) * 16384
														+ cw * 2097152
													if wi >= 2147483648 then
														wi -= 4294967296
													end
													Hz[OR] = wi
													yo += 4
												end
											end
										end
									end
									Tz = {}
									for Ew = 1, gb do
										local OR = rq(jZ, yo)
										if OR < 128 then
											Tz[Ew] = OR
											yo += 1
										else
											local LB = rq(jZ, yo + 1)
											if LB < 128 then
												Tz[Ew] = OR - 128 + LB * 128
												yo += 2
											else
												local AV = rq(jZ, yo + 2)
												if AV < 128 then
													local wi = OR - 128 + (LB - 128) * 128 + AV * 16384
													if wi >= 2147483648 then
														wi -= 4294967296
													end
													Tz[Ew] = wi
													yo += 3
												else
													local wi = rq(jZ, yo + 3)
													local cw = OR
														- 128
														+ (LB - 128) * 128
														+ (AV - 128) * 16384
														+ wi * 2097152
													if cw >= 2147483648 then
														cw -= 4294967296
													end
													Tz[Ew] = cw
													yo += 4
												end
											end
										end
									end
									Xj = {}
									for OR = 1, gb do
										local Ew = rq(jZ, yo)
										if Ew < 128 then
											Xj[OR] = Ew
											yo += 1
										else
											local LB = rq(jZ, yo + 1)
											if LB < 128 then
												Xj[OR] = Ew - 128 + LB * 128
												yo += 2
											else
												local AV = rq(jZ, yo + 2)
												if AV < 128 then
													local cw = Ew - 128 + (LB - 128) * 128 + AV * 16384
													if cw >= 2147483648 then
														cw -= 4294967296
													end
													Xj[OR] = cw
													yo += 3
												else
													local cw = rq(jZ, yo + 3)
													local wi = Ew
														- 128
														+ (LB - 128) * 128
														+ (AV - 128) * 16384
														+ cw * 2097152
													if wi >= 2147483648 then
														wi -= 4294967296
													end
													Xj[OR] = wi
													yo += 4
												end
											end
										end
									end
									local Ew = yo
									yo = qt
									local OR = 0
									for LB = 1, gb do
										local AV = rq(jZ, yo)
										if AV < 128 then
											OR = (OR + AV) % 4294967296
											yo += 1
										else
											local wi = rq(jZ, yo + 1)
											if wi < 128 then
												OR = (OR + (AV - 128) + wi * 128) % 4294967296
												yo += 2
											else
												local cw = rq(jZ, yo + 2)
												if cw < 128 then
													local br = AV - 128 + (wi - 128) * 128 + cw * 16384
													if br >= 2147483648 then
														br -= 4294967296
													end
													OR = (OR + br) % 4294967296
													yo += 3
												else
													local br = rq(jZ, yo + 3)
													local qI = AV
														- 128
														+ (wi - 128) * 128
														+ (cw - 128) * 16384
														+ br * 2097152
													if qI >= 2147483648 then
														qI -= 4294967296
													end
													OR = (OR + qI) % 4294967296
													yo += 4
												end
											end
										end
									end
									for AV = 1, gb do
										local LB = rq(jZ, yo)
										if LB < 128 then
											OR = (OR + LB) % 4294967296
											yo += 1
										else
											local wi = rq(jZ, yo + 1)
											if wi < 128 then
												OR = (OR + (LB - 128) + wi * 128) % 4294967296
												yo += 2
											else
												local cw = rq(jZ, yo + 2)
												if cw < 128 then
													local qI = LB - 128 + (wi - 128) * 128 + cw * 16384
													if qI >= 2147483648 then
														qI -= 4294967296
													end
													OR = (OR + qI) % 4294967296
													yo += 3
												else
													local qI = rq(jZ, yo + 3)
													local br = LB
														- 128
														+ (wi - 128) * 128
														+ (cw - 128) * 16384
														+ qI * 2097152
													if br >= 2147483648 then
														br -= 4294967296
													end
													OR = (OR + br) % 4294967296
													yo += 4
												end
											end
										end
									end
									for LB = 1, gb do
										local AV = rq(jZ, yo)
										if AV < 128 then
											OR = (OR + AV) % 4294967296
											yo += 1
										else
											local wi = rq(jZ, yo + 1)
											if wi < 128 then
												OR = (OR + (AV - 128) + wi * 128) % 4294967296
												yo += 2
											else
												local cw = rq(jZ, yo + 2)
												if cw < 128 then
													local br = AV - 128 + (wi - 128) * 128 + cw * 16384
													if br >= 2147483648 then
														br -= 4294967296
													end
													OR = (OR + br) % 4294967296
													yo += 3
												else
													local br = rq(jZ, yo + 3)
													local qI = AV
														- 128
														+ (wi - 128) * 128
														+ (cw - 128) * 16384
														+ br * 2097152
													if qI >= 2147483648 then
														qI -= 4294967296
													end
													OR = (OR + qI) % 4294967296
													yo += 4
												end
											end
										end
									end
									for AV = 1, gb do
										local LB = rq(jZ, yo)
										if LB < 128 then
											OR = (OR + LB) % 4294967296
											yo += 1
										else
											local wi = rq(jZ, yo + 1)
											if wi < 128 then
												OR = (OR + (LB - 128) + wi * 128) % 4294967296
												yo += 2
											else
												local cw = rq(jZ, yo + 2)
												if cw < 128 then
													local qI = LB - 128 + (wi - 128) * 128 + cw * 16384
													if qI >= 2147483648 then
														qI -= 4294967296
													end
													OR = (OR + qI) % 4294967296
													yo += 3
												else
													local qI = rq(jZ, yo + 3)
													local br = LB
														- 128
														+ (wi - 128) * 128
														+ (cw - 128) * 16384
														+ qI * 2097152
													if br >= 2147483648 then
														br -= 4294967296
													end
													OR = (OR + br) % 4294967296
													yo += 4
												end
											end
										end
									end
									yo = qt
									local LB = 0
									for AV = 1, gb do
										local wi = rq(jZ, yo)
										if wi < 128 then
											LB = (LB + (0 * gb + AV) * wi % 4294967296) % 4294967296
											yo += 1
										else
											local cw = rq(jZ, yo + 1)
											if cw < 128 then
												LB = (LB + (0 * gb + AV) * (wi - 128 + cw * 128) % 4294967296)
													% 4294967296
												yo += 2
											else
												local br = rq(jZ, yo + 2)
												if br < 128 then
													local qI = wi - 128 + (cw - 128) * 128 + br * 16384
													if qI >= 2147483648 then
														qI -= 4294967296
													end
													LB = (LB + (0 * gb + AV) * qI % 4294967296) % 4294967296
													yo += 3
												else
													local qI = rq(jZ, yo + 3)
													local fp = wi
														- 128
														+ (cw - 128) * 128
														+ (br - 128) * 16384
														+ qI * 2097152
													if fp >= 2147483648 then
														fp -= 4294967296
													end
													LB = (LB + (0 * gb + AV) * fp % 4294967296) % 4294967296
													yo += 4
												end
											end
										end
									end
									for wi = 1, gb do
										local AV = rq(jZ, yo)
										if AV < 128 then
											LB = (LB + (1 * gb + wi) * AV % 4294967296) % 4294967296
											yo += 1
										else
											local cw = rq(jZ, yo + 1)
											if cw < 128 then
												LB = (LB + (1 * gb + wi) * (AV - 128 + cw * 128) % 4294967296)
													% 4294967296
												yo += 2
											else
												local br = rq(jZ, yo + 2)
												if br < 128 then
													local fp = AV - 128 + (cw - 128) * 128 + br * 16384
													if fp >= 2147483648 then
														fp -= 4294967296
													end
													LB = (LB + (1 * gb + wi) * fp % 4294967296) % 4294967296
													yo += 3
												else
													local fp = rq(jZ, yo + 3)
													local qI = AV
														- 128
														+ (cw - 128) * 128
														+ (br - 128) * 16384
														+ fp * 2097152
													if qI >= 2147483648 then
														qI -= 4294967296
													end
													LB = (LB + (1 * gb + wi) * qI % 4294967296) % 4294967296
													yo += 4
												end
											end
										end
									end
									for AV = 1, gb do
										local wi = rq(jZ, yo)
										if wi < 128 then
											LB = (LB + (2 * gb + AV) * wi % 4294967296) % 4294967296
											yo += 1
										else
											local cw = rq(jZ, yo + 1)
											if cw < 128 then
												LB = (LB + (2 * gb + AV) * (wi - 128 + cw * 128) % 4294967296)
													% 4294967296
												yo += 2
											else
												local br = rq(jZ, yo + 2)
												if br < 128 then
													local qI = wi - 128 + (cw - 128) * 128 + br * 16384
													if qI >= 2147483648 then
														qI -= 4294967296
													end
													LB = (LB + (2 * gb + AV) * qI % 4294967296) % 4294967296
													yo += 3
												else
													local qI = rq(jZ, yo + 3)
													local fp = wi
														- 128
														+ (cw - 128) * 128
														+ (br - 128) * 16384
														+ qI * 2097152
													if fp >= 2147483648 then
														fp -= 4294967296
													end
													LB = (LB + (2 * gb + AV) * fp % 4294967296) % 4294967296
													yo += 4
												end
											end
										end
									end
									for wi = 1, gb do
										local AV = rq(jZ, yo)
										if AV < 128 then
											LB = (LB + (3 * gb + wi) * AV % 4294967296) % 4294967296
											yo += 1
										else
											local cw = rq(jZ, yo + 1)
											if cw < 128 then
												LB = (LB + (3 * gb + wi) * (AV - 128 + cw * 128) % 4294967296)
													% 4294967296
												yo += 2
											else
												local br = rq(jZ, yo + 2)
												if br < 128 then
													local fp = AV - 128 + (cw - 128) * 128 + br * 16384
													if fp >= 2147483648 then
														fp -= 4294967296
													end
													LB = (LB + (3 * gb + wi) * fp % 4294967296) % 4294967296
													yo += 3
												else
													local fp = rq(jZ, yo + 3)
													local qI = AV
														- 128
														+ (cw - 128) * 128
														+ (br - 128) * 16384
														+ fp * 2097152
													if qI >= 2147483648 then
														qI -= 4294967296
													end
													LB = (LB + (3 * gb + wi) * qI % 4294967296) % 4294967296
													yo += 4
												end
											end
										end
									end
									Dh = OR
									an = LB
									yo = Ew
									tw += 1
								end
								if tw >= iX then
									lF = 2
								end
							else
								yo = tM
								tN = {}
								local rH = ("")["char"]
								local function LB()
									jJ = (QH * jJ + SQ) % 268435456
									local OR = (
										rq(jZ, yo) - (jJ % 256 + AG(jJ / 256) % 256 + AG(jJ / 65536) % 256 + AG(
											jJ / 16777216
										)) % 256
									) % 256
									yo += 1
									return OR
								end
								for OR = 1, EA do
									local Ew = LB()
									if Ew == 0 then
										tN[OR] = nil
									elseif Ew == 1 then
										tN[OR] = LB() == 1
									elseif Ew == 3 then
										local qt = LB()
										local Qb = LB()
										local AV = qt + Qb * 256
										local wi = ""
										for cw = 1, AV do
											wi = wi .. rH(LB())
										end
										tN[OR] = wi
									else
										local wi = 0
										local AV = 1
										while true do
											local Qb = LB()
											if Qb < 128 then
												wi += Qb * AV
												break
											end
											wi += (Qb - 128) * AV
											AV *= 128
										end
										local Qb = 0
										local qt = 1
										while true do
											local cw = LB()
											if cw < 128 then
												Qb += cw * qt
												break
											end
											Qb += (cw - 128) * qt
											qt *= 128
										end
										local cw = AG(Qb / 2) - 2048
										local br = 1
										if cw >= 0 then
											for qI = 1, cw do
												br *= 2
											end
										else
											for qI = 1, 0 - cw do
												br /= 2
											end
										end
										local qI = wi * br
										if Qb % 2 == 1 then
											qI = 0 - qI
										end
										tN[OR] = qI
									end
								end
								if yo ~= tM + iC then
									Dh = (Dh or 0) + yo + 1
									an = (an or 0) + tM + iC + 1
								end
								lF = 3
							end
						end
						return {
							Rs = hl,
							xeKZ = mv,
							Kq_ = eB,
							rNOk = Hl,
							kh = tN,
							roud = xB,
							rZ = Dh,
							Kx = an,
							N_Gl = oG,
							RXsS = IF,
							AX = Hz,
							hgrc = Tz,
							UMog = Xj,
							DI = FA,
							lbY = qs,
						}
					end
					return function(qs, FA, an, Dh, Xj, Tz, Hz, IF)
						local oG = {}
						local gb = { 126, 17, 245 }
						local xB = 0
						xB = (xB * 257 + 255) % 268435456
						xB = (xB * 257 + 247) % 268435456
						for tN = 1, #gb do
							xB = (xB * 257 + gb[tN]) % 268435456
						end
						local tN = (xB - AU) % 268435456
						local EA = 1
						while EA <= #gb do
							local Hl = (gb[EA] - (255 + EA * 247) % 256) % 256
							if 17 == Hl then
								local iC = oG
								local jJ = {}
								local eB = 0
								local mv = 0
								do
									local hl = {}
									local lF = MP(hl)
									for tM = 1, #lF do
										mv = (mv * 31 + rq(lF, tM)) % 268435456
									end
								end
								local lF = { { 1, 5, 8, 9 }, { 1, 10, 15, 16, 20, 21, 23, 25, 26, 41 } }
								local hl = { 3, 2 }
								local tM = { { 2, 8 }, { 7, 9, 23 } }
								local tw, yo, pj, iX, BF, je, Tn, dD, JA, Dl, KA, pv, dr, iE, xx, IB, jZ, LB, rH, Ew, OR, qI, br, cw, qt, Qb, AV, wi, fp, VD, GM, RW, mo, iW, dT =
									348514869410 + 633356331302 - 981871199060,
									822658012031 + 562949994246 - 1385607975311,
									828803399553 + 338811610781 - 1167614996274,
									639312506665 + 261152471161 - 900464951842,
									190122990168 + 902813006756 - 1092935941951,
									543282236668 + 325012163223 - 868294396733,
									830225846146 + 832010163075 - 1662235975105,
									101354040367 + 733650589525 - 835004593027,
									667986582839 + 102344065071 - 770330635755,
									144621476419 + 223963488360 - 368584904954,
									543222345980 + 732563644757 - 1275785945582,
									186235167318 + 150692945478 - 336928065246,
									829753438594 + 18657765384 - 848411141509,
									128969735740 + 63277440541 - 192247157312,
									22030415370 + 202436278366 - 224466689437,
									441756972749 + 122322513464 - 564079486195,
									252606310005 + 1074749873652 - 1327356183652,
									994017723342 + 641598967082 - 1635616689774,
									679720485692 + 261080399993 - 940800885602,
									9710521348 + 344622581920 - 354333096574,
									765235260260 + 578112892173 - 1343348130820,
									482305137888 + 292104491144 - 774409585399,
									38777413650 + 455743827156 - 494521211843,
									1085727557625 + 933196201394 - 2018923727661,
									421959161540 + 1037293798371 - 1459252913634,
									548923876607 + 1073241580019 - 1622165453849,
									754943212383 + 749925586269 - 1504868745025,
									436653531851 + 64731529758 - 501385005587,
									943138443703 + 956867931069 - 1900006369351,
									687441045312 + 205771981407 - 893212999278,
									930780836273 + 378101943984 - 1308882767486,
									565428601095 + 626867187491 - 1192295773420,
									946011026360 + 1080840283639 - 2026851279914,
									315081953938 + 876163178391 - 1190996130077,
									558021756163 + 432334528713 - 990111761815
								for Ie = 1, #iC do
									local HF = iC[Ie]
									local tV = (
										tN
										+ HF.H_ % 65521 * (1 + (Ie + Dl) % 65521)
										+ HF.au % 65521 * (1 + (Ie + pv) % 65521)
									) % 268435456
									HF.H_ = nil
									HF.au = nil
									local Pe = Ie * Tn % 65521
									local eG = tM[Ie]
									for Yj = 1, #eG do
										local Pp = eG[Yj]
										Pe = (
											Pe * tw
											+ HF.RXsS[Pp] * yo
											+ HF.AX[Pp] * pj
											+ HF.hgrc[Pp] * iX
											+ HF.UMog[Pp] * BF
											+ Pp * je
										) % 65521
									end
									Pe += 1
									eB = (eB * 257 + Pe) % 268435456
									local Pp = 2 * ((Xj + Pe * Dl + Ie * KA) % 16000000) + 1
									local Yj = (Tz + Pe * pv + Ie * dr) % 268435456
									local kg = (Hz + Pe * iE + Ie * xx) % 268435456
									local oO = 3 + (Pe * Ew + Ie * OR) % 7
									local Hj = (IB + Ie * jZ) % 24
									local nx = { 0, 1, 2, 3 }
									local xQ = {}
									local bv = { 6, 2, 1, 1 }
									for aT = 1, 4 do
										local wj = aT == 4 and 0 or AG(Hj / bv[aT])
										if aT < 4 then
											Hj %= bv[aT]
										end
										xQ[aT] = nx[wj + 1]
										for io = wj + 1, #nx - 1 do
											nx[io] = nx[io + 1]
										end
										nx[#nx] = nil
									end
									local wj = 1
									for aT = 1, 4 do
										if xQ[aT] == 1 then
											wj = aT
											break
										end
									end
									local aT = (LB + Ie * rH + tV % 720 * (1 + cw % 719)) % 720
									local io = { 0, 1, 2, 3, 4, 5 }
									local wW = {}
									local Gz = { 120, 24, 6, 2, 1, 1 }
									for nH = 1, 6 do
										local ml = nH == 6 and 0 or AG(aT / Gz[nH])
										if nH < 6 then
											aT %= Gz[nH]
										end
										wW[nH] = io[ml + 1]
										for TD = ml + 1, #io - 1 do
											io[TD] = io[TD + 1]
										end
										io[#io] = nil
									end
									local ml = lF[Ie]
									local nH = #ml
									local TD, Mk, mn = {}, {}, {}
									for sl = 1, nH do
										local nn = ml[sl]
										local zl = sl < nH and ml[sl + 1] - 1 or #HF.N_Gl
										TD[sl] = zl - nn + 1
										mn[nn] = sl
										Mk[sl] = sl > 1 and Mk[sl - 1] + TD[sl - 1] * 5 or 1
									end
									local zl = { HF.RXsS, HF.AX, HF.hgrc, HF.UMog }
									local nn, sl = HF.N_Gl, zl[wj]
									local vG = {}
									for kc = 1, #nn do
										if nn[kc] == 29 or nn[kc] == 84 or nn[kc] == 148 or nn[kc] == 196 then
											local zw = sl[kc] + 1
											local YP = (zw * GM + Pe * RW + Ie * mo + tV % 65521 * mo) % 65521
											sl[kc] = YP
											vG[#vG + 1] = YP
											vG[#vG + 1] = zw
										end
									end
									local kc = {}
									local YP = 1
									for zw = 1, nH do
										local Nm = ml[zw]
										local QZ = (
											an
											+ Ie * Dh
											+ Nm * kg
											+ mv
											+ Pe * dD
											+ tV % 65521 * ((Ie * KA + Pe * Dl + Nm * br) % 65521) % 268435456
											+ (251490015861 + 1066184984560 - 1317447643683)
										) % 268435456
										for Mo = Nm, Nm + TD[zw] - 1 do
											QZ = (Pp * QZ + Yj) % 268435456
											kc[YP] = (
												HF.N_Gl[Mo]
												+ (65662646814 + 809113135992 - 874775769653)
												+ QZ % 65536
											) % 65536
											YP += 1
											QZ = (Pp * QZ + Yj) % 268435456
											kc[YP] = (
												HF.UMog[Mo]
												+ (215306716260 + 486594860258 - 701901525012)
												+ QZ % 65536
											) % 65536
											YP += 1
											QZ = (Pp * QZ + Yj) % 268435456
											kc[YP] = (
												HF.RXsS[Mo]
												+ (282599755907 + 831563226499 - 1114162925922)
												+ QZ % 65536
											) % 65536
											YP += 1
											QZ = (Pp * QZ + Yj) % 268435456
											kc[YP] = (
												HF.hgrc[Mo]
												+ (943387518903 + 885349010332 - 1828736473609)
												+ QZ % 65536
											) % 65536
											YP += 1
											QZ = (Pp * QZ + Yj) % 268435456
											kc[YP] = (
												HF.AX[Mo]
												+ (974879393221 + 405033032380 - 1379912394755)
												+ QZ % 65536
												+ Pe
											) % 65536
											YP += 1
											if (Mo - Nm + 1) % oO == 0 then
												QZ = (QZ + Pe * qI + Mo * br) % 268435456
											end
										end
									end
									local QZ = (an + Ie * Dh + mv) % 268435456
									local Nm = HF.kh
									local zw = 0
									for Mo in pairs(Nm) do
										if Mo > zw then
											zw = Mo
										end
									end
									local Mo, za, pM, lr, mV = {}, {}, {}, {}, {}
									local fT = 1
									for Kw = 1, zw do
										mV[Kw] = fT
										local cW = (
											an
											+ Ie * Dh
											+ mv
											+ Pe * JA
											+ tV % 65521 * ((Ie * dr + Kw * fp + Pe) % 65521) % 268435456
											+ (475014779613 + 222941067879 - 697908495809)
										) % 268435456
										local pr = Nm[Kw]
										local rM = Bf(pr)
										local fW = (cW + Kw * IF) % 268435456
										fW = (Xj * fW + Tz) % 268435456
										fW = (Xj * fW + Tz) % 268435456
										local mC = rM == "string" and dT or iW
										local qG = (cW + Kw * mC) % 268435456
										qG = (Xj * qG + Tz) % 268435456
										qG = (Xj * qG + Tz) % 268435456
										if rM == "number" then
											if pr % 1 == 0 and pr > -1125899906842624.0 and pr < 1125899906842624.0 then
												Mo[Kw] = (wW[2] + fW) % 65536
												za[Kw] = pr + qG
											else
												local iL = MP(pr)
												Mo[Kw] = (wW[6] + fW) % 65536
												lr[Kw] = #iL
												for xC = 1, #iL do
													qG = (Xj * qG + Tz) % 268435456
													pM[fT] = (rq(iL, xC) + qG % 256) % 256
													fT += 1
												end
											end
										elseif rM == "string" then
											Mo[Kw] = (wW[3] + fW) % 65536
											lr[Kw] = #pr
											for iL = 1, #pr do
												qG = (Xj * qG + Tz) % 268435456
												pM[fT] = (rq(pr, iL) + qG % 256) % 256
												fT += 1
											end
										elseif rM == "boolean" then
											if pr then
												Mo[Kw] = (wW[4] + fW) % 65536
											else
												Mo[Kw] = (wW[5] + fW) % 65536
											end
										else
											Mo[Kw] = (wW[1] + fW) % 65536
										end
									end
									local qG = (Pe * cw + Ie * qt + AV + tV % 65536 * ((Ie + cw) % 65536)) % 65536
									local mC = {}
									for fW = 1, #HF.rNOk do
										qG = (qG * Qb + AV + fW) % 65536
										mC[fW] = (HF.rNOk[fW] + qG) % 65536
									end
									local fW = (
										HF.xeKZ + (Pe * wi + Ie * fp + AV + tV % 65536 * ((Ie + fp) % 65536)) % 65536
									) % 65536
									qG = nil
									jJ[Ie] = {
										ks = ml,
										Klw = TD,
										xl = Mk,
										tqp = mn,
										Mz = kc,
										mt = (Ie + VD) % 65521,
										roud = HF.roud,
										QGWt = hl[Ie],
										IW = mC,
										DEzQ = fW,
										Iq = vG,
										Zx = zw,
										aC = Mo,
										dU = za,
										xUs = pM,
										Yvl = lr,
										ClYE = mV,
										DI = HF.DI,
										lbY = HF.lbY,
									}
								end
								for fW = 1, #jJ do
									local mC = jJ[fW].Iq
									for qG = 1, #mC, 2 do
										jJ[fW][mC[qG]] = jJ[mC[qG + 1]]
										mC[qG] = nil
										mC[qG + 1] = nil
									end
									jJ[fW].Iq = nil
								end
								return jJ[#jJ], mv, eB
							elseif 36 == Hl then
								do
									local dT = oG[1]
									local iW = 2
									if (dT.RXsS[iW] + dT.hgrc[iW] + iW) % 2 == 0 then
										dT.N_Gl[iW] = FA
									end
								end
								do
									local iW = oG[1]
									local dT = 8
									if (iW.RXsS[dT] + iW.hgrc[dT] + dT) % 2 == 0 then
										iW.N_Gl[dT] = FA
									end
								end
								do
									local dT = oG[2]
									local iW = 7
									if (dT.RXsS[iW] + dT.hgrc[iW] + iW) % 2 == 0 then
										dT.N_Gl[iW] = FA
									end
								end
								do
									local iW = oG[2]
									local dT = 9
									if (iW.RXsS[dT] + iW.hgrc[dT] + dT) % 2 == 0 then
										iW.N_Gl[dT] = FA
									end
								end
								do
									local dT = oG[2]
									local iW = 23
									if (dT.RXsS[iW] + dT.hgrc[iW] + iW) % 2 == 0 then
										dT.N_Gl[iW] = FA
									end
								end
							elseif Hl == 136 then
								local iW = 1
								while iW <= #qs do
									local dT = Fp(qs[iW], iW)
									oG[iW] = dT
									local mo = (dT.rZ - Rb[iW]) % 4294967296
									local RW = (dT.Kx - jg[iW]) % 4294967296
									dT.H_ = (
										mo % 65536 * (1 + (an + iW * Xj) % 65521)
										+ AG(mo / 65536) * (1 + (Dh + iW * Tz) % 65521)
									) % 268435456
									dT.au = (
										RW % 65536 * (1 + (Dh + iW * Xj) % 65521)
										+ AG(RW / 65536) * (1 + (an + iW * Tz) % 65521)
									) % 268435456
									iW += 1
								end
							else
								tN = (tN + PW) % 268435456
							end
							EA += 1
						end
					end
				end
				local jg = (function(Fp)
					local jg = (192180070 + 0) % 268435456
					for Rb = 1, #Fp do
						jg = (jg * 32285 + #Fp[Rb] + Rb * 42893 + 76083425) % 268435456
					end
					return (69918720 + jg) % 268435456
				end)(c)
				local Rb = (function(Fp)
					local Rb = (235993328 + 0) % 268435456
					for MP = 1, #Fp do
						Rb = (Rb * 9628 + #Fp[MP] + MP * 58073 + 67670336) % 268435456
					end
					return (165825438 + Rb) % 268435456
				end)(c)
				local MP = (function(Fp)
					local MP = (102727501 + 0) % 268435456
					for Bf = 1, #Fp do
						MP = (MP * 53633 + #Fp[Bf] + Bf * 30181 + 246838260) % 268435456
					end
					return (238335009 + MP) % 268435456
				end)(c)
				RQ = function(
					Fp,
					Bf,
					Gr,
					mB,
					rL,
					EN,
					SQ,
					QH,
					gR,
					GF,
					MZ,
					wr,
					MQ,
					AG,
					iU,
					rq,
					EA,
					tN,
					xB,
					gb,
					oG,
					IF,
					Hz,
					Tz,
					Xj,
					Dh,
					an,
					FA,
					qs,
					Hl,
					iW,
					RW,
					mo,
					dT,
					GM,
					VD,
					fp,
					wi,
					AV,
					Qb,
					qt
				)
					local cw = SQ[29]
					local br = (FA * Hl + qs * iW + RW) % 268435456
					local qI = (FA * mo + qs * dT + GM) % 268435456
					local OR = EN
					local Ew = 101354040367 + 733650589525 - 835004593027
					local rH = 667986582839 + 102344065071 - 770330635755
					local LB = 181632115796 + 58141730843 - 239773846637
					local jZ, IB = 605815441690 + 705933492552 - 1311748928164, 51250978839 + 34837083152 - 86088057311
					local xx = 307706039439 + 1075161775604 - 1382867815029
					local iE, dr =
						315081953938 + 876163178391 - 1190996130077, 558021756163 + 432334528713 - 990111761815
					local pv, KA, Dl, JA, dD, Tn, je, BF, iX, pj, yo, tw, tM, hl, lF, mv, eB, jJ, iC =
						144621476419 + 223963488360 - 368584904954,
						543222345980 + 732563644757 - 1275785945582,
						186235167318 + 150692945478 - 336928065246,
						829753438594 + 18657765384 - 848411141509,
						128969735740 + 63277440541 - 192247157312,
						22030415370 + 202436278366 - 224466689437,
						441756972749 + 122322513464 - 564079486195,
						252606310005 + 1074749873652 - 1327356183652,
						9710521348 + 344622581920 - 354333096574,
						765235260260 + 578112892173 - 1343348130820,
						482305137888 + 292104491144 - 774409585399,
						38777413650 + 455743827156 - 494521211843,
						1085727557625 + 933196201394 - 2018923727661,
						421959161540 + 1037293798371 - 1459252913634,
						548923876607 + 1073241580019 - 1622165453849,
						754943212383 + 749925586269 - 1504868745025,
						436653531851 + 64731529758 - 501385005587,
						943138443703 + 956867931069 - 1900006369351,
						687441045312 + 205771981407 - 893212999278
					local mC =
						{ 556818056451 + 602661975832 - 1159480027202, 217587719781 + 641753047850 - 859340711967 }
					local fW = 0
					for qG = 1, #mC do
						fW = (fW * 257 + mC[qG]) % 268435456
					end
					local qG = (fW - MP) % 268435456
					local fT = (
						AV * (937631703988 + 123337463353 - 1060968920732) + (
							866740754323
							+ 926003450287
							- 1792522269901
						)
					) % 268435456
					EN = (EN + fT) % 268435456
					EN = (EN + qt * (480655085279 + 906763840934 - 1387418886101)) % 268435456
					local mV, lr, pM, za, Mo
					local zw = { 152, 99, 22, 51, 103 }
					local Nm = 0
					Nm = (Nm * 257 + 155) % 268435456
					Nm = (Nm * 257 + 31) % 268435456
					for QZ = 1, #zw do
						Nm = (Nm * 257 + zw[QZ]) % 268435456
					end
					local QZ = (Nm - Rb) % 268435456
					local YP = 1
					while YP <= #zw do
						local kc = (zw[YP] - (155 + YP * 31) % 256) % 256
						if kc == 28 then
							pM = function(vG, sl, nn, zl, mn)
								local Mk = (vG.mt - iC - 1) % 65521 + 1
								local TD = (mC[Mk] * eB + Mk * jJ + lF) % 65521
								local nH = (
									br % 65521 * ((Mk + pv) % 65521)
									+ qI % 65521 * ((mC[Mk] + Dl) % 65521)
									+ qG % 65521 * ((Mk + jJ) % 65521)
									+ QZ % 65521 * ((mC[Mk] + pj) % 65521)
									+ wi % 65521 * ((Mk + lF) % 65521)
								) % 268435456
								local ml, Gz, wW, io, aT, wj, bv, xQ, nx, Hj, oO, kg, Yj, Pp, eG =
									SQ[60],
									SQ[38],
									SQ[9],
									SQ[58],
									SQ[70],
									SQ[29],
									SQ[50],
									SQ[77],
									SQ[26],
									SQ[17],
									SQ[12],
									SQ[67],
									SQ[16],
									SQ[18],
									SQ[59]
								local Pe = mV(vG, Pp, kg, bv)
								local tV = vG.roud
								local HF = {}
								local Ie = {
									sl,
									Pe,
									tV,
									HF,
									QH,
									zl,
									(mn + TD) % 65536,
									nn,
									za,
									iU,
									rq,
									EA,
									tN,
									Pp,
									GF,
									eG,
									wW,
									xQ,
									io,
									ml,
									gR,
									MZ,
									wr,
									MQ,
									sW = 1,
									bX = 0,
									Ao = nil,
									Tj = nil,
									VQz = TD,
									rp = xx,
									xT = 25 + TD % 4096 * 2048,
									LJ = 1305 + TD % 4096 * 2048,
									NDWY = AG,
									lS = 0,
									Rz_ = 2 + (mC[Mk] * iX + Mk * pj + TD) % 15,
									PZ = nH,
									eX = 4,
									jE = (Mk * 1 + 2) % 4,
								}
								Ie.mK = vG
								Ie.tqp = vG.tqp
								Ie.XPT = {}
								Ie.Se = {}
								Ie.oc = 0
								Ie.qEK = 0
								Ie._b = lr
								lr(Ie, 1)
								return Ie
							end
						elseif 222 == kc then
							mV = function(Ie, HF, tV, Pe)
								local eG = (Ie.mt - iC - 1) % 65521 + 1
								local Pp, Yj, kg, oO, Hj = Ie.aC, Ie.dU, Ie.xUs, Ie.Yvl, Ie.ClYE
								local nx = (
									994017723342
									+ 641598967082
									- 1635616689774
									+ eG * (679720485692 + 261080399993 - 940800885602)
									+ qI % 720 * (1 + eB % 719)
									+ qG % 720 * (1 + jJ % 719)
									+ QZ % 720 * (1 + hl % 719)
									+ wi % 720 * (1 + lF % 719)
								) % 720
								local xQ = { 0, 1, 2, 3, 4, 5 }
								local bv = {}
								local wj = { 120, 24, 6, 2, 1, 1 }
								for aT = 1, 6 do
									local io = aT == 6 and 0 or GF(nx / wj[aT])
									if aT < 6 then
										nx %= wj[aT]
									end
									bv[aT] = xQ[io + 1]
									for wW = io + 1, #xQ - 1 do
										xQ[wW] = xQ[wW + 1]
									end
									xQ[#xQ] = nil
								end
								local io = Qb(eG)
								local aT = (
									qI % 65521 * ((eG + Dl) % 65521)
									+ qG % 65521 * ((mC[eG] + JA) % 65521)
									+ QZ % 65521 * ((eG + eB) % 65521)
									+ wi % 65521 * ((mC[eG] + jJ) % 65521)
								) % 268435456
								local wW = (
									Fp
									+ eG * Bf
									+ OR
									+ mC[eG] * rH
									+ aT
									+ (
											io * (407993143997 + 884288830875 - 1292281088337)
											+ (265741684859 + 714220229964 - 979868081519)
										)
										% 268435456
								) % 268435456
								local Gz = ("")["char"]
								local ml = {}
								local nH = {}
								local TD = {}
								TD.__index = function(Mk, mn)
									if nH[mn] then
										return rawget(Mk, mn)
									end
									if Pp[mn] == nil then
										nH[mn] = true
										return nil
									end
									local zl = (wW + mn * VD) % 268435456
									zl = (Gr * zl + mB) % 268435456
									zl = (Gr * zl + mB) % 268435456
									local nn = (Pp[mn] - zl) % 65536
									local sl = nn == bv[3] and dr or iE
									local vG = (wW + mn * sl) % 268435456
									vG = (Gr * vG + mB) % 268435456
									vG = (Gr * vG + mB) % 268435456
									local rM
									if nn == bv[2] then
										rM = Yj[mn] - vG
									elseif nn == bv[3] or nn == bv[6] then
										local pr = oO[mn]
										local cW = Hj[mn]
										local Kw = ""
										for iL = 1, pr do
											vG = (Gr * vG + mB) % 268435456
											Kw = Kw .. Gz((kg[cW] - vG % 256) % 256)
											cW += 1
										end
										if nn == bv[3] then
											return Kw
										else
											rM = Pe(Kw)
										end
									elseif nn == bv[4] then
										rM = true
									elseif nn == bv[5] then
										rM = false
									end
									nH[mn] = true
									rawset(Mk, mn, rM)
									return rM
								end
								return setmetatable(ml, TD)
							end
						elseif 49 == kc then
							Mo = function(TD, nH, ml, Gz, wW)
								local aT = pM(TD, nH, ml, Gz, wW)
								local io = 0
								local wj = an and an() or 0
								local bv = 0
								local xQ = nil
								local nx = 0
								while true do
									aT.bX = 1013754270680 + 67894198815 - 1081648469479
									if aT.Ao ~= nil then
										local Hj = (aT.Ao - aT.VQz) % 17
										local oO = Hj == 1 and Hz or Hj == 2 and Tz or Hj == 3 and Xj or Dh
										aT.Ao = nil
										oO(aT)
									else
										local oO = io % 4
										local Hj = oO == 0 and xB or oO == 1 and gb or oO == 2 and oG or IF
										Hj(aT)
										io += 1
									end
									aT.lS += 1
									if aT.lS == aT.Rz_ then
										aT.jE = (
											aT.jE + GF((aT.PZ + 268435455) / 268435456) * (1 + aT.PZ % (aT.eX - 1))
										) % aT.eX
									end
									if an and io % 128 == 0 then
										local Hj = an()
										local oO = Hj - wj
										wj = Hj
										bv += 1
										if bv <= 4 then
											if not xQ or oO < xQ then
												xQ = oO
											end
										else
											if xQ and xQ > 0 and oO > xQ * 100 then
												nx += 1
											else
												nx = 0
											end
											if nx >= 2 then
												aT.PZ = (aT.PZ + (aT.VQz % 65521 * jZ + IB + aT.lS * iX) % 268435456)
													% 268435456
												aT.Rz_ = aT.lS + 2 + aT.VQz % 7
												nx = 0
											end
										end
									end
									if aT.Tj ~= nil then
										local oO = aT[aT.LJ + 2 * aT.rp]
										local Hj = aT[aT.LJ + 3 * aT.rp]
										local kg = { aT.tVN, aT.eXa, aT.uWE, aT.we, aT.fL }
										for Yj = 1, 5 do
											local Pp = kg[Yj]
											if Pp then
												for eG = 1, #Pp do
													Pp[eG] = nil
												end
											end
										end
										if aT.Se then
											for Pp = 1, #aT.Se do
												local Yj = aT.XPT[aT.Se[Pp]]
												if Yj then
													for eG = 1, 5 do
														local Pe = Yj[eG]
														if Pe then
															for tV = 1, #Pe do
																Pe[tV] = nil
															end
															Yj[eG] = nil
														end
													end
												end
											end
										end
										aT.XPT = {}
										aT.Se = {}
										aT.tVN, aT.eXa, aT.uWE, aT.we, aT.fL = nil, nil, nil, nil, nil
										aT.qEK = nil
										aT.oc = nil
										for Yj = 0, 3 do
											aT[aT.LJ + Yj * aT.rp] = nil
										end
										return gR(oO, 1, Hj)
									end
								end
							end
						elseif 138 == kc then
							lr = function(nx, xQ)
								local bv = nx.mK
								local wj = (bv.mt - iC - 1) % 65521 + 1
								nx.oc += 1
								local io = (nx.oc * jZ + xQ * IB + wj) % 65536
								local aT = nx.XPT[xQ]
								if aT then
									local wW = aT[8]
									for Gz = 1, #aT[1] do
										aT[1][Gz] = (aT[1][Gz] - wW + io) % 256
										aT[2][Gz] = (aT[2][Gz] - wW + io) % 65536
										aT[3][Gz] = (aT[3][Gz] - wW + io) % 65536
										aT[4][Gz] = (aT[4][Gz] - wW + io) % 65536
										aT[5][Gz] = (aT[5][Gz] - wW + io) % 65536
									end
									aT[8] = io
									nx.tVN, nx.eXa, nx.uWE, nx.we, nx.fL = aT[1], aT[3], aT[5], aT[4], aT[2]
									nx.pbB, nx.UU = aT[6], aT[7]
									nx.qEK = io
									return
								end
								if LB == 0 and nx.tVN then
									local wW = { nx.tVN, nx.eXa, nx.uWE, nx.we, nx.fL }
									for Gz = 1, 5 do
										local ml = wW[Gz]
										if ml then
											for nH = 1, #ml do
												ml[nH] = nil
											end
										end
									end
									nx.tVN, nx.eXa, nx.uWE, nx.we, nx.fL = nil, nil, nil, nil, nil
								end
								local wW = mC[wj]
								local ml = 2 * ((Gr + wW * pv + wj * KA) % 16000000) + 1
								local Gz = (mB + wW * Dl + wj * JA) % 268435456
								local nH = (rL + wW * dD + wj * Tn) % 268435456
								local TD = 3 + (wW * iX + wj * pj) % 7
								local kg = bv.ks[xQ]
								local Hj = bv.Klw[xQ]
								local oO = (
									br % 65521 * ((wj + pv) % 65521)
									+ qG % 65521 * ((wW + JA) % 65521)
									+ QZ % 65521 * ((xQ + pj) % 65521)
									+ wi % 65521 * ((kg + iX) % 65521)
									+ nx.PZ % 65521 * ((kg + wj + tw) % 65521)
								) % 268435456
								local Yj = (Fp + wj * Bf + kg * nH + EN + mC[wj] * Ew + oO) % 268435456
								local Pp, Pe, eG, tV, HF = {}, {}, {}, {}, {}
								local Ie = bv.Mz
								local rM = bv.xl[xQ]
								for vG = 1, Hj do
									Yj = (ml * Yj + Gz) % 268435456
									Pp[vG] = (Ie[rM] - Yj % 65536 - (65662646814 + 809113135992 - 874775769653)) % 65536
									rM += 1
									Yj = (ml * Yj + Gz) % 268435456
									HF[vG] = (Ie[rM] - Yj % 65536 - (215306716260 + 486594860258 - 701901525012))
										% 65536
									rM += 1
									Yj = (ml * Yj + Gz) % 268435456
									Pe[vG] = (Ie[rM] - Yj % 65536 - (282599755907 + 831563226499 - 1114162925922))
										% 65536
									rM += 1
									Yj = (ml * Yj + Gz) % 268435456
									tV[vG] = (Ie[rM] - Yj % 65536 - (943387518903 + 885349010332 - 1828736473609))
										% 65536
									rM += 1
									Yj = (ml * Yj + Gz) % 268435456
									eG[vG] = (
										Ie[rM]
										- Yj % 65536
										- (974879393221 + 405033032380 - 1379912394755)
										- mC[wj]
									) % 65536
									rM += 1
									if vG % TD == 0 then
										Yj = (Yj + wW * yo + (kg + vG - 1) * tw) % 268435456
									end
								end
								local vG = (je + wj * BF) % 24
								local sl = { 0, 1, 2, 3 }
								local nn = {}
								local zl = { 6, 2, 1, 1 }
								for mn = 1, 4 do
									local Mk = mn == 4 and 0 or GF(vG / zl[mn])
									if mn < 4 then
										vG %= zl[mn]
									end
									nn[mn] = sl[Mk + 1]
									for Kw = Mk + 1, #sl - 1 do
										sl[Kw] = sl[Kw + 1]
									end
									sl[#sl] = nil
								end
								local Mk = { Pe, eG, tV, HF }
								local mn = {}
								for Kw = 1, 4 do
									mn[nn[Kw] + 1] = Mk[Kw]
								end
								local Kw, cW, pr, iL, xC = Pp, mn[1], mn[2], mn[3], mn[4]
								for dX = 1, #Kw do
									Kw[dX] = (Kw[dX] + io) % 256
									cW[dX] = (cW[dX] + io) % 65536
									pr[dX] = (pr[dX] + io) % 65536
									iL[dX] = (iL[dX] + io) % 65536
									xC[dX] = (xC[dX] + io) % 65536
								end
								local dX = { Kw, xC, cW, iL, pr, kg, kg + Hj - 1, io }
								if LB > 0 then
									nx.XPT[xQ] = dX
									nx.Se[#nx.Se + 1] = xQ
									if #nx.Se > LB then
										local Lo = nx.Se[1]
										for Vm = 1, #nx.Se - 1 do
											nx.Se[Vm] = nx.Se[Vm + 1]
										end
										nx.Se[#nx.Se] = nil
										local Vm = nx.XPT[Lo]
										nx.XPT[Lo] = nil
										if Vm then
											for qU = 1, 5 do
												local RJ = Vm[qU]
												if RJ then
													for Bj = 1, #RJ do
														RJ[Bj] = nil
													end
													Vm[qU] = nil
												end
											end
										end
									end
								end
								nx.tVN, nx.eXa, nx.uWE, nx.we, nx.fL = Kw, cW, pr, iL, xC
								nx.pbB, nx.UU = kg, kg + Hj - 1
								nx.qEK = io
							end
						elseif kc == 30 then
							za = function(dX, xC, iL, pr)
								local cW = (dX.mt - iC - 1) % 65521 + 1
								local Kw = mC[cW]
								local mn = (Kw * tM + cW * hl + mv) % 65536
								local Mk = dX.IW
								local zl = {}
								for nn = 1, #Mk do
									mn = (mn * lF + mv + nn) % 65536
									local sl = (Mk[nn] - mn) % 65536
									if sl >= 49152 then
										zl[nn] = iL[sl - 49152]
									elseif sl >= 32768 then
										zl[nn] = { ir = xC[pr[sl - 32768]], PRAd = 1 }
									else
										zl[nn] = { ir = xC, PRAd = pr[sl] }
									end
									sl = nil
								end
								local sl = (dX.DEzQ - (Kw * eB + cW * jJ + mv) % 65536) % 65536
								local nn = (Kw * eB + cW * jJ + lF) % 65521
								Mk = nil
								mn = nil
								return function(...)
									local vG = cw("#", ...)
									local rM = { ... }
									local Ie = vG - sl
									if Ie < 0 then
										Ie = 0
									end
									local HF = {}
									for tV = 1, Ie do
										HF[1 + (tV + nn - 1) % Ie] = rM[sl + tV]
									end
									local tV = {}
									for eG = 1, sl do
										tV[dX.roud[eG]] = rM[eG]
									end
									local eG = pM(dX, tV, zl, HF, Ie)
									local Pe = 0
									local Pp = an and an() or 0
									local Yj = 0
									local oO = nil
									local Hj = 0
									while true do
										eG.bX = 1013754270680 + 67894198815 - 1081648469479
										if eG.Ao ~= nil then
											local kg = (eG.Ao - eG.VQz) % 17
											local TD = kg == 1 and Hz or kg == 2 and Tz or kg == 3 and Xj or Dh
											eG.Ao = nil
											TD(eG)
										else
											local TD = Pe % 4
											local kg = TD == 0 and xB or TD == 1 and gb or TD == 2 and oG or IF
											kg(eG)
											Pe += 1
										end
										eG.lS += 1
										if eG.lS == eG.Rz_ then
											eG.jE = (
												eG.jE + GF((eG.PZ + 268435455) / 268435456) * (1 + eG.PZ % (eG.eX - 1))
											) % eG.eX
										end
										if an and Pe % 128 == 0 then
											local kg = an()
											local TD = kg - Pp
											Pp = kg
											Yj += 1
											if Yj <= 4 then
												if not oO or TD < oO then
													oO = TD
												end
											else
												if oO and oO > 0 and TD > oO * 100 then
													Hj += 1
												else
													Hj = 0
												end
												if Hj >= 2 then
													eG.PZ = (
														eG.PZ + (eG.VQz % 65521 * jZ + IB + eG.lS * iX) % 268435456
													) % 268435456
													eG.Rz_ = eG.lS + 2 + eG.VQz % 7
													Hj = 0
												end
											end
										end
										if eG.Tj ~= nil then
											local TD = eG[eG.LJ + 2 * eG.rp]
											local kg = eG[eG.LJ + 3 * eG.rp]
											local nH = { eG.tVN, eG.eXa, eG.uWE, eG.we, eG.fL }
											for Gz = 1, 5 do
												local ml = nH[Gz]
												if ml then
													for wW = 1, #ml do
														ml[wW] = nil
													end
												end
											end
											if eG.Se then
												for ml = 1, #eG.Se do
													local Gz = eG.XPT[eG.Se[ml]]
													if Gz then
														for wW = 1, 5 do
															local aT = Gz[wW]
															if aT then
																for io = 1, #aT do
																	aT[io] = nil
																end
																Gz[wW] = nil
															end
														end
													end
												end
											end
											eG.XPT = {}
											eG.Se = {}
											eG.tVN, eG.eXa, eG.uWE, eG.we, eG.fL = nil, nil, nil, nil, nil
											eG.qEK = nil
											eG.oc = nil
											for Gz = 0, 3 do
												eG[eG.LJ + Gz * eG.rp] = nil
											end
											return gR(TD, 1, kg)
										end
									end
								end
							end
						else
							EN = (EN + jg) % 268435456
							OR = (OR + jg) % 268435456
						end
						YP += 1
					end
					zw = nil
					return Mo
				end
				Kg = (
					(function(YP)
						local QZ = (240689680 + 0) % 268435456
						for Nm = 1, #YP do
							QZ = (QZ * 43203 + #YP[Nm] + Nm * 8640 + 143219753) % 268435456
						end
						return (72416991 + QZ) % 268435456
					end)(c) + Ja
				) % 268435456
				Kj = (
					(function(QZ)
						local YP = (73984559 + 0) % 268435456
						for Nm = 1, #QZ do
							YP = (YP * 10807 + #QZ[Nm] + Nm * 39308 + 180589935) % 268435456
						end
						return (172813892 + YP) % 268435456
					end)(c) + Ja
				) % 268435456
				CQ = (
					(function(YP)
						local QZ = (83758300 + 0) % 268435456
						for Nm = 1, #YP do
							QZ = (QZ * 46585 + #YP[Nm] + Nm * 16438 + 155254537) % 268435456
						end
						return (109161761 + QZ) % 268435456
					end)(c) + Ja
				) % 268435456
				ei = (
					(function(QZ)
						local YP = (110722544 + 0) % 268435456
						for Nm = 1, #QZ do
							YP = (YP * 33817 + #QZ[Nm] + Nm * 59231 + 165593707) % 268435456
						end
						return (130095992 + YP) % 268435456
					end)(c) + Ja
				) % 268435456
				ri = (
					(function(YP)
						local QZ = (93120418 + 0) % 268435456
						for Nm = 1, #YP do
							QZ = (QZ * 15820 + #YP[Nm] + Nm * 54559 + 263893787) % 268435456
						end
						return (244508241 + QZ) % 268435456
					end)(c) + Ja
				) % 268435456
				jt = (function(QZ)
					local YP = (247267416 + 0) % 268435456
					for Nm = 1, #QZ do
						YP = (YP * 32203 + #QZ[Nm] + Nm * 26354 + 210215654) % 268435456
					end
					return (182737309 + YP) % 268435456
				end)(c)
				NC = (function(YP)
					local QZ = (191190838 + 0) % 268435456
					for Nm = 1, #YP do
						QZ = (QZ * 39652 + #YP[Nm] + Nm * 6334 + 96563204) % 268435456
					end
					return (10543484 + QZ) % 268435456
				end)(c)
				BL = (function(QZ)
					local YP = (89194639 + 0) % 268435456
					for Nm = 1, #QZ do
						YP = (YP * 19270 + #QZ[Nm] + Nm * 28334 + 148563116) % 268435456
					end
					return (62000178 + YP) % 268435456
				end)(c)
				TJ = (function(YP)
					local QZ = (36980803 + 0) % 268435456
					for Nm = 1, #YP do
						QZ = (QZ * 1367 + #YP[Nm] + Nm * 5774 + 120150113) % 268435456
					end
					return (60326780 + QZ) % 268435456
				end)(c)
				vy = (function(QZ)
					local YP = (218080443 + 0) % 268435456
					for Nm = 1, #QZ do
						YP = (YP * 64625 + #QZ[Nm] + Nm * 55958 + 145324536) % 268435456
					end
					return (156685434 + YP) % 268435456
				end)(c)
				Cm = (function(YP)
					local QZ = (205374499 + 0) % 268435456
					for Nm = 1, #YP do
						QZ = (QZ * 10631 + #YP[Nm] + Nm * 47705 + 140859785) % 268435456
					end
					return (147516521 + QZ) % 268435456
				end)(c)
				local QZ = 117478689
				local Nm = {
					[QZ] = {
						Kg,
						Kj,
						CQ,
						ei,
						ri,
						(function(YP)
							local Nm = (172914473 + 0) % 268435456
							for zw = 1, #YP do
								Nm = (Nm * 5723 + #YP[zw] + zw * 20150 + 131309017) % 268435456
							end
							return (20287260 + Nm) % 268435456
						end)(c),
						ns,
						PP,
					},
				}
				local zw = function(YP)
					local zw = Nm[YP]
					Nm[YP] = nil
					return zw[1], zw[2], zw[3], zw[4], zw[5], zw[6], zw[7], zw[8]
				end
				local YP, Mo = d(function()
					return AW(Q, t, D, c, Fq, CS, c, QZ, vC, TE, Px, nL, c, ms, RD, M, wT, c, g, gU, et, TH, c, Dv, zw)
				end)
				AW = nil
				ns = nil
				if not YP then
					qX()
				end
				cf, fA, jY, FJ, pH, kS, vr = Mo()
				Mo = nil
				local za = cX()
				cX = nil
				Lw, CM = za[1], za[2]
				local pM, lr = d(RY)
				RY = nil
				Gq = (pM and lr or 12345679) % 268435456
				My[267] = vr
				for mV, fT in pairs(cf) do
					if mV < 256 then
						My[(mV + Ja) % 256] = fT
					end
				end
				local fT = 0
				local mV
				local qG = (jY % 256 + kS % 256 * (111986207796 + 487074381026 - 599060588575) + 0 * 17) % 256
				local fW = 710309811018 + 194287119962 - 904596930929
				do
					local mC =
						'\179X;%\219G\28\251nK;JS\151\134J>\0011\218t\29\240\176\204`\209\161\239\243\131\\\2256\169)\215WX=B\204e\250$\230m\241o[\159-\28\18\244\151#\132P7\6\2233.\176-\12\252\245Ep\250\149\242\206\197$\131\23l\230kE#\159\240\154"\222q\233\232c\144\232\175\19\8S!\21k74\226R\155e%7\146\234E\218\2451\7\133\\\136\241e!\232r\210\197<\203kU/\183\174R\198H^@\29\158,]\8S\19{^\237\158\142\248\133\204ctaN\146\7\26\192\4\219\163Q\1488\218\155P\135q\246\204\211v\232\27?\132\249\179\159\165$1\172O\180\141dm\223=[L\149\233\29\222\243\23\234F\174F\246D\170E\225\202/&\19}.d\174%\9\156\157H\160\252\231@A\143\175\151a\145\254-Q:\20\200\219\200)\27(\8\239-\9\210\2188<\183Zi\221\246\198\214\169b=\25\178m\159\247\213\20/\151\142\190(\25\23\128\242\129\220%g\178jxP\199r\204\170\3'
					local iC = ""
					local jJ = ("")["char"]
					local mv = (function(eB)
						local mv = (197825107 + 0) % 268435456
						for lF = 1, #eB do
							mv = (mv * 39477 + #eB[lF] + lF * 63722 + 36475223) % 268435456
						end
						return (67583116 + mv) % 268435456
					end)(c)
					local lF = (function(eB)
						local lF = (79421618 + 0) % 268435456
						for hl = 1, #eB do
							lF = (lF * 57206 + #eB[hl] + hl * 41475 + 221177505) % 268435456
						end
						return (237506119 + lF) % 268435456
					end)(c)
					local hl = (function(eB)
						local hl = (244422963 + 0) % 268435456
						for tM = 1, #eB do
							hl = (hl * 64878 + #eB[tM] + tM * 63020 + 1366545) % 268435456
						end
						return (75439365 + hl) % 268435456
					end)(c)
					for eB = 1, #mC do
						mv = (lF * mv + hl) % 268435456
						local tM = (
							g(mC, eB) - (mv % 256 + D(mv / 256) % 256 + D(mv / 65536) % 256 + D(mv / 16777216)) % 256
						) % 256
						fT = (fT * 257 + tM) % 268435456
						iC = iC .. jJ((tM + (qG + eB * fW) % 256) % 256)
					end
					mV = iC
					mC = nil
					iC = nil
					mv = nil
					lF = nil
					hl = nil
				end
				local hl
				local lF = (jY % 256 + kS % 256 * (1084126847480 + 631130748709 - 1715257596158) + 1 * 17) % 256
				local mv = 44188557844 + 1072829457907 - 1117018015656
				do
					local jJ =
						"\143YS\147MH\189G\197h5\134S\140\141\199\175(&\174\209\"\171E\199\246\242c*\0278U\24\18*\186t\192\2478\131\142\03006\249\207\163?\185\207bj\27tP\252\172\128?\18#`\188%\4\205 \144\142l\181\232\24\213e)j\156\237\6\26\240.L\248R\198q\155\147:\195'G&\206\25\1338\2\158\4\222\247H\0051\2198E=4\214'\1536\241\138 %zk4$\203\23e\251\163\149\14+H\181\29\187\141\247]\166&\232\253A\12\"\218\174\14f\234\176;\130z3\184.q\240|\241K\204n\149\148\214@D\151\1885\192\7/\219\229w\140B\12q\14f\234\184\248\153I\148\251G\146\169\210_\141g\138\247\253$\2336v\209\130\150HB\216\153\241\19\232\133\12a\165\183\21\235!tk\238W\21j\7\5\164\131\173\203\170\0161\234\222g\194\228\16\137\195XJ\183\215\200r\145j\0000\219\26O\21\255\222Ky\16,Cn?\11\233(G\16Q\176\140\1640\218h\16\165\236\221\151$\149\251\192W\247\129\9\9\8u\167\240"
					local iC = ""
					local mC = ("")["char"]
					local eB = (function(tM)
						local eB = (81459135 + 0) % 268435456
						for tw = 1, #tM do
							eB = (eB * 17609 + #tM[tw] + tw * 7754 + 20019553) % 268435456
						end
						return (208294391 + eB) % 268435456
					end)(c)
					local tw = (function(tM)
						local tw = (141188639 + 0) % 268435456
						for yo = 1, #tM do
							tw = (tw * 2451 + #tM[yo] + yo * 24795 + 9400848) % 268435456
						end
						return (75353277 + tw) % 268435456
					end)(c)
					local yo = (function(tM)
						local yo = (132431480 + 0) % 268435456
						for pj = 1, #tM do
							yo = (yo * 19241 + #tM[pj] + pj * 19661 + 107857453) % 268435456
						end
						return (179407907 + yo) % 268435456
					end)(c)
					for tM = 1, #jJ do
						eB = (tw * eB + yo) % 268435456
						local pj = (
							g(jJ, tM) - (eB % 256 + D(eB / 256) % 256 + D(eB / 65536) % 256 + D(eB / 16777216)) % 256
						) % 256
						fT = (fT * 257 + pj) % 268435456
						iC = iC .. mC((pj + (lF + tM * mv) % 256) % 256)
					end
					hl = iC
					jJ = nil
					iC = nil
					eB = nil
					tw = nil
					yo = nil
				end
				local yo
				local tw = (jY % 256 + kS % 256 * (1064769394159 + 812385099642 - 1877154493556) + 2 * 17) % 256
				local eB = 558940202244 + 786180165998 - 1345120368203
				do
					local mC =
						"\131\181\149R\235\189L\240\229\252\\\218\201v\130\189\5\224\165\201\160O\128\245V\169\19\235\179\28\246\227\214\189\16\165\239\194Z+\149W\23j\176\166\138\9\203\29\181\213 \10q\227_oa\186\168\235\0008\178H\175e\0097\168\221\20\160\133\154q\9)r\1~\231oR\239R\224\222;\2174n\144P\137p|\250\168p.m\224\220\149R\222\128\132\174\255\159d\250bY\238\171-rTT\150\171T!M(\0087\17\180\2223\190\20O\26\178\151\31\184\129r\26\151\206\13\27u\147\226\6\236\15\148\173d\21'\1786{lz\194zIe@\213\11\207\148|\219_\27\221\241]\137o\141\211*\2470\11\16\235\140\200X\240\197\203\0256\1447\200\208H\177\160\152^D\208\0041\16\2549d*\148\252$7\241\227\194\146\19\234\5:3l\230\164I\169\215\202>r\200\221\163\2202A\171\137\234\220\250\220<r\205\208\202\12\233\198\203,q\255y8\234\249w\203\204I\211V\212\182t\228N\162d\22(\161n\156\245\14\162\171o?%yo\204\17\191\0191\7\3k{\21"
					local iC = ""
					local jJ = ("")["char"]
					local tM = (function(pj)
						local tM = (197323866 + 0) % 268435456
						for iX = 1, #pj do
							tM = (tM * 30672 + #pj[iX] + iX * 3843 + 23433915) % 268435456
						end
						return (148732719 + tM) % 268435456
					end)(c)
					local iX = (function(pj)
						local iX = (172064257 + 0) % 268435456
						for BF = 1, #pj do
							iX = (iX * 12985 + #pj[BF] + BF * 58148 + 225058699) % 268435456
						end
						return (88847122 + iX) % 268435456
					end)(c)
					local BF = (function(pj)
						local BF = (225572235 + 0) % 268435456
						for je = 1, #pj do
							BF = (BF * 12412 + #pj[je] + je * 9614 + 11165032) % 268435456
						end
						return (135187187 + BF) % 268435456
					end)(c)
					for pj = 1, #mC do
						tM = (iX * tM + BF) % 268435456
						local je = (
							g(mC, pj) - (tM % 256 + D(tM / 256) % 256 + D(tM / 65536) % 256 + D(tM / 16777216)) % 256
						) % 256
						fT = (fT * 257 + je) % 268435456
						iC = iC .. jJ((je + (tw + pj * eB) % 256) % 256)
					end
					yo = iC
					mC = nil
					iC = nil
					tM = nil
					iX = nil
					BF = nil
				end
				local BF
				local iX = (jY % 256 + kS % 256 * (340871112350 + 1097466242047 - 1438337354371) + 3 * 17) % 256
				local tM = 223231977575 + 416837363906 - 640069341312
				do
					local jJ =
						"d&v\159\131U\129\185\135:W\232\171\173\203\252D\139n)\22pF\0U\149/\252H?\141H\164\10\220\27\161\185\227\217J\177\133)6\14G]\10\13\154-\153^\230b'\138\237C\10\159^\198\145C\14\156\17C~\25\28\18E\197\219\191(m\183=\163\171\129\247\247\175\232\18\156+7[op\152\207\173S\29V\183\157\9\189\166\178\21\188L\27\216~\226\228\30\2549\206\149u\146\243;\5\245\172\247\150jd\252\181M\219K\212~\203\22v\159\238\228F\202;\27\236\223K\196\1506\139t\252\198\129w2\142\247\1\131\213\180iG\26\210\200 \213\247L\200\195\242\30\250\195\222\160\3\191\190w\19(\1391\2386M\13<\184\211\181r\220\161E\29x\158I\166o\221fXA\207.\164\6\229t\23\156K\238\26by\229\\\208N\244XUqI\154T\244\149Z\142T\2\208\237\224h\219R\207\226\0\139\1867\134y\5\196\253\195\158?\210\172\190\221\25\235$\\F\181p\19\225\"\136\167\181\20k\248$\241\19i\26\224\\\127\215\144\154\"Q\233=\185j\21d('\220Q\244"
					local iC = ""
					local mC = ("")["char"]
					local pj = (function(je)
						local pj = (185724063 + 0) % 268435456
						for Tn = 1, #je do
							pj = (pj * 36092 + #je[Tn] + Tn * 2907 + 228064256) % 268435456
						end
						return (242159964 + pj) % 268435456
					end)(c)
					local Tn = (function(je)
						local Tn = (256400612 + 0) % 268435456
						for dD = 1, #je do
							Tn = (Tn * 55904 + #je[dD] + dD * 16849 + 14361530) % 268435456
						end
						return (4653892 + Tn) % 268435456
					end)(c)
					local dD = (function(je)
						local dD = (145091696 + 0) % 268435456
						for JA = 1, #je do
							dD = (dD * 58675 + #je[JA] + JA * 17050 + 107075511) % 268435456
						end
						return (81385598 + dD) % 268435456
					end)(c)
					for je = 1, #jJ do
						pj = (Tn * pj + dD) % 268435456
						local JA = (
							g(jJ, je) - (pj % 256 + D(pj / 256) % 256 + D(pj / 65536) % 256 + D(pj / 16777216)) % 256
						) % 256
						fT = (fT * 257 + JA) % 268435456
						iC = iC .. mC((JA + (iX + je * tM) % 256) % 256)
					end
					BF = iC
					jJ = nil
					iC = nil
					pj = nil
					Tn = nil
					dD = nil
				end
				local function dD(Tn, pj, mC, iC, jJ, JA, je, Dl, KA, pv, dr, iE, xx, IB, jZ)
					local LB, rH, Ew, OR, qI, br, cw, qt, Qb, AV, wi, fp, VD, GM, dT, mo, RW, iW =
						Tn[1],
						Tn[2],
						Tn[3],
						Tn[4],
						Tn[5],
						Tn[6],
						Tn[7],
						Tn[8],
						Tn[9],
						Tn[10],
						Tn[11],
						Tn[13],
						Tn[15],
						Tn[16],
						Tn[17],
						Tn[18],
						Tn[19],
						Tn[20]
					local Hl = Tn.VQz
					cw = (cw - Hl) % 65536
					local qs = { pj, mC, iC, jJ }
					local FA = {}
					local an = (g(KA, JA) - (pv + JA * dr) % 256) % 256
					local Dh = JA + 1
					local Xj = Dh + an - 1
					while Dh <= Xj do
						local Tz = (g(KA, Dh) - (pv + Dh * dr) % 256) % 256
						local Hz = (g(KA, Dh + 1) - (pv + (Dh + 1) * dr) % 256) % 256
						local IF = (g(KA, Dh + 2) - (pv + (Dh + 2) * dr) % 256) % 256
						Dh += 3
						local oG = { Tz, Hz, IF }
						local gb, xB, tN = oG[xx], oG[IB], oG[jZ]
						if gb == iE[1] then
							do
								local EA = 1
								local rq = 2
								FA[EA] = LB[qs[rq] + 1]
							end
							do
								local rq = 2
								local EA = 1
								local iU = FA[EA]
								if dT(iU) == pT[1] then
									FA[rq] = -iU
								else
									local AG, MQ = AV(iU, pT[23])
									if AG then
										FA[rq] = AG(iU)
									elseif MQ then
										FA[rq] = -iU
									else
										GM(pT[3] .. dT(iU) .. pT[4], 0)
									end
								end
							end
							do
								local iU = 1
								local EA = 2
								LB[qs[iU] + 1] = FA[EA]
							end
						elseif gb == iE[2] then
							if LB[qs[1] + 1] then
								Tn.sW = qs[2]
							end
						elseif gb == iE[3] then
							local EA = Tn[Tn.xT + 1024 + 7 * Tn.rp]
							local iU = Tn[Tn.xT + 1024 + 8 * Tn.rp]
							for rq = 1, Dl do
								EA[iU + rq] = je[rq]
							end
							LB[qs[3] + 1] = iU + Dl
						elseif gb == iE[4] then
							local iU = qs[1] + 1
							Tn[Tn.LJ + 0 * Tn.rp] = iU
							Tn[Tn.LJ + 1 * Tn.rp] = Dl
							local EA = Dl
							if qs[3] ~= 255 and qs[3] > EA then
								EA = qs[3]
							end
							for rq = 1, EA do
								local MQ = Ew[iU + rq]
								if MQ then
									LB[MQ] = je[rq]
								else
									OR[iU + rq] = je[rq]
								end
							end
						elseif gb == iE[5] then
							local EA = qt[qs[1] + 1]
							local iU = LB[qs[2] + 1]
							EA.ir[EA.PRAd] = iU
						elseif gb == iE[6] then
							local iU = LB[Ew[qs[1] + 1]]
							local EA, MQ = wi(iU)
							local rq = MQ and 1 or 0
							local AG = VD(qs[4] / 2)
							local wr = qs[4] % 2 == 1
							local MZ = wr and LB[Ew[qs[1] + AG + 2]] or 0
							local GF = AG + rq + MZ
							local gR = {}
							if rq == 1 then
								gR[1] = iU
							end
							for QH = 1, AG + MZ do
								if wr and QH > AG then
									local SQ = qs[1] + QH + 2
									local EN = Ew[SQ]
									if EN then
										gR[rq + QH] = LB[EN]
									else
										gR[rq + QH] = OR[SQ]
									end
								else
									gR[rq + QH] = LB[Ew[qs[1] + QH + 1]]
								end
							end
							Tn[Tn.xT + 1024 + 0 * Tn.rp] = EA
							Tn[Tn.xT + 1024 + 1 * Tn.rp] = gR
							Tn[Tn.xT + 1024 + 2 * Tn.rp] = GF
							Tn[Tn.xT + 1024 + 3 * Tn.rp] = qs[1]
							Tn[Tn.xT + 1024 + 4 * Tn.rp] = qs[2]
							Tn[Tn.xT + 1024 + 5 * Tn.rp] = qs[3]
							Tn[Tn.xT + 1024 + 6 * Tn.rp] = qs[4]
							Tn[Tn.xT + 1024 + 7 * Tn.rp] = LB[qs[2] + 1]
							Tn[Tn.xT + 1024 + 8 * Tn.rp] = LB[qs[3] + 1]
							Tn.Ao = (Tn.VQz + 4) % 17
						elseif gb == iE[7] then
							do
								local gR = 1
								local GF = 2
								FA[gR] = LB[qs[GF] + 1]
							end
							do
								local GF = 2
								local gR = 3
								FA[GF] = LB[qs[gR] + 1]
							end
							do
								local gR = 3
								local GF = 0
								local MZ, wr = FA[1], FA[2]
								local AG, rq = dT(MZ), dT(wr)
								if AG == pT[1] and rq == pT[1] or AG == pT[7] and rq == pT[7] then
									FA[gR] = MZ <= wr
								else
									local MQ, EA = AV(MZ, pT[8])
									if not MQ then
										local iU, QH = AV(wr, pT[8])
										MQ = iU
										EA = EA or QH
									end
									if MQ then
										FA[gR] = MQ(MZ, wr)
									elseif EA then
										FA[gR] = MZ <= wr
									else
										GM(pT[9] .. AG .. pT[10] .. rq, 0)
									end
								end
							end
							do
								local rq = 1
								local AG = 3
								LB[qs[rq] + 1] = FA[AG]
							end
						elseif gb == iE[8] then
							do
								local AG = 1
								local rq = 2
								FA[AG] = LB[qs[rq] + 1]
							end
							do
								local rq = 2
								local AG = 3
								FA[rq] = LB[qs[AG] + 1]
							end
							do
								local AG = 3
								local rq = 0
								local wr, MZ = FA[1], FA[2]
								local GF
								if dT(wr) == pT[7] then
									GF = wr[MZ]
								elseif dT(wr) == pT[15] then
									GF = RW(wr, MZ)
									if GF == nil then
										local gR, EA = AV(wr, pT[16])
										if dT(gR) == pT[17] then
											GF = gR(wr, MZ)
										elseif gR ~= nil then
											GF = gR[MZ]
										elseif EA then
											GF = wr[MZ]
										end
									end
								else
									local EA, gR = AV(wr, pT[16])
									if dT(EA) == pT[17] then
										GF = EA(wr, MZ)
									elseif EA ~= nil then
										GF = EA[MZ]
									elseif gR then
										GF = wr[MZ]
									else
										GM(pT[18] .. dT(wr) .. pT[4], 0)
									end
								end
								FA[AG] = GF
							end
							do
								local GF = 1
								local MZ = 3
								LB[qs[GF] + 1] = FA[MZ]
							end
						elseif gb == iE[9] then
							local MZ = LB[qs[2] + 1]
							LB[qs[1] + 1] = MZ
						elseif gb == iE[10] then
							local MZ = {}
							local GF = qs[2]
							local wr
							if GF == 255 then
								local rq = qs[4]
								for AG = 1, rq do
									MZ[AG] = LB[Ew[qs[1] + AG]]
								end
								if qs[3] == 1 then
									for AG = 1, cw do
										MZ[rq + AG] = br[1 + (AG + Tn.VQz - 1) % cw]
									end
									wr = rq + cw
								else
									for AG = 1, Tn[Tn.LJ + 1 * Tn.rp] do
										local gR = Ew[Tn[Tn.LJ + 0 * Tn.rp] + AG]
										if gR then
											MZ[rq + AG] = LB[gR]
										else
											MZ[rq + AG] = OR[Tn[Tn.LJ + 0 * Tn.rp] + AG]
										end
									end
									wr = rq + Tn[Tn.LJ + 1 * Tn.rp]
								end
							else
								for rq = 1, GF do
									MZ[rq] = LB[Ew[qs[1] + rq]]
								end
								wr = GF
							end
							Tn[Tn.LJ + 2 * Tn.rp] = MZ
							Tn[Tn.LJ + 3 * Tn.rp] = wr
							Tn.Tj = (Tn.VQz + Tn.rp) % 65521
						elseif gb == iE[11] then
							local wr = (1280 * qs[1] + 34922) % 65536
							local GF = (qs[2] - wr) % 65536
							local MZ = (qs[3] - wr) % 65536
							local rq = (qs[4] - wr) % 65536
							local gR = VD(rq / 256)
							local AG = { GF % 256, VD(GF / 256), MZ % 256, VD(MZ / 256), rq % 256 }
							local EA = pT[29][pT[27]]
							local MQ = pT[29]
							for QH = 1, gR do
								MQ = MQ .. EA(AG[QH])
							end
							LB[qs[1] + 1] = MQ
						elseif gb == iE[12] then
							do
								local MQ = 1
								local EA = 2
								FA[MQ] = LB[qs[EA] + 1]
							end
							do
								local EA = 2
								local MQ = 1
								local AG = FA[MQ]
								local gR = fp and AV(AG, pT[24])
								if gR then
									FA[EA] = gR(AG)
								else
									FA[EA] = #AG
								end
							end
							do
								local gR = 1
								local AG = 2
								LB[qs[gR] + 1] = FA[AG]
							end
						elseif gb == iE[13] then
							local AG = qs[1] + 1
							for gR = 1, Dl do
								local MQ = Ew[AG + gR]
								if MQ then
									LB[MQ] = je[gR]
								else
									OR[AG + gR] = je[gR]
								end
							end
							LB[Ew[AG]] = Dl
						elseif gb == iE[14] then
							do
								local AG = 1
								local MQ = 2
								FA[AG] = rH[qs[MQ] + 1]
							end
							do
								local MQ = 2
								local AG = 1
								FA[MQ] = qI[FA[AG]]
							end
							do
								local AG = 1
								local MQ = 2
								LB[qs[AG] + 1] = FA[MQ]
							end
						elseif gb == iE[15] then
							local MQ = qt[qs[2] + 1]
							local AG = MQ.ir[MQ.PRAd]
							LB[qs[1] + 1] = AG
						elseif gb == iE[16] then
							local AG = not LB[qs[2] + 1]
							LB[qs[1] + 1] = AG
						elseif gb == iE[17] then
							do
								local AG = 1
								local MQ = 2
								FA[AG] = LB[qs[MQ] + 1]
							end
							do
								local MQ = 2
								local AG = 3
								FA[MQ] = LB[qs[AG] + 1]
							end
							do
								local AG = 3
								local MQ = 0
								local gR, EA = FA[1], FA[2]
								if dT(gR) == pT[1] and dT(EA) == pT[1] then
									FA[AG] = gR ^ EA
								else
									local rq, MZ = AV(gR, pT[2])
									if not rq then
										local GF, wr = AV(EA, pT[2])
										rq = GF
										MZ = MZ or wr
									end
									if rq then
										FA[AG] = rq(gR, EA)
									elseif MZ then
										FA[AG] = gR ^ EA
									else
										GM(pT[3] .. dT(gR) .. pT[4], 0)
									end
								end
							end
							do
								local EA = 1
								local gR = 3
								LB[qs[EA] + 1] = FA[gR]
							end
						elseif gb == iE[18] then
							Tn.sW = qs[xB]
						elseif gb == iE[19] then
							do
								local gR = 1
								local EA = 2
								FA[gR] = LB[qs[EA] + 1]
							end
							do
								local EA = 2
								local gR = 3
								FA[EA] = LB[qs[gR] + 1]
							end
							do
								local gR = 3
								local EA = 0
								FA[gR] = VD(FA[1] / FA[2])
							end
							do
								local EA = 1
								local gR = 3
								LB[qs[EA] + 1] = FA[gR]
							end
						elseif gb == iE[20] then
							do
								local gR = 1
								local EA = 2
								FA[gR] = LB[qs[EA] + 1]
							end
							do
								local EA = 2
								local gR = 3
								FA[EA] = LB[qs[gR] + 1]
							end
							do
								local gR = 3
								local EA = 0
								local MQ, AG = FA[1], FA[2]
								local MZ, rq = dT(MQ), dT(AG)
								local wr
								if MZ == rq and (MZ == pT[1] or MZ == pT[7] or MZ == pT[12] or MZ == pT[13]) then
									wr = MQ == AG
								else
									local GF = AV(MQ, pT[14]) or AV(AG, pT[14])
									if GF then
										wr = GF(MQ, AG)
									else
										wr = MQ == AG
									end
								end
								FA[gR] = not wr
							end
							do
								local wr = 1
								local rq = 3
								LB[qs[wr] + 1] = FA[rq]
							end
						elseif gb == iE[21] then
							local rq = rH[qs[2] + 1]
							LB[qs[1] + 1] = rq
						elseif gb == iE[22] then
							do
								local rq = 1
								local wr = 2
								FA[rq] = LB[qs[wr] + 1]
							end
							do
								local wr = 2
								local rq = 3
								FA[wr] = LB[qs[rq] + 1]
							end
							do
								local rq = 3
								local wr = 0
								local MZ, AG = FA[1], FA[2]
								local MQ, EA = dT(MZ), dT(AG)
								if (MQ == pT[1] or MQ == pT[7]) and (EA == pT[1] or EA == pT[7]) then
									FA[rq] = MZ .. AG
								else
									local gR, GF = AV(MZ, pT[21])
									if not gR then
										local QH, iU = AV(AG, pT[21])
										gR = QH
										GF = GF or iU
									end
									if gR then
										FA[rq] = gR(MZ, AG)
									elseif GF then
										FA[rq] = MZ .. AG
									else
										GM(pT[22] .. MQ .. pT[4], 0)
									end
								end
							end
							do
								local EA = 1
								local MQ = 3
								LB[qs[EA] + 1] = FA[MQ]
							end
						elseif gb == iE[23] then
							local MQ = qs[1] + 1
							Tn[Tn.LJ + 0 * Tn.rp] = MQ
							Tn[Tn.LJ + 1 * Tn.rp] = Dl
							local EA = Dl
							if qs[3] ~= 255 and qs[3] > EA then
								EA = qs[3]
							end
							for AG = 1, EA do
								local MZ = Ew[MQ + AG]
								if MZ then
									LB[MZ] = je[AG]
								else
									OR[MQ + AG] = je[AG]
								end
							end
						elseif gb == iE[24] then
							do
								local EA = 1
								local MQ = 1
								FA[EA] = LB[qs[MQ] + 1]
							end
							do
								local MQ = 2
								local EA = 2
								FA[MQ] = LB[qs[EA] + 1]
							end
							do
								local EA = 3
								local MQ = 3
								FA[EA] = LB[qs[MQ] + 1]
							end
							do
								local MQ = 0
								local EA = 0
								FA[2] = FA[2] + 1
								FA[1][FA[2]] = FA[3]
							end
							do
								local EA = 2
								local MQ = 2
								LB[qs[EA] + 1] = FA[MQ]
							end
						elseif gb == iE[25] then
							do
								local MQ = 1
								local EA = 2
								FA[MQ] = LB[qs[EA] + 1]
							end
							do
								local EA = 2
								local MQ = 3
								FA[EA] = LB[qs[MQ] + 1]
							end
							do
								local MQ = 3
								local EA = 0
								local MZ, AG = FA[1], FA[2]
								if dT(MZ) == pT[1] and dT(AG) == pT[1] then
									FA[MQ] = MZ - AG
								else
									local wr, rq = AV(MZ, pT[5])
									if not wr then
										local GF, gR = AV(AG, pT[5])
										wr = GF
										rq = rq or gR
									end
									if wr then
										FA[MQ] = wr(MZ, AG)
									elseif rq then
										FA[MQ] = MZ - AG
									else
										GM(pT[3] .. dT(MZ) .. pT[4], 0)
									end
								end
							end
							do
								local AG = 1
								local MZ = 3
								LB[qs[AG] + 1] = FA[MZ]
							end
						elseif gb == iE[26] then
							do
								local MZ = 1
								local AG = 2
								FA[MZ] = LB[qs[AG] + 1]
							end
							do
								local AG = 2
								local MZ = 3
								FA[AG] = LB[qs[MZ] + 1]
							end
							do
								local MZ = 3
								local AG = 0
								local EA, MQ = FA[1], FA[2]
								if dT(EA) == pT[1] and dT(MQ) == pT[1] then
									FA[MZ] = EA + MQ
								else
									local rq, wr = AV(EA, pT[6])
									if not rq then
										local gR, GF = AV(MQ, pT[6])
										rq = gR
										wr = wr or GF
									end
									if rq then
										FA[MZ] = rq(EA, MQ)
									elseif wr then
										FA[MZ] = EA + MQ
									else
										GM(pT[3] .. dT(EA) .. pT[4], 0)
									end
								end
							end
							do
								local MQ = 1
								local EA = 3
								LB[qs[MQ] + 1] = FA[EA]
							end
						elseif gb == iE[27] then
							local EA = qs[1] + 1
							local MQ = LB[Ew[EA]]
							local AG, MZ = wi(MQ)
							local wr = MZ and 1 or 0
							local rq = qs[2]
							local GF = LB[Ew[EA + rq + 1]]
							local gR = rq + GF + wr
							local iU = {}
							if wr == 1 then
								iU[1] = MQ
							end
							for QH = 1, rq + GF do
								if QH <= rq then
									iU[wr + QH] = LB[Ew[EA + QH]]
								else
									local EN = EA + QH + 1
									local SQ = Ew[EN]
									if SQ then
										iU[wr + QH] = LB[SQ]
									else
										iU[wr + QH] = OR[EN]
									end
								end
							end
							if qs[4] == 1 then
								for QH = 1, cw do
									iU[gR + QH] = br[1 + (QH + Tn.VQz - 1) % cw]
								end
								gR += cw
							end
							Tn[Tn.xT + 768 + 0 * Tn.rp] = AG
							Tn[Tn.xT + 768 + 1 * Tn.rp] = iU
							Tn[Tn.xT + 768 + 2 * Tn.rp] = gR
							Tn[Tn.xT + 768 + 3 * Tn.rp] = qs[1]
							Tn[Tn.xT + 768 + 4 * Tn.rp] = qs[2]
							Tn[Tn.xT + 768 + 5 * Tn.rp] = qs[3]
							Tn[Tn.xT + 768 + 6 * Tn.rp] = qs[4]
							Tn.Ao = (Tn.VQz + 3) % 17
						elseif gb == iE[28] then
							do
								local iU = 1
								local gR = 2
								FA[iU] = LB[qs[gR] + 1]
							end
							do
								local gR = 2
								local iU = 3
								FA[gR] = LB[qs[iU] + 1]
							end
							do
								local iU = 3
								local gR = 0
								local GF, rq = FA[1], FA[2]
								local wr, MZ = dT(GF), dT(rq)
								local AG
								if wr == MZ and (wr == pT[1] or wr == pT[7] or wr == pT[12] or wr == pT[13]) then
									AG = GF == rq
								else
									local MQ = AV(GF, pT[14]) or AV(rq, pT[14])
									if MQ then
										AG = MQ(GF, rq)
									else
										AG = GF == rq
									end
								end
								FA[iU] = AG
							end
							do
								local AG = 1
								local MZ = 3
								LB[qs[AG] + 1] = FA[MZ]
							end
						elseif gb == iE[29] then
							do
								local MZ = 1
								local AG = 2
								FA[MZ] = LB[qs[AG] + 1]
							end
							do
								local AG = 2
								local MZ = 3
								FA[AG] = LB[qs[MZ] + 1]
							end
							do
								local MZ = 3
								local AG = 0
								local wr, rq = FA[1], FA[2]
								if dT(wr) == pT[1] and dT(rq) == pT[1] then
									FA[MZ] = wr % rq
								else
									local GF, gR = AV(wr, pT[19])
									if not GF then
										local iU, MQ = AV(rq, pT[19])
										GF = iU
										gR = gR or MQ
									end
									if GF then
										FA[MZ] = GF(wr, rq)
									elseif gR then
										FA[MZ] = wr % rq
									else
										GM(pT[3] .. dT(wr) .. pT[4], 0)
									end
								end
							end
							do
								local rq = 1
								local wr = 3
								LB[qs[rq] + 1] = FA[wr]
							end
						elseif gb == iE[30] then
							do
								local wr = 1
								local rq = 1
								FA[wr] = LB[qs[rq] + 1]
							end
							do
								local rq = 2
								local wr = 2
								FA[rq] = LB[qs[wr] + 1]
							end
							do
								local wr = 0
								local rq = 0
								for AG = 1, cw do
									FA[1][FA[2] + AG] = br[1 + (AG + Tn.VQz - 1) % cw]
								end
								FA[2] = FA[2] + cw
							end
							do
								local rq = 2
								local wr = 2
								LB[qs[rq] + 1] = FA[wr]
							end
						elseif gb == iE[31] then
							LB[qs[xB] + 1] = Qb(Tn.mK[qs[tN]], LB, qt, Ew)
						elseif gb == iE[32] then
							do
								local wr = 1
								local rq = 2
								FA[wr] = LB[qs[rq] + 1]
							end
							do
								local rq = 2
								local wr = 3
								FA[rq] = LB[qs[wr] + 1]
							end
							do
								local wr = 3
								local rq = 0
								local AG, MZ = FA[1], FA[2]
								local gR, GF = dT(AG), dT(MZ)
								if gR == pT[1] and GF == pT[1] or gR == pT[7] and GF == pT[7] then
									FA[wr] = AG < MZ
								else
									local MQ, iU = AV(AG, pT[20])
									if not MQ then
										local EA, QH = AV(MZ, pT[20])
										MQ = EA
										iU = iU or QH
									end
									if MQ then
										FA[wr] = MQ(AG, MZ)
									elseif iU then
										FA[wr] = AG < MZ
									else
										GM(pT[9] .. gR .. pT[10] .. GF, 0)
									end
								end
							end
							do
								local GF = 1
								local gR = 3
								LB[qs[GF] + 1] = FA[gR]
							end
						elseif gb == iE[33] then
							do
								local gR = 1
								local GF = 2
								FA[gR] = LB[qs[GF] + 1]
							end
							do
								local GF = 2
								local gR = 3
								FA[GF] = LB[qs[gR] + 1]
							end
							do
								local gR = 3
								local GF = 0
								local MZ, AG = FA[1], FA[2]
								local rq, wr = dT(MZ), dT(AG)
								if rq == pT[1] and wr == pT[1] or rq == pT[7] and wr == pT[7] then
									FA[gR] = MZ >= AG
								else
									local iU, MQ = AV(MZ, pT[8])
									if not iU then
										local QH, EA = AV(AG, pT[8])
										iU = QH
										MQ = MQ or EA
									end
									if iU then
										FA[gR] = iU(AG, MZ)
									elseif MQ then
										FA[gR] = MZ >= AG
									else
										GM(pT[9] .. rq .. pT[10] .. wr, 0)
									end
								end
							end
							do
								local wr = 1
								local rq = 3
								LB[qs[wr] + 1] = FA[rq]
							end
						elseif gb == iE[34] then
							local rq = {}
							LB[qs[1] + 1] = rq
						elseif gb == iE[35] then
							LB[qs[1] + 1] = cw
						elseif gb == iE[36] then
							do
								local rq = 1
								local wr = 2
								FA[rq] = LB[qs[wr] + 1]
							end
							do
								local wr = 2
								local rq = 3
								FA[wr] = LB[qs[rq] + 1]
							end
							do
								local rq = 3
								local wr = 0
								local AG, MZ = FA[1], FA[2]
								local GF, gR = dT(AG), dT(MZ)
								if GF == pT[1] and gR == pT[1] or GF == pT[7] and gR == pT[7] then
									FA[rq] = AG > MZ
								else
									local MQ, iU = AV(AG, pT[20])
									if not MQ then
										local EA, QH = AV(MZ, pT[20])
										MQ = EA
										iU = iU or QH
									end
									if MQ then
										FA[rq] = MQ(MZ, AG)
									elseif iU then
										FA[rq] = AG > MZ
									else
										GM(pT[9] .. GF .. pT[10] .. gR, 0)
									end
								end
							end
							do
								local gR = 1
								local GF = 3
								LB[qs[gR] + 1] = FA[GF]
							end
						elseif gb == iE[37] then
							for GF = 1, qs[tN] do
								LB[Ew[qs[xB] + GF]] = nil
							end
						elseif gb == iE[38] then
							if pj % 4 == 0 then
								local GF = (pj + mC) * (iC % 17 + 1) - jJ
							elseif pj % 4 == 1 then
								local GF
								if pj < mC then
									GF = iC
								else
									GF = jJ
								end
							elseif pj % 4 == 3 then
								local GF = { pj, iC }
								GF[mC % 2 + 1] = jJ
							else
								local GF = pj
								if mC % 2 == 0 then
									GF += iC % 3
								else
									GF -= jJ % 3
								end
							end
						elseif gb == iE[39] then
							do
								local GF = 1
								local gR = 2
								FA[GF] = rH[qs[gR] + 1]
							end
							do
								local gR = 1
								local GF = 1
								local MZ = FA[GF]
								local AG = qs[3]
								local wr = qs[4]
								local rq = pT[29][pT[28]]
								local iU = pT[29][pT[27]]
								local MQ = pT[29]
								for QH = 1, #MZ do
									AG = (AG * 257 + wr + QH) % 65521
									MQ = MQ .. iU((rq(MZ, QH) - AG % 256) % 256)
								end
								FA[gR] = MQ
							end
							do
								local MQ = 1
								local iU = 1
								LB[qs[MQ] + 1] = FA[iU]
							end
						elseif gb == iE[40] then
							local iU = qs[1] + 1
							local MQ = LB[Ew[iU]]
							local rq, wr = wi(MQ)
							local AG = wr and 1 or 0
							local MZ = qs[2] + AG
							local GF = {}
							if AG == 1 then
								GF[1] = MQ
							end
							for gR = 1, qs[2] do
								GF[AG + gR] = LB[Ew[iU + gR]]
							end
							if qs[4] == 1 then
								for gR = 1, cw do
									GF[MZ + gR] = br[1 + (gR + Tn.VQz - 1) % cw]
								end
								MZ += cw
							end
							Tn[Tn.xT + 256 + 0 * Tn.rp] = rq
							Tn[Tn.xT + 256 + 1 * Tn.rp] = GF
							Tn[Tn.xT + 256 + 2 * Tn.rp] = MZ
							Tn[Tn.xT + 256 + 3 * Tn.rp] = qs[1]
							Tn[Tn.xT + 256 + 4 * Tn.rp] = qs[2]
							Tn[Tn.xT + 256 + 5 * Tn.rp] = qs[3]
							Tn[Tn.xT + 256 + 6 * Tn.rp] = qs[4]
							Tn.Ao = (Tn.VQz + 1) % 17
						elseif gb == iE[41] then
							local GF = {}
							for MZ = 1, cw do
								GF[MZ] = br[1 + (MZ + Tn.VQz - 1) % cw]
							end
							LB[qs[1] + 1] = GF
						elseif gb == iE[42] then
							do
								local GF = 1
								local MZ = 2
								FA[GF] = LB[qs[MZ] + 1]
							end
							do
								local MZ = 2
								local GF = 3
								FA[MZ] = LB[qs[GF] + 1]
							end
							do
								local GF = 3
								local MZ = 0
								local AG, wr = FA[1], FA[2]
								if dT(AG) == pT[1] and dT(wr) == pT[1] then
									FA[GF] = AG / wr
								else
									local rq, MQ = AV(AG, pT[26])
									if not rq then
										local iU, gR = AV(wr, pT[26])
										rq = iU
										MQ = MQ or gR
									end
									if rq then
										FA[GF] = rq(AG, wr)
									elseif MQ then
										FA[GF] = AG / wr
									else
										GM(pT[3] .. dT(AG) .. pT[4], 0)
									end
								end
							end
							do
								local wr = 1
								local AG = 3
								LB[qs[wr] + 1] = FA[AG]
							end
						elseif gb == iE[43] then
							do
								local AG = 1
								local wr = 2
								FA[AG] = LB[qs[wr] + 1]
							end
							do
								local wr = 2
								local AG = 3
								FA[wr] = LB[qs[AG] + 1]
							end
							do
								local AG = 3
								local wr = 0
								local MZ, GF = FA[1], FA[2]
								if dT(MZ) == pT[1] and dT(GF) == pT[1] then
									FA[AG] = MZ * GF
								else
									local MQ, rq = AV(MZ, pT[11])
									if not MQ then
										local gR, iU = AV(GF, pT[11])
										MQ = gR
										rq = rq or iU
									end
									if MQ then
										FA[AG] = MQ(MZ, GF)
									elseif rq then
										FA[AG] = MZ * GF
									else
										GM(pT[3] .. dT(MZ) .. pT[4], 0)
									end
								end
							end
							do
								local GF = 1
								local MZ = 3
								LB[qs[GF] + 1] = FA[MZ]
							end
						elseif gb == iE[44] then
							local MZ = qs[1] + 1
							local GF = LB[Ew[MZ]]
							local wr, AG = wi(GF)
							local rq = AG and 1 or 0
							local MQ = qs[2]
							local iU = qs[4] % 2 == 1
							local gR = qs[4] >= 2
							local QH = MQ + rq
							if gR then
								QH += LB[Ew[MZ + MQ + 1]]
							end
							local EA = {}
							if rq == 1 then
								EA[1] = GF
							end
							local SQ = gR and MQ + LB[Ew[MZ + MQ + 1]] or MQ
							for EN = 1, SQ do
								if gR and EN > MQ then
									local rL = MZ + EN + 1
									local mB = Ew[rL]
									if mB then
										EA[rq + EN] = LB[mB]
									else
										EA[rq + EN] = OR[rL]
									end
								else
									EA[rq + EN] = LB[Ew[MZ + EN]]
								end
							end
							if iU then
								for EN = 1, cw do
									EA[QH + EN] = br[1 + (EN + Tn.VQz - 1) % cw]
								end
								QH += cw
							end
							Tn[Tn.xT + 512 + 0 * Tn.rp] = wr
							Tn[Tn.xT + 512 + 1 * Tn.rp] = EA
							Tn[Tn.xT + 512 + 2 * Tn.rp] = QH
							Tn[Tn.xT + 512 + 3 * Tn.rp] = qs[1]
							Tn[Tn.xT + 512 + 4 * Tn.rp] = qs[2]
							Tn[Tn.xT + 512 + 5 * Tn.rp] = qs[3]
							Tn[Tn.xT + 512 + 6 * Tn.rp] = qs[4]
							Tn.Ao = (Tn.VQz + 2) % 17
						elseif gb == iE[45] then
							do
								local SQ = 1
								local EA = 1
								FA[SQ] = LB[qs[EA] + 1]
							end
							do
								local EA = 2
								local SQ = 2
								FA[EA] = LB[qs[SQ] + 1]
							end
							do
								local SQ = 3
								local EA = 3
								FA[SQ] = LB[qs[EA] + 1]
							end
							do
								local EA = 0
								local SQ = 0
								local QH, gR, iU = FA[1], FA[2], FA[3]
								if dT(QH) ~= pT[15] then
									local MQ, rq = AV(QH, pT[25])
									if dT(MQ) == pT[17] then
										MQ(QH, gR, iU)
									elseif MQ ~= nil then
										iW(MQ, gR, iU)
									elseif rq then
										QH[gR] = iU
									else
										GM(pT[18] .. dT(QH) .. pT[4], 0)
									end
								else
									if RW(QH, gR) == nil then
										local rq, MQ = AV(QH, pT[25])
										if dT(rq) == pT[17] then
											rq(QH, gR, iU)
										elseif rq ~= nil then
											iW(rq, gR, iU)
										elseif MQ then
											QH[gR] = iU
										else
											iW(QH, gR, iU)
										end
									else
										iW(QH, gR, iU)
									end
								end
							end
						elseif gb == iE[46] then
							do
								local iU = 1
								local gR = 2
								FA[iU] = rH[qs[gR] + 1]
							end
							do
								local gR = 2
								local iU = 1
								FA[gR] = LB[qs[iU] + 1]
							end
							do
								local iU = 1
								local gR = 2
								qI[FA[iU]] = FA[gR]
							end
						elseif gb == iE[47] then
							if not LB[qs[1] + 1] then
								Tn.sW = qs[2]
							end
						end
					end
					for tN = 1, 3 do
						FA[tN] = nil
					end
					DK = nil
					for tN = 1, 4 do
						qs[tN] = nil
					end
				end
				local RW = function(Xj, Dh, an, FA, qs, Hl, iW, RW)
					return dD(
						Xj,
						Dh,
						an,
						FA,
						qs,
						Hl,
						iW,
						RW,
						mV,
						qG,
						fW,
						{
							158,
							118,
							142,
							88,
							133,
							65,
							124,
							111,
							206,
							12,
							204,
							72,
							40,
							35,
							64,
							187,
							8,
							168,
							49,
							201,
							73,
							90,
							99,
							167,
							226,
							123,
							112,
							19,
							26,
							230,
							93,
							237,
							59,
							155,
							241,
							195,
							202,
							127,
							108,
							144,
							234,
							249,
							91,
							117,
							223,
							119,
							36,
						},
						1,
						3,
						2
					)
				end
				local mo = function(iW, Hl, qs, FA, an, Dh, Xj, mo)
					return dD(
						iW,
						Hl,
						qs,
						FA,
						an,
						Dh,
						Xj,
						mo,
						hl,
						lF,
						mv,
						{
							222,
							220,
							82,
							22,
							216,
							101,
							131,
							76,
							231,
							10,
							173,
							75,
							215,
							79,
							128,
							243,
							160,
							217,
							94,
							120,
							20,
							17,
							178,
							73,
							109,
							116,
							167,
							40,
							249,
							108,
							72,
							193,
							55,
							30,
							182,
							237,
							37,
							36,
							159,
							208,
							78,
							44,
							141,
							171,
							199,
							246,
							125,
						},
						2,
						1,
						3
					)
				end
				local dT = function(Xj, Dh, an, FA, qs, Hl, iW, dT)
					return dD(
						Xj,
						Dh,
						an,
						FA,
						qs,
						Hl,
						iW,
						dT,
						yo,
						tw,
						eB,
						{
							72,
							172,
							39,
							81,
							51,
							136,
							64,
							248,
							216,
							84,
							164,
							42,
							145,
							174,
							215,
							17,
							153,
							85,
							128,
							133,
							114,
							27,
							125,
							93,
							246,
							108,
							160,
							87,
							221,
							101,
							217,
							204,
							208,
							32,
							137,
							132,
							170,
							135,
							230,
							109,
							242,
							46,
							235,
							10,
							206,
							127,
							37,
						},
						1,
						3,
						2
					)
				end
				local GM = function(iW, Hl, qs, FA, an, Dh, Xj, GM)
					return dD(
						iW,
						Hl,
						qs,
						FA,
						an,
						Dh,
						Xj,
						GM,
						BF,
						iX,
						tM,
						{
							163,
							29,
							238,
							244,
							182,
							12,
							94,
							226,
							137,
							145,
							135,
							44,
							31,
							208,
							23,
							106,
							179,
							112,
							129,
							168,
							233,
							93,
							59,
							139,
							147,
							167,
							69,
							190,
							70,
							148,
							245,
							22,
							187,
							242,
							42,
							195,
							37,
							220,
							154,
							159,
							175,
							80,
							223,
							58,
							193,
							230,
							155,
						},
						2,
						1,
						3
					)
				end
				My[(24 + Ja) % 256] = function(Xj, Dh, an, FA, qs)
					if Xj.jE == 0 then
						RW(Xj, Dh, an, FA, qs, 1)
					elseif Xj.jE == 1 then
						mo(Xj, Dh, an, FA, qs, 1)
					elseif 3 == Xj.jE then
						GM(Xj, Dh, an, FA, qs, 1)
					elseif 2 == Xj.jE then
						dT(Xj, Dh, an, FA, qs, 1)
					end
					Xj.bX -= 1
					if Xj.bX == 0 then
						return
					end
					local Hl = Xj.sW
					if Hl < Xj.pbB or Hl > Xj.UU then
						Xj._b(Xj, Xj.tqp[Hl])
					end
					local iW = Hl - Xj.pbB + 1
					local VD = (Xj.tVN[iW] - Xj.qEK) % 256
					Xj.sW = Hl + 1
					return My[(VD + Ja) % 256](
						Xj,
						(Xj.eXa[iW] - Xj.qEK) % 65536,
						(Xj.uWE[iW] - Xj.qEK) % 65536,
						(Xj.we[iW] - Xj.qEK) % 65536,
						(Xj.fL[iW] - Xj.qEK) % 65536
					)
				end
				NF = function(VD)
					local iW = VD.NDWY(
						VD[VD.xT + 256 + 0 * VD.rp](VD[21](VD[VD.xT + 256 + 1 * VD.rp], 1, VD[VD.xT + 256 + 2 * VD.rp]))
					)
					if VD.jE == 2 then
						dT(
							VD,
							VD[VD.xT + 256 + 3 * VD.rp],
							VD[VD.xT + 256 + 4 * VD.rp],
							VD[VD.xT + 256 + 5 * VD.rp],
							VD[VD.xT + 256 + 6 * VD.rp],
							6,
							iW,
							iW.n
						)
					elseif 1 == VD.jE then
						mo(
							VD,
							VD[VD.xT + 256 + 3 * VD.rp],
							VD[VD.xT + 256 + 4 * VD.rp],
							VD[VD.xT + 256 + 5 * VD.rp],
							VD[VD.xT + 256 + 6 * VD.rp],
							6,
							iW,
							iW.n
						)
					elseif 0 == VD.jE then
						RW(
							VD,
							VD[VD.xT + 256 + 3 * VD.rp],
							VD[VD.xT + 256 + 4 * VD.rp],
							VD[VD.xT + 256 + 5 * VD.rp],
							VD[VD.xT + 256 + 6 * VD.rp],
							5,
							iW,
							iW.n
						)
					elseif 3 == VD.jE then
						GM(
							VD,
							VD[VD.xT + 256 + 3 * VD.rp],
							VD[VD.xT + 256 + 4 * VD.rp],
							VD[VD.xT + 256 + 5 * VD.rp],
							VD[VD.xT + 256 + 6 * VD.rp],
							6,
							iW,
							iW.n
						)
					end
					for Hl = 0, 8 do
						VD[VD.xT + 256 + Hl * VD.rp] = nil
					end
					VD.bX -= 1
					if VD.bX <= 0 then
						return
					end
					local Hl = VD.sW
					if Hl < VD.pbB or Hl > VD.UU then
						VD._b(VD, VD.tqp[Hl])
					end
					local qs = Hl - VD.pbB + 1
					local FA = (VD.tVN[qs] - VD.qEK) % 256
					VD.sW = Hl + 1
					return My[(FA + Ja) % 256](
						VD,
						(VD.eXa[qs] - VD.qEK) % 65536,
						(VD.uWE[qs] - VD.qEK) % 65536,
						(VD.we[qs] - VD.qEK) % 65536,
						(VD.fL[qs] - VD.qEK) % 65536
					)
				end
				My[(10 + Ja) % 256] = function(FA, qs, Hl, iW, VD)
					if FA.jE == 0 then
						RW(FA, qs, Hl, iW, VD, 10)
					elseif 3 == FA.jE then
						GM(FA, qs, Hl, iW, VD, 11)
					elseif FA.jE == 2 then
						dT(FA, qs, Hl, iW, VD, 11)
					elseif 1 == FA.jE then
						mo(FA, qs, Hl, iW, VD, 11)
					end
					return
				end
				My[(6 + Ja) % 256] = function(VD, iW, Hl, qs, FA)
					if 0 == VD.jE then
						RW(VD, iW, Hl, qs, FA, 16)
					elseif 1 == VD.jE then
						mo(VD, iW, Hl, qs, FA, 16)
					elseif 3 == VD.jE then
						GM(VD, iW, Hl, qs, FA, 18)
					elseif 2 == VD.jE then
						dT(VD, iW, Hl, qs, FA, 16)
					end
					VD.bX -= 1
					if VD.bX <= 0 then
						return
					end
					local an = VD.sW
					if an < VD.pbB or an > VD.UU then
						VD._b(VD, VD.tqp[an])
					end
					local Dh = an - VD.pbB + 1
					local Xj = (VD.tVN[Dh] - VD.qEK) % 256
					local fp, wi, AV, Qb =
						(VD.eXa[Dh] - VD.qEK) % 65536,
						(VD.uWE[Dh] - VD.qEK) % 65536,
						(VD.we[Dh] - VD.qEK) % 65536,
						(VD.fL[Dh] - VD.qEK) % 65536
					VD.sW = an + 1
					return My[(Xj + Ja) % 256](VD, fp, wi, AV, Qb)
				end
				ug = function(Qb)
					local AV = Qb.NDWY(
						Qb[Qb.xT + 512 + 0 * Qb.rp](Qb[21](Qb[Qb.xT + 512 + 1 * Qb.rp], 1, Qb[Qb.xT + 512 + 2 * Qb.rp]))
					)
					if 1 == Qb.jE then
						mo(
							Qb,
							Qb[Qb.xT + 512 + 3 * Qb.rp],
							Qb[Qb.xT + 512 + 4 * Qb.rp],
							Qb[Qb.xT + 512 + 5 * Qb.rp],
							Qb[Qb.xT + 512 + 6 * Qb.rp],
							20,
							AV,
							AV.n
						)
					elseif 2 == Qb.jE then
						dT(
							Qb,
							Qb[Qb.xT + 512 + 3 * Qb.rp],
							Qb[Qb.xT + 512 + 4 * Qb.rp],
							Qb[Qb.xT + 512 + 5 * Qb.rp],
							Qb[Qb.xT + 512 + 6 * Qb.rp],
							20,
							AV,
							AV.n
						)
					elseif Qb.jE == 3 then
						GM(
							Qb,
							Qb[Qb.xT + 512 + 3 * Qb.rp],
							Qb[Qb.xT + 512 + 4 * Qb.rp],
							Qb[Qb.xT + 512 + 5 * Qb.rp],
							Qb[Qb.xT + 512 + 6 * Qb.rp],
							25,
							AV,
							AV.n
						)
					elseif Qb.jE == 0 then
						RW(
							Qb,
							Qb[Qb.xT + 512 + 3 * Qb.rp],
							Qb[Qb.xT + 512 + 4 * Qb.rp],
							Qb[Qb.xT + 512 + 5 * Qb.rp],
							Qb[Qb.xT + 512 + 6 * Qb.rp],
							21,
							AV,
							AV.n
						)
					end
					for wi = 0, 8 do
						Qb[Qb.xT + 512 + wi * Qb.rp] = nil
					end
					Qb.bX -= 1
					if Qb.bX == 0 then
						return
					end
					local wi = Qb.sW
					if wi < Qb.pbB or wi > Qb.UU then
						Qb._b(Qb, Qb.tqp[wi])
					end
					local fp = wi - Qb.pbB + 1
					local Xj = (Qb.tVN[fp] - Qb.qEK) % 256
					local Dh, an, FA, qs =
						(Qb.eXa[fp] - Qb.qEK) % 65536,
						(Qb.uWE[fp] - Qb.qEK) % 65536,
						(Qb.we[fp] - Qb.qEK) % 65536,
						(Qb.fL[fp] - Qb.qEK) % 65536
					Qb.sW = wi + 1
					return My[(Xj + Ja) % 256](Qb, Dh, an, FA, qs)
				end
				My[(39 + Ja) % 256] = function(qs, FA, an, Dh, Xj)
					if qs.jE == 2 then
						dT(qs, FA, an, Dh, Xj, 25)
					elseif qs.jE == 1 then
						mo(qs, FA, an, Dh, Xj, 26)
					elseif qs.jE == 3 then
						GM(qs, FA, an, Dh, Xj, 29)
					elseif 0 == qs.jE then
						RW(qs, FA, an, Dh, Xj, 25)
					end
					return
				end
				My[(31 + Ja) % 256] = function(Xj, Dh, an, FA, qs)
					if 3 == Xj.jE then
						GM(Xj, Dh, an, FA, qs, 36)
					elseif 1 == Xj.jE then
						mo(Xj, Dh, an, FA, qs, 33)
					elseif Xj.jE == 0 then
						RW(Xj, Dh, an, FA, qs, 29)
					elseif 2 == Xj.jE then
						dT(Xj, Dh, an, FA, qs, 32)
					end
					Xj.bX -= 1
					if Xj.bX == 0 then
						return
					end
					local fp = Xj.sW
					Xj.sW = fp + 1
					if fp < Xj.pbB or fp > Xj.UU then
						Xj._b(Xj, Xj.tqp[fp])
					end
					local wi = fp - Xj.pbB + 1
					local AV = (Xj.tVN[wi] - Xj.qEK) % 256
					local Qb = My[(AV + Ja) % 256]
					return Qb(
						Xj,
						(Xj.eXa[wi] - Xj.qEK) % 65536,
						(Xj.uWE[wi] - Xj.qEK) % 65536,
						(Xj.we[wi] - Xj.qEK) % 65536,
						(Xj.fL[wi] - Xj.qEK) % 65536
					)
				end
				My[(26 + Ja) % 256] = function(Qb, AV, wi, fp, qs)
					if Qb.jE == 0 then
						RW(Qb, AV, wi, fp, qs, 35)
					elseif Qb.jE == 3 then
						GM(Qb, AV, wi, fp, qs, 40)
					elseif Qb.jE == 1 then
						mo(Qb, AV, wi, fp, qs, 40)
					elseif 2 == Qb.jE then
						dT(Qb, AV, wi, fp, qs, 37)
					end
					Qb.bX -= 1
					if Qb.bX <= 0 then
						return
					end
					local FA = Qb.sW
					if FA < Qb.pbB or FA > Qb.UU then
						Qb._b(Qb, Qb.tqp[FA])
					end
					local an = FA - Qb.pbB + 1
					local Dh = (Qb.tVN[an] - Qb.qEK) % 256
					local Xj, Hl, iW, VD =
						(Qb.eXa[an] - Qb.qEK) % 65536,
						(Qb.uWE[an] - Qb.qEK) % 65536,
						(Qb.we[an] - Qb.qEK) % 65536,
						(Qb.fL[an] - Qb.qEK) % 65536
					Qb.sW = FA + 1
					return My[(Dh + Ja) % 256](Qb, Xj, Hl, iW, VD)
				end
				My[(1 + Ja) % 256] = function(VD, iW, Hl, Xj, Dh)
					if VD.jE == 3 then
						GM(VD, iW, Hl, Xj, Dh, 46)
					elseif VD.jE == 2 then
						dT(VD, iW, Hl, Xj, Dh, 41)
					elseif 1 == VD.jE then
						mo(VD, iW, Hl, Xj, Dh, 47)
					elseif 0 == VD.jE then
						RW(VD, iW, Hl, Xj, Dh, 40)
					end
					VD.bX -= 1
					if VD.bX == 0 then
						return
					end
					local an = VD.sW
					VD.sW = an + 1
					if an < VD.pbB or an > VD.UU then
						VD._b(VD, VD.tqp[an])
					end
					local FA = an - VD.pbB + 1
					local qs = (VD.tVN[FA] - VD.qEK) % 256
					local fp = My[(qs + Ja) % 256]
					return fp(
						VD,
						(VD.eXa[FA] - VD.qEK) % 65536,
						(VD.uWE[FA] - VD.qEK) % 65536,
						(VD.we[FA] - VD.qEK) % 65536,
						(VD.fL[FA] - VD.qEK) % 65536
					)
				end
				My[(25 + Ja) % 256] = function(fp, qs, FA, an, Dh)
					if 3 == fp.jE then
						GM(fp, qs, FA, an, Dh, 50)
					elseif 2 == fp.jE then
						dT(fp, qs, FA, an, Dh, 48)
					elseif fp.jE == 1 then
						mo(fp, qs, FA, an, Dh, 53)
					elseif fp.jE == 0 then
						RW(fp, qs, FA, an, Dh, 47)
					end
					fp.bX -= 1
					if fp.bX == 0 then
						return
					end
					local Xj = fp.sW
					if Xj < fp.pbB or Xj > fp.UU then
						fp._b(fp, fp.tqp[Xj])
					end
					local Hl = Xj - fp.pbB + 1
					local iW = (fp.tVN[Hl] - fp.qEK) % 256
					local VD, wi, AV, Qb =
						(fp.eXa[Hl] - fp.qEK) % 65536,
						(fp.uWE[Hl] - fp.qEK) % 65536,
						(fp.we[Hl] - fp.qEK) % 65536,
						(fp.fL[Hl] - fp.qEK) % 65536
					fp.sW = Xj + 1
					return My[(iW + Ja) % 256](fp, VD, wi, AV, Qb)
				end
				My[(19 + Ja) % 256] = function(Qb, AV, wi, VD, iW)
					if 2 == Qb.jE then
						dT(Qb, AV, wi, VD, iW, 52)
					elseif Qb.jE == 1 then
						mo(Qb, AV, wi, VD, iW, 59)
					elseif 0 == Qb.jE then
						RW(Qb, AV, wi, VD, iW, 53)
					elseif 3 == Qb.jE then
						GM(Qb, AV, wi, VD, iW, 56)
					end
					Qb.bX -= 1
					if Qb.bX <= 0 then
						return
					end
					local Hl = Qb.sW
					if Hl < Qb.pbB or Hl > Qb.UU then
						Qb._b(Qb, Qb.tqp[Hl])
					end
					local Xj = Hl - Qb.pbB + 1
					local Dh = (Qb.tVN[Xj] - Qb.qEK) % 256
					Qb.sW = Hl + 1
					return My[(Dh + Ja) % 256](
						Qb,
						(Qb.eXa[Xj] - Qb.qEK) % 65536,
						(Qb.uWE[Xj] - Qb.qEK) % 65536,
						(Qb.we[Xj] - Qb.qEK) % 65536,
						(Qb.fL[Xj] - Qb.qEK) % 65536
					)
				end
				My[(16 + Ja) % 256] = function(Dh, Xj, Hl, iW, VD)
					if Dh.jE == 0 then
						RW(Dh, Xj, Hl, iW, VD, 58)
					elseif 3 == Dh.jE then
						GM(Dh, Xj, Hl, iW, VD, 60)
					elseif Dh.jE == 2 then
						dT(Dh, Xj, Hl, iW, VD, 56)
					elseif Dh.jE == 1 then
						mo(Dh, Xj, Hl, iW, VD, 63)
					end
					Dh.bX -= 1
					if Dh.bX <= 0 then
						return
					end
					local wi = Dh.sW
					if wi < Dh.pbB or wi > Dh.UU then
						Dh._b(Dh, Dh.tqp[wi])
					end
					local AV = wi - Dh.pbB + 1
					local Qb = (Dh.tVN[AV] - Dh.qEK) % 256
					local an, FA, qs, fp =
						(Dh.eXa[AV] - Dh.qEK) % 65536,
						(Dh.uWE[AV] - Dh.qEK) % 65536,
						(Dh.we[AV] - Dh.qEK) % 65536,
						(Dh.fL[AV] - Dh.qEK) % 65536
					Dh.sW = wi + 1
					return My[(Qb + Ja) % 256](Dh, an, FA, qs, fp)
				end
				My[(3 + Ja) % 256] = function(fp, qs, FA, an, Qb)
					if fp.jE == 0 then
						RW(fp, qs, FA, an, Qb, 64)
					elseif 3 == fp.jE then
						GM(fp, qs, FA, an, Qb, 65)
					elseif 1 == fp.jE then
						mo(fp, qs, FA, an, Qb, 67)
					elseif fp.jE == 2 then
						dT(fp, qs, FA, an, Qb, 61)
					end
					fp.bX -= 1
					if fp.bX == 0 then
						return
					end
					local AV = fp.sW
					if AV < fp.pbB or AV > fp.UU then
						fp._b(fp, fp.tqp[AV])
					end
					local wi = AV - fp.pbB + 1
					local VD = My[((fp.tVN[wi] - fp.qEK) % 256 + Ja) % 256]
					fp.sW = AV + 1
					return VD(
						fp,
						(fp.eXa[wi] - fp.qEK) % 65536,
						(fp.uWE[wi] - fp.qEK) % 65536,
						(fp.we[wi] - fp.qEK) % 65536,
						(fp.fL[wi] - fp.qEK) % 65536
					)
				end
				My[(14 + Ja) % 256] = function(VD, wi, AV, Qb, an)
					if 1 == VD.jE then
						mo(VD, wi, AV, Qb, an, 71)
					elseif 0 == VD.jE then
						RW(VD, wi, AV, Qb, an, 71)
					elseif VD.jE == 3 then
						GM(VD, wi, AV, Qb, an, 70)
					elseif 2 == VD.jE then
						dT(VD, wi, AV, Qb, an, 67)
					end
					VD.bX -= 1
					if VD.bX <= 0 then
						return
					end
					local FA = VD.sW
					if FA < VD.pbB or FA > VD.UU then
						VD._b(VD, VD.tqp[FA])
					end
					local qs = FA - VD.pbB + 1
					local fp = (VD.tVN[qs] - VD.qEK) % 256
					VD.sW = FA + 1
					return My[(fp + Ja) % 256](
						VD,
						(VD.eXa[qs] - VD.qEK) % 65536,
						(VD.uWE[qs] - VD.qEK) % 65536,
						(VD.we[qs] - VD.qEK) % 65536,
						(VD.fL[qs] - VD.qEK) % 65536
					)
				end
				My[(36 + Ja) % 256] = function(fp, qs, FA, an, Qb)
					if 0 == fp.jE then
						RW(fp, qs, FA, an, Qb, 77)
					elseif 2 == fp.jE then
						dT(fp, qs, FA, an, Qb, 74)
					elseif 1 == fp.jE then
						mo(fp, qs, FA, an, Qb, 76)
					elseif fp.jE == 3 then
						GM(fp, qs, FA, an, Qb, 76)
					end
					fp.bX -= 1
					if fp.bX == 0 then
						return
					end
					local AV = fp.sW
					fp.sW = AV + 1
					if AV < fp.pbB or AV > fp.UU then
						fp._b(fp, fp.tqp[AV])
					end
					local wi = AV - fp.pbB + 1
					local VD = (fp.tVN[wi] - fp.qEK) % 256
					local iW = My[(VD + Ja) % 256]
					return iW(
						fp,
						(fp.eXa[wi] - fp.qEK) % 65536,
						(fp.uWE[wi] - fp.qEK) % 65536,
						(fp.we[wi] - fp.qEK) % 65536,
						(fp.fL[wi] - fp.qEK) % 65536
					)
				end
				My[(37 + Ja) % 256] = function(iW, VD, wi, AV, Qb)
					if iW.jE == 0 then
						RW(iW, VD, wi, AV, Qb, 83)
					elseif iW.jE == 2 then
						dT(iW, VD, wi, AV, Qb, 78)
					elseif iW.jE == 3 then
						GM(iW, VD, wi, AV, Qb, 80)
					elseif iW.jE == 1 then
						mo(iW, VD, wi, AV, Qb, 83)
					end
					iW.bX -= 1
					if iW.bX == 0 then
						return
					end
					local an = iW.sW
					if an < iW.pbB or an > iW.UU then
						iW._b(iW, iW.tqp[an])
					end
					local FA = an - iW.pbB + 1
					local qs = (iW.tVN[FA] - iW.qEK) % 256
					iW.sW = an + 1
					return My[(qs + Ja) % 256](
						iW,
						(iW.eXa[FA] - iW.qEK) % 65536,
						(iW.uWE[FA] - iW.qEK) % 65536,
						(iW.we[FA] - iW.qEK) % 65536,
						(iW.fL[FA] - iW.qEK) % 65536
					)
				end
				My[(27 + Ja) % 256] = function(qs, FA, an, Qb, AV)
					if qs.jE == 0 then
						RW(qs, FA, an, Qb, AV, 87)
					elseif 2 == qs.jE then
						dT(qs, FA, an, Qb, AV, 83)
					elseif qs.jE == 1 then
						mo(qs, FA, an, Qb, AV, 88)
					elseif qs.jE == 3 then
						GM(qs, FA, an, Qb, AV, 85)
					end
					qs.bX -= 1
					if qs.bX <= 0 then
						return
					end
					local wi = qs.sW
					if wi < qs.pbB or wi > qs.UU then
						qs._b(qs, qs.tqp[wi])
					end
					local VD = wi - qs.pbB + 1
					local iW = (qs.tVN[VD] - qs.qEK) % 256
					qs.sW = wi + 1
					return My[(iW + Ja) % 256](
						qs,
						(qs.eXa[VD] - qs.qEK) % 65536,
						(qs.uWE[VD] - qs.qEK) % 65536,
						(qs.we[VD] - qs.qEK) % 65536,
						(qs.fL[VD] - qs.qEK) % 65536
					)
				end
				My[(33 + Ja) % 256] = function(iW, VD, wi, AV, Qb)
					if iW.jE == 1 then
						mo(iW, VD, wi, AV, Qb, 92)
					elseif iW.jE == 0 then
						RW(iW, VD, wi, AV, Qb, 93)
					elseif iW.jE == 2 then
						dT(iW, VD, wi, AV, Qb, 89)
					elseif iW.jE == 3 then
						GM(iW, VD, wi, AV, Qb, 92)
					end
					iW.bX -= 1
					if iW.bX == 0 then
						return
					end
					local an = iW.sW
					if an < iW.pbB or an > iW.UU then
						iW._b(iW, iW.tqp[an])
					end
					local FA = an - iW.pbB + 1
					local qs = My[((iW.tVN[FA] - iW.qEK) % 256 + Ja) % 256]
					iW.sW = an + 1
					return qs(
						iW,
						(iW.eXa[FA] - iW.qEK) % 65536,
						(iW.uWE[FA] - iW.qEK) % 65536,
						(iW.we[FA] - iW.qEK) % 65536,
						(iW.fL[FA] - iW.qEK) % 65536
					)
				end
				My[(41 + Ja) % 256] = function(qs, FA, an, Qb, AV)
					if 2 == qs.jE then
						dT(qs, FA, an, Qb, AV, 95)
					elseif qs.jE == 1 then
						mo(qs, FA, an, Qb, AV, 96)
					elseif 0 == qs.jE then
						RW(qs, FA, an, Qb, AV, 99)
					elseif qs.jE == 3 then
						GM(qs, FA, an, Qb, AV, 97)
					end
					qs.bX -= 1
					if qs.bX == 0 then
						return
					end
					local wi = qs.sW
					if wi < qs.pbB or wi > qs.UU then
						qs._b(qs, qs.tqp[wi])
					end
					local VD = wi - qs.pbB + 1
					local iW = My[((qs.tVN[VD] - qs.qEK) % 256 + Ja) % 256]
					qs.sW = wi + 1
					return iW(
						qs,
						(qs.eXa[VD] - qs.qEK) % 65536,
						(qs.uWE[VD] - qs.qEK) % 65536,
						(qs.we[VD] - qs.qEK) % 65536,
						(qs.fL[VD] - qs.qEK) % 65536
					)
				end
				My[(20 + Ja) % 256] = function(iW, VD, wi, AV, Qb)
					if iW.jE == 3 then
						GM(iW, VD, wi, AV, Qb, 104)
					elseif 2 == iW.jE then
						dT(iW, VD, wi, AV, Qb, 100)
					elseif 0 == iW.jE then
						RW(iW, VD, wi, AV, Qb, 103)
					elseif iW.jE == 1 then
						mo(iW, VD, wi, AV, Qb, 102)
					end
					iW.bX -= 1
					if iW.bX == 0 then
						return
					end
					local an = iW.sW
					if an < iW.pbB or an > iW.UU then
						iW._b(iW, iW.tqp[an])
					end
					local FA = an - iW.pbB + 1
					local qs = (iW.tVN[FA] - iW.qEK) % 256
					iW.sW = an + 1
					return My[(qs + Ja) % 256](
						iW,
						(iW.eXa[FA] - iW.qEK) % 65536,
						(iW.uWE[FA] - iW.qEK) % 65536,
						(iW.we[FA] - iW.qEK) % 65536,
						(iW.fL[FA] - iW.qEK) % 65536
					)
				end
				My[(9 + Ja) % 256] = function(qs, FA, an, Qb, AV)
					if 2 == qs.jE then
						dT(qs, FA, an, Qb, AV, 106)
					elseif 0 == qs.jE then
						RW(qs, FA, an, Qb, AV, 109)
					elseif 3 == qs.jE then
						GM(qs, FA, an, Qb, AV, 109)
					elseif 1 == qs.jE then
						mo(qs, FA, an, Qb, AV, 107)
					end
					return
				end
				My[(30 + Ja) % 256] = function(AV, Qb, an, FA, qs)
					if AV.jE == 1 then
						mo(AV, Qb, an, FA, qs, 111)
					elseif 2 == AV.jE then
						dT(AV, Qb, an, FA, qs, 110)
					elseif AV.jE == 3 then
						GM(AV, Qb, an, FA, qs, 115)
					elseif 0 == AV.jE then
						RW(AV, Qb, an, FA, qs, 114)
					end
					AV.bX -= 1
					if AV.bX == 0 then
						return
					end
					local wi = AV.sW
					if wi < AV.pbB or wi > AV.UU then
						AV._b(AV, AV.tqp[wi])
					end
					local VD = wi - AV.pbB + 1
					local iW = (AV.tVN[VD] - AV.qEK) % 256
					local fp, Hl, Xj, Dh =
						(AV.eXa[VD] - AV.qEK) % 65536,
						(AV.uWE[VD] - AV.qEK) % 65536,
						(AV.we[VD] - AV.qEK) % 65536,
						(AV.fL[VD] - AV.qEK) % 65536
					AV.sW = wi + 1
					return My[(iW + Ja) % 256](AV, fp, Hl, Xj, Dh)
				end
				My[(11 + Ja) % 256] = function(Dh, Xj, Hl, fp, iW)
					if Dh.jE == 2 then
						dT(Dh, Xj, Hl, fp, iW, 116)
					elseif Dh.jE == 0 then
						RW(Dh, Xj, Hl, fp, iW, 119)
					elseif 1 == Dh.jE then
						mo(Dh, Xj, Hl, fp, iW, 118)
					elseif 3 == Dh.jE then
						GM(Dh, Xj, Hl, fp, iW, 119)
					end
					Dh.bX -= 1
					if Dh.bX == 0 then
						return
					end
					local VD = Dh.sW
					if VD < Dh.pbB or VD > Dh.UU then
						Dh._b(Dh, Dh.tqp[VD])
					end
					local wi = VD - Dh.pbB + 1
					local qs = (Dh.tVN[wi] - Dh.qEK) % 256
					Dh.sW = VD + 1
					return My[(qs + Ja) % 256](
						Dh,
						(Dh.eXa[wi] - Dh.qEK) % 65536,
						(Dh.uWE[wi] - Dh.qEK) % 65536,
						(Dh.we[wi] - Dh.qEK) % 65536,
						(Dh.fL[wi] - Dh.qEK) % 65536
					)
				end
				My[(28 + Ja) % 256] = function(qs, wi, VD, iW, fp)
					if 2 == qs.jE then
						dT(qs, wi, VD, iW, fp, 122)
					elseif qs.jE == 0 then
						RW(qs, wi, VD, iW, fp, 124)
					elseif qs.jE == 3 then
						GM(qs, wi, VD, iW, fp, 126)
					elseif 1 == qs.jE then
						mo(qs, wi, VD, iW, fp, 125)
					end
					qs.bX -= 1
					if qs.bX == 0 then
						return
					end
					local Hl = qs.sW
					if Hl < qs.pbB or Hl > qs.UU then
						qs._b(qs, qs.tqp[Hl])
					end
					local Xj = Hl - qs.pbB + 1
					local Dh = (qs.tVN[Xj] - qs.qEK) % 256
					local FA, an, Qb, AV =
						(qs.eXa[Xj] - qs.qEK) % 65536,
						(qs.uWE[Xj] - qs.qEK) % 65536,
						(qs.we[Xj] - qs.qEK) % 65536,
						(qs.fL[Xj] - qs.qEK) % 65536
					qs.sW = Hl + 1
					return My[(Dh + Ja) % 256](qs, FA, an, Qb, AV)
				end
				zb = function(AV)
					local Qb = AV.NDWY(
						AV[AV.xT + 768 + 0 * AV.rp](AV[21](AV[AV.xT + 768 + 1 * AV.rp], 1, AV[AV.xT + 768 + 2 * AV.rp]))
					)
					if AV.jE == 0 then
						RW(
							AV,
							AV[AV.xT + 768 + 3 * AV.rp],
							AV[AV.xT + 768 + 4 * AV.rp],
							AV[AV.xT + 768 + 5 * AV.rp],
							AV[AV.xT + 768 + 6 * AV.rp],
							129,
							Qb,
							Qb.n
						)
					elseif 3 == AV.jE then
						GM(
							AV,
							AV[AV.xT + 768 + 3 * AV.rp],
							AV[AV.xT + 768 + 4 * AV.rp],
							AV[AV.xT + 768 + 5 * AV.rp],
							AV[AV.xT + 768 + 6 * AV.rp],
							131,
							Qb,
							Qb.n
						)
					elseif AV.jE == 1 then
						mo(
							AV,
							AV[AV.xT + 768 + 3 * AV.rp],
							AV[AV.xT + 768 + 4 * AV.rp],
							AV[AV.xT + 768 + 5 * AV.rp],
							AV[AV.xT + 768 + 6 * AV.rp],
							130,
							Qb,
							Qb.n
						)
					elseif AV.jE == 2 then
						dT(
							AV,
							AV[AV.xT + 768 + 3 * AV.rp],
							AV[AV.xT + 768 + 4 * AV.rp],
							AV[AV.xT + 768 + 5 * AV.rp],
							AV[AV.xT + 768 + 6 * AV.rp],
							128,
							Qb,
							Qb.n
						)
					end
					for an = 0, 8 do
						AV[AV.xT + 768 + an * AV.rp] = nil
					end
					AV.bX -= 1
					if AV.bX <= 0 then
						return
					end
					local an = AV.sW
					if an < AV.pbB or an > AV.UU then
						AV._b(AV, AV.tqp[an])
					end
					local FA = an - AV.pbB + 1
					local Dh = (AV.tVN[FA] - AV.qEK) % 256
					local Xj, Hl, fp, iW =
						(AV.eXa[FA] - AV.qEK) % 65536,
						(AV.uWE[FA] - AV.qEK) % 65536,
						(AV.we[FA] - AV.qEK) % 65536,
						(AV.fL[FA] - AV.qEK) % 65536
					AV.sW = an + 1
					return My[(Dh + Ja) % 256](AV, Xj, Hl, fp, iW)
				end
				My[(35 + Ja) % 256] = function(iW, fp, Hl, Xj, Dh)
					if iW.jE == 2 then
						dT(iW, fp, Hl, Xj, Dh, 133)
					elseif iW.jE == 1 then
						mo(iW, fp, Hl, Xj, Dh, 134)
					elseif 0 == iW.jE then
						RW(iW, fp, Hl, Xj, Dh, 133)
					elseif 3 == iW.jE then
						GM(iW, fp, Hl, Xj, Dh, 138)
					end
					return
				end
				My[(4 + Ja) % 256] = function(Dh, Xj, Hl, fp, iW)
					if 2 == Dh.jE then
						dT(Dh, Xj, Hl, fp, iW, 139)
					elseif 0 == Dh.jE then
						RW(Dh, Xj, Hl, fp, iW, 140)
					elseif Dh.jE == 3 then
						GM(Dh, Xj, Hl, fp, iW, 144)
					elseif Dh.jE == 1 then
						mo(Dh, Xj, Hl, fp, iW, 138)
					end
					Dh.bX -= 1
					if Dh.bX <= 0 then
						return
					end
					local FA = Dh.sW
					if FA < Dh.pbB or FA > Dh.UU then
						Dh._b(Dh, Dh.tqp[FA])
					end
					local an = FA - Dh.pbB + 1
					local Qb = My[((Dh.tVN[an] - Dh.qEK) % 256 + Ja) % 256]
					Dh.sW = FA + 1
					return Qb(
						Dh,
						(Dh.eXa[an] - Dh.qEK) % 65536,
						(Dh.uWE[an] - Dh.qEK) % 65536,
						(Dh.we[an] - Dh.qEK) % 65536,
						(Dh.fL[an] - Dh.qEK) % 65536
					)
				end
				My[(5 + Ja) % 256] = function(Qb, an, FA, iW, fp)
					if Qb.jE == 0 then
						RW(Qb, an, FA, iW, fp, 144)
					elseif 3 == Qb.jE then
						GM(Qb, an, FA, iW, fp, 150)
					elseif Qb.jE == 2 then
						dT(Qb, an, FA, iW, fp, 145)
					elseif 1 == Qb.jE then
						mo(Qb, an, FA, iW, fp, 143)
					end
					Qb.bX -= 1
					if Qb.bX == 0 then
						return
					end
					local Hl = Qb.sW
					if Hl < Qb.pbB or Hl > Qb.UU then
						Qb._b(Qb, Qb.tqp[Hl])
					end
					local Xj = Hl - Qb.pbB + 1
					local Dh = (Qb.tVN[Xj] - Qb.qEK) % 256
					local AV, VD, wi, qs =
						(Qb.eXa[Xj] - Qb.qEK) % 65536,
						(Qb.uWE[Xj] - Qb.qEK) % 65536,
						(Qb.we[Xj] - Qb.qEK) % 65536,
						(Qb.fL[Xj] - Qb.qEK) % 65536
					Qb.sW = Hl + 1
					return My[(Dh + Ja) % 256](Qb, AV, VD, wi, qs)
				end
				My[(8 + Ja) % 256] = function(qs, wi, VD, AV, Dh)
					if qs.jE == 2 then
						dT(qs, wi, VD, AV, Dh, 150)
					elseif qs.jE == 0 then
						RW(qs, wi, VD, AV, Dh, 148)
					elseif 3 == qs.jE then
						GM(qs, wi, VD, AV, Dh, 154)
					elseif qs.jE == 1 then
						mo(qs, wi, VD, AV, Dh, 150)
					end
					qs.bX -= 1
					if qs.bX <= 0 then
						return
					end
					local Xj = qs.sW
					qs.sW = Xj + 1
					if Xj < qs.pbB or Xj > qs.UU then
						qs._b(qs, qs.tqp[Xj])
					end
					local Hl = Xj - qs.pbB + 1
					local fp = (qs.tVN[Hl] - qs.qEK) % 256
					local iW = My[(fp + Ja) % 256]
					return iW(
						qs,
						(qs.eXa[Hl] - qs.qEK) % 65536,
						(qs.uWE[Hl] - qs.qEK) % 65536,
						(qs.we[Hl] - qs.qEK) % 65536,
						(qs.fL[Hl] - qs.qEK) % 65536
					)
				end
				My[(23 + Ja) % 256] = function(iW, fp, Hl, Xj, Dh)
					if 2 == iW.jE then
						dT(iW, fp, Hl, Xj, Dh, 156)
					elseif 0 == iW.jE then
						RW(iW, fp, Hl, Xj, Dh, 152)
					elseif 1 == iW.jE then
						mo(iW, fp, Hl, Xj, Dh, 156)
					elseif 3 == iW.jE then
						GM(iW, fp, Hl, Xj, Dh, 160)
					end
					iW.bX -= 1
					if iW.bX <= 0 then
						return
					end
					local AV = iW.sW
					if AV < iW.pbB or AV > iW.UU then
						iW._b(iW, iW.tqp[AV])
					end
					local VD = AV - iW.pbB + 1
					local wi = (iW.tVN[VD] - iW.qEK) % 256
					iW.sW = AV + 1
					return My[(wi + Ja) % 256](
						iW,
						(iW.eXa[VD] - iW.qEK) % 65536,
						(iW.uWE[VD] - iW.qEK) % 65536,
						(iW.we[VD] - iW.qEK) % 65536,
						(iW.fL[VD] - iW.qEK) % 65536
					)
				end
				My[(40 + Ja) % 256] = function(wi, VD, AV, Dh, Xj)
					if 0 == wi.jE then
						RW(wi, VD, AV, Dh, Xj, 157)
					elseif wi.jE == 2 then
						dT(wi, VD, AV, Dh, Xj, 160)
					elseif wi.jE == 1 then
						mo(wi, VD, AV, Dh, Xj, 160)
					elseif 3 == wi.jE then
						GM(wi, VD, AV, Dh, Xj, 164)
					end
					wi.bX -= 1
					if wi.bX <= 0 then
						return
					end
					local Hl = wi.sW
					if Hl < wi.pbB or Hl > wi.UU then
						wi._b(wi, wi.tqp[Hl])
					end
					local fp = Hl - wi.pbB + 1
					local iW = My[((wi.tVN[fp] - wi.qEK) % 256 + Ja) % 256]
					wi.sW = Hl + 1
					return iW(
						wi,
						(wi.eXa[fp] - wi.qEK) % 65536,
						(wi.uWE[fp] - wi.qEK) % 65536,
						(wi.we[fp] - wi.qEK) % 65536,
						(wi.fL[fp] - wi.qEK) % 65536
					)
				end
				My[(42 + Ja) % 256] = function(iW, fp, Hl, Xj, Dh)
					if 1 == iW.jE then
						mo(iW, fp, Hl, Xj, Dh, 164)
					elseif iW.jE == 3 then
						GM(iW, fp, Hl, Xj, Dh, 170)
					elseif iW.jE == 0 then
						RW(iW, fp, Hl, Xj, Dh, 161)
					elseif 2 == iW.jE then
						dT(iW, fp, Hl, Xj, Dh, 166)
					end
					iW.bX -= 1
					if iW.bX <= 0 then
						return
					end
					local AV = iW.sW
					if AV < iW.pbB or AV > iW.UU then
						iW._b(iW, iW.tqp[AV])
					end
					local VD = AV - iW.pbB + 1
					local wi = My[((iW.tVN[VD] - iW.qEK) % 256 + Ja) % 256]
					iW.sW = AV + 1
					return wi(
						iW,
						(iW.eXa[VD] - iW.qEK) % 65536,
						(iW.uWE[VD] - iW.qEK) % 65536,
						(iW.we[VD] - iW.qEK) % 65536,
						(iW.fL[VD] - iW.qEK) % 65536
					)
				end
				Am = function(wi)
					local VD = wi.NDWY(
						wi[wi.xT + 1024 + 0 * wi.rp](
							wi[21](wi[wi.xT + 1024 + 1 * wi.rp], 1, wi[wi.xT + 1024 + 2 * wi.rp])
						)
					)
					if 0 == wi.jE then
						RW(
							wi,
							wi[wi.xT + 1024 + 3 * wi.rp],
							wi[wi.xT + 1024 + 4 * wi.rp],
							wi[wi.xT + 1024 + 5 * wi.rp],
							wi[wi.xT + 1024 + 6 * wi.rp],
							166,
							VD,
							VD.n
						)
					elseif wi.jE == 2 then
						dT(
							wi,
							wi[wi.xT + 1024 + 3 * wi.rp],
							wi[wi.xT + 1024 + 4 * wi.rp],
							wi[wi.xT + 1024 + 5 * wi.rp],
							wi[wi.xT + 1024 + 6 * wi.rp],
							172,
							VD,
							VD.n
						)
					elseif wi.jE == 1 then
						mo(
							wi,
							wi[wi.xT + 1024 + 3 * wi.rp],
							wi[wi.xT + 1024 + 4 * wi.rp],
							wi[wi.xT + 1024 + 5 * wi.rp],
							wi[wi.xT + 1024 + 6 * wi.rp],
							169,
							VD,
							VD.n
						)
					elseif 3 == wi.jE then
						GM(
							wi,
							wi[wi.xT + 1024 + 3 * wi.rp],
							wi[wi.xT + 1024 + 4 * wi.rp],
							wi[wi.xT + 1024 + 5 * wi.rp],
							wi[wi.xT + 1024 + 6 * wi.rp],
							177,
							VD,
							VD.n
						)
					end
					for AV = 0, 8 do
						wi[wi.xT + 1024 + AV * wi.rp] = nil
					end
					wi.bX -= 1
					if wi.bX == 0 then
						return
					end
					local AV = wi.sW
					if AV < wi.pbB or AV > wi.UU then
						wi._b(wi, wi.tqp[AV])
					end
					local Dh = AV - wi.pbB + 1
					local Xj = My[((wi.tVN[Dh] - wi.qEK) % 256 + Ja) % 256]
					wi.sW = AV + 1
					return Xj(
						wi,
						(wi.eXa[Dh] - wi.qEK) % 65536,
						(wi.uWE[Dh] - wi.qEK) % 65536,
						(wi.we[Dh] - wi.qEK) % 65536,
						(wi.fL[Dh] - wi.qEK) % 65536
					)
				end
				My[(0 + Ja) % 256] = function(Xj, Dh, AV, VD, wi)
					if Xj.jE == 2 then
						dT(Xj, Dh, AV, VD, wi, 176)
					elseif Xj.jE == 3 then
						GM(Xj, Dh, AV, VD, wi, 183)
					elseif 0 == Xj.jE then
						RW(Xj, Dh, AV, VD, wi, 172)
					elseif Xj.jE == 1 then
						mo(Xj, Dh, AV, VD, wi, 173)
					end
					return
				end
				My[(22 + Ja) % 256] = function(wi, VD, AV, Dh, Xj)
					if wi.jE == 1 then
						mo(wi, VD, AV, Dh, Xj, 179)
					elseif wi.jE == 2 then
						dT(wi, VD, AV, Dh, Xj, 182)
					elseif wi.jE == 0 then
						RW(wi, VD, AV, Dh, Xj, 177)
					elseif 3 == wi.jE then
						GM(wi, VD, AV, Dh, Xj, 189)
					end
					wi.bX -= 1
					if wi.bX == 0 then
						return
					end
					local Hl = wi.sW
					if Hl < wi.pbB or Hl > wi.UU then
						wi._b(wi, wi.tqp[Hl])
					end
					local fp = Hl - wi.pbB + 1
					local iW = (wi.tVN[fp] - wi.qEK) % 256
					wi.sW = Hl + 1
					return My[(iW + Ja) % 256](
						wi,
						(wi.eXa[fp] - wi.qEK) % 65536,
						(wi.uWE[fp] - wi.qEK) % 65536,
						(wi.we[fp] - wi.qEK) % 65536,
						(wi.fL[fp] - wi.qEK) % 65536
					)
				end
				My[(21 + Ja) % 256] = function(iW, fp, Hl, Xj, Dh)
					if iW.jE == 1 then
						mo(iW, fp, Hl, Xj, Dh, 184)
					elseif 2 == iW.jE then
						dT(iW, fp, Hl, Xj, Dh, 189)
					elseif 0 == iW.jE then
						RW(iW, fp, Hl, Xj, Dh, 181)
					elseif 3 == iW.jE then
						GM(iW, fp, Hl, Xj, Dh, 193)
					end
					iW.bX -= 1
					if iW.bX <= 0 then
						return
					end
					local AV = iW.sW
					if AV < iW.pbB or AV > iW.UU then
						iW._b(iW, iW.tqp[AV])
					end
					local VD = AV - iW.pbB + 1
					iW.sW = AV + 1
					return My[((iW.tVN[VD] - iW.qEK) % 256 + Ja) % 256](
						iW,
						(iW.eXa[VD] - iW.qEK) % 65536,
						(iW.uWE[VD] - iW.qEK) % 65536,
						(iW.we[VD] - iW.qEK) % 65536,
						(iW.fL[VD] - iW.qEK) % 65536
					)
				end
				My[(18 + Ja) % 256] = function(VD, AV, Dh, Xj, Hl)
					if VD.jE == 0 then
						RW(VD, AV, Dh, Xj, Hl, 185)
					elseif VD.jE == 1 then
						mo(VD, AV, Dh, Xj, Hl, 188)
					elseif VD.jE == 2 then
						dT(VD, AV, Dh, Xj, Hl, 195)
					elseif VD.jE == 3 then
						GM(VD, AV, Dh, Xj, Hl, 197)
					end
					VD.bX -= 1
					if VD.bX == 0 then
						return
					end
					local fp = VD.sW
					if fp < VD.pbB or fp > VD.UU then
						VD._b(VD, VD.tqp[fp])
					end
					local iW = fp - VD.pbB + 1
					local wi = (VD.tVN[iW] - VD.qEK) % 256
					VD.sW = fp + 1
					return My[(wi + Ja) % 256](
						VD,
						(VD.eXa[iW] - VD.qEK) % 65536,
						(VD.uWE[iW] - VD.qEK) % 65536,
						(VD.we[iW] - VD.qEK) % 65536,
						(VD.fL[iW] - VD.qEK) % 65536
					)
				end
				My[(29 + Ja) % 256] = function(wi, iW, fp, Hl, Xj)
					if wi.jE == 3 then
						GM(wi, iW, fp, Hl, Xj, 202)
					elseif 1 == wi.jE then
						mo(wi, iW, fp, Hl, Xj, 194)
					elseif wi.jE == 0 then
						RW(wi, iW, fp, Hl, Xj, 192)
					elseif wi.jE == 2 then
						dT(wi, iW, fp, Hl, Xj, 199)
					end
					wi.bX -= 1
					if wi.bX == 0 then
						return
					end
					local Dh = wi.sW
					wi.sW = Dh + 1
					if Dh < wi.pbB or Dh > wi.UU then
						wi._b(wi, wi.tqp[Dh])
					end
					local AV = Dh - wi.pbB + 1
					local VD = (wi.tVN[AV] - wi.qEK) % 256
					local qs = My[(VD + Ja) % 256]
					return qs(
						wi,
						(wi.eXa[AV] - wi.qEK) % 65536,
						(wi.uWE[AV] - wi.qEK) % 65536,
						(wi.we[AV] - wi.qEK) % 65536,
						(wi.fL[AV] - wi.qEK) % 65536
					)
				end
				My[(17 + Ja) % 256] = function(qs, VD, AV, Dh, Xj)
					if qs.jE == 1 then
						mo(qs, VD, AV, Dh, Xj, 199)
					elseif 2 == qs.jE then
						dT(qs, VD, AV, Dh, Xj, 203)
					elseif qs.jE == 0 then
						RW(qs, VD, AV, Dh, Xj, 199)
					elseif qs.jE == 3 then
						GM(qs, VD, AV, Dh, Xj, 207)
					end
					qs.bX -= 1
					if qs.bX <= 0 then
						return
					end
					local Hl = qs.sW
					if Hl < qs.pbB or Hl > qs.UU then
						qs._b(qs, qs.tqp[Hl])
					end
					local fp = Hl - qs.pbB + 1
					local iW = My[((qs.tVN[fp] - qs.qEK) % 256 + Ja) % 256]
					qs.sW = Hl + 1
					return iW(
						qs,
						(qs.eXa[fp] - qs.qEK) % 65536,
						(qs.uWE[fp] - qs.qEK) % 65536,
						(qs.we[fp] - qs.qEK) % 65536,
						(qs.fL[fp] - qs.qEK) % 65536
					)
				end
				My[(2 + Ja) % 256] = function(iW, fp, Hl, Xj, Dh)
					if 1 == iW.jE then
						mo(iW, fp, Hl, Xj, Dh, 203)
					elseif 0 == iW.jE then
						RW(iW, fp, Hl, Xj, Dh, 204)
					elseif 3 == iW.jE then
						GM(iW, fp, Hl, Xj, Dh, 211)
					elseif 2 == iW.jE then
						dT(iW, fp, Hl, Xj, Dh, 209)
					end
					iW.bX -= 1
					if iW.bX <= 0 then
						return
					end
					local AV = iW.sW
					if AV < iW.pbB or AV > iW.UU then
						iW._b(iW, iW.tqp[AV])
					end
					local VD = AV - iW.pbB + 1
					local qs = My[((iW.tVN[VD] - iW.qEK) % 256 + Ja) % 256]
					iW.sW = AV + 1
					return qs(
						iW,
						(iW.eXa[VD] - iW.qEK) % 65536,
						(iW.uWE[VD] - iW.qEK) % 65536,
						(iW.we[VD] - iW.qEK) % 65536,
						(iW.fL[VD] - iW.qEK) % 65536
					)
				end
				My[(32 + Ja) % 256] = function(qs, VD, AV, Dh, Xj)
					if 2 == qs.jE then
						dT(qs, VD, AV, Dh, Xj, 215)
					elseif 1 == qs.jE then
						mo(qs, VD, AV, Dh, Xj, 209)
					elseif qs.jE == 3 then
						GM(qs, VD, AV, Dh, Xj, 217)
					elseif qs.jE == 0 then
						RW(qs, VD, AV, Dh, Xj, 211)
					end
					qs.bX -= 1
					if qs.bX <= 0 then
						return
					end
					local Hl = qs.sW
					if Hl < qs.pbB or Hl > qs.UU then
						qs._b(qs, qs.tqp[Hl])
					end
					local fp = Hl - qs.pbB + 1
					local iW = (qs.tVN[fp] - qs.qEK) % 256
					local wi, FA, an, Qb =
						(qs.eXa[fp] - qs.qEK) % 65536,
						(qs.uWE[fp] - qs.qEK) % 65536,
						(qs.we[fp] - qs.qEK) % 65536,
						(qs.fL[fp] - qs.qEK) % 65536
					qs.sW = Hl + 1
					return My[(iW + Ja) % 256](qs, wi, FA, an, Qb)
				end
				My[(34 + Ja) % 256] = function(Qb, an, FA, wi, iW)
					if 2 == Qb.jE then
						dT(Qb, an, FA, wi, iW, 221)
					elseif Qb.jE == 1 then
						mo(Qb, an, FA, wi, iW, 213)
					elseif 0 == Qb.jE then
						RW(Qb, an, FA, wi, iW, 215)
					elseif Qb.jE == 3 then
						GM(Qb, an, FA, wi, iW, 224)
					end
					Qb.bX -= 1
					if Qb.bX == 0 then
						return
					end
					local fp = Qb.sW
					Qb.sW = fp + 1
					if fp < Qb.pbB or fp > Qb.UU then
						Qb._b(Qb, Qb.tqp[fp])
					end
					local Hl = fp - Qb.pbB + 1
					local Xj = (Qb.tVN[Hl] - Qb.qEK) % 256
					local Dh = My[(Xj + Ja) % 256]
					return Dh(
						Qb,
						(Qb.eXa[Hl] - Qb.qEK) % 65536,
						(Qb.uWE[Hl] - Qb.qEK) % 65536,
						(Qb.we[Hl] - Qb.qEK) % 65536,
						(Qb.fL[Hl] - Qb.qEK) % 65536
					)
				end
				My[(43 + Ja) % 256] = function(Dh, Xj, Hl, fp, iW)
					if 0 == Dh.jE then
						RW(Dh, Xj, Hl, fp, iW, 219)
					elseif Dh.jE == 2 then
						dT(Dh, Xj, Hl, fp, iW, 228)
					elseif 1 == Dh.jE then
						mo(Dh, Xj, Hl, fp, iW, 219)
					elseif 3 == Dh.jE then
						GM(Dh, Xj, Hl, fp, iW, 230)
					end
					Dh.bX -= 1
					if Dh.bX == 0 then
						return
					end
					local wi = Dh.sW
					if wi < Dh.pbB or wi > Dh.UU then
						Dh._b(Dh, Dh.tqp[wi])
					end
					local FA = wi - Dh.pbB + 1
					local an = (Dh.tVN[FA] - Dh.qEK) % 256
					local Qb, AV, VD, qs =
						(Dh.eXa[FA] - Dh.qEK) % 65536,
						(Dh.uWE[FA] - Dh.qEK) % 65536,
						(Dh.we[FA] - Dh.qEK) % 65536,
						(Dh.fL[FA] - Dh.qEK) % 65536
					Dh.sW = wi + 1
					return My[(an + Ja) % 256](Dh, Qb, AV, VD, qs)
				end
				My[(13 + Ja) % 256] = function(qs, VD, AV, Qb, an)
					if qs.jE == 0 then
						RW(qs, VD, AV, Qb, an, 225)
					elseif 2 == qs.jE then
						dT(qs, VD, AV, Qb, an, 232)
					elseif 3 == qs.jE then
						GM(qs, VD, AV, Qb, an, 237)
					elseif qs.jE == 1 then
						mo(qs, VD, AV, Qb, an, 226)
					end
					qs.bX -= 1
					if qs.bX <= 0 then
						return
					end
					local FA = qs.sW
					if FA < qs.pbB or FA > qs.UU then
						qs._b(qs, qs.tqp[FA])
					end
					local wi = FA - qs.pbB + 1
					local iW = (qs.tVN[wi] - qs.qEK) % 256
					local fp, Hl, Xj, Dh =
						(qs.eXa[wi] - qs.qEK) % 65536,
						(qs.uWE[wi] - qs.qEK) % 65536,
						(qs.we[wi] - qs.qEK) % 65536,
						(qs.fL[wi] - qs.qEK) % 65536
					qs.sW = FA + 1
					return My[(iW + Ja) % 256](qs, fp, Hl, Xj, Dh)
				end
				My[(7 + Ja) % 256] = function(Dh, Xj, Hl, fp, iW)
					if 3 == Dh.jE then
						GM(Dh, Xj, Hl, fp, iW, 244)
					elseif 0 == Dh.jE then
						RW(Dh, Xj, Hl, fp, iW, 232)
					elseif Dh.jE == 2 then
						dT(Dh, Xj, Hl, fp, iW, 237)
					elseif 1 == Dh.jE then
						mo(Dh, Xj, Hl, fp, iW, 233)
					end
					Dh.bX -= 1
					if Dh.bX == 0 then
						return
					end
					local wi = Dh.sW
					Dh.sW = wi + 1
					if wi < Dh.pbB or wi > Dh.UU then
						Dh._b(Dh, Dh.tqp[wi])
					end
					local FA = wi - Dh.pbB + 1
					local an = (Dh.tVN[FA] - Dh.qEK) % 256
					local Qb = My[(an + Ja) % 256]
					return Qb(
						Dh,
						(Dh.eXa[FA] - Dh.qEK) % 65536,
						(Dh.uWE[FA] - Dh.qEK) % 65536,
						(Dh.we[FA] - Dh.qEK) % 65536,
						(Dh.fL[FA] - Dh.qEK) % 65536
					)
				end
				My[(38 + Ja) % 256] = function(Qb, an, FA, wi, iW)
					if 2 == Qb.jE then
						dT(Qb, an, FA, wi, iW, 244)
					elseif Qb.jE == 1 then
						mo(Qb, an, FA, wi, iW, 238)
					elseif 0 == Qb.jE then
						RW(Qb, an, FA, wi, iW, 236)
					elseif 3 == Qb.jE then
						GM(Qb, an, FA, wi, iW, 251)
					end
					Qb.bX -= 1
					if Qb.bX == 0 then
						return
					end
					local fp = Qb.sW
					if fp < Qb.pbB or fp > Qb.UU then
						Qb._b(Qb, Qb.tqp[fp])
					end
					local Hl = fp - Qb.pbB + 1
					local Xj = (Qb.tVN[Hl] - Qb.qEK) % 256
					Qb.sW = fp + 1
					return My[(Xj + Ja) % 256](
						Qb,
						(Qb.eXa[Hl] - Qb.qEK) % 65536,
						(Qb.uWE[Hl] - Qb.qEK) % 65536,
						(Qb.we[Hl] - Qb.qEK) % 65536,
						(Qb.fL[Hl] - Qb.qEK) % 65536
					)
				end
				My[(12 + Ja) % 256] = function(Xj, Hl, fp, iW, wi)
					if Xj.jE == 2 then
						dT(Xj, Hl, fp, iW, wi, 251)
					elseif Xj.jE == 3 then
						GM(Xj, Hl, fp, iW, wi, 255)
					elseif Xj.jE == 1 then
						mo(Xj, Hl, fp, iW, wi, 243)
					elseif Xj.jE == 0 then
						RW(Xj, Hl, fp, iW, wi, 240)
					end
					Xj.bX -= 1
					if Xj.bX == 0 then
						return
					end
					local FA = Xj.sW
					Xj.sW = FA + 1
					if FA < Xj.pbB or FA > Xj.UU then
						Xj._b(Xj, Xj.tqp[FA])
					end
					local an = FA - Xj.pbB + 1
					local Qb = (Xj.tVN[an] - Xj.qEK) % 256
					local Dh = My[(Qb + Ja) % 256]
					return Dh(
						Xj,
						(Xj.eXa[an] - Xj.qEK) % 65536,
						(Xj.uWE[an] - Xj.qEK) % 65536,
						(Xj.we[an] - Xj.qEK) % 65536,
						(Xj.fL[an] - Xj.qEK) % 65536
					)
				end
				My[(15 + Ja) % 256] = function(Dh, Qb, an, FA, wi)
					if Dh.jE == 0 then
						RW(Dh, Qb, an, FA, wi, 246)
					elseif 2 == Dh.jE then
						dT(Dh, Qb, an, FA, wi, 257)
					elseif Dh.jE == 1 then
						mo(Dh, Qb, an, FA, wi, 248)
					elseif 3 == Dh.jE then
						GM(Dh, Qb, an, FA, wi, 260)
					end
					Dh.bX -= 1
					if Dh.bX <= 0 then
						return
					end
					local iW = Dh.sW
					Dh.sW = iW + 1
					if iW < Dh.pbB or iW > Dh.UU then
						Dh._b(Dh, Dh.tqp[iW])
					end
					local fp = iW - Dh.pbB + 1
					local Hl = (Dh.tVN[fp] - Dh.qEK) % 256
					local Xj = My[(Hl + Ja) % 256]
					return Xj(
						Dh,
						(Dh.eXa[fp] - Dh.qEK) % 65536,
						(Dh.uWE[fp] - Dh.qEK) % 65536,
						(Dh.we[fp] - Dh.qEK) % 65536,
						(Dh.fL[fp] - Dh.qEK) % 65536
					)
				end
				My[(176 + Ja) % 256] = function(Xj, Hl, fp, iW, wi)
					if Xj.jE == 0 then
						RW(Xj, Hl, fp, iW, wi, 252)
					elseif 3 == Xj.jE then
						GM(Xj, Hl, fp, iW, wi, 265)
					elseif 1 == Xj.jE then
						mo(Xj, Hl, fp, iW, wi, 254)
					elseif Xj.jE == 2 then
						dT(Xj, Hl, fp, iW, wi, 263)
					end
					return
				end
				My[(177 + Ja) % 256] = function(wi, iW, fp, Hl, Xj)
					if 2 == wi.jE then
						dT(wi, iW, fp, Hl, Xj, 267)
					elseif 1 == wi.jE then
						mo(wi, iW, fp, Hl, Xj, 260)
					elseif wi.jE == 3 then
						GM(wi, iW, fp, Hl, Xj, 269)
					elseif 0 == wi.jE then
						RW(wi, iW, fp, Hl, Xj, 258)
					end
					return
				end
				My[(178 + Ja) % 256] = function(Xj, Hl, fp, iW, wi)
					if Xj.jE == 3 then
						GM(Xj, Hl, fp, iW, wi, 276)
					elseif 2 == Xj.jE then
						dT(Xj, Hl, fp, iW, wi, 271)
					elseif 1 == Xj.jE then
						mo(Xj, Hl, fp, iW, wi, 267)
					elseif 0 == Xj.jE then
						RW(Xj, Hl, fp, iW, wi, 264)
					end
					return
				end
				My[(179 + Ja) % 256] = function(wi, iW, fp, Hl, Xj)
					if wi.jE == 3 then
						GM(wi, iW, fp, Hl, Xj, 281)
					elseif wi.jE == 1 then
						mo(wi, iW, fp, Hl, Xj, 271)
					elseif wi.jE == 0 then
						RW(wi, iW, fp, Hl, Xj, 268)
					elseif 2 == wi.jE then
						dT(wi, iW, fp, Hl, Xj, 278)
					end
					return
				end
				My[(172 + Ja) % 256] = function(Xj, Hl, fp, iW, wi)
					local FA = Xj.mK.DI
					local an = (FA[1] - Xj.mK.lbY) % 65536
					local Qb = an % 256
					My[(Qb + Ja) % 256](Xj, Hl, fp, iW, wi)
					an = (an - Qb) / 256 % 256
					My[(an + Ja) % 256](Xj, iW, wi, iW, wi)
					Xj.bX -= 1
					if Xj.bX == 0 then
						return
					end
					local Dh = Xj.sW
					Xj.sW = Dh + 1
					if Dh < Xj.pbB or Dh > Xj.UU then
						Xj._b(Xj, Xj.tqp[Dh])
					end
					local AV = Dh - Xj.pbB + 1
					local VD = (Xj.tVN[AV] - Xj.qEK) % 256
					local qs = My[(VD + Ja) % 256]
					return qs(
						Xj,
						(Xj.eXa[AV] - Xj.qEK) % 65536,
						(Xj.uWE[AV] - Xj.qEK) % 65536,
						(Xj.we[AV] - Xj.qEK) % 65536,
						(Xj.fL[AV] - Xj.qEK) % 65536
					)
				end
				My[(173 + Ja) % 256] = function(qs, VD, AV, Dh, Qb)
					local an = qs.mK.DI
					local FA = (an[2] - qs.mK.lbY) % 65536
					local wi = FA % 256
					My[(wi + Ja) % 256](qs, VD, AV, Dh, Qb)
					FA = (FA - wi) / 256 % 256
					My[(FA + Ja) % 256](qs, Dh, Qb, Dh, Qb)
					qs.bX -= 1
					if qs.bX <= 0 then
						return
					end
					local iW = qs.sW
					if iW < qs.pbB or iW > qs.UU then
						qs._b(qs, qs.tqp[iW])
					end
					local fp = iW - qs.pbB + 1
					local Hl = (qs.tVN[fp] - qs.qEK) % 256
					local Xj, qt, cw, br =
						(qs.eXa[fp] - qs.qEK) % 65536,
						(qs.uWE[fp] - qs.qEK) % 65536,
						(qs.we[fp] - qs.qEK) % 65536,
						(qs.fL[fp] - qs.qEK) % 65536
					qs.sW = iW + 1
					return My[(Hl + Ja) % 256](qs, Xj, qt, cw, br)
				end
				My[(174 + Ja) % 256] = function(br, cw, qt, Xj, Hl)
					local fp = br.mK.DI
					local iW = (fp[3] - br.mK.lbY) % 65536
					local wi = iW % 256
					My[(wi + Ja) % 256](br, cw, qt, Xj, Hl)
					iW = (iW - wi) / 256 % 256
					My[(iW + Ja) % 256](br, Xj, Hl, Xj, Hl)
					br.bX -= 1
					if br.bX == 0 then
						return
					end
					local FA = br.sW
					br.sW = FA + 1
					if FA < br.pbB or FA > br.UU then
						br._b(br, br.tqp[FA])
					end
					local an = FA - br.pbB + 1
					local Qb = (br.tVN[an] - br.qEK) % 256
					local Dh = My[(Qb + Ja) % 256]
					return Dh(
						br,
						(br.eXa[an] - br.qEK) % 65536,
						(br.uWE[an] - br.qEK) % 65536,
						(br.we[an] - br.qEK) % 65536,
						(br.fL[an] - br.qEK) % 65536
					)
				end
				My[(175 + Ja) % 256] = function(Dh, Qb, an, FA, wi)
					local iW = Dh.mK.DI
					local fp = (iW[4] - Dh.mK.lbY) % 65536
					local Hl = fp % 256
					My[(Hl + Ja) % 256](Dh, Qb, an, FA, wi)
					fp = (fp - Hl) / 256 % 256
					My[(fp + Ja) % 256](Dh, FA, wi, FA, wi)
					Dh.bX -= 1
					if Dh.bX <= 0 then
						return
					end
					local Xj = Dh.sW
					if Xj < Dh.pbB or Xj > Dh.UU then
						Dh._b(Dh, Dh.tqp[Xj])
					end
					local qt = Xj - Dh.pbB + 1
					local cw = (Dh.tVN[qt] - Dh.qEK) % 256
					Dh.sW = Xj + 1
					return My[(cw + Ja) % 256](
						Dh,
						(Dh.eXa[qt] - Dh.qEK) % 65536,
						(Dh.uWE[qt] - Dh.qEK) % 65536,
						(Dh.we[qt] - Dh.qEK) % 65536,
						(Dh.fL[qt] - Dh.qEK) % 65536
					)
				end
				My[(240 + Ja) % 256] = function(cw, qt, Xj, Hl, fp)
					if 3 == cw.jE then
						GM(cw, qt, Xj, Hl, fp, 286)
					elseif cw.jE == 0 then
						RW(cw, qt, Xj, Hl, fp, 273)
					elseif cw.jE == 2 then
						dT(cw, qt, Xj, Hl, fp, 283)
					elseif cw.jE == 1 then
						mo(cw, qt, Xj, Hl, fp, 278)
					end
					return
				end
				My[(241 + Ja) % 256] = function(fp, Hl, Xj, qt, cw)
					if fp.jE == 3 then
						GM(fp, Hl, Xj, qt, cw, 293)
					elseif 0 == fp.jE then
						RW(fp, Hl, Xj, qt, cw, 279)
					elseif 2 == fp.jE then
						dT(fp, Hl, Xj, qt, cw, 287)
					elseif 1 == fp.jE then
						mo(fp, Hl, Xj, qt, cw, 284)
					end
					return
				end
				My[(242 + Ja) % 256] = function(cw, qt, Xj, Hl, fp)
					if 1 == cw.jE then
						mo(cw, qt, Xj, Hl, fp, 288)
					elseif 3 == cw.jE then
						GM(cw, qt, Xj, Hl, fp, 297)
					elseif cw.jE == 0 then
						RW(cw, qt, Xj, Hl, fp, 284)
					elseif 2 == cw.jE then
						dT(cw, qt, Xj, Hl, fp, 294)
					end
					return
				end
				My[(243 + Ja) % 256] = function(fp, Hl, Xj, qt, cw)
					if fp.jE == 1 then
						mo(fp, Hl, Xj, qt, cw, 295)
					elseif fp.jE == 0 then
						RW(fp, Hl, Xj, qt, cw, 290)
					elseif 3 == fp.jE then
						GM(fp, Hl, Xj, qt, cw, 304)
					elseif 2 == fp.jE then
						dT(fp, Hl, Xj, qt, cw, 300)
					end
					return
				end
				My[(236 + Ja) % 256] = function(cw, qt, Xj, Hl, fp)
					local iW = cw.mK.DI
					local wi = (iW[1] - cw.mK.lbY) % 65536
					local FA = wi % 256
					My[(FA + Ja) % 256](cw, qt, Xj, Hl, fp)
					wi = (wi - FA) / 256 % 256
					My[(wi + Ja) % 256](cw, Hl, fp, Hl, fp)
					cw.bX -= 1
					if cw.bX == 0 then
						return
					end
					local an = cw.sW
					cw.sW = an + 1
					if an < cw.pbB or an > cw.UU then
						cw._b(cw, cw.tqp[an])
					end
					local Qb = an - cw.pbB + 1
					local Dh = (cw.tVN[Qb] - cw.qEK) % 256
					local br = My[(Dh + Ja) % 256]
					return br(
						cw,
						(cw.eXa[Qb] - cw.qEK) % 65536,
						(cw.uWE[Qb] - cw.qEK) % 65536,
						(cw.we[Qb] - cw.qEK) % 65536,
						(cw.fL[Qb] - cw.qEK) % 65536
					)
				end
				My[(237 + Ja) % 256] = function(br, Dh, Qb, an, FA)
					local wi = br.mK.DI
					local iW = (wi[2] - br.mK.lbY) % 65536
					local fp = iW % 256
					My[(fp + Ja) % 256](br, Dh, Qb, an, FA)
					iW = (iW - fp) / 256 % 256
					My[(iW + Ja) % 256](br, an, FA, an, FA)
					br.bX -= 1
					if br.bX <= 0 then
						return
					end
					local Hl = br.sW
					br.sW = Hl + 1
					if Hl < br.pbB or Hl > br.UU then
						br._b(br, br.tqp[Hl])
					end
					local Xj = Hl - br.pbB + 1
					local qt = (br.tVN[Xj] - br.qEK) % 256
					local cw = My[(qt + Ja) % 256]
					return cw(
						br,
						(br.eXa[Xj] - br.qEK) % 65536,
						(br.uWE[Xj] - br.qEK) % 65536,
						(br.we[Xj] - br.qEK) % 65536,
						(br.fL[Xj] - br.qEK) % 65536
					)
				end
				My[(238 + Ja) % 256] = function(cw, qt, Xj, Hl, fp)
					local iW = cw.mK.DI
					local wi = (iW[3] - cw.mK.lbY) % 65536
					local FA = wi % 256
					My[(FA + Ja) % 256](cw, qt, Xj, Hl, fp)
					wi = (wi - FA) / 256 % 256
					My[(wi + Ja) % 256](cw, Hl, fp, Hl, fp)
					cw.bX -= 1
					if cw.bX == 0 then
						return
					end
					local an = cw.sW
					if an < cw.pbB or an > cw.UU then
						cw._b(cw, cw.tqp[an])
					end
					local Qb = an - cw.pbB + 1
					local Dh = (cw.tVN[Qb] - cw.qEK) % 256
					local br, AV, VD, qs =
						(cw.eXa[Qb] - cw.qEK) % 65536,
						(cw.uWE[Qb] - cw.qEK) % 65536,
						(cw.we[Qb] - cw.qEK) % 65536,
						(cw.fL[Qb] - cw.qEK) % 65536
					cw.sW = an + 1
					return My[(Dh + Ja) % 256](cw, br, AV, VD, qs)
				end
				My[(239 + Ja) % 256] = function(qs, VD, AV, br, Dh)
					local Qb = qs.mK.DI
					local an = (Qb[4] - qs.mK.lbY) % 65536
					local FA = an % 256
					My[(FA + Ja) % 256](qs, VD, AV, br, Dh)
					an = (an - FA) / 256 % 256
					My[(an + Ja) % 256](qs, br, Dh, br, Dh)
					qs.bX -= 1
					if qs.bX == 0 then
						return
					end
					local wi = qs.sW
					if wi < qs.pbB or wi > qs.UU then
						qs._b(qs, qs.tqp[wi])
					end
					local iW = wi - qs.pbB + 1
					local fp = My[((qs.tVN[iW] - qs.qEK) % 256 + Ja) % 256]
					qs.sW = wi + 1
					return fp(
						qs,
						(qs.eXa[iW] - qs.qEK) % 65536,
						(qs.uWE[iW] - qs.qEK) % 65536,
						(qs.we[iW] - qs.qEK) % 65536,
						(qs.fL[iW] - qs.qEK) % 65536
					)
				end
				fT = (fT + kS * (555026258690 + 972210856900 - 1527237090853)) % 268435456
				bR = (
					fT
					- (function(fp)
						local iW = (57367363 + 0) % 268435456
						for wi = 1, #fp do
							iW = (iW * 65492 + #fp[wi] + wi * 6513 + 54565656) % 268435456
						end
						return (266234477 + iW) % 268435456
					end)(c)
				) % 268435456
				rm = function(iW)
					local fp, wi = iW[23], iW[24]
					iW.bX -= 1
					if iW.bX <= 0 then
						return
					end
					local FA = iW.sW
					if FA < iW.pbB or FA > iW.UU then
						iW._b(iW, iW.tqp[FA])
					end
					local an = FA - iW.pbB + 1
					local Qb = wi[((iW.tVN[an] - iW.qEK) % 256 + fp) % 256]
					iW.sW = FA + 1
					return Qb(
						iW,
						(iW.eXa[an] - iW.qEK) % 65536,
						(iW.uWE[an] - iW.qEK) % 65536,
						(iW.we[an] - iW.qEK) % 65536,
						(iW.fL[an] - iW.qEK) % 65536
					)
				end
				gS = function(Qb)
					local an, FA = Qb[23], Qb[24]
					Qb.bX -= 1
					if Qb.bX == 0 then
						return
					end
					local wi = Qb.sW
					if wi < Qb.pbB or wi > Qb.UU then
						Qb._b(Qb, Qb.tqp[wi])
					end
					local fp = wi - Qb.pbB + 1
					Qb.sW = wi + 1
					return FA[((Qb.tVN[fp] - Qb.qEK) % 256 + an) % 256](
						Qb,
						(Qb.eXa[fp] - Qb.qEK) % 65536,
						(Qb.uWE[fp] - Qb.qEK) % 65536,
						(Qb.we[fp] - Qb.qEK) % 65536,
						(Qb.fL[fp] - Qb.qEK) % 65536
					)
				end
				Zw = function(fp)
					local wi, FA = fp[23], fp[24]
					fp.bX -= 1
					if fp.bX == 0 then
						return
					end
					local an = fp.sW
					if an < fp.pbB or an > fp.UU then
						fp._b(fp, fp.tqp[an])
					end
					local Qb = an - fp.pbB + 1
					local iW = (fp.tVN[Qb] - fp.qEK) % 256
					fp.sW = an + 1
					return FA[(iW + wi) % 256](
						fp,
						(fp.eXa[Qb] - fp.qEK) % 65536,
						(fp.uWE[Qb] - fp.qEK) % 65536,
						(fp.we[Qb] - fp.qEK) % 65536,
						(fp.fL[Qb] - fp.qEK) % 65536
					)
				end
				iR = function(iW)
					local Qb, an = iW[23], iW[24]
					iW.bX -= 1
					if iW.bX == 0 then
						return
					end
					local FA = iW.sW
					if FA < iW.pbB or FA > iW.UU then
						iW._b(iW, iW.tqp[FA])
					end
					local wi = FA - iW.pbB + 1
					local fp = (iW.tVN[wi] - iW.qEK) % 256
					iW.sW = FA + 1
					return an[(fp + Qb) % 256](
						iW,
						(iW.eXa[wi] - iW.qEK) % 65536,
						(iW.uWE[wi] - iW.qEK) % 65536,
						(iW.we[wi] - iW.qEK) % 65536,
						(iW.fL[wi] - iW.qEK) % 65536
					)
				end
				do
					local fp = Ja
					local wi = {
						{ 66, 25 },
						{ 158, 25 },
						{ 233, 25 },
						{ 71, 7 },
						{ 146, 7 },
						{ 209, 7 },
						{ 103, 42 },
						{ 165, 42 },
						{ 219, 42 },
						{ 76, 38 },
						{ 130, 38 },
						{ 212, 38 },
						{ 91, 8 },
						{ 170, 8 },
						{ 222, 8 },
						{ 93, 41 },
						{ 161, 41 },
						{ 228, 41 },
						{ 101, 4 },
						{ 167, 4 },
						{ 223, 4 },
						{ 68, 6 },
						{ 136, 6 },
						{ 195, 6 },
						{ 95, 28 },
						{ 149, 28 },
						{ 206, 28 },
						{ 106, 40 },
						{ 144, 40 },
						{ 197, 40 },
						{ 70, 16 },
						{ 135, 16 },
						{ 221, 16 },
						{ 67, 1 },
						{ 133, 1 },
						{ 207, 1 },
						{ 73, 20 },
						{ 141, 20 },
						{ 192, 20 },
						{ 89, 11 },
						{ 154, 11 },
						{ 210, 11 },
						{ 105, 2 },
						{ 140, 2 },
						{ 194, 2 },
						{ 80, 24 },
						{ 163, 24 },
						{ 230, 24 },
						{ 100, 18 },
						{ 138, 18 },
						{ 229, 18 },
						{ 104, 30 },
						{ 159, 30 },
						{ 215, 30 },
						{ 72, 31 },
						{ 147, 31 },
						{ 216, 31 },
						{ 74, 3 },
						{ 139, 3 },
						{ 213, 3 },
						{ 69, 26 },
						{ 128, 26 },
						{ 226, 26 },
						{ 99, 15 },
						{ 157, 15 },
						{ 231, 15 },
						{ 102, 5 },
						{ 156, 5 },
						{ 211, 5 },
						{ 82, 22 },
						{ 142, 22 },
						{ 217, 22 },
						{ 64, 13 },
						{ 145, 13 },
						{ 220, 13 },
						{ 94, 34 },
						{ 153, 34 },
						{ 202, 34 },
						{ 97, 17 },
						{ 160, 17 },
						{ 232, 17 },
						{ 90, 0 },
						{ 151, 0 },
						{ 193, 0 },
						{ 84, 29 },
						{ 148, 29 },
						{ 196, 29 },
						{ 96, 10 },
						{ 132, 10 },
						{ 200, 10 },
						{ 86, 14 },
						{ 164, 14 },
						{ 224, 14 },
						{ 78, 21 },
						{ 155, 21 },
						{ 204, 21 },
						{ 92, 27 },
						{ 134, 27 },
						{ 208, 27 },
						{ 87, 37 },
						{ 169, 37 },
						{ 214, 37 },
						{ 85, 19 },
						{ 168, 19 },
						{ 227, 19 },
						{ 79, 32 },
						{ 131, 32 },
						{ 199, 32 },
						{ 75, 23 },
						{ 166, 23 },
						{ 198, 23 },
						{ 98, 9 },
						{ 152, 9 },
						{ 205, 9 },
						{ 83, 36 },
						{ 162, 36 },
						{ 225, 36 },
						{ 65, 39 },
						{ 150, 39 },
						{ 201, 39 },
						{ 81, 35 },
						{ 129, 35 },
						{ 203, 35 },
						{ 88, 12 },
						{ 137, 12 },
						{ 218, 12 },
						{ 77, 33 },
						{ 143, 33 },
						{ 234, 33 },
						{ 107, 43 },
						{ 171, 43 },
						{ 235, 43 },
					}
					for FA = 1, #wi do
						local an = wi[FA]
						My[(an[1] + fp) % 256] = My[(an[2] + fp) % 256]
					end
				end
				bR = (bR + Gq * (833843918724 + 657642744114 - 1491486660734)) % 268435456
				cf = nil
			end
			local GM = {}
			local dT = 1
			local RW = (function(mo)
				local RW = (254185316 + 0) % 268435456
				for dD = 1, #mo do
					RW = (RW * 32258 + #mo[dD] + dD * 64648 + 130368213) % 268435456
				end
				return (136411070 + RW) % 268435456
			end)(c)
			while RW > 0 do
				local mo = GM[dT]
				if mo >= 4 then
					if mo < 6 then
						if mo ~= 5 then
							RW = 0
						else
							RW = 0
						end
					else
						RW = 0
					end
				elseif mo < 2 then
					RW = 0
				else
					RW = 0
				end
				local dD = GM[dT]
				if dD then
					local tM = GM[dT]
					local iX = GM[dT]
					local BF = GM[dT]
					local eB = GM[dT]
					dT += 1
					if dD == x[30] then
						GM[dT] = tM
					elseif dD == x[21] then
						GM[dT] = iX
					else
						local tw = GM[dT](tM, iX, BF, eB)
						if tw then
							RW = tw[1]
						end
					end
				end
				local eB = GM[dT]
				if eB then
					local BF = GM[dT]
					local iX = GM[dT]
					local tM = GM[dT]
					local tw = GM[dT]
					dT += 1
					if eB == x[36] then
						GM[dT] = BF
					elseif eB == x[41] then
						GM[dT] = iX
					else
						local yo = GM[dT](BF, iX, tM, tw)
						if yo then
							RW = yo[1]
						end
					end
				end
				local tw = GM[dT]
				if tw then
					local tM = GM[dT]
					local iX = GM[dT]
					local BF = GM[dT]
					local yo = GM[dT]
					dT += 1
					if tw == x[42] then
						GM[dT] = tM
					elseif tw == x[21] then
						GM[dT] = iX
					else
						local mv = GM[dT](tM, iX, BF, yo)
						if mv then
							RW = mv[1]
						end
					end
				end
				local yo = GM[dT]
				if yo then
					local BF = GM[dT]
					local iX = GM[dT]
					local tM = GM[dT]
					local mv = GM[dT]
					dT += 1
					if yo == x[17] then
						GM[dT] = BF
					elseif yo == x[14] then
						GM[dT] = iX
					else
						local lF = GM[dT](BF, iX, tM, mv)
						if lF then
							RW = lF[1]
						end
					end
				end
				dT += 1
			end
			vC = nil
			CS = nil
			ms = nil
			Fq = nil
			Px = nil
			Dv = nil
			x = nil
			local yo = h(0)
			local tw = wY
			local eB = D
			local dD = S({}, {
				__len = function()
					return 99
				end,
			})
			local mo = dD == nil or false
			do
				local mv, tM = d(function()
					return #dD
				end)
				mo = mv and tM == 99
			end
			local function tM(mv, iX)
				local BF = 5294 + 9711
				local lF = BF * 344 - 4442
				if lF * lF >= 0 then
					local hl = lF - BF
				end
				local hl = lF + 1 - 1
				local fW = 7156 + 3546
				local qG = fW * 937 - 488
				if qG * qG >= 0 then
					local mV = qG - fW
				end
				local mV = qG + 1 - 1
				local fT = U(mv)
				if M(fT) == pT[15] then
					return fT[iX], false
				end
				return nil, fT ~= nil
			end
			local function fT(mV)
				local qG = 9832 + 3055
				local fW = qG * 546 - 9921
				if fW * fW >= 0 then
					local hl = fW - qG
				end
				local hl = fW + 1 - 1
				local lF = 2633 + 6285
				local BF = lF * 841 - 6357
				if BF * BF >= 0 then
					local iX = BF - lF
				end
				local iX = BF + 1 - 1
				if M(mV) == pT[17] then
					return mV, false
				end
				local mv = U(mV)
				if M(mv) == pT[15] then
					local lr = mv[pT[31]]
					if M(lr) == pT[17] then
						return lr, true
					end
					if M(lr) == pT[15] then
						local pM = lr[mV]
						if M(pM) == pT[17] then
							return pM, false
						end
					end
				elseif mv ~= nil then
					return mV, false
				end
				e(pT[32] .. M(mV) .. pT[4], 0)
			end
			local mv = h(0)[pT[15]][pT[30]]
			local function iX(BF, lF, hl)
				local fW = 277 + 6590
				local qG = fW * 377 - 4930
				if qG * qG >= 0 then
					local mV = qG - fW
				end
				local mV = qG + 1 - 1
				local lr = 1768 + 9236
				local pM = lr * 70 - 1270
				if pM * pM >= 0 then
					local za = pM - lr
				end
				local za = pM + 1 - 1
				local Mo = mv(BF(tw(lF, 1, hl)))
				return Mo, Mo.n
			end
			local Mo = RQ(
				Kg,
				Kj,
				CQ,
				ei,
				ri,
				jY,
				n,
				yo,
				tw,
				eB,
				pT,
				Ja,
				My,
				mv,
				tM,
				fT,
				iX,
				mo,
				rm,
				gS,
				Zw,
				iR,
				NF,
				ug,
				zb,
				Am,
				qV,
				FJ,
				pH,
				jt,
				NC,
				BL,
				TJ,
				vy,
				Cm,
				vY,
				Vz,
				bR,
				Lw,
				CM,
				Gq
			)
			RQ = nil
			local za = {}
			local pM = {}
			return Mo(fA, pM, {}, za, 0)
		end
		N[11] = pM
		return 229, N, j, f, X, s, K
	end,
	GB = function(pM, o, r, m, I, i, s)
		local a = o[13] ~= nil and 87 or 209
		return 180, o, m, I, i, s, r
	end,
	[2] = {
		1393336914,
		320080531,
		4170594322,
		3653444510,
		1146767090,
		23597265,
		2554144190,
		1668859325,
		1645672399,
		3115025598,
		2511478010,
		1025,
		221338538,
		4099571454,
		1894491187,
		3620213543,
		1985553,
		1936626,
		1586971667,
		26043900,
		3795255461,
		1919286043,
		2475815760,
		16346,
		2928706502,
		269951957,
		1917794278,
		3464291205,
		3796012984,
		4133968626,
		42040892,
		1234243680,
		2638090704,
		345917226,
		1789217306,
		4279603,
		1553980535,
		4137321557,
		3487559804,
		1975128890,
		1454424886,
		3435990858,
		3191549048,
		3563100976,
		2844790797,
		3080066853,
		2547062159,
		3329538819,
	},
	GF = function(a, s, i, I, m, r, o)
		local pM = s[13] ~= nil and 96 or 165
		return 112, s, I, m, r, o, i
	end,
	[66] = tostring,
	[100] = function(pM, o, r, m)
		return function()
			local I = 0
			while true do
				if I <= 0 then
					r[1][4][r[1][7]] = (106681 * r[1][4][r[1][7]] + 128476132) % 268435456
					r[1][4][r[1][7]], I = (543361 * r[1][4][r[1][7]] + 111958044) % 268435456, 1
				elseif I <= 1 then
					r[1][4][r[1][7]] = (233822 * r[1][4][r[1][7]] + 191846301) % 268435456
					r[1][4][r[1][7]], I = (252839 * r[1][4][r[1][7]] + 174245737) % 268435456, 2
				else
					return
				end
			end
		end
	end,
	AL = "n",
	ja = function(m, r, o, pM, I, i, s)
		local a = r[13] ~= nil and 28 or 165
		return 68, r, pM, I, i, s, o
	end,
	[65] = buffer.writeu8,
	[94] = assert,
	[84] = string.unpack,
	[23] = 603978831 - 27856893,
	QL = false,
	Ur = function(a, s, i, I, pM, o, r)
		local m = s[13] ~= nil and 66 or 165
		return 151, s, I, pM, o, r, i
	end,
	SY = function(m, r, o, pM, I, i, s)
		local a = r[13] ~= nil and 36 or 212
		return 221, r, pM, I, i, s, o
	end,
	Ed = function(a, s, i, I, pM, o, r)
		local m = (a[31] + a[121]) % 4294967296
		local X = (a[23] - a[48]) % 4294967296
		local j = {}
		local K = 348
		local f = a[98](a)
		local N = (f % 256 + bit32.extract(f, 8, 8) + bit32.extract(f, 16, 8) + bit32.extract(f, 24, 4)) % 256
		local L = 1
		local za = a[62]
		local Mo = 78
		while Mo <= 90 do
			local iX = (Mo - 1) * 5 + 1
			local mv, fT, tM, mo, dD = a[36](za, iX, iX + 4)
			local eB = (
				((((mv - 33) * 94 + fT - 33) * 94 + tM - 33) * 94 + mo - 33) * 94
				+ dD
				- 33
				- (m + K * X) % 4294967296
			) % 4294967296
			K += 1
			j[L] = a[81](bit32.bxor(eB % 256, (N + L) % 256))
			eB = (eB - eB % 256) / 256
			L += 1
			j[L] = a[81](bit32.bxor(eB % 256, (N + L) % 256))
			eB = (eB - eB % 256) / 256
			L += 1
			j[L] = a[81](bit32.bxor(eB % 256, (N + L) % 256))
			eB = (eB - eB % 256) / 256
			L += 1
			j[L] = a[81](bit32.bxor(eB % 256, (N + L) % 256))
			L += 1
			Mo += 1
		end
		local eB = a[58]
		local dD = 1
		while dD <= 44 do
			local mo = (dD - 1) * 5 + 1
			local tM, fT, mv, iX, tw = a[36](eB, mo, mo + 4)
			local yo = (
				((((tM - 33) * 94 + fT - 33) * 94 + mv - 33) * 94 + iX - 33) * 94
				+ tw
				- 33
				- (m + K * X) % 4294967296
			) % 4294967296
			K += 1
			j[L] = a[81](bit32.bxor(yo % 256, (N + L) % 256))
			yo = (yo - yo % 256) / 256
			L += 1
			j[L] = a[81](bit32.bxor(yo % 256, (N + L) % 256))
			yo = (yo - yo % 256) / 256
			L += 1
			j[L] = a[81](bit32.bxor(yo % 256, (N + L) % 256))
			yo = (yo - yo % 256) / 256
			L += 1
			j[L] = a[81](bit32.bxor(yo % 256, (N + L) % 256))
			L += 1
			dD += 1
		end
		local yo = s[10] ~= nil and 66 or 236
		local tw = if 66 ~= 236 then 66 else 236
		s[10] = table.concat(j, nil, 1, 228)
		return 35, s, pM, i, o, r, I
	end,
	jg = function(tw, yo, dD, eB, Mo, za, L)
		local N = yo[13] ~= nil and 26 or 166
		return 43, yo, eB, Mo, za, L, dD
	end,
	JV = function(N, L, za, Mo, eB, dD, yo)
		local tw = L[13] ~= nil and 106 or 180
		return 165, L, Mo, eB, dD, yo, za
	end,
	[111] = pcall,
	[31] = 4150268640 - 11442537,
	VE = function(tw, yo, dD, eB, Mo, za, L)
		local N = yo[13] ~= nil and 66 or 164
		return 116, yo, eB, Mo, za, L, dD
	end,
	Kj = function(N, ...)
		return true, 237, nil, nil, nil, nil, nil, nil, nil, nil
	end,
	ki = function(N, L, za, Mo, eB, dD, yo)
		local tw = L[13] ~= nil and 87 or 150
		return 104, L, Mo, eB, dD, yo, za
	end,
	kK = function(tw, yo, dD, eB, Mo, za, L)
		local N = yo[13] ~= nil and 83 or 116
		return 198, yo, eB, Mo, za, L, dD
	end,
	[112] = bit32.rshift,
	[40] = tonumber,
	[118] = [[3/l^}:,'RU<CWZVC-geACxpD8Pb<pDOy3^\"MnxJWH!vd"tt_>*O9-Z#e}|#,pRt2,}r5|4W`><@g32]I#U_BR|vB)"@uf%NM1WP.-T&:!:6-T;#$j(+/2Pe=1UbRIw%8iR5DbC#'n0-'6p8u2>:Qo/kL)?7b)a<<8$)[7%hFHNC``bO|,_]W/\y5%IM0N)ZEBD.74q8@Z[3g8whED>mT#i=4zvkCjB-$Fu.._))^,:P)!b8EY%6wWQrFB$'YJ(#g-8W&5ikv.t4)w3W#Ld;G)^]EUzed?JN/,?vpP==KO*6Kf/drD,]:IMp*9MPmj..+8^o?30-Q}7Un]?*R2E"+y:P\2]9~,>]_8)>!lw7B2.Y)3llr-5r3>,VI>&3LbMQI&AI)|Nr*2^)&r#15tAUu1u&9&4@zWE@(N(FE}xnIK:gdN"RwnYJh?EXLW;[/Mi;yR]],
	rS = function(N, L, za, Mo, eB, dD, yo)
		local tw = L[13] ~= nil and 22 or 159
		return 105, L, Mo, eB, dD, yo, za
	end,
	Gn = function(tw, yo, dD, eB, Mo, za, L)
		local N = yo[13] ~= nil and 5 or 153
		return 93, yo, eB, Mo, za, L, dD
	end,
	DV = function(N, L, za, Mo, eB, dD, yo)
		local tw = L[13] ~= nil and 109 or 229
		return 212, L, Mo, eB, dD, yo, za
	end,
	[11] = table.create,
	[19] = buffer.readf64,
	gU = function(tw, yo, dD, eB, Mo, za, L)
		local N = yo[13] ~= nil and 68 or 166
		return 138, yo, eB, Mo, za, L, dD
	end,
	[96] = vector.create,
	_r = function(N, L, za, Mo, eB, dD, yo, tw)
		while true do
			if za <= 233 then
				if za <= 109 then
					if za <= 66 then
						if za <= 35 then
							if za <= 12 then
								if za <= 6 then
									if za <= 4 then
										if (za + 1) * (za + 1) >= za * za then
											za, Mo, eB, dD, yo, tw = N:rA(L, Mo, eB, dD, yo, tw)
											continue
										else
											local f = za
										end
									else
										if za <= 5 then
											if not ((za * za + za) % 2 == 0) then
												local f = za
											else
												za, Mo, eB, dD, yo, tw = N:X(L, Mo, eB, dD, yo, tw)
												continue
											end
										else
											if not ((za + 1) * (za + 1) >= za * za) then
												local f = za
											else
												za, Mo, eB, dD, yo, tw = N:km(L, Mo, eB, dD, yo, tw)
												continue
											end
										end
									end
								else
									if za <= 8 then
										if za % 5 * (za % 5) * (za % 5 * (za % 5)) >= 0 then
											za, Mo, eB, dD, yo, tw = N:Kf(L, Mo, eB, dD, yo, tw)
											continue
										else
											local f = za
										end
									else
										if za <= 11 then
											if not (za % 5 * (za % 5) * (za % 5 * (za % 5)) >= 0) then
												local f = za
											else
												za, Mo, eB, dD, yo, tw = N:tm(L, Mo, eB, dD, yo, tw)
												continue
											end
										else
											if za % 3 * (za % 3) >= 0 then
												za, Mo, eB, dD, yo, tw = N:oB(L, Mo, eB, dD, yo, tw)
												continue
											else
												local f = za
											end
										end
									end
								end
							else
								if za <= 25 then
									if za <= 16 then
										if not ((za * za + za) % 2 == 0) then
											local f = za
										else
											za, Mo, eB, dD, yo, tw = N:fY(L, Mo, eB, dD, yo, tw)
											continue
										end
									else
										if za <= 22 then
											if (za + 1) * (za + 1) >= za * za then
												za, Mo, eB, dD, yo, tw = N:dV(L, Mo, eB, dD, yo, tw)
												continue
											else
												local f = za
											end
										else
											if not ((za * za + za) % 2 == 0) then
												local f = za
											else
												za, Mo, eB, dD, yo, tw = N:BD(L, Mo, eB, dD, yo, tw)
												continue
											end
										end
									end
								else
									if za <= 27 then
										if za <= 26 then
											if (za * za + za) % 2 == 0 then
												za, Mo, eB, dD, yo, tw = N:yK(L, Mo, eB, dD, yo, tw)
												continue
											else
												local f = za
											end
										else
											if not ((za + 1) * (za + 1) >= za * za) then
												local f = za
											else
												za, Mo, eB, dD, yo, tw = N:mB(L, Mo, eB, dD, yo, tw)
												continue
											end
										end
									else
										if za <= 28 then
											if (za * za + za) % 2 == 0 then
												za, Mo, eB, dD, yo, tw = N:Ed(L, Mo, eB, dD, yo, tw)
												continue
											else
												local f = za
											end
										else
											if not ((za * za + za) % 2 == 0) then
												local f = za
											else
												za, Mo, eB, dD, yo, tw = N:Su(L, Mo, eB, dD, yo, tw)
												continue
											end
										end
									end
								end
							end
						else
							if za <= 49 then
								if za <= 39 then
									if za <= 36 then
										if not ((za * za + za) % 2 == 0) then
											local f = za
										else
											za, Mo, eB, dD, yo, tw = N:QX(L, Mo, eB, dD, yo, tw)
											continue
										end
									else
										if za <= 37 then
											if za % 5 * (za % 5) * (za % 5 * (za % 5)) >= 0 then
												za, Mo, eB, dD, yo, tw = N:ZD(L, Mo, eB, dD, yo, tw)
												continue
											else
												local f = za
											end
										else
											if not (za % 3 * (za % 3) >= 0) then
												local f = za
											else
												za, Mo, eB, dD, yo, tw = N:jg(L, Mo, eB, dD, yo, tw)
												continue
											end
										end
									end
								else
									if za <= 43 then
										if not ((za * za + za) % 2 == 0) then
											local f = za
										else
											za, Mo, eB, dD, yo, tw = N:_q(L, Mo, eB, dD, yo, tw)
											continue
										end
									else
										if za <= 44 then
											if not (za % 3 * (za % 3) >= 0) then
												local f = za
											else
												za, Mo, eB, dD, yo, tw = N:xH(L, Mo, eB, dD, yo, tw)
												continue
											end
										else
											if not (za % 5 * (za % 5) * (za % 5 * (za % 5)) >= 0) then
												local f = za
											else
												za, Mo, eB, dD, yo, tw = N:DW(L, Mo, eB, dD, yo, tw)
												continue
											end
										end
									end
								end
							else
								if za <= 58 then
									if za <= 52 then
										if not ((za * za + za) % 2 == 0) then
											local f = za
										else
											za, Mo, eB, dD, yo, tw = N:aX(L, Mo, eB, dD, yo, tw)
											continue
										end
									else
										if za <= 57 then
											if za % 5 * (za % 5) * (za % 5 * (za % 5)) >= 0 then
												za, Mo, eB, dD, yo, tw = N:xy(L, Mo, eB, dD, yo, tw)
												continue
											else
												local f = za
											end
										else
											if not (za % 5 * (za % 5) * (za % 5 * (za % 5)) >= 0) then
												local f = za
											else
												za, Mo, eB, dD, yo, tw = N:oT(L, Mo, eB, dD, yo, tw)
												continue
											end
										end
									end
								else
									if za <= 62 then
										if za <= 59 then
											if not ((za * za + za) % 2 == 0) then
												local f = za
											else
												za, Mo, eB, dD, yo, tw = N:Iu(L, Mo, eB, dD, yo, tw)
												continue
											end
										else
											if (za + 1) * (za + 1) >= za * za then
												za, Mo, eB, dD, yo, tw = N:qO(L, Mo, eB, dD, yo, tw)
												continue
											else
												local f = za
											end
										end
									else
										if za <= 65 then
											if (za * za + za) % 2 == 0 then
												za, Mo, eB, dD, yo, tw = N:ai(L, Mo, eB, dD, yo, tw)
												continue
											else
												local f = za
											end
										else
											if (za * za + za) % 2 == 0 then
												za, Mo, eB, dD, yo, tw = N:ja(L, Mo, eB, dD, yo, tw)
												continue
											else
												local f = za
											end
										end
									end
								end
							end
						end
					else
						if za <= 90 then
							if za <= 78 then
								if za <= 70 then
									if za <= 68 then
										if not ((za + 1) * (za + 1) >= za * za) then
											local f = za
										else
											za, Mo, eB, dD, yo, tw = N:zn(L, Mo, eB, dD, yo, tw)
											continue
										end
									else
										if za <= 69 then
											if za % 3 * (za % 3) >= 0 then
												za, Mo, eB, dD, yo, tw = N:eg(L, Mo, eB, dD, yo, tw)
												continue
											else
												local f = za
											end
										else
											if (za + 1) * (za + 1) >= za * za then
												za, Mo, eB, dD, yo, tw = N:x(L, Mo, eB, dD, yo, tw)
												continue
											else
												local f = za
											end
										end
									end
								else
									if za <= 71 then
										if not ((za * za + za) % 2 == 0) then
											local f = za
										else
											za, Mo, eB, dD, yo, tw = N:vP(L, Mo, eB, dD, yo, tw)
											continue
										end
									else
										if za <= 75 then
											if not ((za * za + za) % 2 == 0) then
												local f = za
											else
												za, Mo, eB, dD, yo, tw = N:Tg(L, Mo, eB, dD, yo, tw)
												continue
											end
										else
											if za % 5 * (za % 5) * (za % 5 * (za % 5)) >= 0 then
												za, Mo, eB, dD, yo, tw = N:um(L, Mo, eB, dD, yo, tw)
												continue
											else
												local f = za
											end
										end
									end
								end
							else
								if za <= 84 then
									if za <= 79 then
										if not (za % 3 * (za % 3) >= 0) then
											local f = za
										else
											za, Mo, eB, dD, yo, tw = N:qp(L, Mo, eB, dD, yo, tw)
											continue
										end
									else
										if za <= 83 then
											if not (za % 3 * (za % 3) >= 0) then
												local f = za
											else
												za, Mo, eB, dD, yo, tw = N:jP(L, Mo, eB, dD, yo, tw)
												continue
											end
										else
											if (za * za + za) % 2 == 0 then
												za, Mo, eB, dD, yo, tw = N:Ci(L, Mo, eB, dD, yo, tw)
												continue
											else
												local f = za
											end
										end
									end
								else
									if za <= 87 then
										if za <= 85 then
											if (za + 1) * (za + 1) >= za * za then
												za, Mo, eB, dD, yo, tw = N:kB(L, Mo, eB, dD, yo, tw)
												continue
											else
												local f = za
											end
										else
											if (za * za + za) % 2 == 0 then
												za, Mo, eB, dD, yo, tw = N:Q(L, Mo, eB, dD, yo, tw)
												continue
											else
												local f = za
											end
										end
									else
										if za <= 89 then
											if za % 3 * (za % 3) >= 0 then
												za, Mo, eB, dD, yo, tw = N:Ve(L, Mo, eB, dD, yo, tw)
												continue
											else
												local f = za
											end
										else
											if za % 5 * (za % 5) * (za % 5 * (za % 5)) >= 0 then
												za, Mo, eB, dD, yo, tw = N:rr(L, Mo, eB, dD, yo, tw)
												continue
											else
												local f = za
											end
										end
									end
								end
							end
						else
							if za <= 98 then
								if za <= 94 then
									if za <= 91 then
										if (za + 1) * (za + 1) >= za * za then
											za, Mo, eB, dD, yo, tw = N:Gn(L, Mo, eB, dD, yo, tw)
											continue
										else
											local f = za
										end
									else
										if za <= 93 then
											if not (za % 5 * (za % 5) * (za % 5 * (za % 5)) >= 0) then
												local f = za
											else
												za, Mo, eB, dD, yo, tw = N:CX(L, Mo, eB, dD, yo, tw)
												continue
											end
										else
											if not ((za + 1) * (za + 1) >= za * za) then
												local f = za
											else
												za, Mo, eB, dD, yo, tw = N:te(L, Mo, eB, dD, yo, tw)
												continue
											end
										end
									end
								else
									if za <= 95 then
										if not (za % 5 * (za % 5) * (za % 5 * (za % 5)) >= 0) then
											local f = za
										else
											za, Mo, eB, dD, yo, tw = N:ZB(L, Mo, eB, dD, yo, tw)
											continue
										end
									else
										if za <= 96 then
											if za % 3 * (za % 3) >= 0 then
												za, Mo, eB, dD, yo, tw = N:qe(L, Mo, eB, dD, yo, tw)
												continue
											else
												local f = za
											end
										else
											if not ((za + 1) * (za + 1) >= za * za) then
												local f = za
											else
												za, Mo, eB, dD, yo, tw = N:dQ(L, Mo, eB, dD, yo, tw)
												continue
											end
										end
									end
								end
							else
								if za <= 104 then
									if za <= 101 then
										if (za + 1) * (za + 1) >= za * za then
											za, Mo, eB, dD, yo, tw = N:Mz(L, Mo, eB, dD, yo, tw)
											continue
										else
											local f = za
										end
									else
										if za <= 102 then
											if not ((za * za + za) % 2 == 0) then
												local f = za
											else
												za, Mo, eB, dD, yo, tw = N:ki(L, Mo, eB, dD, yo, tw)
												continue
											end
										else
											if (za * za + za) % 2 == 0 then
												za, Mo, eB, dD, yo, tw = N:rS(L, Mo, eB, dD, yo, tw)
												continue
											else
												local f = za
											end
										end
									end
								else
									if za <= 106 then
										if za <= 105 then
											if za % 5 * (za % 5) * (za % 5 * (za % 5)) >= 0 then
												za, Mo, eB, dD, yo, tw = N:dW(L, Mo, eB, dD, yo, tw)
												continue
											else
												local f = za
											end
										else
											if za % 3 * (za % 3) >= 0 then
												za, Mo, eB, dD, yo, tw = N:KZ(L, Mo, eB, dD, yo, tw)
												continue
											else
												local f = za
											end
										end
									else
										if za <= 108 then
											if not ((za * za + za) % 2 == 0) then
												local f = za
											else
												za, Mo, eB, dD, yo, tw = N:Jr(L, Mo, eB, dD, yo, tw)
												continue
											end
										else
											if za % 5 * (za % 5) * (za % 5 * (za % 5)) >= 0 then
												za, Mo, eB, dD, yo, tw = N:n_(L, Mo, eB, dD, yo, tw)
												continue
											else
												local f = za
											end
										end
									end
								end
							end
						end
					end
				else
					if za <= 179 then
						if za <= 143 then
							if za <= 121 then
								if za <= 115 then
									if za <= 111 then
										if (za + 1) * (za + 1) >= za * za then
											za, Mo, eB, dD, yo, tw = N:GF(L, Mo, eB, dD, yo, tw)
											continue
										else
											local f = za
										end
									else
										if za <= 112 then
											if za % 5 * (za % 5) * (za % 5 * (za % 5)) >= 0 then
												za, Mo, eB, dD, yo, tw = N:xN(L, Mo, eB, dD, yo, tw)
												continue
											else
												local f = za
											end
										else
											if not ((za + 1) * (za + 1) >= za * za) then
												local f = za
											else
												za, Mo, eB, dD, yo, tw = N:VE(L, Mo, eB, dD, yo, tw)
												continue
											end
										end
									end
								else
									if za <= 116 then
										if not (za % 5 * (za % 5) * (za % 5 * (za % 5)) >= 0) then
											local f = za
										else
											za, Mo, eB, dD, yo, tw = N:iN(L, Mo, eB, dD, yo, tw)
											continue
										end
									else
										if za <= 118 then
											if za % 5 * (za % 5) * (za % 5 * (za % 5)) >= 0 then
												za, Mo, eB, dD, yo, tw = N:ID(L, Mo, eB, dD, yo, tw)
												continue
											else
												local f = za
											end
										else
											if not ((za + 1) * (za + 1) >= za * za) then
												local f = za
											else
												za, Mo, eB, dD, yo, tw = N:iF(L, Mo, eB, dD, yo, tw)
												continue
											end
										end
									end
								end
							else
								if za <= 133 then
									if za <= 131 then
										if not (za % 3 * (za % 3) >= 0) then
											local f = za
										else
											za, Mo, eB, dD, yo, tw = N:S_(L, Mo, eB, dD, yo, tw)
											continue
										end
									else
										if za <= 132 then
											if not (za % 3 * (za % 3) >= 0) then
												local f = za
											else
												za, Mo, eB, dD, yo, tw = N:F_(L, Mo, eB, dD, yo, tw)
												continue
											end
										else
											if (za * za + za) % 2 == 0 then
												za, Mo, eB, dD, yo, tw = N:mn(L, Mo, eB, dD, yo, tw)
												continue
											else
												local f = za
											end
										end
									end
								else
									if za <= 137 then
										if za <= 134 then
											if za % 3 * (za % 3) >= 0 then
												za, Mo, eB, dD, yo, tw = N:yU(L, Mo, eB, dD, yo, tw)
												continue
											else
												local f = za
											end
										else
											if za % 3 * (za % 3) >= 0 then
												za, Mo, eB, dD, yo, tw = N:gU(L, Mo, eB, dD, yo, tw)
												continue
											else
												local f = za
											end
										end
									else
										if za <= 138 then
											if (za * za + za) % 2 == 0 then
												za, Mo, eB, dD, yo, tw = N:qH(L, Mo, eB, dD, yo, tw)
												continue
											else
												local f = za
											end
										else
											if (za * za + za) % 2 == 0 then
												za, Mo, eB, dD, yo, tw = N:zW(L, Mo, eB, dD, yo, tw)
												continue
											else
												local f = za
											end
										end
									end
								end
							end
						else
							if za <= 162 then
								if za <= 151 then
									if za <= 147 then
										if not (za % 3 * (za % 3) >= 0) then
											local f = za
										else
											za, Mo, eB, dD, yo, tw = N:pv(L, Mo, eB, dD, yo, tw)
											continue
										end
									else
										if za <= 150 then
											if (za * za + za) % 2 == 0 then
												za, Mo, eB, dD, yo, tw = N:Ur(L, Mo, eB, dD, yo, tw)
												continue
											else
												local f = za
											end
										else
											if (za + 1) * (za + 1) >= za * za then
												za, Mo, eB, dD, yo, tw = N:R(L, Mo, eB, dD, yo, tw)
												continue
											else
												local f = za
											end
										end
									end
								else
									if za <= 153 then
										if (za + 1) * (za + 1) >= za * za then
											za, Mo, eB, dD, yo, tw = N:Ft(L, Mo, eB, dD, yo, tw)
											continue
										else
											local f = za
										end
									else
										if za <= 159 then
											if za % 5 * (za % 5) * (za % 5 * (za % 5)) >= 0 then
												za, Mo, eB, dD, yo, tw = N:SQ(L, Mo, eB, dD, yo, tw)
												continue
											else
												local f = za
											end
										else
											if not (za % 5 * (za % 5) * (za % 5 * (za % 5)) >= 0) then
												local f = za
											else
												za, Mo, eB, dD, yo, tw = N:NK(L, Mo, eB, dD, yo, tw)
												continue
											end
										end
									end
								end
							else
								if za <= 166 then
									if za <= 164 then
										if not ((za + 1) * (za + 1) >= za * za) then
											local f = za
										else
											za, Mo, eB, dD, yo, tw = N:JV(L, Mo, eB, dD, yo, tw)
											continue
										end
									else
										if za <= 165 then
											if not ((za + 1) * (za + 1) >= za * za) then
												local f = za
											else
												za, Mo, eB, dD, yo, tw = N:tg(L, Mo, eB, dD, yo, tw)
												continue
											end
										else
											if za % 3 * (za % 3) >= 0 then
												za, Mo, eB, dD, yo, tw = N:Hq(L, Mo, eB, dD, yo, tw)
												continue
											else
												local f = za
											end
										end
									end
								else
									if za <= 174 then
										if za <= 168 then
											if not (za % 3 * (za % 3) >= 0) then
												local f = za
											else
												za, Mo, eB, dD, yo, tw = N:pR(L, Mo, eB, dD, yo, tw)
												continue
											end
										else
											if (za * za + za) % 2 == 0 then
												za, Mo, eB, dD, yo, tw = N:mo(L, Mo, eB, dD, yo, tw)
												continue
											else
												local f = za
											end
										end
									else
										if za <= 178 then
											if za % 3 * (za % 3) >= 0 then
												za, Mo, eB, dD, yo, tw = N:j(L, Mo, eB, dD, yo, tw)
												continue
											else
												local f = za
											end
										else
											if not (za % 3 * (za % 3) >= 0) then
												local f = za
											else
												za, Mo, eB, dD, yo, tw = N:GB(L, Mo, eB, dD, yo, tw)
												continue
											end
										end
									end
								end
							end
						end
					else
						if za <= 209 then
							if za <= 190 then
								if za <= 183 then
									if za <= 180 then
										if not ((za * za + za) % 2 == 0) then
											local f = za
										else
											za, Mo, eB, dD, yo, tw = N:nU(L, Mo, eB, dD, yo, tw)
											continue
										end
									else
										if za <= 181 then
											if not ((za + 1) * (za + 1) >= za * za) then
												local f = za
											else
												za, Mo, eB, dD, yo, tw = N:kl(L, Mo, eB, dD, yo, tw)
												continue
											end
										else
											if not ((za + 1) * (za + 1) >= za * za) then
												local f = za
											else
												za, Mo, eB, dD, yo, tw = N:yI(L, Mo, eB, dD, yo, tw)
												continue
											end
										end
									end
								else
									if za <= 185 then
										if not (za % 5 * (za % 5) * (za % 5 * (za % 5)) >= 0) then
											local f = za
										else
											za, Mo, eB, dD, yo, tw = N:kn(L, Mo, eB, dD, yo, tw)
											continue
										end
									else
										if za <= 187 then
											if not (za % 3 * (za % 3) >= 0) then
												local f = za
											else
												za, Mo, eB, dD, yo, tw = N:NY(L, Mo, eB, dD, yo, tw)
												continue
											end
										else
											if not (za % 5 * (za % 5) * (za % 5 * (za % 5)) >= 0) then
												local f = za
											else
												za, Mo, eB, dD, yo, tw = N:zy(L, Mo, eB, dD, yo, tw)
												continue
											end
										end
									end
								end
							else
								if za <= 201 then
									if za <= 191 then
										if not (za % 5 * (za % 5) * (za % 5 * (za % 5)) >= 0) then
											local f = za
										else
											za, Mo, eB, dD, yo, tw = N:kK(L, Mo, eB, dD, yo, tw)
											continue
										end
									else
										if za <= 198 then
											if za % 3 * (za % 3) >= 0 then
												za, Mo, eB, dD, yo, tw = N:Nu(L, Mo, eB, dD, yo, tw)
												continue
											else
												local f = za
											end
										else
											if not (za % 5 * (za % 5) * (za % 5 * (za % 5)) >= 0) then
												local f = za
											else
												za, Mo, eB, dD, yo, tw = N:xv(L, Mo, eB, dD, yo, tw)
												continue
											end
										end
									end
								else
									if za <= 203 then
										if za <= 202 then
											if not (za % 5 * (za % 5) * (za % 5 * (za % 5)) >= 0) then
												local f = za
											else
												za, Mo, eB, dD, yo, tw = N:UZ(L, Mo, eB, dD, yo, tw)
												continue
											end
										else
											if not ((za * za + za) % 2 == 0) then
												local f = za
											else
												za, Mo, eB, dD, yo, tw = N:Tt(L, Mo, eB, dD, yo, tw)
												continue
											end
										end
									else
										if za <= 204 then
											if not ((za * za + za) % 2 == 0) then
												local f = za
											else
												za, Mo, eB, dD, yo, tw = N:D_(L, Mo, eB, dD, yo, tw)
												continue
											end
										else
											if za % 3 * (za % 3) >= 0 then
												za, Mo, eB, dD, yo, tw = N:DV(L, Mo, eB, dD, yo, tw)
												continue
											else
												local f = za
											end
										end
									end
								end
							end
						else
							if za <= 222 then
								if za <= 218 then
									if za <= 212 then
										if za % 5 * (za % 5) * (za % 5 * (za % 5)) >= 0 then
											za, Mo, eB, dD, yo, tw = N:Nx(L, Mo, eB, dD, yo, tw)
											continue
										else
											local f = za
										end
									else
										if za <= 214 then
											if not ((za * za + za) % 2 == 0) then
												local f = za
											else
												za, Mo, eB, dD, yo, tw = N:uO(L, Mo, eB, dD, yo, tw)
												continue
											end
										else
											if not ((za + 1) * (za + 1) >= za * za) then
												local f = za
											else
												za, Mo, eB, dD, yo, tw = N:kO(L, Mo, eB, dD, yo, tw)
												continue
											end
										end
									end
								else
									if za <= 220 then
										if not ((za * za + za) % 2 == 0) then
											local f = za
										else
											za, Mo, eB, dD, yo, tw = N:SY(L, Mo, eB, dD, yo, tw)
											continue
										end
									else
										if za <= 221 then
											if za % 3 * (za % 3) >= 0 then
												za, Mo, eB, dD, yo, tw = N:Gf(L, Mo, eB, dD, yo, tw)
												continue
											else
												local f = za
											end
										else
											if not ((za * za + za) % 2 == 0) then
												local f = za
											else
												za, Mo, eB, dD, yo, tw = N:_D(L, Mo, eB, dD, yo, tw)
												continue
											end
										end
									end
								end
							else
								if za <= 225 then
									if za <= 223 then
										if za % 3 * (za % 3) >= 0 then
											za, Mo, eB, dD, yo, tw = N:Ll(L, Mo, eB, dD, yo, tw)
											continue
										else
											local f = za
										end
									else
										if za <= 224 then
											if (za + 1) * (za + 1) >= za * za then
												za, Mo, eB, dD, yo, tw = N:Vp(L, Mo, eB, dD, yo, tw)
												continue
											else
												local f = za
											end
										else
											if za % 3 * (za % 3) >= 0 then
												za, Mo, eB, dD, yo, tw = N:Nf(L, Mo, eB, dD, yo, tw)
												continue
											else
												local f = za
											end
										end
									end
								else
									if za <= 229 then
										if za <= 228 then
											if not ((za + 1) * (za + 1) >= za * za) then
												local f = za
											else
												za, Mo, eB, dD, yo, tw = N[117](N, L, za, Mo, eB, dD, yo, tw)
												continue
											end
										else
											if not (za % 3 * (za % 3) >= 0) then
												local f = za
											else
												za, Mo, eB, dD, yo, tw = N:ey(L, Mo, eB, dD, yo, tw)
												continue
											end
										end
									else
										if za <= 231 then
											if za % 5 * (za % 5) * (za % 5 * (za % 5)) >= 0 then
												za, Mo, eB, dD, yo, tw = N:y(L, Mo, eB, dD, yo, tw)
												continue
											else
												local f = za
											end
										else
											if za % 3 * (za % 3) >= 0 then
												za, Mo, eB, dD, yo, tw = N:r(L, Mo, eB, dD, yo, tw)
												continue
											else
												local f = za
											end
										end
									end
								end
							end
						end
					end
				end
			else
				local f, K = N:Dn(L, za)
				if f == 2 then
					return 2, K
				end
				za = f
			end
		end
	end,
	[1641] = function(tw)
		local yo = 7
		yo = (213 * yo + 225) % 268435456
		yo = (yo * 213 + 225) % 268435456
		return yo
	end,
	yU = function(yo, tw, dD, eB, Mo, za, L)
		local N = tw[13] ~= nil and 91 or 131
		return 137, tw, eB, Mo, za, L, dD
	end,
	[91] = buffer.fromstring,
	mo = function(N, L, za, Mo, eB, dD, tw)
		local yo = L[13] ~= nil and 87 or 162
		return 178, L, Mo, eB, dD, tw, za
	end,
	[28] = buffer.readu32,
	kl = function(yo, tw, dD, eB, Mo, za, L)
		local N = tw[13] ~= nil and 104 or 204
		return 183, tw, eB, Mo, za, L, dD
	end,
	Gf = function(N, L, za, Mo, eB, dD, tw)
		local yo = L[13] ~= nil and 71 or 118
		return 222, L, Mo, eB, dD, tw, za
	end,
	BD = function(yo, tw, dD, eB, Mo, za, L)
		local N = (yo[31] + yo[121]) % 4294967296
		local K = (yo[23] - yo[48]) % 4294967296
		local f = {}
		local j = 177
		local X = yo[98](yo)
		local m = (X % 256 + bit32.extract(X, 8, 8) + bit32.extract(X, 16, 8) + bit32.extract(X, 24, 4)) % 256
		local r = 1
		local o = yo[78]
		for pM = 87, 90 do
			local I = (pM - 1) * 5 + 1
			local i, s, a, iX, mv = yo[36](o, I, I + 4)
			local fT = (
				((((i - 33) * 94 + s - 33) * 94 + a - 33) * 94 + iX - 33) * 94
				+ mv
				- 33
				- (N + j * K) % 4294967296
			) % 4294967296
			j += 1
			f[r] = yo[81](bit32.bxor(fT % 256, (m + r) % 256))
			fT = (fT - fT % 256) / 256
			r += 1
			f[r] = yo[81](bit32.bxor(fT % 256, (m + r) % 256))
			fT = (fT - fT % 256) / 256
			r += 1
			f[r] = yo[81](bit32.bxor(fT % 256, (m + r) % 256))
			fT = (fT - fT % 256) / 256
			r += 1
			f[r] = yo[81](bit32.bxor(fT % 256, (m + r) % 256))
			r += 1
		end
		local fT = yo[12]
		for mv = 1, 53 do
			local iX = (mv - 1) * 5 + 1
			local a, s, i, I, pM = yo[36](fT, iX, iX + 4)
			local tM = (
				((((a - 33) * 94 + s - 33) * 94 + i - 33) * 94 + I - 33) * 94
				+ pM
				- 33
				- (N + j * K) % 4294967296
			) % 4294967296
			j += 1
			f[r] = yo[81](bit32.bxor(tM % 256, (m + r) % 256))
			tM = (tM - tM % 256) / 256
			r += 1
			f[r] = yo[81](bit32.bxor(tM % 256, (m + r) % 256))
			tM = (tM - tM % 256) / 256
			r += 1
			f[r] = yo[81](bit32.bxor(tM % 256, (m + r) % 256))
			tM = (tM - tM % 256) / 256
			r += 1
			f[r] = yo[81](bit32.bxor(tM % 256, (m + r) % 256))
			r += 1
		end
		local tM = tw[7] ~= nil and 57 or 116
		local pM = if 57 ~= 116 then 57 else 116
		tw[7] = ("")["sub"](table.concat(f), 1, 228)
		return 26, tw, Mo, dD, za, L, eB
	end,
	[83] = coroutine.close,
	tg = function(pM, tM, fT, o, r, m, X)
		local j = tM[13] ~= nil and 26 or 165
		return 166, tM, o, r, m, X, fT
	end,
	eg = function(j, X, m, r, o, fT, tM)
		local pM = X[13] ~= nil and 96 or 112
		return 70, X, r, o, fT, tM, m
	end,
	uO = function(pM, tM, fT, o, r, m, X)
		local j = tM[13] ~= nil and 6 or 131
		return 218, tM, o, r, m, X, fT
	end,
	_D = function(j, X, m, r, o, fT, tM)
		local pM = X[13] ~= nil and 79 or 222
		return 223, X, r, o, fT, tM, m
	end,
	r = function(pM, tM, fT, o, r, m, X)
		if tM[14] ~= tM[13] then
			tM[13] = tM[13] + 7919
		end
		return 236, tM, o, r, m, X, fT
	end,
	[55] = buffer.tostring,
	Nu = function(X, m, r, o, fT, tM, pM)
		local j = m[13] ~= nil and 44 or 183
		return 201, m, o, fT, tM, pM, r
	end,
	Mz = function(j, pM, tM, fT, o, r, m)
		local X = pM[13] ~= nil and 12 or 147
		return 102, pM, fT, o, r, m, tM
	end,
	[48] = 148163911 - 50107544,
	oT = function(X, m, r, o, fT, tM, pM)
		local j = m[13] ~= nil and 11 or 134
		return 59, m, o, fT, tM, pM, r
	end,
	x = function(j, pM, tM, fT, o, r, m)
		local X = pM[13] ~= nil and 95 or 204
		return 71, pM, fT, o, r, m, tM
	end,
	[77] = table.pack,
	_q = function(X, m, r, o, fT, tM, pM)
		local j = m[13] ~= nil and 6 or 225
		return 44, m, o, fT, tM, pM, r
	end,
	EQ = function(j, pM, tM, fT, o, r, m, X)
		local f = { [7] = "_r" }
		while true do
			if tM <= 111 then
				return j[f[7]](j, pM, tM, fT, o, r, m, X)
			else
				return j:_r(pM, tM, fT, o, r, m, X)
			end
		end
	end,
	ey = function(f, X, m, r, o, fT, tM)
		local pM = function(...)
			return X[11](X[1] .. X[2] .. X[3] .. X[4] .. X[5], X[6] .. X[7] .. X[8] .. X[9] .. X[10])
		end
		X[15], X[12] = 7, function(...)
			return f[5](f, pM, ...)
		end
		f.ey = X[12]
		return 231, X, m, o, fT, tM, r
	end,
	[107] = function(pM, tM, fT, o)
		return function()
			local r = 0
			while true do
				if r <= 0 then
					fT[1][4][fT[1][7]] = (242275 * fT[1][4][fT[1][7]] + 201012383) % 268435456
					fT[1][4][fT[1][7]], r = (391108 * fT[1][4][fT[1][7]] + 9891558) % 268435456, 1
				elseif r <= 1 then
					fT[1][4][fT[1][7]] = (607190 * fT[1][4][fT[1][7]] + 135040541) % 268435456
					fT[1][4][fT[1][7]], r = (324547 * fT[1][4][fT[1][7]] + 21728191) % 268435456, 2
				elseif r <= 2 then
					fT[1][4][fT[1][7]] = (555093 * fT[1][4][fT[1][7]] + 197337803) % 268435456
					fT[1][4][fT[1][7]], r = (1062925 * fT[1][4][fT[1][7]] + 79573320) % 268435456, 3
				else
					return
				end
			end
		end
	end,
	qp = function(o, fT, tM, pM, r, m, X)
		local f = fT[13] ~= nil and 111 or 183
		return 83, fT, pM, r, m, X, tM
	end,
	[12] = [[C,$IZDuD1,9Ed?Y@J2b\M1Y,OL1ii11"?0-$IS$s/w.b2+i2E@5O|yJG`iTh?6P/nK{gG`$lt3E+k_e*.6p@p's+q_<0;uP'K!L60PF,Q(8B@3=1k+P4xZixA<`NLRY"kOH?6KZW*DZ_PPFIm2+|[&'$n!?9rkK@?VvJaE_b[%G4sN<HMaI-)/hBw*Qd0+Sw!2>7dOF4'J=I;7oOan??DMFK]tZ6J\1j0LuW1oR^WjnV/op#&+[6h,5p8e4U1X^"~WBc2zD~7#G)o_Ok}%1R}@&Y1A($A1LVIx,16EM2eh7BF*HQ^G;?DkLUqX@OtoB\T<m99Mj#(@O&/s{&,l5.,!d6|%%3f-4tyjM6'0/YE4[d&Ed2Dt;@%Ac>W\!hWK+h5+S!W0,MQO{WC67#:Xy`DBwe8t9(q_CCQr2&@:8KS'AU8FSgZJ[1$(DXV{$nx'5il+]],
	[4] = ("")["char"],
	[15] = buffer.readu16,
	UZ = function(f, X, m, r, pM, tM, fT)
		local o = X[13] ~= nil and 84 or 147
		return 203, X, r, pM, tM, fT, m
	end,
	[17] = bit32.lshift,
	[57] = 302361488 - 63457351,
	aX = function(o, fT, tM, pM, r, m, X)
		local f = fT[13] ~= nil and 59 or 134
		return 57, fT, pM, r, m, X, tM
	end,
	[36] = ("")["byte"],
	dQ = function(f, X, m, r, pM, tM, fT)
		local o = X[13] ~= nil and 91 or 233
		return 101, X, r, pM, tM, fT, m
	end,
	[14] = coroutine.yield,
	R = function(o, fT, tM, pM, r, m, X)
		local f = fT[13] ~= nil and 49 or 118
		return 153, fT, pM, r, m, X, tM
	end,
	j = function(f, X, m, r, pM, tM, fT)
		local o = X[13] ~= nil and 111 or 166
		return 179, X, r, pM, tM, fT, m
	end,
	[67] = next,
	ai = function(o, fT, tM, pM, r, m, X)
		local f = fT[13] ~= nil and 58 or 162
		return 66, fT, pM, r, m, X, tM
	end,
	[1642] = function(f)
		local X = 7
		X = (213 * X + 225) % 268435456
		X = (X * 213 + 225) % 268435456
		return X
	end,
	Hq = function(X, f, m, r, pM, tM, fT)
		local o = f[13] ~= nil and 6 or 150
		return 168, f, r, pM, tM, fT, m
	end,
	[104] = {
		230061427,
		59363570,
		30303734,
		2274454231,
		988047737,
		4215210872,
		1767322910,
		1159604974,
		2391683907,
		332795340,
		3889812340,
		15739002,
		143769529,
		3497178444,
		2528030855,
		3578469307,
		1602300,
		1266538271,
		2820168931,
		7308895,
		89783189,
		274992465,
		472027039,
		390374504,
		802864284,
		970662110,
		2317225017,
		178358054,
		3374807368,
		4052835742,
		247768517,
		38480,
		219640919,
		3739200171,
		1273798363,
		1166714809,
		2073108368,
		3363819739,
		1826966326,
		3248849368,
		4191892148,
		1168655625,
		1290957678,
		728362704,
		3049500323,
		4194864940,
		79556,
		23320555,
	},
	zn = function(o, fT, tM, pM, r, m, f)
		local X = fT[13] ~= nil and 79 or 180
		return 69, fT, pM, r, m, f, tM
	end,
	[32] = bit32.band,
	[115] = ("")["sub"],
	CX = function(X, f, m, r, pM, tM, fT)
		local o = f[13] ~= nil and 68 or 222
		return 94, f, r, pM, tM, fT, m
	end,
	[113] = unpack,
	oB = function(o, fT, tM, pM, r, m, f)
		local X = (o[31] + o[121]) % 4294967296
		local j = (o[23] - o[48]) % 4294967296
		local K = {}
		local N = 96
		local L = o[98](o)
		local za = (L % 256 + bit32.extract(L, 8, 8) + bit32.extract(L, 16, 8) + bit32.extract(L, 24, 4)) % 256
		local Mo = 1
		local eB = o[78]
		local dD = 6
		while dD <= 28 do
			local tw = (dD - 1) * 5 + 1
			local yo, I, i, s, a = o[36](eB, tw, tw + 4)
			local iX = (
				((((yo - 33) * 94 + I - 33) * 94 + i - 33) * 94 + s - 33) * 94
				+ a
				- 33
				+ (4294967296 - (X + N * j) % 4294967296)
			) % 4294967296
			N += 1
			K[Mo] = o[81](bit32.bxor(iX % 256, (za + Mo) % 256))
			iX = (iX - iX % 256) / 256
			Mo += 1
			K[Mo] = o[81](bit32.bxor(iX % 256, (za + Mo) % 256))
			iX = (iX - iX % 256) / 256
			Mo += 1
			K[Mo] = o[81](bit32.bxor(iX % 256, (za + Mo) % 256))
			iX = (iX - iX % 256) / 256
			Mo += 1
			K[Mo] = o[81](bit32.bxor(iX % 256, (za + Mo) % 256))
			Mo += 1
			dD += 1
		end
		local iX = fT[5] ~= nil and 25 or 203
		local a = if 25 ~= 203 then 25 else 203
		fT[5] = table.concat(K, nil, 1, 92)
		return 16, fT, r, tM, m, f, pM
	end,
	ZB = function(a, iX, dD, eB, Mo, za, L)
		local N = iX[13] ~= nil and 8 or 198
		return 96, iX, eB, Mo, za, L, dD
	end,
	aI = function(N, ...)
		return true, 4, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil
	end,
	h = { 24123, 1250774562, 1783630544, 715613900, 3271588553, 1198560506, 2504734947, 2731252267, 1962075462 },
	[80] = ("")["byte"],
	[1] = string.pack,
	BL = "__index",
	[54] = string.format,
	kB = function(N, L, za, Mo, eB, dD, iX)
		local a = L[13] ~= nil and 71 or 121
		return 87, L, Mo, eB, dD, iX, za
	end,
	jP = function(a, iX, dD, eB, Mo, za, L)
		local N = iX[13] ~= nil and 108 or 162
		return 84, iX, eB, Mo, za, L, dD
	end,
	[121] = 2432705607 - 72704477,
}
return N:Gr()(...)
