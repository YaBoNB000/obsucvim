# 部署到 Windows Server 2019（数据中心版 x64）

本目录是 **已构建好的运行版**，服务器上**不需要安装 Rust、Visual Studio 或任何第三方库**。

## 一、上传

1. 在本地把整个 `obsucvim` 目录压缩成 zip（或使用我生成的 `obsucvim-deploy-win.zip`）。
2. 通过以下任一方式传到服务器：
   - RDP 远程桌面：直接把 zip 复制/粘贴到服务器桌面（小文件最快）。
   - 云厂商控制台：文件上传 / 远程命令。
   - SMB 共享：`\\<服务器IP>\C$\...`（需管理员共享）。
   - OpenSSH：服务器安装 `OpenSSH Server` 后用 `scp`。
3. 在服务器上解压到例如 `C:\obsucvim`。

## 二、运行

```bat
cd /d C:\obsucvim
bin\obsucvim.exe --help
```

把 `.lua` / `.luau` 文件拖到 `obfuscate.bat` 上即可，输出为同目录 `<原名>.obf.lua`。

默认参数：

```
--preset v15 --seed 42 --no-bind-executor
```

`--no-bind-executor` 让产物可以在普通 Luau CLI 中直接运行；如果目标就是 Roblox 执行器且需要认证绑定，设置 `OBS_BIND=1`。

### 可选环境变量

```bat
set OBS_SEED=67067
set OBS_PRESET=v15
set OBS_BIND=1
set OBS_EXTRA=--env-check
set OBS_NO_PAUSE=1
obfuscate.bat D:\scripts\demo.luau
```

## 三、验证

```bat
py verify_deploy.py
```

会检查：二进制可运行、`obfuscate.bat` 端到端产出、首行水印。若服务器上装了 Luau，可设置：

```bat
set LUAU=C:\tools\luau.exe
py verify_deploy.py
```

## 四、可选的“服务器化”用法

### 1. 共享文件夹 + 拖放

- 建 `C:\obf\in`、`C:\obf\out`。
- 把 `obfuscate.bat` 放到桌面，用户远程桌面里拖文件即可。

### 2. 计划任务 / 文件夹监听

用 PowerShell 监听 `C:\obf\in`，自动调用 `bin\obsucvim.exe`：

```powershell
$in = "C:\obf\in"; $out = "C:\obf\out"
while ($true) {
    Get-ChildItem $in -Filter *.lua -File | ForEach-Object {
        $dst = Join-Path $out ($_.BaseName + ".obf.lua")
        & "C:\obsucvim\bin\obsucvim.exe" --preset v15 --seed 42 --no-bind-executor $_.FullName $dst
        if ($LASTEXITCODE -eq 0) { Move-Item $_.FullName (Join-Path $out $_.Name) -Force }
    }
    Start-Sleep -Seconds 2
}
```

### 3. Discord 机器人

项目自带 `services\discord_obf\`（Python + Rust 引擎），需要 Discord Bot Token，见该目录的 README。当前固定 v15 / Luau。

## 五、可选：在服务器上重新构建

只有修改了 Rust 源码才需要。服务器需要 Rust 1.99.1：

- 联网安装：`winget install Rustlang.Rustup`，然后 `rustup default stable-x86_64-pc-windows-gnu`。
- 离线安装：下载
  `https://static.rust-lang.org/dist/rust-1.99.1-x86_64-pc-windows-gnu.tar.xz`
  （SHA-256 `0210624b2eb2bdf4ec32c2a6caf5c3bd2ab84e5df66c7530023e37f02add1084`），
  解压后把 `rustc`、`rust-std-*`、`cargo`、`rust-mingw` 拼装成工具链目录，
  然后运行 `setup.bat`（会使用 `%USERPROFILE%\.rust-1.99.1`）。

## 六、安全建议（云服务器）

- **RDP 3389 只允许你的固定 IP**（安全组/防火墙），不要对公网全开。
- 使用非 Administrator 的专用账户运行；`C:\obsucvim` 只给该账户读写权限。
- 不要把 445（SMB）、3389、RDP 网关暴露给不受信任来源。
- 若做对外服务（Discord/HTTP），把输出目录与系统目录隔离，限制上传大小和并发。
- 混淆器本身只处理文本，不执行输入脚本；但仍建议对上传文件做大小/扩展名白名单。

## 七、已知注意事项

- 输入必须是 **无 BOM 的 UTF-8**。PowerShell 5.1 的 `Set-Content -Encoding UTF8` 会写 BOM，obsucvim 会报 `unexpected character 'ï'`。
- 默认 `--bind-executor`（`OBS_BIND=1`）产物在裸 Luau CLI 中静默死亡是设计行为，与 R067 一致。
- 同 seed、同版本输出逐字节确定；跨版本不保证一致。
