# Obsucvim 本地部署说明

## 已部署内容

| 路径 | 说明 |
|---|---|
| `C:\Users\15268\obsucvim\` | 项目根目录（从 zip 解压，524 个文件） |
| `C:\Users\15268\obsucvim\bin\obsucvim.exe` | 已构建的混淆器（1.79 MB） |
| `C:\Users\15268\obsucvim\obfuscate.bat` | **拖放混淆入口** |
| `C:\Users\15268\obsucvim\setup.bat` | 重新构建（使用本地离线 Rust 工具链） |
| `C:\Users\15268\.rust-1.99.1\` | 手动拼装的 Rust 1.99.1 GNU 工具链 |
| `C:\Users\15268\.rust-offline\` | 解压的官方离线包（可删除，约 1 GB） |

## 拖放用法

把 `.lua` / `.luau` 文件（可多选）拖到 `obfuscate.bat` 上：

- 输出：与源文件同目录的 `<原名>.obf.lua`
- 默认：`--preset v15 --seed 42 --no-bind-executor`
  - `--no-bind-executor` 让产物可以在普通 Luau CLI 里直接运行
- 日志：`C:\Users\15268\obsucvim\obfuscate.log`

### 可选环境变量（在 cmd 里 set 后再拖）

| 变量 | 作用 |
|---|---|
| `OBS_SEED=42` | 指定 seed（同 seed 逐字节确定） |
| `OBS_PRESET=v15` | `v15` / `low` / `medium` / `high` / `vm` / `max` |
| `OBS_BIND=1` | 加 `--bind-executor`，产物只在 Roblox executor 内运行 |
| `OBS_EXTRA=--env-check --bind-env roblox` | 追加任意参数 |
| `OBS_NO_PAUSE=1` | 结束时不暂停（自动化用） |

示例（cmd）：

```bat
set OBS_SEED=67067
set OBS_BIND=1
set OBS_EXTRA=--env-check
obfuscate.bat D:\scripts\demo.luau
```

## 验证结果（本机实测）

| 检查 | 结果 |
|---|---|
| `cargo build --release` | 成功，42.29s |
| 普通 v15 + `--no-bind-executor` | 206,965 B；Luau CLI 输出 `hello from obsucvim`，rc=0 |
| 拖放 bat | `bat_test.lua` → `bat_test.obf.lua`（206,941 B），Luau CLI 输出 `bat drop test`，rc=0 |
| 同 seed 两次生成 | SHA-256 完全一致（确定性） |
| 默认 v15（带 executor 绑定） | 裸 Luau CLI 报错退出（符合产品设计） |
| 首行水印 | `-- This file was obfuscated by Obsucvim.` |

## 重新构建

```bat
cd /d C:\Users\15268\obsucvim
setup.bat
```

工具链是官方 `rust-1.99.1-x86_64-pc-windows-gnu.tar.xz`（SHA-256
`0210624b2eb2bdf4ec32c2a6caf5c3bd2ab84e5df66c7530023e37f02add1084`）手动拼装的，
不依赖 rustup / Visual Studio。

## 注意

- 输入文件必须是 **无 BOM 的 UTF-8**。PowerShell 5.1 的
  `Set-Content -Encoding UTF8` 会写 BOM，obsucvim 会报
  `unexpected character 'ï'`。用 `[IO.File]::WriteAllText(..., New-Object Text.UTF8Encoding($false))`。
- `--bind-executor` 产物在裸 Luau CLI 中静默死亡是预期行为（与 R067 一致）。
