@echo off
setlocal EnableExtensions EnableDelayedExpansion
title Obsucvim Drop-to-Obfuscate
set "ROOT=%~dp0"
set "EXE=%ROOT%bin\obsucvim.exe"
if not exist "%EXE%" set "EXE=%ROOT%obsucvim\target\release\obsucvim.exe"
if not exist "%EXE%" (
    echo [ERROR] obsucvim.exe not found.
    echo         Run setup.bat first.
    if not "%OBS_NO_PAUSE%"=="1" pause
    exit /b 1
)
if "%~1"=="" (
    echo Drag and drop .lua / .luau files onto this .bat.
    echo.
    echo Default: v15 pipeline, seed 42, --no-bind-executor
    echo          ^(output runs in plain Luau CLI^)
    echo.
    echo Optional environment variables:
    echo   OBS_SEED=42
    echo   OBS_PRESET=v15    ^(v15 / low / medium / high / vm / max^)
    echo   OBS_BIND=1        ^(adds --bind-executor; only runs in Roblox executor^)
    echo   OBS_EXTRA=--env-check --bind-env roblox
    echo   OBS_NO_PAUSE=1    ^(no pause at the end^)
    if not "%OBS_NO_PAUSE%"=="1" pause
    exit /b 0
)
if "%OBS_SEED%"=="" (set "SEED=42") else (set "SEED=%OBS_SEED%")
if "%OBS_PRESET%"=="" (set "PRESET=v15") else (set "PRESET=%OBS_PRESET%")
if "%OBS_BIND%"=="1" (set "BIND=--bind-executor") else (set "BIND=--no-bind-executor")
set "EXTRA=%OBS_EXTRA%"
set /a OK=0
set /a FAIL=0
:loop
if "%~1"=="" goto done
set "SRC=%~f1"
set "OUT=%~dpn1.obf.lua"
echo [*] %SRC%
"%EXE%" --preset %PRESET% --seed %SEED% %BIND% %EXTRA% "%SRC%" "%OUT%" >> "%ROOT%obfuscate.log" 2>&1
if errorlevel 1 (
    echo     [FAIL] see obfuscate.log
    set /a FAIL+=1
) else (
    echo     [OK] %OUT%
    set /a OK+=1
)
shift
goto loop
:done
echo.
echo Finished: %OK% ok, %FAIL% failed.
echo Log: %ROOT%obfuscate.log
if not "%OBS_NO_PAUSE%"=="1" pause
