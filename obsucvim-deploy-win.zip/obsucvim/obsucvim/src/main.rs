
mod anti;
mod antidbg;
mod guard;
mod ast;
mod body;
mod flatten;
mod junk;
mod lexer;
mod mangle;
mod minify;
mod numbers;
mod parser;
mod printer;
mod rng;
mod strings;
mod symtab;
mod vmgen;

use std::process::ExitCode;

const VERSION: &str = env!("CARGO_PKG_VERSION");
const OUTPUT_WATERMARK: &str = "-- This file was obfuscated by Obsucvim.\n";

struct Options {
dialect: &'static str,
	input: String,
	output: Option<String>,
	seed: u64,
	do_mangle: bool,
	do_minify: bool,
	do_numbers: bool,
	do_body: bool,
	do_antidbg: bool,
	do_guard: bool,
	do_vm: bool,
	vm_seal_strings: Option<bool>,
	do_v15: bool,
	do_strings: bool,
	do_flatten: bool,
	do_junk: bool,
	junk_n: usize,
	bind_env: Option<String>,
	bind_executor: bool,
	bind_given: bool,
	env_check: bool,
}

fn apply_preset(opts: &mut Options, name: &str) -> Result<(), String> {
	opts.do_mangle = false;
	opts.do_minify = false;
	opts.do_strings = false;
	opts.do_flatten = false;
	opts.do_junk = false;
	opts.do_numbers = false;
	opts.do_body = false;
	opts.do_antidbg = false;
	opts.do_guard = false;
	opts.do_vm = false;
	opts.do_v15 = false;
	opts.junk_n = 1;
	match name {
		"low" => {
			opts.do_mangle = true;
			opts.do_minify = true;
			opts.do_strings = true;
		}
		"medium" => {
			opts.do_mangle = true;
			opts.do_minify = true;
			opts.do_strings = true;
			opts.do_flatten = true;
			opts.do_junk = true;
		}
		"high" => {
			opts.do_mangle = true;
			opts.do_minify = true;
			opts.do_strings = true;
			opts.do_flatten = true;
			opts.do_junk = true;
			opts.do_numbers = true;
			opts.do_body = true;
			opts.do_antidbg = true;
			opts.do_guard = true;
		}
		"vm" => {
			opts.do_mangle = true;
			opts.do_minify = true;
			opts.do_strings = true;
			opts.do_flatten = true;
			opts.do_junk = true;
			opts.do_numbers = true;
			opts.do_body = true;
			opts.do_antidbg = true;
			opts.do_guard = true;
			opts.do_vm = true;
		}
		"max" => {
			opts.do_mangle = true;
			opts.do_minify = true;
			opts.do_strings = true;
			opts.do_flatten = true;
			opts.do_junk = true;
			opts.do_numbers = true;
			opts.do_body = true;
			opts.do_antidbg = true;
			opts.do_guard = true;
			opts.do_vm = true;
			opts.junk_n = 2;
		}
		"v15" => {
			opts.do_mangle = true;
			opts.do_minify = true;
			opts.do_strings = false;
			opts.do_flatten = true;
			opts.do_junk = true;
			opts.do_numbers = false;
			opts.do_body = false;
			opts.do_antidbg = false;
			opts.do_guard = true;
			opts.do_vm = true;
			opts.do_v15 = true;
		}
		other => {
			return Err(format!(
				"unknown --preset '{other}' (want low|medium|high|vm|max|v15)"
			));
		}
	}
	Ok(())
}

fn print_help() {
	print!(
		"obsucvim {} — commercial-grade Lua 5.1 / Luau obfuscator
Usage: obsucvim [options] <input.lua> [output.lua]

Options:
  --dialect <luau>       target dialect (仅 luau；5.1 自 2026-09-10 起停止支持)
  -o, --output <file>    output file (default: stdout)
  --seed <n>             PRNG seed (default: time-based; use a fixed seed
                         for reproducible output)
  --preset <name>        named strength (flags after this override it).
                         DEFAULT (no --preset/--vm): v15 — 产品默认形态
                         （产品线为 Luau-only）。
                           v15     Luraph-v15 structural clone (Luau/Roblox
                                   only) — 默认
                           low     L1+L2  name+minify+strings (legacy)
                           medium  low+L3 flatten+junk (legacy)
                           high    medium+L4+L5+L7 (legacy)
                           vm      high+L6 private bytecode VM (legacy)
                           max     strongest legacy shipping (= vm)
  --minify               L1 minify output to a single compact line (default: enabled)
  --no-minify            keep the normalized (indented) printer output
  --no-numbers           disable L4 numeric literal rewriting (default: enabled)
  --no-body              disable L5 whole-program encryption (default: enabled)
  --no-antidbg           disable L7 anti-tamper (default: enabled)
  --no-guard             disable the anti-debug environment guard prelude
                         (default: enabled for the standard pipeline)
  --vm                   L6: compile the program to private bytecode and
                         run it through a generated obfuscated interpreter
  --vm-seal-strings       EXPERIMENTAL: seal source string literals before VM
                         compilation (default on for VM presets)
  --no-vm-seal-strings    disable experimental VM string sealing
  --no-mangle            disable L1 name mangling (default: enabled)
  --no-strings           disable L2 string encryption (default: enabled)
  --no-flatten           disable L3 loop desugar + CFG flattening (default: enabled)
  --no-junk              disable L3 junk code injection (default: enabled)
  --bind-env <roblox>    增量㉑ 环境绑定（仅 v15）：把目标运行时 API
                         (Vector3/Vector2/task) 嵌进原语槽，产物只在目标运行
                         时可加载，通用分析沙箱加载期即失败。绑定态产物不进
                         通用运行等价矩阵（只语法校验）。
  --env-check            WTF-PORT 纯 Luau 环境检查组（仅 v15）：buffer/
                         bit32/string/元表/协程/freeze/loadstring 语义常量
                         挑战 + 首尾身份全等；差值折入 SLT/MZD 静默投毒。
                         防错误语义 mock 环境，不防真环境录制重放。
  --bind-executor        增量51 executor 认证绑定（仅 v15，IronBrew2 守卫
                         移植）——**默认开启（底层保护层）**：产物只在完整
                         Roblox executor 环境内正确运行（identifyexecutor/
                         getgenv/闭包内省语义全认证），其他环境错钥静默死亡。
                         绑定态产物只做语法校验。非 v15 管线自动降级为关闭。
  --no-bind-executor     显式关闭 executor 认证绑定（等价于 2026-10-11 前
                         的默认产物；运行等价测试矩阵用此旗标）。
  -h, --help             show this help
  --version              show version
",
		VERSION
	);
}

fn main() -> ExitCode {
	let args: Vec<String> = std::env::args().skip(1).collect();
	let mut opts = Options {
		dialect: "luau",
		input: String::new(),
		output: None,
		seed: 0,
		do_mangle: true,
		do_minify: true,
		do_numbers: true,
		do_body: true,
		do_antidbg: true,
		do_guard: true,
		do_vm: false,
		vm_seal_strings: None,
		do_v15: false,
		do_strings: true,
	do_flatten: true,
	do_junk: true,
	junk_n: 2,
		bind_env: None,
		bind_executor: true,
		bind_given: false,
		env_check: false,
	};
	let mut i = 0;
	let mut positional: Vec<String> = Vec::new();
	let mut preset_given = false;
	let mut vm_given = false;
	while i < args.len() {
		match args[i].as_str() {
			"-h" | "--help" => {
				print_help();
				return ExitCode::SUCCESS;
			}
			"--version" => {
				println!("obsucvim {}", VERSION);
				return ExitCode::SUCCESS;
			}
			"--dialect" => {
				i += 1;
				if i >= args.len() {
					eprintln!("error: --dialect requires a value (5.1|luau)");
					return ExitCode::FAILURE;
				}
				match args[i].as_str() {
					"5.1" => opts.dialect = "5.1",
					"luau" => opts.dialect = "luau",
					other => {
						eprintln!("error: unknown dialect '{}'", other);
						return ExitCode::FAILURE;
					}
				}
			}
			"-o" | "--output" => {
				i += 1;
				if i >= args.len() {
					eprintln!("error: --output requires a file");
					return ExitCode::FAILURE;
				}
				opts.output = Some(args[i].clone());
			}
			"--seed" => {
				i += 1;
				if i >= args.len() {
					eprintln!("error: --seed requires a number");
					return ExitCode::FAILURE;
				}
				match args[i].parse() {
					Ok(v) => opts.seed = v,
					Err(_) => {
						eprintln!("error: --seed must be a number");
						return ExitCode::FAILURE;
					}
				}
			}
			"--preset" => {
				preset_given = true;
				opts.vm_seal_strings = None;
				i += 1;
				if i >= args.len() {
					eprintln!("error: --preset requires a value (low|medium|high|vm|max|v15)");
					return ExitCode::FAILURE;
				}
				if let Err(e) = apply_preset(&mut opts, args[i].as_str()) {
					eprintln!("error: {e}");
					return ExitCode::FAILURE;
				}
			}
			"--no-mangle" => opts.do_mangle = false,
		"--minify" => opts.do_minify = true,
		"--no-minify" => opts.do_minify = false,
		"--no-numbers" => opts.do_numbers = false,
		"--no-body" => opts.do_body = false,
		"--no-antidbg" => opts.do_antidbg = false,
		"--no-guard" => opts.do_guard = false,
		"--vm" => {
			vm_given = true;
			opts.do_vm = true;
		}
			"--vm-seal-strings" => opts.vm_seal_strings = Some(true),
			"--no-vm-seal-strings" => opts.vm_seal_strings = Some(false),
			"--no-strings" => opts.do_strings = false,
			"--no-flatten" => opts.do_flatten = false,
			"--no-junk" => opts.do_junk = false,
			"--bind-env" => {
				i += 1;
				if i >= args.len() {
					eprintln!("error: --bind-env requires a target (roblox)");
					return ExitCode::FAILURE;
				}
				opts.bind_env = Some(args[i].clone());
			}
			"--bind-executor" => {
				opts.bind_executor = true;
				opts.bind_given = true;
			}
			"--no-bind-executor" => {
				opts.bind_executor = false;
				opts.bind_given = true;
			}
			"--env-check" => opts.env_check = true,
			s if s.starts_with('-') => {
				eprintln!("error: unknown option '{}'", s);
				print_help();
				return ExitCode::FAILURE;
			}
			_ => positional.push(args[i].clone()),
		}
		i += 1;
	}
	if positional.is_empty() {
		eprintln!("error: missing input file");
		print_help();
		return ExitCode::FAILURE;
	}
	opts.input = positional[0].clone();
	if positional.len() > 1 {
		opts.output = Some(positional[1].clone());
	}

	if !preset_given && !vm_given {
		if let Err(e) = apply_preset(&mut opts, "v15") {
			eprintln!("error: {e}");
			return ExitCode::FAILURE;
		}
	}
	let vm_seal_strings = opts.vm_seal_strings.unwrap_or(opts.do_vm);
	if vm_seal_strings && !opts.do_vm {
		eprintln!("error: --vm-seal-strings requires a VM preset or --vm");
		return ExitCode::FAILURE;
	}

	if opts.dialect != "luau" {
		eprintln!(
			"error: 产品形态已统一为 Luau（v15 架构），不再支持 Lua 5.1 目标\n  \
			 (product is Luau-only since 2026-09-10; drop --dialect 5.1)"
		);
		return ExitCode::FAILURE;
	}
	if opts.do_v15 && opts.dialect != "luau" {
		eprintln!(
			"error: --preset v15 requires --dialect luau\n  \
			 the v15 structural profile clones the Luraph v15 shape \
			 (buffer/bit32/typeof/setfenv),\n  which Lua 5.1 cannot \
			 run. Use `--preset vm` for the dual-target output."
		);
		return ExitCode::FAILURE;
	}
	if let Some(e) = &opts.bind_env {
		if !(opts.do_vm && opts.do_v15) {
			eprintln!(
				"error: --bind-env requires --preset v15\n  \
				 environment binding embeds target-runtime API refs into \
				 the v15 module table."
			);
			return ExitCode::FAILURE;
		}
		if e != "roblox" {
			eprintln!(
				"error: --bind-env target '{e}' unknown (only 'roblox')\n  \
				the target must be a runtime whose APIs we can reference."
			);
			return ExitCode::FAILURE;
		}
	}
	if opts.bind_executor && !(opts.do_vm && opts.do_v15) {
		if opts.bind_given {
			eprintln!(
				"error: --bind-executor requires --preset v15\n  \
				\tthe executor attestation guard rides the v15 fragment chain."
			);
			return ExitCode::FAILURE;
		}
		opts.bind_executor = false;
	}
	if opts.env_check && !(opts.do_vm && opts.do_v15) {
		eprintln!(
			"error: --env-check requires --preset v15\n  \
				the environment check battery rides the v15 boot fragment chain."
		);
		return ExitCode::FAILURE;
	}

	let luau = opts.dialect == "luau";
	let seed = if opts.seed == 0 {
		std::time::SystemTime::now()
			.duration_since(std::time::UNIX_EPOCH)
			.map(|d| d.as_nanos() as u64)
			.unwrap_or(1)
	} else {
		opts.seed
	};

	let src = match std::fs::read_to_string(&opts.input) {
		Ok(s) => s,
		Err(e) => {
			eprintln!("error: cannot read {}: {}", opts.input, e);
			return ExitCode::FAILURE;
		}
	};

	let result = (|| -> Result<String, String> {
		let mut block = parser::parse(&src, luau).map_err(|e| e.to_string())?;
		let mut table = symtab::resolve(&mut block);
		let mut rng = rng::Rng::new(seed);
		if vm_seal_strings {
			let mut seal_rng = rng::Rng::new(seed ^ 0x5230_3632_5354_5253);
			vmgen::strseal::seal_literals(&mut block, &mut seal_rng);
		}
		let env_slots: Option<[i64; 4]> = if opts.do_v15 && opts.bind_env.is_some() {
			let mut es: Vec<i64> = Vec::new();
			while es.len() < 4 {
				let n = rng.int(5000, 6000);
				if !es.contains(&n) {
					es.push(n);
				}
			}
			Some([es[0], es[1], es[2], es[3]])
			} else {
				None
			};
			let vm_raw = std::env::var("OBSUCVIM_VM_RAW").is_ok();
			let (mut block, mut table, v15_done) = if opts.do_vm {
			let program = vmgen::compile(&block, &table, &mut rng, !luau, opts.do_v15);
			let n = program.fns.len();
			let carrier_bytes: Vec<Vec<u8>> = program
				.fns
				.iter()
				.map(|b| program.carrier.encode(b))
				.collect();
			let carrier_lengths: Vec<usize> = carrier_bytes.iter().map(Vec::len).collect();
			let tsrc = vmgen::template::generate(
				&program.opmap,
				&program.slot_perm,
				&program.slot_perms,
				(program.lane_base, program.lane_step),
				&program.carrier,
				&carrier_lengths,
				&mut rng,
				n,
				opts.do_v15,
				program.has_loadstr,
				&program.nop_sites,
				&program.operand_sums,
				&program.operand_sums2,
				&program.chaff_folds,
				(
					program.chaff_mul,
					program.chaff_coeffs,
					program.chaff_pos,
					program.chaff_fn,
				),
				(program.ck_km, program.ck_kc),
				(program.mk1, program.mk2),
				(
					program.blob_km,
					program.blob_kc,
					program.blob_seed,
					program.blob_step,
				),
				program.section_tags,
				program.consts_mask_safe,
				&program.block_starts,
				&program.s_indices,
				opts.bind_env.as_deref(),
				env_slots.as_ref(),
				opts.bind_executor,
				opts.env_check,
				opts.do_guard,
			);
			if std::env::var("OBSUCVIM_VM_TSRC").is_ok() {
				std::fs::write("/tmp/vm_tsrc.lua", &tsrc).unwrap();
			}
			let mut tblock = parser::parse(&tsrc, luau).map_err(|e| e.to_string())?;
			if opts.do_v15 {
				let mut ttable = symtab::resolve(&mut tblock);
				let mut reserved = mangle::reserved_set(
					&ttable
						.globals
						.iter()
						.cloned()
						.collect::<std::collections::HashSet<_>>(),
				);
				reserved.extend(ttable.syms.iter().map(|s| s.name.clone()));
				if opts.do_junk {
					junk::inject(&mut tblock, &mut ttable, &mut rng, 2);
				}
				if opts.do_mangle {
					mangle::mangle_v15_compact(&tblock, &mut ttable, &mut rng)
						.map_err(|e| format!("v15 compact-name allocation: {e}"))?;
				}
				if opts.do_strings {
					strings::apply_strings(
						&mut tblock, &mut ttable, &mut rng, &reserved,
					);
				}
				if opts.do_numbers {
					numbers::apply_numbers(&mut tblock, &mut rng);
				}
				let mut vm_name = String::from("VM");
				for st in tblock.stmts.iter() {
					if let ast::Stmt::Local { names, syms, .. } = st {
						if names.first().map(|s| s.as_str()) == Some("VM") {
							if let Some(id) = syms.first() {
								vm_name = ttable.syms[*id as usize]
									.name
									.clone();
							}
						}
					}
				}
				let interp_src = printer::print_chunk(&ttable, &tblock);
				let total_bytes: usize = carrier_bytes.iter().map(|c| c.len()).sum();
				let est_words = total_bytes / 4 + carrier_bytes.len() * vmgen::v15::CHUNKS + 4;
				let n_bw_slots = est_words / vmgen::v15::BW_SLOT_WORDS + 1;
				let mut slot_pool: Vec<i64> =
					(1..=std::cmp::max(126, n_bw_slots as i64 + 96)).collect();
				rng.shuffle(&mut slot_pool);
				let r1 = slot_pool[0];
				let r2 = slot_pool[1];
let ks = slot_pool[2];
let kg = slot_pool[3];
				let bw_slots: Vec<i64> =
					slot_pool[4..4 + n_bw_slots].to_vec();
				let sb_slot = slot_pool[4 + n_bw_slots];
				let sc_slot = slot_pool[5 + n_bw_slots];
				let kfrag: Vec<i64> = slot_pool
					[6 + n_bw_slots..11 + n_bw_slots]
					.to_vec();
				let st_slots: Vec<i64> = slot_pool
					[11 + n_bw_slots..13 + n_bw_slots]
					.to_vec();
				let max_len = carrier_bytes.iter().map(|c| c.len()).max().unwrap_or(0);
				let mut avoid: Vec<i64> = vec![r1, r2, ks, kg, sb_slot, sc_slot];
				avoid.extend_from_slice(&bw_slots);
				avoid.extend_from_slice(&kfrag);
				avoid.extend_from_slice(&st_slots);
				let (d1, d2) = vmgen::v15::decoy_slots(max_len, &avoid);
				let (scaffold_fields, fc) = vmgen::v15::scaffold(
					&mut rng,
					&interp_src,
					&vm_name,
					&carrier_bytes,
					r1,
					r2,
					ks,
					kg,
					d1,
					d2,
					&program.carrier,
					&bw_slots,
					(sb_slot, sc_slot),
				&kfrag,
				&st_slots,
				&ttable.globals,
			);
				let mut exclude: Vec<i64> = vec![r1, r2, ks, kg, d1, d2, sb_slot, sc_slot];
				exclude.extend_from_slice(&bw_slots);
				exclude.extend_from_slice(&kfrag);
				exclude.extend_from_slice(&st_slots);
				let (mut fields, _env_slots_back) = vmgen::v15::module_fields(
					&mut rng,
					&exclude,
					slot_pool.len() as i64,
					opts.bind_env.as_deref(),
					env_slots.as_ref(),
				);
				fields.extend(scaffold_fields);
				rng.shuffle(&mut fields);
				let module = ast::Expr::Table { fields };
				let root_name = "rt".to_string();
				let root_ref = || ast::Expr::Ident {
					name: root_name.clone(),
					sym: None,
				};
				let shell = ast::Block {
					stmts: vec![
						ast::Stmt::Local {
							names: vec![root_name.clone()],
							syms: vec![0],
							values: vec![Some(module)],
						},
						ast::Stmt::Return(vec![ast::Expr::Call {
							func: Box::new(ast::Expr::Method {
								obj: Box::new(root_ref()),
								name: fc,
								args: Vec::new(),
							}),
							args: vec![ast::Expr::Vararg],
						}]),
					],
				};
				let mut shell_block = shell;
				let mut shell_table = symtab::resolve(&mut shell_block);
				if opts.do_mangle {
					mangle::mangle_v15_compact(&shell_block, &mut shell_table, &mut rng)
						.map_err(|e| format!("v15 compact-name allocation: {e}"))?;
				}
				(shell_block, shell_table, true)
			} else {
				let vm_call = ast::Expr::Call {
					func: Box::new(ast::Expr::Ident {
						name: "VM".to_string(),
						sym: None,
					}),
					args: carrier_bytes
						.into_iter()
						.map(|b| ast::Expr::Str {
							bytes: b,
							is_binary: true,
						})
						.collect(),
				};
				tblock.stmts.push(ast::Stmt::ExprStmt(vm_call));
				let ttable = symtab::resolve(&mut tblock);
				(tblock, ttable, false)
			}
		} else {
			(block, table, false)
		};
		if opts.do_vm && vm_raw {
		let out = printer::print_chunk(&table, &block);
			return Ok(out);
		}
		let tim = std::env::var("OBSUCVIM_TIMING").is_ok();
		let mut tmark = std::time::Instant::now();
		let mut tlog = |name: &str| {
			if tim {
				eprintln!("[time] {} = {:?}", name, tmark.elapsed());
				tmark = std::time::Instant::now();
			}
		};
		let mut reserved = std::collections::HashSet::new();
		if !v15_done {
			if opts.do_junk {
				junk::inject(&mut block, &mut table, &mut rng, 2);
				tlog("junk");
			}
			if opts.do_mangle {
				mangle::mangle(&mut table, &mut rng);
				tlog("mangle");
			}
			reserved = mangle::reserved_set(
				&table.globals.iter().cloned().collect::<std::collections::HashSet<_>>(),
			);
			reserved.extend(table.syms.iter().map(|s| s.name.clone()));
			if opts.do_flatten && !opts.do_vm {
				flatten::flatten_block(&mut block, &mut table, &mut rng, &mut reserved);
				tlog("flatten");
			}
			if opts.do_strings {
				strings::apply_strings(&mut block, &mut table, &mut rng, &reserved);
				tlog("strings");
			}
			if opts.do_numbers {
				numbers::apply_numbers(&mut block, &mut rng);
				tlog("numbers");
			}
			if opts.do_body {
				body::apply_body(&mut block, &mut table, &mut rng, &mut reserved, luau);
				tlog("body");
			}
			if opts.do_antidbg {
				antidbg::apply_antidbg(&mut block, &mut table, &mut rng, &mut reserved);
				tlog("antidbg");
			}
		}
		tlog("pre-print");
		let out = if luau {
			printer::print_chunk_luau(&table, &block)
		} else {
			printer::print_chunk(&table, &block)
		};
		tlog("print");
		if opts.do_minify {
			let m = minify::minify(&out, luau).map_err(|e| format!("minify: {}", e))?;
			tlog("minify");
			if opts.do_v15 {
				Ok(format!("\n{};", m.trim_end_matches('\n')))
			} else if opts.do_guard {
				Ok(format!("{}\n{}", guard::guard_prelude(&mut rng, luau), m))
			} else {
				Ok(m)
			}
		} else if opts.do_guard && !opts.do_v15 {
			Ok(format!("{}\n{}", guard::guard_prelude(&mut rng, luau), out))
		} else {
			Ok(out)
		}
	})();

	match result.map(|out| format!("{OUTPUT_WATERMARK}{out}")) {
		Ok(out) => match &opts.output {
			Some(path) => match std::fs::write(path, out) {
				Ok(()) => {}
				Err(e) => {
					eprintln!("error: cannot write {}: {}", path, e);
					return ExitCode::FAILURE;
				}
			},
			None => print!("{}", out),
		},
		Err(e) => {
			eprintln!("obsucvim: {}", e);
			return ExitCode::FAILURE;
		}
	}
	ExitCode::SUCCESS
}
