@echo off
setlocal
title Obsucvim Setup
set "ROOT=%~dp0"
set "TC=%USERPROFILE%\.rust-1.99.1"
if not exist "%TC%\bin\cargo.exe" (
    echo [ERROR] Rust toolchain not found at %TC%
    echo         See README-DEPLOY.md for the required download.
    if not "%OBS_NO_PAUSE%"=="1" pause
    exit /b 1
)
set "RUSTC=%TC%\bin\rustc.exe"
set "RUSTFLAGS=-C linker=%TC%\lib\rustlib\x86_64-pc-windows-gnu\bin\rust-lld.exe -C link-self-contained=yes"
echo [*] Building obsucvim (release)...
pushd "%ROOT%obsucvim"
"%TC%\bin\cargo.exe" build --release
if errorlevel 1 (
    echo [ERROR] Build failed.
    popd
    if not "%OBS_NO_PAUSE%"=="1" pause
    exit /b 1
)
popd
if not exist "%ROOT%bin" mkdir "%ROOT%bin"
copy /Y "%ROOT%obsucvim\target\release\obsucvim.exe" "%ROOT%bin\obsucvim.exe" >nul
if errorlevel 1 (
    echo [ERROR] Could not copy the built binary.
    if not "%OBS_NO_PAUSE%"=="1" pause
    exit /b 1
)
echo [OK] Built: %ROOT%bin\obsucvim.exe
if not "%OBS_NO_PAUSE%"=="1" pause
