#!/usr/bin/env python3
"""Self-check for the Obsucvim deployment (works on any Windows x64 box).

Exit 0 = every check passed.

Environment (optional):
    LUAU             path to luau.exe; if set, the generated file is executed
    RUST_TOOLCHAIN   toolchain root; if absent, rebuild checks are skipped
"""
import os
import subprocess
import sys
import tempfile

BASE = os.path.dirname(os.path.abspath(__file__))
TC = os.environ.get("RUST_TOOLCHAIN", r"C:\Users\15268\.rust-1.99.1")
LUAU = os.environ.get(
    "LUAU", r"D:\lura\vendor\luraph-deobf\Deobfuscator\deobf\bin\luau.exe"
)

fails = []


def check(name, cond, detail=""):
    print(("PASS " if cond else "FAIL ") + name + (("  " + str(detail)) if detail and not cond else ""))
    if not cond:
        fails.append(name)


def skip(name, why):
    print("SKIP " + name + "  (" + why + ")")


# 1. files
for rel, min_size in [
    (r"bin\obsucvim.exe", 1000000),
    ("obfuscate.bat", 1000),
    ("setup.bat", 800),
    ("README-DEPLOY.md", 800),
    (r"obsucvim\Cargo.toml", 100),
]:
    p = os.path.join(BASE, rel)
    check("exists:" + rel, os.path.isfile(p) and os.path.getsize(p) >= min_size,
          os.path.getsize(p) if os.path.isfile(p) else -1)

# 2. toolchain (optional: runtime-only deployment does not need it)
have_tc = os.path.isfile(os.path.join(TC, "bin", "rustc.exe"))
if have_tc:
    check("toolchain:rustc", True)
    check("toolchain:cargo", os.path.isfile(os.path.join(TC, "bin", "cargo.exe")))
    check("toolchain:rust-lld", os.path.isfile(os.path.join(
        TC, "lib", "rustlib", "x86_64-pc-windows-gnu", "bin", "rust-lld.exe")))
    r = subprocess.run([os.path.join(TC, "bin", "rustc.exe"), "--version"],
                       capture_output=True, text=True, encoding="utf-8",
                       errors="replace", timeout=60)
    check("rustc:version", r.returncode == 0 and "1.99.1" in (r.stdout + r.stderr),
          (r.stdout + r.stderr)[:200])
else:
    skip("toolchain", "not installed (runtime-only is fine)")

# 3. binary runs
exe = os.path.join(BASE, "bin", "obsucvim.exe")
if os.path.isfile(exe):
    r = subprocess.run([exe, "--help"], capture_output=True, text=True,
                       encoding="utf-8", errors="replace", timeout=60)
    help_out = r.stdout + r.stderr
    check("exe:help_rc0", r.returncode == 0, r.returncode)
    check("exe:version_banner", "obsucvim 0.2.0" in help_out, help_out[:200])
    check("exe:has_bind_flag", "--bind-executor" in help_out and "--no-bind-executor" in help_out)

# 4. obfuscate.bat end-to-end
with tempfile.TemporaryDirectory() as td:
    src = os.path.join(td, "deploy_check.lua")
    with open(src, "w", encoding="utf-8", newline="\n") as f:
        f.write('print("deploy check ok")\n')
    out = os.path.join(td, "deploy_check.obf.lua")
    env = os.environ.copy()
    env["OBS_NO_PAUSE"] = "1"
    r = subprocess.run(
        ["cmd", "/c", os.path.join(BASE, "obfuscate.bat"), src],
        capture_output=True, text=True, encoding="utf-8",
        errors="replace", timeout=240, env=env,
    )
    check("bat:rc0", r.returncode == 0, (r.stdout + r.stderr)[:300])
    check("bat:output_exists", os.path.isfile(out), (r.stdout + r.stderr)[:300])
    if os.path.isfile(out):
        with open(out, encoding="utf-8") as f:
            first = f.readline().strip()
        check("bat:watermark", first == "-- This file was obfuscated by Obsucvim.", first)
        if os.path.isfile(LUAU):
            r2 = subprocess.run([LUAU, out], capture_output=True, text=True,
                                encoding="utf-8", errors="replace", timeout=120)
            check("bat:runs", r2.returncode == 0 and "deploy check ok" in (r2.stdout + r2.stderr),
                  (r2.stdout + r2.stderr)[:300])
        else:
            skip("bat:runs", "LUAU not set")

print()
if fails:
    print("FAILED %d check(s): %s" % (len(fails), ", ".join(fails)))
    sys.exit(1)
print("ALL CHECKS PASSED")
