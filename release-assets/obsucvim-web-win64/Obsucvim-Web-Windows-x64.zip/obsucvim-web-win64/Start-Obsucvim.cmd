@echo off
setlocal
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start-Obsucvim.ps1" %*
if errorlevel 1 (
  echo.
  echo Obsucvim stopped with an error. See the message above.
  pause
)
endlocal
